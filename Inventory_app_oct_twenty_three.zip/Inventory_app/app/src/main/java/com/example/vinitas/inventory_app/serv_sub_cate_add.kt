package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.vansuita.pickimage.bean.PickResult
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import com.vansuita.pickimage.listeners.IPickResult
import kotlinx.android.synthetic.main.serv_sub_cate_add.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URL
import java.util.*

class serv_sub_cate_add : AppCompatActivity(),IPickResult  {
    var db = FirebaseFirestore.getInstance()
    var TAG = "tag"
    data class s(var cat: String,var ur: String,var imgname: String,var disc: String)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.serv_sub_cate_add)


        net_status()

        sc_sub_add_back.setOnClickListener {
            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

        }

        //getting key from serv_cate_list activity
        val key = intent.getStringExtra("key")
        val sub = key+"_subcategory"
        val id = intent.getStringExtra("id")
        sc_sub_add_get_id.setText(id)
        if (sc_sub_add_get_id.text.isNotEmpty()){
            sc_sub_add_save.visibility=View.GONE
            sc_sub_add_edit.visibility=View.VISIBLE
            sc_sub_add_name.isEnabled=false
            sc_sub_add_disc.isEnabled=false
            sc_sub_add_card.isEnabled=false

            db.collection(sub).document(sc_sub_add_get_id.text.toString())
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result != null) {
                                Log.d("data", "is" + task.result.data)
                                sc_sub_add_name.setText(task.result.get("cat").toString())
                                sc_sub_add_disc.setText(task.result.get("disc").toString())
                                sc_sub_imgname.setText(task.result.get("imgname").toString())
                                sc_sub_imguri.setText(task.result.get("ur").toString())
                                sc_sub_add_cam_back.visibility=View.GONE
                                sc_sub_add_camera.visibility=View.GONE
                                val newurl = URL(task.result.get("ur").toString()).openStream()
                                println(newurl)
                                val img = BitmapFactory.decodeStream(newurl)
                                sc_sub_add_card.setImageBitmap(img)
                            } else {
                                Log.d("data", "is not here")
                            }
                        } else {
                            Log.d("task is not success", "full" + task.exception)
                        }
                    }
        }
        sc_sub_add_edit.setOnClickListener {
            sc_sub_add_save.visibility=View.VISIBLE
            sc_sub_add_edit.visibility=View.GONE
            sc_sub_add_name.isEnabled=true
            sc_sub_add_disc.isEnabled=true
            sc_sub_add_card.isEnabled=true

        }
        sc_sub_add_save.setOnClickListener {
            if (sc_sub_add_name.text.isNotEmpty() == true&& sc_sub_imguri.text.isNotEmpty()==true&&sc_sub_imgname.text.isNotEmpty()==true&&sc_sub_add_disc.text.isNotEmpty()==true) {
                if (sc_sub_add_get_id.text.isEmpty()) {

                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    val cate = sc_sub_add_name.text.toString()
                    val ur = sc_sub_imguri.text.toString()
                    val name = sc_sub_imgname.text.toString()
                    val disc = sc_sub_add_disc.text.toString()
                    val data = s(cat = cate, ur = ur, imgname = name, disc = disc)
                    //if ((did.text.toString()).isEmpty()) {
                    //progress.visibility = View.VISIBLE
                    sc_sub_add_save.isEnabled = false
                    println(data)
                    db.collection(sub)
                            .add(data)
                            .addOnSuccessListener { documentReference ->
                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                Toast.makeText(this, "Category saved", Toast.LENGTH_LONG).show()
                               pDialog.dismiss()
                                sc_sub_add_save.isEnabled = true
                                finish()
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                                Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                            }
                } else if (sc_sub_add_get_id.text.isNotEmpty()) {

                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    val cate = sc_sub_add_name.text.toString()
                    val ur = sc_sub_imguri.text.toString()
                    val name = sc_sub_imgname.text.toString()
                    val disc = sc_sub_add_disc.text.toString()
                    val data = s(cat = cate, ur = ur, imgname = name, disc = disc)
                    //if ((did.text.toString()).isEmpty()) {
                    //progress.visibility = View.VISIBLE
                    sc_sub_add_save.isEnabled = false
                    println(data)
                    db.collection(sub).document(sc_sub_add_get_id.text.toString())
                            .set(data)
                            .addOnSuccessListener {
                                Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                pDialog.dismiss()
                                finish()
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                            }
                }
            }else {
                Toast.makeText(this, "Nothing saved", Toast.LENGTH_LONG).show()
            }

        }
        sc_sub_add_camera.setOnClickListener {
            sc_sub_add_cam_back.visibility= View.GONE
            sc_sub_add_camera.visibility= View.GONE
            if (sc_sub_imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@serv_sub_cate_add)
            }else{
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val imagesRef = storageRef.child(sc_sub_imgname.text.toString())
                imagesRef.delete()
                        .addOnSuccessListener {
                            sc_sub_imgname.setText("")
                            sc_sub_imguri.setText("")
                            PickImageDialog.build(PickSetup()).show(this@serv_sub_cate_add)
                        }
            }
        }
        sc_sub_add_card.setOnClickListener {
            sc_sub_add_cam_back.visibility= View.GONE
            sc_sub_add_camera.visibility= View.GONE
            if (sc_sub_imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@serv_sub_cate_add)
            }else{
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val imagesRef = storageRef.child(sc_sub_imgname.text.toString())
                imagesRef.delete()
                        .addOnSuccessListener {
                            sc_sub_imgname.setText("")
                            sc_sub_imguri.setText("")
                            PickImageDialog.build(PickSetup()).show(this@serv_sub_cate_add)
                        }
            }
        }
    }
    override fun onPickResult(r: PickResult) {

        if (r.error == null) {
            sc_sub_add_card.setImageBitmap(r.bitmap)
            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.getReference()
            val generator = Random()
            var n = 1000
            n = generator.nextInt(n)
            val imname = "ourimages-$n.jpg"
            val imagesRef = storageRef.child(imname)
            sc_sub_add_card.isDrawingCacheEnabled = true
            sc_sub_add_card.buildDrawingCache()
            val bitmap = sc_sub_add_card.drawingCache
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)

            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            sc_sub_add_cam_back.visibility= View.GONE
            val data = baos.toByteArray()
            val uploadTask = imagesRef.putBytes(data)
            uploadTask.addOnFailureListener(OnFailureListener {}).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                pDialog.dismiss()
                val ur = taskSnapshot.downloadUrl
                sc_sub_imguri.text = ur.toString()
                sc_sub_imgname.text = imname
                Toast.makeText(applicationContext, "URL :" + Uri.PARCELABLE_WRITE_RETURN_VALUE, Toast.LENGTH_SHORT).show()
                val localFile: File = File.createTempFile("images21", "jpg")
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                val downloadUrl = taskSnapshot.downloadUrl

            })
            uploadTask.addOnProgressListener { taskSnapshot -> }.addOnPausedListener { println("Upload is paused") }
            //Image path
            r.getPath();
        } else {
            //Handle possible errors
            //TODO: do what you have to do with r.getError();
            Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
        }
        // Reference to an image file in Firebase Storage


    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}