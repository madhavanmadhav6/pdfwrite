package com.example.vinitas.inventory_app

import android.Manifest
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.applovin.sdk.AppLovinSdk
import com.example.vinitas.Makeup_items.Main_makeup
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*
import java.util.ArrayList

class MainActivity : AppCompatActivity() {




    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }




    private var view = String()
    private var add = String()
    private var delete = String()
    private var edit = String()
    private var import = String()
    private var export = String()

    private var viewpro = String()
    private var addpro = String()
    private var deletepro = String()
    private var editpro = String()
    private var importpro = String()
    private var exportpro = String()
    private var stockin_hand = String()

    private var viewsupp = String()
    private var addsupp = String()
    private var deletesupp = String()
    private var editsupp = String()
    private var importsupp = String()
    private var exportsupp = String()


    private var viewtrans = String()
    private var addtrans = String()
    private var deletetrans = String()
    private var edittrans = String()
    private var transfertrans = String()
    private var exporttrans = String()
    private var sendtrans = String()

    private var viewtransano = String()
    private var addtransano = String()
    private var deletetransano = String()
    private var edittransano = String()
    private var transfertransano = String()
    private var exporttransano = String()
    private var sendtransano = String()

    private var viewrec = String()
    private var addrec = String()
    private var deleterec = String()
    private var editrec = String()
    private var transferrec = String()
    private var exportrec = String()
    private var sendstrec = String()

    //Purchase request
    private var viewpurreq = String()
    private var addpurreq = String()
    private var deletepurreq = String()
    private var editpurreq = String()
    private var transferpurreq = String()
    private var exportpurreq = String()

    //Purchase Order
    private var viewpurord = String()
    private var addpurord = String()
    private var deletepurord = String()
    private var editpurord = String()
    private var transferpurord = String()
    private var exportpurord = String()
    private var sendpurpo = String()

    //Supplier Invoice
    private var viewsuppin = String()
    private var addsuppin = String()
    private var deletesuppin = String()
    private var editsuppin = String()
    private var transfersuppin = String()
    private var exportsuppin = String()

    private var viewstklvls = String()

    var user= HashMap<String,String>()

    private var firstTimeprod: Boolean? = null

    var service_access:SessionManagement?=null
var empkey= String()
    var mids = String()
    internal var nameArray = arrayOf("Octopus", "Pig", "Sheep", "Rabbit", "Snake", "Spider")
    internal var infoArray = arrayOf("8 tentacled monster", "Delicious in rolls", "Great for jumpers", "Nice in a stew", "Great for shoes", "Scary.")
    internal var imageArray = arrayOf(R.drawable.ic_services, R.drawable.ic_products, R.drawable.ic_purchasing, R.drawable.ic_suppliers, R.drawable.ic_stock_transfers, R.drawable.ic_stock_level)
    protected lateinit var listView: GridView
    internal lateinit var sessions: SessionManagement
    var db = FirebaseFirestore.getInstance()




    //This function will be executed only once when the activity opens first time.
    private fun isFirstTimeProd(): Boolean {
        if (firstTimeprod == null) {
            val mPreferences = this.getSharedPreferences("first_times", Context.MODE_PRIVATE)
            firstTimeprod = mPreferences.getBoolean("firstTimes", true)
            if (firstTimeprod!!) {
                val editor = mPreferences.edit()
                editor.putBoolean("firstTimes", false)
                editor.commit()
/*
                val i = IntentFilter("android.net.conn.CONNECTIVITY_CHANGE")
                registerReceiver(NetworkChangeReceiver(), i)*/




            }

        }
        return firstTimeprod!!
    }








    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        net_status() //Check internet status

        isFirstTimeProd()



        //Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainActivity) > 0)
        {

        }
        else{

        }

        //Advertisement
     /*   AppLovinSdk.initializeSdk(this);*/

        //Camera permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERMISSION_REQUEST)
        }



        //Get key and branch name from session
        service_access = SessionManagement(this)
        empkey = service_access!!.userDetails[SessionManagement.employeeky].toString()


        user = service_access!!.userDetails

        // name
        val name = user[SessionManagement.KEY_NAME]
        mids = name.toString()

        val namebrs = user[SessionManagement.KEY_brnm]
        brnms.setText(namebrs)




        println("EMPLOYEEE KEY" + empkey)



       /* relative12dis=findViewById(R.id.relative12)
        relative13dis=findViewById(R.id.relative13)
        relative14dis=findViewById(R.id.relative14)
        relative15dis=findViewById(R.id.relative15)
        relative16dis=findViewById(R.id.relative16)
        relative17dis=findViewById(R.id.relative17)
        relative20dis=findViewById(R.id.relative20)*/




        //Define variable names for every imageviews in dashboard

        imageView12dis=findViewById(R.id.imageView12)
        imageView20dis=findViewById(R.id.imageView20)

        imageView13dis=findViewById(R.id.imageView13)
        imageView14dis=findViewById(R.id.imageView14)
        imageView15dis=findViewById(R.id.imageView15)
        imageView16dis=findViewById(R.id.imageView16)
        imageView17dis=findViewById(R.id.imageView17)

        relativedis=findViewById(R.id.relative)
        textnin=findViewById(R.id.constraintLayout3)

        con=findViewById<ConstraintLayout>(R.id.maincont)
        addLogText(NetworkUtil.getConnectivityStatusString(this@MainActivity))




        try {


        } catch (e: Exception) {

        }

        println("ADD MAIN ACTIVITY" + addtrans)
        println("ANOTHER ADD MAIN ACTIVITY" + addtransano)
        println("PURCHASE REQUEST TRANSFER" + transferpurreq)

        //Another transfer with state


        println("VIEW FOR PRODUCT" + viewsupp)



        //Menu button click action
        userback.setOnClickListener({


            val popup = PopupMenu(this@MainActivity, userback)

            popup.menuInflater.inflate(R.menu.changestore, popup.menu)

            popup.setOnMenuItemClickListener { item ->
                //Toast.makeText(this@MainActivity, "Logged out from this store" + item.title, Toast.LENGTH_SHORT).show()

                if (item.title == "Change store") {

                    if(net_status()==true) {
                        val f = Intent(this@MainActivity, changestverifyact::class.java)
                        startActivity(f)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                        finish()
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }

                } else if (item.title == "Inventory Settings") {

                    if(net_status()==true) {
                        val f = Intent(this@MainActivity, Inventory_settings::class.java)


                        //Service


                        f.putExtra("mids", mids)

                        startActivity(f)
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()

                    }
                }

                true

            }

            popup.show()

        })

        sessions = SessionManagement(applicationContext)

        try {
            val p = intent.getStringExtra("bid")
            mids = p

            println("MAIN ACT ID OF BRANCH" + mids)

        } catch (e: Exception) {

        }

        /* val window = this.getWindow()
// clear FLAG_TRANSLUCENT_STATUS flag:
    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
// finally change the color
    window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.black))*/


      /*  listView = findViewById<GridView>(R.id.gridview) as GridView
        val whatever = InventoryAdapter(this, nameArray, infoArray, imageArray)
        listView.adapter = whatever*/

/*        listView.setOnItemClickListener { parent, vie, position, id ->*/
            // println(i)
            /*  if (i == 0) { //employees
                var intent = Intent(this, servicelistActivity::class.java)
                startActivity(intent)
            }*/


        //Service option click
        imageView12.setOnClickListener {

                getService(empkey)
                /*if (view == "true") {
                    var intent = Intent(this, servicelistActivity::class.java)
                    intent.putExtra("view", view)
                    intent.putExtra("add", add)
                    intent.putExtra("edit", edit)
                    intent.putExtra("delete", delete)
                    intent.putExtra("import", import)
                    intent.putExtra("export", export)
                    intent.putExtra("skey", mids)
                    intent.putExtra("frm_main", "main")
                    startActivity(intent)


                }
                else if (view == "false") {
                    popup("View")
                }*/
            }

        //Makeup option click
        imageView20.setOnClickListener {

            getMakeup(empkey)
            /*if (view == "true") {
                var intent = Intent(this, servicelistActivity::class.java)
                intent.putExtra("view", view)
                intent.putExtra("add", add)
                intent.putExtra("edit", edit)
                intent.putExtra("delete", delete)
                intent.putExtra("import", import)
                intent.putExtra("export", export)
                intent.putExtra("skey", mids)
                intent.putExtra("frm_main", "main")
                startActivity(intent)


            }
            else if (view == "false") {
                popup("View")
            }*/
        }

        //Product option click

        imageView13.setOnClickListener {

                getProduct(empkey)
            }



        //Purchasing option click

        imageView16.setOnClickListener{

                //stock transfer
try {
    println("EMP ID" + empkey)
    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
    pDialog.setTitleText("Loading...")
    pDialog.setCancelable(false);
    pDialog.show();
    //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);

    val path = "emp_access/$empkey/inventory"
    val collection = ArrayList<String>()
    db.collection(path).document("purchase_request")
            .get()
            .addOnCompleteListener { task ->
                if (task.getResult().exists()) {
                    val dd = task.result.data
                    val viewpurreq = dd.get("view").toString()
                    val addpurreq = dd.get("add").toString()
                    val deletepurreq = dd.get("delete").toString()
                    val editpurreq = dd.get("edit").toString()
                    val transferpurreq = dd.get("transfer").toString()
                    val exportpurreq = dd.get("export").toString()

                    println("view : " + viewpurreq)
                    println("add : " + addpurreq)
                    println("delete : " + deletepurreq)
                    println("edit : " + editpurreq)
                    println("import : " + transferpurreq)
                    println("export : " + exportpurreq)

                    val session = SessionManagement(this)
                    session.putPurreq_Access(viewpurreq, addpurreq, deletepurreq, editpurreq, transferpurreq, exportpurreq)


                } else {
                    val session = SessionManagement(this)
                    session.putPurreq_Access("false", "false", "false", "false", "false", "false")

                }
            }
            .addOnSuccessListener {
                val path = "emp_access/$empkey/inventory"
                val collection1 = ArrayList<String>()
                db.collection(path).document("purchase_order")
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.getResult().exists()) {
                                val dd = task.result.data
                                val viewpurord = dd.get("view").toString()
                                val addpurord = dd.get("add").toString()
                                val deletepurord = dd.get("delete").toString()
                                val editpurord = dd.get("edit").toString()
                                val transferpurord = dd.get("transfer").toString()
                                val exportpurord = dd.get("export").toString()
                                val sendpurpo = dd.get("send_po").toString()

                                println("view : " + viewpurord)
                                println("add : " + addpurord)
                                println("delete : " + deletepurord)
                                println("edit : " + editpurord)
                                println("import : " + transferpurord)
                                println("export : " + exportpurord)

                                val session = SessionManagement(this)
                                session.putPurord_Access(viewpurord, addpurord, deletepurord, editpurord, transferpurord, exportpurord, sendpurpo)


                            } else {
                                val session = SessionManagement(this)
                                session.putPurord_Access("false", "false", "false", "false", "false", "false", "false")

                            }
                        }
                        .addOnSuccessListener {
                            val path = "emp_access/$empkey/inventory"
                            db.collection(path).document("supplier_invoice")
                                    .get()
                                    .addOnCompleteListener { task ->
                                        if (task.getResult().exists()) {
                                            val dd = task.result.data
                                            val viewsuppin = dd.get("view").toString()
                                            val addsuppin = dd.get("add").toString()
                                            val deletesuppin = dd.get("delete").toString()
                                            val editsuppin = dd.get("edit").toString()
                                            val transfersuppin = dd.get("transfer").toString()
                                            val exportsuppin = dd.get("export").toString()

                                            println("view : " + viewsuppin)
                                            println("add : " + addsuppin)
                                            println("delete : " + deletesuppin)
                                            println("edit : " + editsuppin)
                                            println("import : " + transfersuppin)
                                            println("export : " + exportsuppin)

                                            val session = SessionManagement(this)
                                            session.putSuppinvoice_Access(viewsuppin, addsuppin, deletesuppin, editsuppin, transfersuppin, exportsuppin)
                                            pDialog.dismiss()


                                        } else {
                                            val session = SessionManagement(this)
                                            session.putSuppinvoice_Access("false", "false", "false", "false", "false", "false")
                                            pDialog.dismiss()
                                        }
                                    }
                                    .addOnSuccessListener {
                                        //Service


                                        //Purchase Request
                                        val purrequest_access = SessionManagement(this)
                                        viewpurreq = purrequest_access.userDetails[SessionManagement.viewpreq].toString()
                                        addpurreq = purrequest_access.userDetails[SessionManagement.addpreq].toString()
                                        deletepurreq = purrequest_access.userDetails[SessionManagement.deletepreq].toString()
                                        editpurreq = purrequest_access.userDetails[SessionManagement.editpreq].toString()
                                        transferpurreq = purrequest_access.userDetails[SessionManagement.transferpreq].toString()
                                        exportpurreq = purrequest_access.userDetails[SessionManagement.exportpreq].toString()


                                        //Purchase Order
                                        val purord_access = SessionManagement(this)
                                        viewpurord = purord_access.userDetails[SessionManagement.viewpord].toString()
                                        addpurord = purord_access.userDetails[SessionManagement.addpord].toString()
                                        deletepurord = purord_access.userDetails[SessionManagement.deletepord].toString()
                                        editpurord = purord_access.userDetails[SessionManagement.editpord].toString()
                                        transferpurord = purord_access.userDetails[SessionManagement.transferpord].toString()
                                        exportpurord = purord_access.userDetails[SessionManagement.exportpord].toString()
                                        sendpurpo = purord_access.userDetails[SessionManagement.sendpord].toString()
                                        //Supplier Invoice
                                        val suppin_access = SessionManagement(this)
                                        viewsuppin = suppin_access.userDetails[SessionManagement.viewsupin].toString()
                                        addsuppin = suppin_access.userDetails[SessionManagement.addsupin].toString()
                                        deletesuppin = suppin_access.userDetails[SessionManagement.deletesupin].toString()
                                        editsuppin = suppin_access.userDetails[SessionManagement.editsupin].toString()
                                        transfersuppin = suppin_access.userDetails[SessionManagement.transfersupin].toString()
                                        exportsuppin = suppin_access.userDetails[SessionManagement.exportsupin].toString()
                                        //With state

                                        //Purchase request
                                        if ((viewpurreq == "true") || (viewpurord == "true") || (viewsuppin == "true")) {
                                            var intent = Intent(this, MainPurchasefirstActivity::class.java)
                                            intent.putExtra("viewpurreq", viewpurreq)
                                            intent.putExtra("addpurreq", addpurreq)
                                            intent.putExtra("deletepurreq", deletepurreq)
                                            intent.putExtra("editpurreq", editpurreq)
                                            intent.putExtra("transferpurreq", transferpurreq)
                                            intent.putExtra("exportpurreq", exportpurreq)
                                            intent.putExtra("viewpurord", viewpurord)
                                            intent.putExtra("addpurord", addpurord)
                                            intent.putExtra("deletepurord", deletepurord)
                                            intent.putExtra("editpurord", editpurord)
                                            intent.putExtra("transferpurord", transferpurord)
                                            intent.putExtra("exportpurord", exportpurord)
                                            intent.putExtra("sendpurord", exportpurord)
                                            intent.putExtra("viewsuppin", viewsuppin)
                                            intent.putExtra("addsuppin", addsuppin)
                                            intent.putExtra("deletesuppin", deletesuppin)
                                            intent.putExtra("editsuppin", editsuppin)
                                            intent.putExtra("transfersuppin", transfersuppin)
                                            intent.putExtra("exportsuppin", exportsuppin)


                                            intent.putExtra("skey", mids)
                                            startActivity(intent)
                                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                                            finish()
                                        } else if (viewpurreq == "false") {
                                            popup("View")
                                        }
                                    }

                        }
            }
}
catch (e:Exception){

}

        }







        //Supplier option click

        imageView14.setOnClickListener {


               getSupplier(empkey)

            }

        //Stock transfer  option click

        imageView15.setOnClickListener {

                //stock transfer
try {
    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
    pDialog.setTitleText("Loading...")
    pDialog.setCancelable(false);
    pDialog.show();
    val path = "emp_access/$empkey/inventory"
    val collection1 = ArrayList<String>()
    db.collection(path).document("transfer_within_state")
            .get()
            .addOnCompleteListener { task ->

                if (task.getResult().exists()) {
                    val dd = task.result.data
                    val viewtrans = dd.get("view").toString()
                    val addtrans = dd.get("add").toString()
                    val deletetrans = dd.get("delete").toString()
                    val edittrans = dd.get("edit").toString()
                    val transfertrans = dd.get("transfer").toString()
                    val exporttrans = dd.get("export").toString()
                    val sendtrans = dd.get("send_st").toString()
                    println("view : " + viewtrans)
                    println("add : " + addtrans)
                    println("delete : " + deletetrans)
                    println("edit : " + edittrans)
                    println("import : " + transfertrans)
                    println("export : " + exporttrans)

                    val session = SessionManagement(this)
                    session.putStatetransfer_Access(viewtrans, addtrans, deletetrans, edittrans, transfertrans, exporttrans, sendtrans)


                } else {
                    val session = SessionManagement(this)
                    session.putStatetransfer_Access("false", "false", "false", "false", "false", "false", "false")

                }
            }
            .addOnSuccessListener {



                val path = "emp_access/$empkey/inventory"
                val collection1 = ArrayList<String>()
                db.collection(path).document("receive_stock")
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.getResult().exists()) {
                                val dd = task.result.data
                                val viewrec = dd.get("view").toString()
                                val addrec = dd.get("add").toString()
                                val deleterec = dd.get("delete").toString()
                                val editrec = dd.get("edit").toString()
                                val transferrec = dd.get("transfer").toString()
                                val exportrec = dd.get("export").toString()
                                val sendstrec = dd.get("send_st").toString()
                                println("view : " + viewrec)
                                println("add : " + addrec)
                                println("delete : " + deleterec)
                                println("edit : " + editrec)
                                println("import : " + transferrec)
                                println("export : " + exportrec)
                                println("sendst : " + sendstrec)

                                val session = SessionManagement(this)
                                session.putReceive_Access(viewrec, addrec, deleterec, editrec, transferrec, exportrec, sendstrec)


                            } else {
                                val session = SessionManagement(this)
                                session.putReceive_Access("false", "false", "false", "false", "false", "false", "false")

                            }
                        }
                        .addOnSuccessListener {
                            val path = "emp_access/$empkey/inventory"
                            val collection1 = ArrayList<String>()
                            db.collection(path).document("transfer_another_state")
                                    .get()
                                    .addOnCompleteListener { task ->
                                        if (task.getResult().exists()) {
                                            val dd = task.result.data
                                            val viewtransano = dd.get("view").toString()
                                            val addtransano = dd.get("add").toString()
                                            val deletetransano = dd.get("delete").toString()
                                            val edittransano = dd.get("edit").toString()
                                            val transfertransano = dd.get("transfer").toString()
                                            val exporttransano = dd.get("export").toString()
                                            val sendtransano = dd.get("send_st").toString()
                                            println("view : " + viewtransano)
                                            println("add : " + addtransano)
                                            println("delete : " + deletetransano)
                                            println("edit : " + edittransano)
                                            println("import : " + transfertransano)
                                            println("export : " + exporttransano)

                                            val session = SessionManagement(this)
                                            session.putStatetransferano_Access(viewtransano, addtransano, deletetransano, edittransano, transfertransano, exporttransano, sendtransano)
                                            pDialog.dismiss()


                                        } else {
                                            val session = SessionManagement(this)
                                            session.putStatetransferano_Access("false", "false", "false", "false", "false", "false", "false")
                                            pDialog.dismiss()
                                        }
                                    }
                                    .addOnSuccessListener {
                                        //With state
                                        val state_access = SessionManagement(this)
                                        viewtrans = state_access.userDetails[SessionManagement.viewtransf].toString()
                                        addtrans = state_access.userDetails[SessionManagement.addtransf].toString()
                                        edittrans = state_access.userDetails[SessionManagement.edittransf].toString()
                                        deletetrans = state_access.userDetails[SessionManagement.deletetransf].toString()
                                        transfertrans = state_access.userDetails[SessionManagement.transfertransf].toString()
                                        exporttrans = state_access.userDetails[SessionManagement.exporttransf].toString()
                                        sendtrans = state_access.userDetails[SessionManagement.sendtransf].toString()


                                        //another state
                                        val stateanother_access = SessionManagement(this)
                                        viewtransano = stateanother_access.userDetails[SessionManagement.viewtransfano].toString()
                                        addtransano = stateanother_access.userDetails[SessionManagement.addtransfano].toString()
                                        edittransano = stateanother_access.userDetails[SessionManagement.edittransfano].toString()
                                        deletetransano = stateanother_access.userDetails[SessionManagement.deletetransfano].toString()
                                        transfertransano = stateanother_access.userDetails[SessionManagement.transfertransfano].toString()
                                        exporttransano = stateanother_access.userDetails[SessionManagement.exporttransfano].toString()
                                        sendtransano = stateanother_access.userDetails[SessionManagement.sendtransfano].toString()


                                        //Receive
                                        val receive_access = SessionManagement(this)

                                        viewrec = receive_access.userDetails[SessionManagement.viewreceive].toString()
                                        addrec = receive_access.userDetails[SessionManagement.addreceive].toString()
                                        deleterec = receive_access.userDetails[SessionManagement.deletereceive].toString()
                                        editrec = receive_access.userDetails[SessionManagement.editreceive].toString()
                                        transferrec = receive_access.userDetails[SessionManagement.transferreceive].toString()
                                        exportrec = receive_access.userDetails[SessionManagement.exportreceive].toString()
                                        sendstrec = receive_access.userDetails[SessionManagement.sendstreceive].toString()



                                        if ((viewtrans == "true") || (viewtransano == "true") || (viewrec == "true")) {

                                            var intent = Intent(this, StockTransferActivity::class.java)
                                            intent.putExtra("viewtrans", viewtrans)
                                            intent.putExtra("addtrans", addtrans)
                                            intent.putExtra("edittrans", edittrans)
                                            intent.putExtra("deletetrans", deletetrans)
                                            intent.putExtra("transfertrans", transfertrans)
                                            intent.putExtra("exporttrans", exporttrans)

                                            intent.putExtra("viewtransano", viewtransano)
                                            intent.putExtra("addtransano", addtransano)
                                            intent.putExtra("edittransano", edittransano)
                                            intent.putExtra("deletetransano", deletetransano)
                                            intent.putExtra("transfertransano", transfertransano)
                                            intent.putExtra("exporttransano", exporttransano)

                                            intent.putExtra("viewrec", viewrec)
                                            intent.putExtra("addrec", addrec)
                                            intent.putExtra("deleterec", deleterec)
                                            intent.putExtra("editrec", editrec)
                                            intent.putExtra("transferrec", transferrec)
                                            intent.putExtra("exportrec", exportrec)
                                            intent.putExtra("sendstrec", sendstrec)



                                            intent.putExtra("skey", mids)
                                            startActivity(intent)
                                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                                            finish()
                                        } else if (viewtrans == "false") {
                                            popup("View")
                                        }
                                    }
                        }
            }


}
catch (e:Exception){

}


            }



        //Stock levels  option click


        imageView17.setOnClickListener {
            try {
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Loading...")
                pDialog.setCancelable(false);
                pDialog.show();
                val path = "emp_access/$empkey/inventory"
                val collection = ArrayList<String>()
                db.collection(path).document("stock_level")
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.getResult().exists()) {
                                val dd = task.result.data
                                val viewstklvls = dd.get("view").toString()

                                println("view : " + viewstklvls)

                                val session = SessionManagement(this)
                                session.putStklvl_Access(viewstklvls)
                                pDialog.dismiss()

                            } else {
                                val session = SessionManagement(this)
                                session.putStklvl_Access("false")
                                pDialog.dismiss()
                            }
                        }
                        .addOnSuccessListener {
                            val stklvl_access = SessionManagement(this)
                            viewstklvls = stklvl_access.userDetails[SessionManagement.viewstklvl].toString()
                            if (viewstklvls == "true") {
                                var intent = Intent(this, stocklevelsActivity::class.java)
                                intent.putExtra("from_stock", "main")
                                intent.putExtra("viewstklvl", viewstklvls)
                                intent.putExtra("skey", mids)
                                startActivity(intent)
                                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                            } else if (viewstklvls == "false") {
                                popup("View")
                            }


                        }
            }
            catch (e:Exception){

            }
        }

        }



    //Create popup when the user could not access to click any options.
    fun popup(st: String) {
        val pop = AlertDialog.Builder(this)
        pop.create()
        val title = TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50, 20, 20, 20)
        title.textSize = 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    //On back navigation
    override fun onBackPressed() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }


    //Get service access controls and navigate to service list activity
    fun getService(id: String) {

        try {
            println("EMP ID" + id)
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false);
            pDialog.show();
            //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
            val path = "emp_access/$id/inventory"
            db.collection(path).document("service")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.getResult().exists()) {
                            val dd = task.result.data
                            val view = dd.get("view").toString()
                            val add = dd.get("add").toString()
                            val delete = dd.get("delete").toString()
                            val edit = dd.get("edit").toString()
                            val import = dd.get("import").toString()
                            val export = dd.get("export").toString()
                            println("view : " + view)
                            println("add : " + add)
                            println("delete : " + delete)
                            println("edit : " + edit)
                            println("import : " + import)
                            println("export : " + export)

                            val session = SessionManagement(this)
                            session.putService_Access(view, edit, add, delete, import, export)
                            pDialog.dismiss()
                        } else {
                            val session = SessionManagement(this)
                            println("EMP ID ELSE" + id)
                            session.putService_Access("false", "false", "false", "false", "false", "false")
                            pDialog.dismiss()
                        }
                    }
                    .addOnSuccessListener {
                        val sview = SessionManagement(this).userDetails[SessionManagement.sview].toString()
                        if (sview == "true") {
                            val intent = Intent(this, servicelistActivity::class.java)
                            intent.putExtra("frm_main", "main")
                            intent.putExtra("skey", mids)
                            startActivity(intent)
                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                        } else {
                            popup("View")
                        }
                    }
        }
        catch (e:Exception){

        }
    }

    //Get Makeup access controls and navigate to makeup list activity

    fun getMakeup(id: String) {

        try {
            println("EMP ID" + id)
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false);
            pDialog.show();
            //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
            val path = "emp_access/$id/inventory"
            db.collection(path).document("service")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.getResult().exists()) {
                            val dd = task.result.data
                            val view = dd.get("view").toString()
                            val add = dd.get("add").toString()
                            val delete = dd.get("delete").toString()
                            val edit = dd.get("edit").toString()
                            val import = dd.get("import").toString()
                            val export = dd.get("export").toString()
                            println("view : " + view)
                            println("add : " + add)
                            println("delete : " + delete)
                            println("edit : " + edit)
                            println("import : " + import)
                            println("export : " + export)

                            val session = SessionManagement(this)
                            session.putService_Access(view, edit, add, delete, import, export)
                            pDialog.dismiss()
                        } else {
                            val session = SessionManagement(this)
                            println("EMP ID ELSE" + id)
                            session.putService_Access("false", "false", "false", "false", "false", "false")
                            pDialog.dismiss()
                        }
                    }
                    .addOnSuccessListener {
                        val sview = SessionManagement(this).userDetails[SessionManagement.sview].toString()
                        if (sview == "true") {
                            val intent = Intent(this, Main_makeup::class.java)
                            intent.putExtra("frm_main", "main")
                            intent.putExtra("skey", mids)
                            startActivity(intent)
                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                        } else {
                            popup("View")
                        }
                    }
        }
        catch (e:Exception){

        }
    }

    //Get Product access controls and navigate to Product list activity

    fun getProduct(id: String) {
        try {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false);
            pDialog.show();
            //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
            val path = "emp_access/$id/inventory"
            val collection = ArrayList<String>()
            db.collection(path).document("product")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.getResult().exists()) {
                            val dd = task.result.data
                            val viewpro = dd.get("view").toString()
                            val addpro = dd.get("add").toString()
                            val deletepro = dd.get("delete").toString()
                            val editpro = dd.get("edit").toString()
                            val importpro = dd.get("import").toString()
                            val exportpro = dd.get("export").toString()
                            val stockin_hand = dd.get("stockin_hand").toString()
                            println("view : " + viewpro)
                            println("add : " + addpro)
                            println("delete : " + deletepro)
                            println("edit : " + editpro)
                            println("import : " + importpro)
                            println("export : " + exportpro)
                            val session = SessionManagement(this)
                            session.putProduct_Access(viewpro, addpro, deletepro, editpro, importpro, exportpro, stockin_hand)
                            pDialog.dismiss()
                        } else {
                            val session = SessionManagement(this)
                            session.putProduct_Access("false", "false", "false", "false", "false", "false", "false")
                            pDialog.dismiss()
                        }
                    }
                    .addOnSuccessListener {
                        val pview = SessionManagement(this).userDetails[SessionManagement.pview].toString()
                        if (pview == "true") {
                            var intent = Intent(this, MainProductlistActivity::class.java)
                            intent.putExtra("frm_main", "main")
                            intent.putExtra("skey", mids)
                            startActivity(intent)
                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                        } else {
                            popup("View")
                        }
                    }
        }
        catch (e:Exception){

        }
    }




    //Get Supplier access controls and navigate to Supplier list activity

    fun getSupplier(id: String) {

        try {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false);
            pDialog.show();
            //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
            val path = "emp_access/$id/inventory"
            val collection = ArrayList<String>()
            db.collection(path).document("supplier")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.getResult().exists()) {
                            val dd = task.result.data
                            val viewsupp = dd.get("view").toString()
                            val addsupp = dd.get("add").toString()
                            val deletesupp = dd.get("delete").toString()
                            val editsupp = dd.get("edit").toString()
                            val importsupp = dd.get("import").toString()
                            val exportsupp = dd.get("export").toString()
                            println("view : " + viewsupp)
                            println("add : " + addsupp)
                            println("delete : " + deletesupp)
                            println("edit : " + editsupp)
                            println("import : " + importsupp)
                            println("export : " + exportsupp)
                            val session = SessionManagement(this)
                            session.putSupplier_Access(viewsupp, addsupp, deletesupp, editsupp, importsupp, exportsupp)
                            pDialog.dismiss()
                        } else {
                            val session = SessionManagement(this)
                            session.putSupplier_Access("false", "false", "false", "false", "false", "false")
                            pDialog.dismiss()
                        }
                    }
                    .addOnSuccessListener {
                        val supview = SessionManagement(this).userDetails[SessionManagement.suppview].toString()
                        if (supview == "true") {
                            var intent = Intent(this, SupplierListFirstMAin::class.java)
                            intent.putExtra("frm_main", "main")
                            intent.putExtra("skey", mids)
                            startActivity(intent)
                            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                        } else {
                            popup("View")
                        }
                    }
        }
        catch (e:Exception){

        }
    }

    //Get Purchase access controls and navigate to Purchase list activity

    fun getPurchase(id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);

        val path = "emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("purchase_request")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewpurreq = dd.get("view").toString()
                        val addpurreq = dd.get("add").toString()
                        val deletepurreq = dd.get("delete").toString()
                        val editpurreq = dd.get("edit").toString()
                        val transferpurreq = dd.get("transfer").toString()
                        val exportpurreq = dd.get("export").toString()

                        println("view : " + viewpurreq)
                        println("add : " + addpurreq)
                        println("delete : " + deletepurreq)
                        println("edit : " + editpurreq)
                        println("import : " + transferpurreq)
                        println("export : " + exportpurreq)

                        val session = SessionManagement(this)
                        session.putPurreq_Access(viewpurreq, addpurreq, deletepurreq, editpurreq, transferpurreq, exportpurreq)
                        session.putPurreq_Access(viewpurreq, addpurreq, deletepurreq, editpurreq, transferpurreq, exportpurreq)
                        pDialog.dismiss()


                    } else {
                        val session = SessionManagement(this)
                        session.putPurreq_Access("false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }

                }
    }

    fun getPurchaseOrd(id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        val path = "emp_access/$id/inventory"
        val collection1 = ArrayList<String>()
        db.collection(path).document("purchase_order")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewpurord = dd.get("view").toString()
                        val addpurord = dd.get("add").toString()
                        val deletepurord = dd.get("delete").toString()
                        val editpurord = dd.get("edit").toString()
                        val transferpurord = dd.get("transfer").toString()
                        val exportpurord = dd.get("export").toString()
                        val sendpurpo = dd.get("send_po").toString()

                        println("view : " + viewpurord)
                        println("add : " + addpurord)
                        println("delete : " + deletepurord)
                        println("edit : " + editpurord)
                        println("import : " + transferpurord)
                        println("export : " + exportpurord)

                        val session = SessionManagement(this)
                        session.putPurord_Access(viewpurord, addpurord, deletepurord, editpurord, transferpurord, exportpurord, sendpurpo)
                        pDialog.dismiss()


                    } else {
                        val session = SessionManagement(this)
                        session.putPurord_Access("false", "false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }

    fun getPurchasesuppin(id: String) {

        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        val path = "emp_access/$id/inventory"
        db.collection(path).document("supplier_invoice")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewsuppin = dd.get("view").toString()
                        val addsuppin = dd.get("add").toString()
                        val deletesuppin = dd.get("delete").toString()
                        val editsuppin = dd.get("edit").toString()
                        val transfersuppin = dd.get("transfer").toString()
                        val exportsuppin = dd.get("export").toString()

                        println("view : " + viewsuppin)
                        println("add : " + addsuppin)
                        println("delete : " + deletesuppin)
                        println("edit : " + editsuppin)
                        println("import : " + transfersuppin)
                        println("export : " + exportsuppin)

                        val session = SessionManagement(this)
                        session.putSuppinvoice_Access(viewsuppin, addsuppin, deletesuppin, editsuppin, transfersuppin, exportsuppin)
                        pDialog.dismiss()


                    } else {
                        val session = SessionManagement(this)
                        session.putSuppinvoice_Access("false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }



    fun gettransstate(id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        val path = "emp_access/$id/inventory"
        val collection1 = ArrayList<String>()
        db.collection(path).document("transfer_within_state")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewtrans=dd.get("view").toString()
                        val addtrans=dd.get("add").toString()
                        val deletetrans=dd.get("delete").toString()
                        val edittrans=dd.get("edit").toString()
                        val transfertrans=dd.get("transfer").toString()
                        val exporttrans=dd.get("export").toString()
                        val sendtrans=dd.get("send_st").toString()
                        println("view : "+viewtrans)
                        println("add : "+addtrans)
                        println("delete : "+deletetrans)
                        println("edit : "+edittrans)
                        println("import : "+transfertrans)
                        println("export : "+exporttrans)

                        val session = SessionManagement(this)
                        session.putStatetransfer_Access(viewtrans, addtrans, deletetrans, edittrans, transfertrans, exporttrans, sendtrans)
                        pDialog.dismiss()


                    } else {
                        val session = SessionManagement(this)
                        session.putStatetransfer_Access("false", "false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }

    fun gettransanostate(id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        val path = "emp_access/$id/inventory"
        val collection1 = ArrayList<String>()
        db.collection(path).document("transfer_another_state")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewtransano=dd.get("view").toString()
                        val addtransano=dd.get("add").toString()
                        val deletetransano=dd.get("delete").toString()
                        val edittransano=dd.get("edit").toString()
                        val transfertransano=dd.get("transfer").toString()
                        val exporttransano=dd.get("export").toString()
                        val sendtransano=dd.get("send_st").toString()
                        println("view : "+viewtransano)
                        println("add : "+addtransano)
                        println("delete : "+deletetransano)
                        println("edit : "+edittransano)
                        println("import : "+transfertransano)
                        println("export : "+exporttransano)

                        val session = SessionManagement(this)
                        session.putStatetransferano_Access(viewtransano, addtransano, deletetransano, edittransano, transfertransano, exporttransano, sendtransano)
                        pDialog.dismiss()


                    } else {
                        val session = SessionManagement(this)
                        session.putStatetransferano_Access("false", "false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }

    fun getreceive(id: String) {

    }


    fun getAccessstklvl(id:String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);

        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("stock_level")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        val viewstklvls=dd.get("view").toString()

                        println("view : "+viewstklvls)

                        val session = SessionManagement(this)
                        session.putStklvl_Access(viewstklvls)
                        pDialog.dismiss()

                    }
                    else{
                        val session = SessionManagement(this)
                        session.putStklvl_Access("false")
                        pDialog.dismiss()
                    }
                }
    }


    fun servputextra(id:String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val path = "emp_access/$id/inventory"
        db.collection(path).document("service")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val view = dd.get("view").toString()
                        val add = dd.get("add").toString()
                        val delete = dd.get("delete").toString()
                        val edit = dd.get("edit").toString()
                        val import = dd.get("import").toString()
                        val export = dd.get("export").toString()
                        println("view : " + view)
                        println("add : " + add)
                        println("delete : " + delete)
                        println("edit : " + edit)
                        println("import : " + import)
                        println("export : " + export)
                        val session = SessionManagement(this)
                        session.putService_Access(view, edit, add, delete, import, export)
                        pDialog.dismiss()
                    } else {
                        val session = SessionManagement(this)
                        session.putService_Access("false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }

    fun productputextra(id:String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val path = "emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("product")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewpro = dd.get("view").toString()
                        val addpro = dd.get("add").toString()
                        val deletepro = dd.get("delete").toString()
                        val editpro = dd.get("edit").toString()
                        val importpro = dd.get("import").toString()
                        val exportpro = dd.get("export").toString()
                        val stockin_hand = dd.get("stockin_hand").toString()
                        println("view : " + viewpro)
                        println("add : " + addpro)
                        println("delete : " + deletepro)
                        println("edit : " + editpro)
                        println("import : " + importpro)
                        println("export : " + exportpro)
                        val session = SessionManagement(this)
                        session.putProduct_Access(viewpro, addpro, deletepro, editpro, importpro, exportpro, stockin_hand)
                        pDialog.dismiss()
                    } else {
                        val session = SessionManagement(this)
                        session.putProduct_Access("false", "false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }


    fun supplierputextra(id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false);
        pDialog.show();
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val path = "emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("supplier")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()) {
                        val dd = task.result.data
                        val viewsupp = dd.get("view").toString()
                        val addsupp = dd.get("add").toString()
                        val deletesupp = dd.get("delete").toString()
                        val editsupp = dd.get("edit").toString()
                        val importsupp = dd.get("import").toString()
                        val exportsupp = dd.get("export").toString()
                        println("view : " + viewsupp)
                        println("add : " + addsupp)
                        println("delete : " + deletesupp)
                        println("edit : " + editsupp)
                        println("import : " + importsupp)
                        println("export : " + exportsupp)
                        val session = SessionManagement(this)
                        session.putSupplier_Access(viewsupp, addsupp, deletesupp, editsupp, importsupp, exportsupp)
                        pDialog.dismiss()
                    } else {
                        val session = SessionManagement(this)
                        session.putSupplier_Access("false", "false", "false", "false", "false", "false")
                        pDialog.dismiss()
                    }
                }
    }

    companion object {

        val PERMISSION_REQUEST = 200
    /*    private var relative12dis:RelativeLayout?=null
        private var relative13dis:RelativeLayout?=null
        private var relative14dis:RelativeLayout?=null
        private var relative15dis:RelativeLayout?=null
        private var relative16dis:RelativeLayout?=null
        private var relative17dis:RelativeLayout?=null

        private var relative20dis:RelativeLayout?=null*/

        private var relativedis:RelativeLayout?=null
        private var con:ConstraintLayout?=null
        private var textnin:ConstraintLayout?=null

        private var imageView20dis:ImageView?=null
        private var imageView12dis:ImageView?=null
        private var imageView13dis:ImageView?=null
        private var imageView14dis:ImageView?=null
        private var imageView15dis:ImageView?=null
        private var imageView16dis:ImageView?=null
        private var imageView17dis:ImageView?=null

        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){



                //Disable the whole page when the internet connection is off.

                /*relative12dis!!.visibility= View.VISIBLE
                relative13dis!!.visibility= View.VISIBLE
                relative14dis!!.visibility= View.VISIBLE
                relative15dis!!.visibility= View.VISIBLE
                relative16dis!!.visibility= View.VISIBLE
                relative17dis!!.visibility= View.VISIBLE
                relative20dis!!.visibility=View.VISIBLE
                relativedis!!.visibility= View.VISIBLE*/

                imageView12dis!!.isEnabled=false
                imageView13dis!!.isEnabled=false
                imageView14dis!!.isEnabled=false
                imageView15dis!!.isEnabled=false
                imageView16dis!!.isEnabled=false
                imageView17dis!!.isEnabled=false
                imageView20dis!!.isEnabled=false
                relativedis!!.visibility= View.VISIBLE

                textnin!!.visibility=View.VISIBLE
                for (i  in 0 until con!!.getChildCount()) {
                    val child = con!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {
                /*relative12dis!!.visibility= View.GONE
                relative13dis!!.visibility= View.GONE
                relative14dis!!.visibility= View.GONE
                relative15dis!!.visibility= View.GONE
                relative16dis!!.visibility= View.GONE
                relative17dis!!.visibility= View.GONE
                relative20dis!!.visibility=View.GONE

                relativedis!!.visibility= View.GONE*/


                //Enable the whole page when the internet connection is off.

                imageView12dis!!.isEnabled=true
                imageView13dis!!.isEnabled=true
                imageView14dis!!.isEnabled=true
                imageView15dis!!.isEnabled=true
                imageView16dis!!.isEnabled=true
                imageView17dis!!.isEnabled=true
                imageView20dis!!.isEnabled=true
                relativedis!!.visibility= View.GONE

                textnin!!.visibility=View.GONE

                for (i  in 0 until con!!.getChildCount()) {
                    val child = con!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }


    //Check internet status.
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}









