package com.example.vinitas.inventory_app

import android.app.AlertDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.graphics.Color
import kotlin.collections.ArrayList
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.firestore.EventListener
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.FirebaseFirestore

import kotlinx.android.synthetic.main.activity_request_add.*
import java.text.SimpleDateFormat
import java.util.*
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog

import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.QuerySnapshot
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter
import com.squareup.picasso.Picasso


import java.io.File
import java.io.FileOutputStream
import java.io.IOException


class RequestAddActivity : AppCompatActivity(){



    private val datePicker: DatePicker? = null
    private var calendar: Calendar? = null
    private var dateView: TextView? = null

    private var dateView1: TextView? = null

    private var year: Int = 0
    private var month: Int = 0
    private var day: Int = 0

    var frmver=String()
    var requestid=String()

    var supplieridfr=String()




    private val myDateListener = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day
        showDate(arg1, arg2 + 1, arg3)

    }



    private val myDateListener1 = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day

        showDate1(arg1, arg2 + 1, arg3)
    }

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }




    var incompstr = String()

    private var addpurord: String = ""
    private var editepurord: String = ""
    private var deletepurord: String = ""
    private var viewpurord: String = ""
    private var transferpurord: String = ""
    private var exportpurord: String = ""
    private var sendpurpo = String()


    private var addsuppin: String = ""
    private var editesuppin: String = ""
    private var deletesuppin: String = ""
    private var viewsuppin: String = ""
    private var transfersuppin: String = ""
    private var exportsuppin: String = ""


    private var addpurreq: String = ""
    private var editepurreq: String = ""
    private var deletepurreq: String = ""
    private var viewpurreq: String = ""
    private var transferpurreq: String = ""
    private var exportpurreq: String = ""




    var updatestatus= String()


    var reqnmcnt = 0
    var reqphcnt = 0
    var reqemailcnt = 0
    var reqesticnt = 0
    var reqsuppnmcnt = 0
    var reqsuppphcnt = 0
    var reqsuppaddress1cnt = 0
    var reqsuppaddress2cnt = 0
    var reqsuppaddress3cnt = 0
    var reqsuppgstcnt = 0
    var reqsuppcitycnt = 0
    var reqsuppstatecnt = 0


    var savecli=String()


    var TAG = "some"
    var pri = arrayListOf<String>()
    var prodnms = arrayListOf<String>()
    var orikys = String()
    var statuscheck = String()
    var imgslnks = String()
    var descriplistener = String()
    var listListener = String()
    var listListenergross = String()
    var deletelistener = String()
    var grosscheck = String()
    var forgross = String()

    var pritot = arrayOf<String>()

    var pdfFile = String()
    var db = FirebaseFirestore.getInstance()
    var mapsub = mutableMapOf<String, Any?>()

    data class k(
            var status: String
    )

    data class s(

            var req_id: String,
            var brid: String,
            var req_date: Any,
            var req_name: Any,
            var req_mail: Any,

            var prod_nms: Any,
            var req_estimated: Any,
            var supplier_name: Any,
            var supplier_address: Any,
            var supplier_addressLine1: Any,
            var supplier_addressLine2: Any,
            var supplier_GST: Any,
            var supplier_Phone: Any,
            var supplier_City: Any,
            var supplier_State: Any,
            var supplier_Key: Any,
            var imglinks: Any,

            var IGST_tot: Any,
            var CGST_tot: Any,
            var SGST_tot: Any,
            var Cess_tot: Any,


            var Gross_tot: Any


            /*    var stk_wg_vol: Any,
                var stk_name: String,
                var stk_mfr: String,

                var taxchk: Any*/
    )


    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_grosstotal: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_cgst: Any,
            var otherstk_sgst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_img: Any,
            var otherstk_received: Any,
            var stk_key: Any,
            var stk_prokey:Any

    )




    var pronamestr= String()
    var hsnstr = String()
    var manustr = String()
    var barcodestr= String()
    var quantitystr= String()
    var pricestr = String()
    var totstr = String()
    var grosstotstr=String()
    var cessstr = String()
    var keystr = String()
    var igststr = String()
    var cgststr = String()
    var sgststr = String()
    var igsttotstr= String()
    var cesstotstr= String()
    var tallystr = String()
    var receivedstr= String()
    var imagestr = String()
    var idofpro = String()




    var nameofbrnch = String()
    var locofbrnch = String()
    var keyofbrnch = String()
    var datestk = String()
    var smlistids = String()
    var descstk = String()
    var stkidstock = String()
    var ididdb = String()

    var downstatus = String()
    var igsttt = String()
    var cgsttt = String()
    var sgsttt = String()
    var cestt = String()
    var grosstt = String()
    var singrosstot = arrayOf<String>()

    var i = arrayListOf<String>()
    var getiddel = ArrayList<String>()
    var checkcount = arrayListOf<Int>()
    var ids = arrayOf<String>()

    var idsup = String()


    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var grosstotArray = arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var cgstArray = arrayListOf<String>()
    var sgstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var idproarray=arrayListOf<String>()

    var pronameArraydelglo = arrayListOf<String>()
    var hsnArraydelglo = arrayListOf<String>()
    var manufacturerArraydelglo = arrayListOf<String>()
    var barcodeArraydelglo = arrayListOf<String>()
    var quantityArraydelglo = arrayListOf<String>()
    var priceArraydelglo = arrayListOf<String>()
    var totArraydelglo = arrayListOf<String>()
    var grosstotArrayglo = arrayListOf<String>()
    var cessArraydelglo = arrayListOf<String>()
    var keyArraydelglo = arrayListOf<String>()
    var igstArraydelglo = arrayListOf<String>()
    var cgstArraydelglo = arrayListOf<String>()
    var sgstArraydelglo = arrayListOf<String>()
    var igsttotArraydelglo = arrayListOf<String>()
    var cesstotalArraydelglo = arrayListOf<String>()
    var tallyArraydelglo = arrayListOf<String>()
    var receivedArraydelglo = arrayListOf<String>()
    var imageArraydelglo = arrayListOf<String>()



    var status = String()


    var befnm= String()
    var request_datedup= String()
    var reqest_datedup= String()
    var supp_namedup= String()
    var supp_gstdup= String()
    var supp_addredup= String()

    var editclick= String()





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_add)

        net_status()   //Check internet status.


        //Date views

        calendar = Calendar.getInstance()
        year = calendar!!.get(Calendar.YEAR)
        month = calendar!!.get(Calendar.MONTH)
        day = calendar!!.get(Calendar.DAY_OF_MONTH)

        dateView =  findViewById<TextView>(R.id.textView47)
        dateView1=findViewById<TextView>(R.id.textView48)

        showDate(year, month + 1, day)
        showDate1(year, month + 1, day)

        var idsforup = ArrayList<Any>()


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@RequestAddActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view and other views when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relativeslayoutdis=findViewById(R.id.relativeslayout)
        consermaindis=findViewById(R.id.container)
        editdis=findViewById<ImageButton>(R.id.edit)
        req_iddis=findViewById(R.id.req_id)
        req_namedis=findViewById(R.id.req_name)
        request_datedis=findViewById(R.id.request_date)
        reqest_datedis=findViewById(R.id.reqest_date)
        supp_addredis=findViewById(R.id.supp_addre)
        supp_gstdis=findViewById(R.id.supp_gst)
        supp_namedis=findViewById(R.id.supp_name)
        compstatusdis=findViewById(R.id.compstatus)

        bottnav = findViewById(R.id.bottonNavBar)
        req_savedis=findViewById(R.id.req_save)
        mnudis=findViewById(R.id.mnu)
        userbackdis=findViewById(R.id.userback)
        addLogText(NetworkUtil.getConnectivityStatusString(this@RequestAddActivity))



      /*  reqest_date.setOnClickListener(View.OnClickListener {
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@RequestAddActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> reqest_date.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })*/

        val c = Calendar.getInstance()
        System.out.println("Current time =&gt; " + c.time)

        val df = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = df.format(c.time)






       /* request_date.setOnClickListener(View.OnClickListener {
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@RequestAddActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> request_date.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })*/




        edit.setOnClickListener {


            if (editepurreq == "true") {

                if (incompstr == "inside") {

                    mnu.visibility = View.VISIBLE

                    edit.visibility = View.GONE
                        editclick="clicked"

                    request_date.isEnabled = true
                    req_name.isEnabled = true
                    req_mail.isEnabled = true
                    reqest_date.isEnabled = true

                    supp_name.isEnabled = true
                    supp_phone.isEnabled = true
                    supp_gst.isEnabled = true
                    supp_city.isEnabled = true
                    supp_state.isEnabled = true
                    supp_addre.isEnabled = true
                    addre1.isEnabled = true
                    addre2.isEnabled = true


                    /*val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                    purreq_list.adapter = whatever
                    Helper.getListViewSize(purreq_list);*/
                    req_save.visibility = View.VISIBLE


                } else {

                    edit.visibility = View.GONE


                    request_date.isEnabled = true
                    req_name.isEnabled = true
                    req_mail.isEnabled = true
                    reqest_date.isEnabled = true

                    supp_name.isEnabled = true
                    supp_phone.isEnabled = true
                    supp_gst.isEnabled = true
                    supp_city.isEnabled = true
                    supp_state.isEnabled = true
                    supp_addre.isEnabled = true
                    addre1.isEnabled = true
                    addre2.isEnabled = true


                    /*
                    val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                    purreq_list.adapter = whatever

                    Helper.getListViewSize(purreq_list);*/
                    req_save.visibility = View.VISIBLE
                }


            } else if (editepurreq == "false") {
                popup("Edit")
            }

        }

        val bundle = intent.extras
        var frm = bundle!!.get("from_req").toString()





        if (frm == "from_suppadd") {


            //For new purchase request

            val n = intent.getStringExtra("name")
            val idl=intent.getStringExtra("id")
            val m = intent.getStringExtra("mobile")
            val o = intent.getStringExtra("city")
            val p = intent.getStringExtra("state")
            val q = intent.getStringExtra("gst")
            val r = intent.getStringExtra("addre1")
            val s = intent.getStringExtra("addre2")
            val t = intent.getStringExtra("addre3")
            val ps = intent.getStringExtra("oribrky")
            val imgs = intent.getStringExtra("imglink")
            imgslnks = imgs

            supplieridfr=idl



            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }





            try {

                Picasso.with(this)
                        .load(imgs)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }

            orikys = ps
            request_date.setText(formattedDate)
            try {
                supp_name.setText(n)
                comttname.setText(n)
            } catch (e: Exception) {
                if (supp_name.equals("")) {
                    Toast.makeText(applicationContext, "Invalid Supplier Name", Toast.LENGTH_SHORT).show()
                }
            }
            try {
                if((r.isNotEmpty())&&(s.isEmpty())&&(t.isEmpty())){
                    supp_addre.setText(r)

                }
                else if((r.isNotEmpty())&&(s.isNotEmpty())&&(t.isEmpty())) {
                    supp_addre.setText(r + ",$s")
                    addre1.setText(s)
                }
                else if((r.isEmpty())&&(s.isNotEmpty())&&(t.isNotEmpty())) {
                    supp_addre.setText(s + ",$t")
                    addre1.setText(s)
                }
                else if((r.isNotEmpty())&&(s.isNotEmpty())&&(t.isNotEmpty())) {
                    supp_addre.setText(r + ",$s , $t")
                    addre1.setText(s)
                }
                else if((r.isEmpty())&&(s.isEmpty())&&(t.isEmpty())){
                    supp_addre.setText("")

                }
            } catch (e: Exception) {
                if (supp_addre.equals("")) {

                }
            }
            try {
                addre2.setText(t)
            } catch (e: Exception) {

            }
            try {
                supp_gst.setText(q)
            } catch (e: Exception) {
                if (supp_gst.equals("")) {
                    Toast.makeText(applicationContext, "GST required", Toast.LENGTH_SHORT).show()
                }
            }
            try {
                supp_phone.setText(m)
                comphone.setText(m)
            } catch (e: Exception) {
                if (supp_phone.equals("")) {
                    Toast.makeText(applicationContext, "Mobile number required", Toast.LENGTH_SHORT).show()
                }
            }
            try {
                supp_city.setText(o)
            } catch (e: Exception) {
                if (supp_city.equals("")) {

                }
            }
            try {

                supp_state.setText(p)
            } catch (e: Exception) {
                if (supp_state.equals("")) {

                }
            }

            mnu.setOnClickListener({  //Menu contains two options 'Send this request' , 'Export as Pdf'.
                val popup = PopupMenu(this@RequestAddActivity, mnu)
                popup.menuInflater.inflate(R.menu.menu_supp, popup.menu)
                popup.setOnMenuItemClickListener { item ->



                    if(net_status()==true) {
                        if (item.title == "Export as pdf") {   //Clicked 'Export as Pdf'
                            if ((exportpurreq == "true")&&(net_status()==true)) {
                                pdfnav()
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else {
                                    popup("Export")
                                }
                            }
                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                val inflater = this.layoutInflater
                val dialog = alert.create()
                dialog.setView(inflater.inflate(R.layout.loginpop,null))
                dialog.show()
                val ok = dialog.findViewById<Button>(R.id.ok) as Button
                val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                ok.setOnClickListener {

                }*/
                        } else if (item.title == "Send this request") {  //Clicked 'Send this request'
                            if ((exportpurreq == "true")&&(net_status()==true)) {



                                //Make purchase request details to pdf document.

                                createandDisplayPdf(req_id.text.toString(), reqest_date.text.toString(), req_name.text.toString(), req_mail.text.toString(),
                                        reqest_date.text.toString(), supp_name.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                        supp_phone.text.toString(), supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                        cess_tot.text.toString(), gross_tot.text.toString())

                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)  //And send that pdf document using this 'ACTION_SEND'


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {

                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Send")

                                }
                            }
                        }
                    }
                    else if(net_status()==false)
                    {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                    }


                    return@setOnMenuItemClickListener true
                }
                popup.show()

            })


            try {

                grosscheck = gross_tot.text.toString()
            } catch (e: Exception) {

                grosscheck = gross_tot.text.toString()
            }


        }





        //Select products from bottom navigation bar and  navigate to 'RequestBottproActivity'

        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val suppadd: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.matching -> {

                }
                R.id.watchList -> {

                    println("STATUS VALUE RAD"+status)

                    val b = Intent(this@RequestAddActivity, RequestBottproActivity::class.java)
                    b.putExtra("from_req", "bott_req")
                    b.putExtra("pnm", pronameArray)
                    b.putExtra("pmanu", manufacturerArray)
                    b.putExtra("phsn", hsnArray)
                    b.putExtra("barcode", barcodeArray)
                    b.putExtra("price", priceArray)
                    b.putExtra("quan", quantityArray)
                    b.putExtra("tot", totArray)
                    b.putExtra("grosstot", grosstotArray)
                    b.putExtra("incompstr",incompstr)
                    b.putExtra("cessup", cessArray)
                    b.putExtra("igst", igstArray)
                    b.putExtra("cgst", cgstArray)
                    b.putExtra("sgst", sgstArray)
                    b.putExtra("igsttotal", igsttotArray)
                    b.putExtra("cesstotarray", cesstotalArray)
                    b.putExtra("tallyarray", tallyArray)
                    b.putExtra("receivedarray", receivedArray)
                    b.putExtra("idsofli", keyArray)
                    b.putExtra("smlistids", smlistids)
                    b.putExtra("image", imageArray)
                    b.putExtra("idpro", idproarray)
                    b.putExtra("reqid", req_id.text.toString())
                    b.putExtra("reqliid", listoids.text.toString())
                    b.putExtra("reprnms", names.text.toString())
                    b.putExtra("reqname", req_name.text.toString())
                    b.putExtra("reqdate", request_date.text.toString())
                    b.putExtra("reqest", reqest_date.text.toString())
                    b.putExtra("reqmail", req_mail.text.toString())

                    b.putExtra("request_datedup",request_datedup)
                    b.putExtra("reqest_datedup",reqest_datedup)
                    b.putExtra("supp_namedup",supp_namedup)
                    b.putExtra("supp_gstdup",supp_gstdup)
                    b.putExtra("supp_addredup",supp_addredup)
                    b.putExtra("befnm",befnm)
                    b.putExtra("supplieridfr",supplieridfr)



                    b.putExtra("edclick",editclick)

                    b.putExtra("updatestatus",updatestatus)

                    b.putExtra("supnm", supp_name.text.toString())
                    b.putExtra("supadd1", supp_addre.text.toString())
                    b.putExtra("supadd2", addre1.text.toString())
                    b.putExtra("supadd3", addre2.text.toString())
                    b.putExtra("supcity", supp_city.text.toString())
                    b.putExtra("supstate", supp_state.text.toString())
                    b.putExtra("supph", supp_phone.text.toString())
                    b.putExtra("supgst", supp_gst.text.toString())
                    b.putExtra("status", compstatus.text.toString())
                    b.putExtra("viewsuppin", viewsuppin)
                    b.putExtra("addsuppin", addsuppin)
                    b.putExtra("deletesuppin", deletesuppin)
                    b.putExtra("editsuppin", editesuppin)
                    b.putExtra("transfersuppin", transfersuppin)
                    b.putExtra("exportsuppin", exportsuppin)


                    b.putExtra("viewpurord", viewpurord)
                    b.putExtra("addpurord", addpurord)
                    b.putExtra("deletepurord", deletepurord)
                    b.putExtra("editpurord", editepurord)
                    b.putExtra("transferpurord", transferpurord)
                    b.putExtra("exportpurord", exportpurord)
                    b.putExtra("sendpurord", sendpurpo)




                    b.putExtra("viewpurreq", viewpurreq)
                    b.putExtra("addpurreq", addpurreq)
                    b.putExtra("deletepurreq", deletepurreq)
                    b.putExtra("editpurreq", editepurreq)
                    b.putExtra("transferpurreq", transferpurreq)
                    b.putExtra("exportpurreq", exportpurreq)


                    b.putExtra("imlinks", imgslnks)
                    b.putExtra("brky", orikys)
                    b.putExtra("groschk", gross_tot.text.toString())
                    b.putExtra("listlistnr",listListener)
                    b.putExtra("deletelistener",deletelistener)

                    b.putExtra("ids", ids)
                    startActivity(b)
                    overridePendingTransition(0,0)
                    finish()
                }
                else -> {
                }

            }


        })


        /*  val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever
            Helper.getListViewSize(purreq_list);*/
        /* try {
                var total = 0.0F
                var igsttot = 0.0F
                var cesstotals = 0.0F
                var b = 2
                for (i in 0 until priceArray.count()) {
                    var c = (priceArray[i])
                    var cy = (igsttotArray[i])
                    var cyz = (cesstotalArray[i])
                    var qyz = (quantityArray[i])

                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.text = DecimalFormat("##.##").format(igsttot)
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.text = DecimalFormat("##.##").format(tt)
                    sgst_tot.text = DecimalFormat("##.##").format(tt)

                    cess_tot.text = DecimalFormat("##.##").format(cesstotals)

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText(DecimalFormat("#.00").format(yy))
                    } catch (e: Exception) {
                        gross_tot.text = DecimalFormat("##.##").format(yy)
                    }
                    Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                    var d = pronameArray[i]
                    var t = d.removeSuffix("- ml")
                    prodnms.add(t)
                    names.setText((prodnms.toString()))
                    var u = names.text
                    var s = u.removePrefix("[")
                    var y = s.removeSuffix("]")
                    names.setText(y)



                    println("TRIMED LIST NAMESSS" + (prodnms))
                    if (grosscheck != gross_tot.text.toString()) {
                        listListener = "listadded"
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
            }*/

        ///LOCAL DELETE







/*
            val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever
            Helper.getListViewSize(purreq_list);*/


            ///LOCAL DELETE






        if (frm == "startlist_req") {
            try {
                pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialogs!!.setTitleText("Loading...")
                pDialogs!!.setCancelable(true)
                pDialogs!!.show();
            }
            catch (e:Exception){

            }






            req_id.isEnabled = false

            request_date.isEnabled = false
            req_name.isEnabled = false
            req_mail.isEnabled = false
            reqest_date.isEnabled = false

            supp_name.isEnabled = false
            supp_phone.isEnabled = false
            supp_gst.isEnabled = false
            supp_city.isEnabled = false
            supp_state.isEnabled = false
            supp_addre.isEnabled = false
            addre1.isEnabled = false
            addre2.isEnabled = false





            val name = intent.getStringExtra("spnm")
            val statuss = intent.getStringExtra("status")
            val phone = intent.getStringExtra("spph")
            val date = intent.getStringExtra("date")
            val dates = intent.getStringExtra("estidate")
            val Stockids = intent.getStringExtra("reqids")
            val listids = intent.getStringExtra("listids")
            val brids = intent.getStringExtra("brids")

            try {
                editclick = intent.getStringExtra("edclick")
            }
            catch (e:Exception){


            }


            try{
                frmver=intent.getStringExtra("frmver")
            }
            catch (e:Exception){

            }




            if(frmver.isEmpty()) {
                edit.visibility = View.VISIBLE
                req_save.visibility = View.INVISIBLE
                mnu.visibility=View.GONE
            }
            else if(frmver=="verify"){
                edit.visibility = View.GONE
                req_save.visibility = View.VISIBLE
                mnu.visibility=View.VISIBLE

            }


            try{

                supplieridfr=intent.getStringExtra("suppkey")
            }
            catch (e:Exception){

            }


            status = statuss

            println("ONTIME STATUS VIEW"+statuss)
            compstatus.setText(statuss)
            comttname.setText(name)
            comphone.setText(phone)
            req_id.setText(Stockids)
            listoids.setText(listids)
            request_date.setText(date)
            request_datedup=request_date.text.toString()

            reqest_date.setText(dates)
            reqest_datedup=reqest_date.text.toString()

            orikys = brids
            try {
                val imlinks = intent.getStringExtra("imlink")
                imgslnks = imlinks


                Picasso.with(this)
                        .load(imlinks)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }

            println("ONTIME COMP STATUS VIEW"+statuss)
            //Purchase request



            //Purchase request access

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order access

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice access

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            updatestatus="start_update_req"

            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result.exists()) {
                                if (task.result != null) {
                                    Log.d("data", "is" + task.result.data)
                                    req_name.setText(task.result.get("req_name").toString())

                                    req_mail.setText(task.result.get("req_mail").toString())

                                    supp_name.setText(name)
                                    supp_phone.setText(phone)
                                    supp_namedup=supp_name.text.toString()

                                    supp_addre.setText(task.result.get("supplier_address").toString())

                                    supp_addredup=supp_addre.text.toString()
                                    addre1.setText(task.result.get("supplier_addressLine1").toString())
                                    addre2.setText(task.result.get("supplier_addressLine2").toString())
                                    supp_gst.setText(task.result.get("supplier_GST").toString())
                                    supp_gstdup=supp_gst.text.toString()
                                    supp_city.setText(task.result.get("supplier_City").toString())
                                    supp_state.setText(task.result.get("supplier_State").toString())
                                    befnm=task.result.get("req_name").toString()
                                    try {
                                        compstatus.setText(task.result.get("status").toString())

                                        println("STATUS OF TEXTVIEW COMPLETE" + compstatus.text)
                                    } catch (e: Exception) {
                                        compstatus.setText(status)
                                        println("STATUS OF TEXTVIEW INCOMPLETE" + compstatus.text)
                                    }

                                    println("STATUSSSS FROM FIRESTORE" + statuscheck)


                                } else {
                                    Log.d("data", "is not here")
                                }
                            }
                            else {
                                Log.d("task is not success", "full" + task.exception)
                            }
                        }else {
                            Log.d("task is not success", "full" + task.exception)
                        }

                    }

            println("STATUSS FROM STARTLIST" + statuscheck)
            try {
                pDialogs!!.dismiss()
            }
            catch (e:Exception){

            }


            println("STATUS OF TEXTVIEW above if" + compstatus.text)


            if ((listoids.text.isNotEmpty()) && (compstatus.text == "Pending") && (transferpurreq == "true")) {
                incompstr = "inside"

                println("Inside Iffff" + statuscheck)

                if(frmver.isEmpty()) {
                    edit.visibility = View.VISIBLE
                    req_save.visibility = View.INVISIBLE
                    mnu.visibility=View.GONE
                }
                else if(frmver=="verify"){
                    edit.visibility = View.GONE
                    req_save.visibility = View.VISIBLE
                    mnu.visibility=View.VISIBLE

                }



                req_id.isEnabled = false

                request_date.isEnabled = false
                req_name.isEnabled = false
                req_mail.isEnabled = false
                reqest_date.isEnabled = false

                supp_name.isEnabled = false
                supp_phone.isEnabled = false
                supp_gst.isEnabled = false
                supp_city.isEnabled = false
                supp_state.isEnabled = false
                supp_addre.isEnabled = false
                addre1.isEnabled = false
                addre2.isEnabled = false
                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }



                mnu.setOnClickListener({  //Menu contains two options 'Approve' , 'Export as Pdf'.

                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.approve, popup.menu)
                    popup.setOnMenuItemClickListener { item ->


                        if(net_status()==true){


                     //------------------Navigate to 'RequestVerifyActivity' for accept purchase request and make purchase order----------------//


                        if (item.title == "Approve") {
                            val u = Intent(this@RequestAddActivity, RequestVerifyActivity::class.java)
                            u.putExtra("idd", listoids.text.toString())
                            u.putExtra("status", compstatus.text.toString())

                            u.putExtra("viewsuppin", viewsuppin)
                            u.putExtra("edclick",editclick)
                            u.putExtra("addsuppin", addsuppin)
                            u.putExtra("deletesuppin", deletesuppin)
                            u.putExtra("editsuppin", editesuppin)
                            u.putExtra("transfersuppin", transfersuppin)
                            u.putExtra("exportsuppin", exportsuppin)


                            u.putExtra("viewpurord", viewpurord)
                            u.putExtra("addpurord", addpurord)
                            u.putExtra("deletepurord", deletepurord)
                            u.putExtra("editpurord", editepurord)
                            u.putExtra("transferpurord", transferpurord)
                            u.putExtra("exportpurord", exportpurord)
                            u.putExtra("sendpurord", sendpurpo)




                            u.putExtra("viewpurreq", viewpurreq)
                            u.putExtra("addpurreq", addpurreq)
                            u.putExtra("deletepurreq", deletepurreq)
                            u.putExtra("editpurreq", editepurreq)
                            u.putExtra("transferpurreq", transferpurreq)
                            u.putExtra("exportpurreq", exportpurreq)






                            u.putExtra("spnm", comttname.text.toString())
                            u.putExtra("spph", comphone.text.toString())
                            u.putExtra("date", request_date.text.toString())
                            u.putExtra("estidate", reqest_date.text.toString())
                            u.putExtra("reqids", req_id.text.toString())
                            u.putExtra("listids", listoids.text.toString())
                            u.putExtra("status", compstatus.text.toString())
                            u.putExtra("supplieridfr",supplieridfr)


                            try {
                                u.putExtra("imlink", imgslnks)
                            } catch (e: Exception) {

                            }
                            u.putExtra("brid", orikys)
                            startActivity(u)
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                            finish()

                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
                        } else if (item.title == "Export as pdf") {    //Navigate  to pdf activity with details. (RequestActivityPdf)

                            if ((exportpurreq == "true")&&(net_status()==true)) {
                                pdfnav()
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Export")

                                }
                            }

                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
                        } else if (item.title == "Send this request") {     //Clicked 'Send this request'

                            if ((exportpurreq == "true")&&(net_status()==true)) {

                                //Make purchase request details to pdf document.

                                createandDisplayPdf(req_id.text.toString(), reqest_date.text.toString(), req_name.text.toString(), req_mail.text.toString(),
                                        reqest_date.text.toString(), supp_name.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                        supp_phone.text.toString(), supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                        cess_tot.text.toString(), gross_tot.text.toString())
                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)  //And send that pdf document using this 'ACTION_SEND'


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Send")

                                }
                            }
                        }
                        }
                        else if(net_status()==false){
                            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                        }
                        return@setOnMenuItemClickListener true
                    }
                    popup.show()

                })
            } else {
                mnu.visibility = View.VISIBLE

                edit.isEnabled = false
                edit.setImageResource(R.drawable.disable_edit)
                edit.visibility=View.GONE

                mnu.setOnClickListener({
                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.menu_supp, popup.menu)
                    popup.setOnMenuItemClickListener { item ->


                        if(net_status()==true){

                        if (item.title == "Export as pdf") {
                            if ((exportpurreq == "true")&&(net_status()==true)) {
                                pdfnav()
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Export")

                                }
                            }
                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                          val inflater = this.layoutInflater
                          val dialog = alert.create()
                          dialog.setView(inflater.inflate(R.layout.loginpop,null))
                          dialog.show()
                          val ok = dialog.findViewById<Button>(R.id.ok) as Button
                          val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                          ok.setOnClickListener {

                          }*/
                        } else if (item.title == "Send this request") {


                            if ((exportpurreq == "true")&&(net_status()==true)) {

                                createandDisplayPdf(req_id.text.toString(), request_date.text.toString(), req_name.text.toString(), req_mail.text.toString(),
                                        reqest_date.text.toString(), supp_name.text.toString(), supp_phone.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                        supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                        cess_tot.text.toString(), gross_tot.text.toString())
                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Send")

                                }
                            }
                        }
                        }
                        else if(net_status()==false){
                            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                        }
                        true
                    }
                    popup.show()
                })

            }














            db.collection("${orikys}_Purchase Request/${listoids.text}/Stock_products")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        if(value.isEmpty==false) {
                            for (document in value) {

                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                println(document.data)

                                var dt = document.data
                                var id = (document.id)
                                id = id
                                ids = ids.plusElement(id)
                                /*idsforup=ids*/
                                println("Heyyyyyyy" + Arrays.toString(ids))
                                println("HELLOOOOOOOOO" + id)
                                pronameArray.add(dt["stk_name"].toString())

                                manufacturerArray.add(dt["stk_mfr"].toString())
                                hsnArray.add(dt["stk_hsn"].toString())

                                quantityArray.add(dt["stk_received"].toString())

                                priceArray.add(dt["stk_price"].toString())
                                totArray.add(dt["stk_total"].toString())
                                grosstotArray.add(dt["stk_grosstotal"].toString())
                                barcodeArray.add(dt["stk_barcode"].toString())
                                cessArray.add(dt["stk_cess"].toString())
                                igstArray.add(dt["otherstk_igst"].toString())
                                cgstArray.add(dt["otherstk_cgst"].toString())
                                sgstArray.add(dt["otherstk_sgst"].toString())
                                igsttotArray.add(dt["otherstk_igsttotal"].toString())
                                cesstotalArray.add(dt["otherstk_cesstotal"].toString())
                                tallyArray.add(dt["otherstk_tally"].toString())
                                receivedArray.add(dt["otherstk_received"].toString())
                                try {
                                    var im = (dt["otherstk_img"].toString())
                                    if (im.isNotEmpty()) {

                                        imageArray.add(im)
                                    } else {
                                        imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                    }
                                } catch (e: Exception) {

                                }
                                keyArray.add(id)
                                idproarray.add(dt["stk_prokey"].toString())

                            }
                        }
                        else{

                        }
                       /* val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                        purreq_list.adapter = whatever
                        Helper.getListViewSize(purreq_list);*/
                        pur_save_prgrs.visibility = View.GONE



                        var kk=priceArray.count()

                        watchList.setText("Products ($kk)")

                        if(savecli!="clicked") {
                            try {
                                var total = 0.0F
                                var igsttot = 0.0F
                                var cesstotals = 0.0F
                                var b = 2
                                for (i in 0 until priceArray.count()) {
                                    var c = (priceArray[i])
                                    var cy = (igsttotArray[i])
                                    var cyz = (cesstotalArray[i])
                                    var qyz = (quantityArray[i])

                                    var cdec = c.toBigDecimal()
                                    var qyzdec = qyz.toBigDecimal()
                                    var totquanpri = (cdec * qyzdec)




                                    total = total.plus(totquanpri.toInt())

                                    igsttot = igsttot.plus(cy.toFloat())
                                    cesstotals = cesstotals.plus(cyz.toFloat())

                                    igst_tot.setText((String.format("%.2f",igsttot)))
                                    var l = igst_tot.text.toString()
                                    var ss = l.toBigDecimal()
                                    var tt = ss / b.toBigDecimal()
                                    cgst_tot.setText((String.format("%.2f",tt)))
                                    sgst_tot.setText((String.format("%.2f",tt)))

                                    cess_tot.setText((String.format("%.2f",cesstotals)))

                                    var f = cesstotals
                                    var g = igsttot

                                    var op = total
                                    var m = f.toFloat()
                                    var n = g.toFloat()

                                    var yy = m + n + op

                                    try {
                                        gross_tot.setText((String.format("%.2f",yy)))
                                        grosscheck = gross_tot.text.toString()
                                    } catch (e: Exception) {
                                        gross_tot.setText((String.format("%.2f",yy)))
                                        grosscheck = gross_tot.text.toString()
                                    }
                                    Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                    var d = pronameArray[i]
                                    var t = d.removeSuffix("- ml")
                                    prodnms.add(t)
                                    names.setText((prodnms.toString()))
                                    var u = names.text
                                    var s = u.removePrefix("[")
                                    var y = s.removeSuffix("]")
                                    names.setText(y)



                                    println("TRIMED LIST NAMESSS" + (prodnms))
                                }
                            } catch (e: Exception) {
                                Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                            }
                        }

                    })










        }

        else if (frm == "from_pdf") {

            mnu.visibility = View.VISIBLE






            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            /*   val dv=bundle!!.get("reprice") as Array<String>*/
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val hvgro = bundle!!.get("regrosstotal") as ArrayList<String>
            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val idv = bundle!!.get("recgst") as ArrayList<String>
            val isv = bundle!!.get("resgst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val immv = bundle!!.get("reimmg") as ArrayList<String>
            val rid = intent.getStringExtra("req_id")
            val rdt = intent.getStringExtra("req_date")
            val rnm = intent.getStringExtra("req_name")
            val imlins = intent.getStringExtra("images")
             val idpr = bundle!!.get("idpro") as ArrayList<String>


            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            try {
                var nmscomtt = intent.getStringExtra("nm")
                var addre = intent.getStringExtra("addre")
                comttname.setText(nmscomtt)
                comphone.setText(addre)
            }
            catch (e:Exception){

            }


            ids= bundle!!.get("ids") as Array<String>

            try {

                Picasso.with(this)
                        .load(imlins)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }






            //Purchase request access

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order access

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice access

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }



            try {
                val stat = intent.getStringExtra("status")
                status = stat
                compstatus.setText(status)
                val imgli = intent.getStringExtra("images")
                imgslnks = imgli
            } catch (e: Exception) {

            }

            val rmail = intent.getStringExtra("req_mail")
            val rids = intent.getStringExtra("req_liids")
            val rprnms = intent.getStringExtra("req_prnms")
            val resti = intent.getStringExtra("req_esti")




            val rsnm = intent.getStringExtra("req_supnm")
            val rsadd1 = intent.getStringExtra("req_supadd1")
            val rsadd2 = intent.getStringExtra("req_supadd2")
            val rsadd3 = intent.getStringExtra("req_supadd3")
            val rsgst = intent.getStringExtra("req_supgst")
            val rscity = intent.getStringExtra("req_supcity")
            val rsstate = intent.getStringExtra("req_supstate")
            val rssuph = intent.getStringExtra("req_supph")
            val oriky = intent.getStringExtra("orikys")

            editclick=intent.getStringExtra("edclick")


            updatestatus=intent.getStringExtra("updatestatus")

            val ig = intent.getStringExtra("igsttot")



            val cg = intent.getStringExtra("cgsttot")



            val sg = intent.getStringExtra("sgsttot")



            val cessg = intent.getStringExtra("cesstot")


            val gt = intent.getStringExtra("grosstot")



            igst_tot.setText((String.format("%.2f",ig.toFloat())))

            cgst_tot.setText((String.format("%.2f",cg.toFloat())))

            sgst_tot.setText((String.format("%.2f",sg.toFloat())))

            cess_tot.setText((String.format("%.2f",cessg.toFloat())))

            gross_tot.setText((String.format("%.2f",gt.toFloat())))


            val nm=intent.getStringExtra("names")
            names.setText(nm)


            pronameArray = (av)
            manufacturerArray = mv
            quantityArray = ev
            priceArray = hv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            grosstotArray = hvgro
            cessArray = gv
            keyArray = rekey
            igstArray = iv
            cgstArray = idv
            sgstArray = isv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            imageArray = immv

idproarray=idpr


            var kk=priceArray.count()

            watchList.setText("Products ($kk)")

            req_id.setText(rid.toString())

            listoids.setText(rids)
            names.setText(rprnms)
            request_date.setText(rdt)
            req_name.setText(rnm)


            req_mail.setText(rmail)
            reqest_date.setText(resti)

            supp_name.setText(rsnm.toString())
            supp_addre.setText(rsadd1)
            addre1.setText(rsadd2)
            addre2.setText(rsadd3)
            supp_gst.setText(rsgst)
            supp_city.setText(rscity)
            supp_state.setText(rsstate)
            supp_phone.setText(rssuph)
            orikys = oriky

          /*  val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever
            Helper.getListViewSize(purreq_list);*/
            /*try {
                var total = 0.0F
                var igsttot = 0.0F
                var cesstotals = 0.0F
                var b = 2
                for (i in 0 until priceArray.count()) {
                    var c = (priceArray[i])
                    var cy = (igsttotArray[i])
                    var cyz = (cesstotalArray[i])
                    var qyz = (quantityArray[i])

                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.text = DecimalFormat("##.##").format(igsttot)
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.text = DecimalFormat("##.##").format(tt)
                    sgst_tot.text = DecimalFormat("##.##").format(tt)

                    cess_tot.text = DecimalFormat("##.##").format(cesstotals)

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText(DecimalFormat("#.00").format(yy))
                    } catch (e: Exception) {
                        gross_tot.text = DecimalFormat("##.##").format(yy)
                    }
                    Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                    var d = pronameArray[i]
                    var t = d.removeSuffix("- ml")
                    prodnms.add(t)
                    names.setText((prodnms.toString()))
                    var u = names.text
                    var s = u.removePrefix("[")
                    var y = s.removeSuffix("]")
                    names.setText(y)



                    println("TRIMED LIST NAMESSS" + (prodnms))
                }
            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
            }*/


            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }

            if ((listoids.text.isNotEmpty()) && (compstatus.text == "Pending") && (transferpurreq == "true")) {

                println("Inside Iffff" + statuscheck)
                mnu.visibility = View.VISIBLE
                mnu.setOnClickListener({
                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.approve, popup.menu)
                    popup.setOnMenuItemClickListener { item ->

    if(net_status()==true) {

        if (item.title == "Approve") {
            val u = Intent(this@RequestAddActivity, RequestVerifyActivity::class.java)
            u.putExtra("idd", listoids.text.toString())
            u.putExtra("status", compstatus.text.toString())
            u.putExtra("viewsuppin", viewsuppin)
            u.putExtra("addsuppin", addsuppin)
            u.putExtra("deletesuppin", deletesuppin)
            u.putExtra("editsuppin", editesuppin)
            u.putExtra("transfersuppin", transfersuppin)
            u.putExtra("exportsuppin", exportsuppin)

            u.putExtra("edclick", editclick)


            u.putExtra("viewpurord", viewpurord)
            u.putExtra("addpurord", addpurord)
            u.putExtra("deletepurord", deletepurord)
            u.putExtra("editpurord", editepurord)
            u.putExtra("transferpurord", transferpurord)
            u.putExtra("exportpurord", exportpurord)
            u.putExtra("sendpurord", sendpurpo)




            u.putExtra("viewpurreq", viewpurreq)
            u.putExtra("addpurreq", addpurreq)
            u.putExtra("deletepurreq", deletepurreq)
            u.putExtra("editpurreq", editepurreq)
            u.putExtra("transferpurreq", transferpurreq)
            u.putExtra("exportpurreq", exportpurreq)


            u.putExtra("brid", orikys)
            startActivity(u)
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
            finish()

            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
        } else if (item.title == "Export as pdf") {

            if ((exportpurreq == "true")&&(net_status()==true)) {
                pdfnav()
            } else {
                if(net_status()==false){
                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                }
                else{
                    popup("Export")

                }
            }

            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
        } else if (item.title == "Send this request") {

            if ((exportpurreq == "true")&&(net_status()==true)) {
                var k = req_id.text.toString()
                var fs = k + "_request"

                var c = comttname.text.toString()
                var y = fs + ".pdf"
                println("GET URI FROM STORAGE" + y)
                val share = Intent(Intent.ACTION_SEND)
                share.type = "application/pdf"

                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                println()
                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                try {

                    sendMail(pdfFile)


                } catch (e: IOException) {
                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                }
            } else {
                if(net_status()==false){
                    Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                }
                else{
                    popup("Send")

                }
            }

        }
    }
                        else if(net_status()==false)
                    {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                    }
                        return@setOnMenuItemClickListener true
                    }
                    popup.show()

                })
            } else {
                mnu.visibility = View.VISIBLE

                req_save.visibility=View.GONE
                edit.visibility=View.VISIBLE



                req_id.isEnabled = false

                request_date.isEnabled = false
                req_name.isEnabled = false
                req_mail.isEnabled = false
                reqest_date.isEnabled = false

                supp_name.isEnabled = false
                supp_phone.isEnabled = false
                supp_gst.isEnabled = false
                supp_city.isEnabled = false
                supp_state.isEnabled = false
                supp_addre.isEnabled = false
                addre1.isEnabled = false
                addre2.isEnabled = false

                edit.isEnabled = false
                edit.setImageResource(R.drawable.disable_edit)
                edit.visibility=View.GONE
                mnu.setOnClickListener({
                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.menu_supp, popup.menu)
                    popup.setOnMenuItemClickListener { item ->


 if(net_status()==true) {
                        if (item.title == "Export as pdf") {
                            if (exportpurreq == "true") {
                                pdfnav()
                            } else {
                                popup("Export")
                            }
                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                          val inflater = this.layoutInflater
                          val dialog = alert.create()
                          dialog.setView(inflater.inflate(R.layout.loginpop,null))
                          dialog.show()
                          val ok = dialog.findViewById<Button>(R.id.ok) as Button
                          val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                          ok.setOnClickListener {

                          }*/
                        } else if (item.title == "Send this request") {
                            createandDisplayPdf(req_id.text.toString(), reqest_date.text.toString(), req_name.text.toString(),/* req_phone.text.toString()*/ req_mail.text.toString(),
                                    reqest_date.text.toString(), supp_name.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                    supp_phone.text.toString(), supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                    cess_tot.text.toString(), gross_tot.text.toString())

                            if (exportpurreq == "true") {
                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                popup("Send")
                            }
                        }
                        }
                        else if(net_status()==false)
                    {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                    }
                        true
                    }
                    popup.show()
                })

            }




        }


        //UPDATE Action


        else if (frm == "update_request") {
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MMM/yyyy")
            val formattedDate = df.format(c.time)
            request_date.setText(formattedDate)
            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            val dv = bundle!!.get("reprice") as ArrayList<String>
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val hvgro = bundle!!.get("regrosstotal") as ArrayList<String>
            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val idv = bundle!!.get("recgst") as ArrayList<String>
            val isv = bundle!!.get("resgst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val immv = bundle!!.get("reimmg") as ArrayList<String>
             val idpr = bundle!!.get("idpro") as ArrayList<String>


            ids=bundle!!.get("ids") as Array<String>

            val rid = intent.getStringExtra("req_id")
            val rdt = intent.getStringExtra("req_date")
            val rnm = intent.getStringExtra("req_name")

            var grocheck = intent.getStringExtra("groschk")
            grosscheck = grocheck

            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            println("grosscheck"+grosscheck)

            try{
                befnm=intent.getStringExtra("befnm")
                println("befnm names"+befnm)
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }


            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }

            try{
                deletelistener=intent.getStringExtra("deletelistener")

                if(deletelistener=="listdelete"){
                    listListenergross="listaddedgross"
                }

            }
            catch(e:Exception){

            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }



            try {
                val stat = intent.getStringExtra("status")
                status = stat

                val imgli = intent.getStringExtra("images")
                imgslnks = imgli


                Picasso.with(this)
                            .load(imgli)
                            .into(comp_toolimg)


            } catch (e: Exception) {

            }

            val rmail = intent.getStringExtra("req_mail")
            val rids = intent.getStringExtra("req_liids")
            val rprnms = intent.getStringExtra("req_prnms")
            val resti = intent.getStringExtra("req_esti")

            val rsnm = intent.getStringExtra("req_supnm")
            val rsadd1 = intent.getStringExtra("req_supadd1")
            val rsadd2 = intent.getStringExtra("req_supadd2")
            val rsadd3 = intent.getStringExtra("req_supadd3")
            val rsgst = intent.getStringExtra("req_supgst")
            val rscity = intent.getStringExtra("req_supcity")
            val rsstate = intent.getStringExtra("req_supstate")
            val rssuph = intent.getStringExtra("req_supph")
            val oriky = intent.getStringExtra("orikys")

            try {
                editclick = intent.getStringExtra("edclick")
            }
            catch (e:Exception){
            }


            try {
                incompstr = intent.getStringExtra("incompstr")
            }
            catch (e:Exception){

            }


            try {
                updatestatus = intent.getStringExtra("updatestatus")
            }
            catch (e:Exception){

            }










            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = dv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            grosstotArray = hvgro
            cessArray = gv
            keyArray = rekey
            igstArray = iv
            cgstArray = idv
            sgstArray = isv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            imageArray = immv
idproarray=idpr


            var za = priceArray
            var ya = quantityArray














            req_id.setText(rid.toString())

            listoids.setText(rids)
            names.setText(rprnms)
            request_date.setText(rdt)
            req_name.setText(rnm)

            req_mail.setText(rmail)
            reqest_date.setText(resti)

            supp_name.setText(rsnm.toString())
            supp_addre.setText(rsadd1)
            addre1.setText(rsadd2)
            addre2.setText(rsadd3)
            supp_gst.setText(rsgst)
            supp_city.setText(rscity)
            supp_state.setText(rsstate)
            supp_phone.setText(rssuph)
            orikys = oriky

            comttname.setText(rsnm.toString())
            comphone.setText(rssuph.toString())
            compstatus.setText(status)


            println("LISTOIDS USE"+listoids.text.toString())
            println("compstatus USE"+compstatus.text.toString())

            if ((listoids.text.isNotEmpty()) && (compstatus.text == "Pending") && (transferpurreq == "true")) {

                println("NOT INSIDE DISABLE APPROVE")
                if(editclick.isEmpty()){
                    edit.visibility=View.VISIBLE
                    req_save.visibility=View.GONE
                    mnu.visibility=View.GONE



                    req_id.isEnabled = false

                    request_date.isEnabled = false
                    req_name.isEnabled = false
                    req_mail.isEnabled = false
                    reqest_date.isEnabled = false

                    supp_name.isEnabled = false
                    supp_phone.isEnabled = false
                    supp_gst.isEnabled = false
                    supp_city.isEnabled = false
                    supp_state.isEnabled = false
                    supp_addre.isEnabled = false
                    addre1.isEnabled = false
                    addre2.isEnabled = false

                }
                else if(editclick=="clicked"){


                    if (incompstr == "inside") {


                        mnu.visibility = View.VISIBLE

                        edit.visibility = View.GONE
                        req_save.visibility = View.VISIBLE

                    }

                }


                mnu.setOnClickListener({
                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.approve, popup.menu)
                    popup.setOnMenuItemClickListener { item ->


 if(net_status()==true) {
                        if (item.title == "Approve") {
                            val u = Intent(this@RequestAddActivity, RequestVerifyActivity::class.java)
                            u.putExtra("idd", listoids.text.toString())
                            u.putExtra("status", compstatus.text.toString())

                            u.putExtra("viewsuppin", viewsuppin)
                            u.putExtra("edclick",editclick)
                            u.putExtra("addsuppin", addsuppin)
                            u.putExtra("deletesuppin", deletesuppin)
                            u.putExtra("editsuppin", editesuppin)
                            u.putExtra("transfersuppin", transfersuppin)
                            u.putExtra("exportsuppin", exportsuppin)


                            u.putExtra("viewpurord", viewpurord)
                            u.putExtra("addpurord", addpurord)
                            u.putExtra("deletepurord", deletepurord)
                            u.putExtra("editpurord", editepurord)
                            u.putExtra("transferpurord", transferpurord)
                            u.putExtra("exportpurord", exportpurord)
                            u.putExtra("sendpurord", sendpurpo)




                            u.putExtra("viewpurreq", viewpurreq)
                            u.putExtra("addpurreq", addpurreq)
                            u.putExtra("deletepurreq", deletepurreq)
                            u.putExtra("editpurreq", editepurreq)
                            u.putExtra("transferpurreq", transferpurreq)
                            u.putExtra("exportpurreq", exportpurreq)






                            u.putExtra("spnm", comttname.text.toString())
                            u.putExtra("spph", comphone.text.toString())
                            u.putExtra("date", request_date.text.toString())
                            u.putExtra("estidate", reqest_date.text.toString())
                            u.putExtra("reqids", req_id.text.toString())
                            u.putExtra("listids", listoids.text.toString())
                            u.putExtra("status", compstatus.text.toString())
                            u.putExtra("supplieridfr",supplieridfr)


                            try {
                                u.putExtra("imlink", imgslnks)
                            } catch (e: Exception) {

                            }
                            u.putExtra("brid", orikys)
                            startActivity(u)
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                            finish()

                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
                        } else if (item.title == "Export as pdf") {

                            if (exportpurreq == "true") {
                                pdfnav()
                            } else {
                                popup("Export")
                            }

                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                              val inflater = this.layoutInflater
                              val dialog = alert.create()
                              dialog.setView(inflater.inflate(R.layout.loginpop,null))
                              dialog.show()
                              val ok = dialog.findViewById<Button>(R.id.ok) as Button
                              val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                              ok.setOnClickListener {

                              }*/
                        } else if (item.title == "Send this request") {

                            if (exportpurreq == "true") {
                                createandDisplayPdf(req_id.text.toString(), reqest_date.text.toString(), req_name.text.toString(), req_mail.text.toString(),
                                        reqest_date.text.toString(), supp_name.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                        supp_phone.text.toString(), supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                        cess_tot.text.toString(), gross_tot.text.toString())
                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                popup("Send")
                            }
                        }
                        }
                        else if(net_status()==false)
                    {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                    }
                        return@setOnMenuItemClickListener true
                    }
                    popup.show()

                })
            }

            else if ((listoids.text.isNotEmpty()) && (compstatus.text == "Approved") && (transferpurreq == "true")) {


                println("INSIDE DISABLE APPROVE")
                mnu.visibility = View.VISIBLE

                req_save.visibility=View.GONE
                edit.visibility=View.VISIBLE



                req_id.isEnabled = false

                request_date.isEnabled = false
                req_name.isEnabled = false
                req_mail.isEnabled = false
                reqest_date.isEnabled = false

                supp_name.isEnabled = false
                supp_phone.isEnabled = false
                supp_gst.isEnabled = false
                supp_city.isEnabled = false
                supp_state.isEnabled = false
                supp_addre.isEnabled = false
                addre1.isEnabled = false
                addre2.isEnabled = false

                edit.isEnabled = false
                edit.setImageResource(R.drawable.disable_edit)
                edit.visibility=View.GONE
                mnu.setOnClickListener({
                    val popup = PopupMenu(this@RequestAddActivity, mnu)
                    popup.menuInflater.inflate(R.menu.menu_supp, popup.menu)
                    popup.setOnMenuItemClickListener { item ->
                         if(net_status()==true) {


                        if (item.title == "Export as pdf") {
                            if (exportpurreq == "true") {
                                pdfnav()
                            } else {
                                popup("Export")
                            }
                            /*val alert = AlertDialog.Builder(this@RequestAddActivity)
                          val inflater = this.layoutInflater
                          val dialog = alert.create()
                          dialog.setView(inflater.inflate(R.layout.loginpop,null))
                          dialog.show()
                          val ok = dialog.findViewById<Button>(R.id.ok) as Button
                          val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                          ok.setOnClickListener {

                          }*/
                        } else if (item.title == "Send this request") {


                            if (exportpurreq == "true") {

                                createandDisplayPdf(req_id.text.toString(), request_date.text.toString(), req_name.text.toString(), req_mail.text.toString(),
                                        reqest_date.text.toString(), supp_name.text.toString(), supp_phone.text.toString(), supp_addre.text.toString(), addre1.text.toString(), addre2.text.toString(),
                                        supp_gst.text.toString(), igst_tot.text.toString(), cgst_tot.text.toString(), sgst_tot.text.toString(),
                                        cess_tot.text.toString(), gross_tot.text.toString())
                                var k = req_id.text.toString()
                                var fs = k + "_request"

                                var c = comttname.text.toString()
                                var y = fs + ".pdf"
                                println("GET URI FROM STORAGE" + y)
                                val share = Intent(Intent.ACTION_SEND)
                                share.type = "application/pdf"

                                pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()



                                println()
                                val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                                try {

                                    sendMail(pdfFile)


                                } catch (e: IOException) {
                                    Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                popup("Send")
                            }
                        }
                        }
                        else if(net_status()==false)
                    {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                    }
                        true
                    }
                    popup.show()
                })
            }


            var kk=priceArray.count()

            watchList.setText("Products ($kk)")

            /*val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever
            Helper.getListViewSize(purreq_list);*/

            if(savecli!="clicked") {
                try {
                    var total = 0.0F
                    var igsttot = 0.0F
                    var cesstotals = 0.0F
                    var b = 2
                    for (i in 0 until priceArray.count()) {
                        var c = (priceArray[i])
                        var cy = (igsttotArray[i])
                        var cyz = (cesstotalArray[i])
                        var qyz = (quantityArray[i])

                        var cdec = c.toBigDecimal()
                        var qyzdec = qyz.toBigDecimal()
                        var totquanpri = (cdec * qyzdec)




                        total = total.plus(totquanpri.toInt())

                        igsttot = igsttot.plus(cy.toFloat())
                        cesstotals = cesstotals.plus(cyz.toFloat())

                        igst_tot.setText((String.format("%.2f",igsttot)))
                        var l = igst_tot.text.toString()
                        var ss = l.toBigDecimal()
                        var tt = ss / b.toBigDecimal()
                        cgst_tot.setText((String.format("%.2f",tt)))
                        sgst_tot.setText((String.format("%.2f",tt)))

                        cess_tot.setText((String.format("%.2f",cesstotals)))

                        var f = cesstotals
                        var g = igsttot

                        var op = total
                        var m = f.toFloat()
                        var n = g.toFloat()

                        var yy = m + n + op

                        try {
                            gross_tot.setText((String.format("%.2f",yy)))
                        } catch (e: Exception) {
                            gross_tot.setText((String.format("%.2f",yy)))
                        }
                        Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                        var d = pronameArray[i]
                        var t = d.removeSuffix("- ml")
                        prodnms.add(t)
                        names.setText((prodnms.toString()))
                        var u = names.text
                        var s = u.removePrefix("[")
                        var y = s.removeSuffix("]")
                        names.setText(y)



                        println("TRIMED LIST NAMESSS" + (prodnms))
                    }
                    if (grosscheck == "") {

                    } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                        listListenergross = "listaddedgross"
                    }
                } catch (e: Exception) {
                    Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                }

            }










        }


        //UPDATE


        supp_name.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errsnm.visibility = View.INVISIBLE
                errsnm.setError(null)

            /*    reqsuppnmcnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppnmcnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppnmcnt == 1)) {
                    listListener = "listadded"
                }*/


            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

            }

            override fun afterTextChanged(arg0: Editable) {


            }

        })


        supp_phone.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                /*errsph.visibility = View.INVISIBLE*/


             /*   reqsuppphcnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppphcnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppphcnt == 1)) {
                    listListener = "listadded"
                }*/


            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {


            }

        })


        supp_gst.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errsgt.visibility = View.INVISIBLE
                errsgt.setError(null)
             /*   reqsuppgstcnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppgstcnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppgstcnt == 1)) {
                    listListener = "listadded"
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {


            }

        })


        supp_addre.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errsad1.visibility = View.INVISIBLE
                errsad1.setError(null)
            /*    reqsuppaddress1cnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppaddress1cnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppaddress1cnt == 1)) {
                    listListener = "listadded"
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {


            }

        })
        addre1.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errsad1.visibility = View.INVISIBLE
             /*   reqsuppaddress2cnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppaddress2cnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppaddress2cnt == 1)) {
                    listListener = "listadded"
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {


            }

        })
        addre2.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errsad1.visibility = View.INVISIBLE
            /*    reqsuppaddress3cnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqsuppaddress3cnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqsuppaddress3cnt == 1)) {
                    listListener = "listadded"
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {


            }

        })




        req_name.addTextChangedListener(object : TextWatcher {



            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


                errrnm.visibility = View.INVISIBLE
                errrnm.setError(null)


               /* reqnmcnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqnmcnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqnmcnt == 1)) {
                    listListener = "listadded"
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {



            }

            override fun afterTextChanged(arg0: Editable) {

                println("BEFNM"+befnm)

             /*   if(befnm!=req_name.text.toString()) {
                    listListener = "listadded"
                }
                else if(befnm==req_name.text.toString()){

                }*/
            }



        })

        req_mail.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
/*
                reqemailcnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqemailcnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqemailcnt == 1)) {
                    listListener = "listadded"
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {



            }

        })






        reqest_date.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

             /*   reqesticnt += 1
                if ((listoids.text.toString().isNotEmpty()) && (reqesticnt >= 2)) {

                    listListener = "listadded"

                } else if ((listoids.text.toString().isEmpty()) && (reqesticnt == 1)) {
                    listListener = "listadded"
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {




            }

        })




                    //Save

        req_save.setOnClickListener { views ->

            savecli="clicked"
            if (net_status() == true) {


                if (supp_name.length() == 0) {
                    errsnm.visibility = View.VISIBLE
                    errsnm.setText("Required field*")


                    Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                }

                if (req_name.length() == 0) {
                    errrnm.visibility = View.VISIBLE
                    errrnm.setText("Required field*")


                    Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                }


                if (supp_phone.length() == 0) {





                }
                if (supp_gst.length() == 0) {
                    errsgt.visibility = View.VISIBLE
                    errsgt.setText("Required field*")


                    Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                }
                if ((supp_addre.length() !== 0)) {

                }
                if ((supp_addre.length() == 0)) {
                    errsad1.visibility = View.VISIBLE
                    errsad1.setText("Required field*")



                }


                if ((listoids.text == "") && (errrnm.visibility == View.INVISIBLE) && (errsnm.visibility == View.INVISIBLE)  && (errsgt.visibility == View.INVISIBLE) && (errsad1.visibility == View.INVISIBLE) && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {


try {
    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
    pDialogs!!.setTitleText("Saving...")
    pDialogs!!.setCancelable(false)
    pDialogs!!.show();
}
catch (e:Exception){

}


                    //------------------------Save action--------------------//

                    onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray,
                            totArray,grosstotArray, cessArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray,
                            receivedArray, keyArray, imageArray,idproarray)

                } else if ((listoids.text != "") && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {


                    if((befnm!=req_name.text.toString())||(request_datedup!=request_date.text.toString())||(reqest_datedup!=reqest_date.text.toString())||
                            (supp_namedup!=supp_name.text.toString())||(supp_gstdup!=supp_gst.text.toString())||(supp_addredup!=supp_addre.text.toString()))
                    {
                        listListener="listadded"
                        println("listListener inside"+listListener)
                    }
                    println("NAMES OF PRO" + names.text.toString())




                    var pronms = (names.text).toString()
                    var brid = orikys
                    var requestid = (req_id.text).toString()
                    var requestdate = (request_date.text).toString()
                    var requ_name = (req_name.text).toString()
                    var requ_mail = (req_mail.text).toString()
                    var requ_esti = (reqest_date.text).toString()

                    var supp_name = (supp_name.text).toString()
                    var supp_phone = (supp_phone.text).toString()
                    var supp_gst = (supp_gst.text).toString()
                    var supp_city = (supp_city.text).toString()
                    var supp_state = (supp_state.text).toString()
                    var supp_add1 = (supp_addre.text).toString()
                    var supp_add2 = (addre1.text).toString()
                    var supp_add3 = (addre2.text).toString()

                    var igsttot = (igst_tot.text).toString()
                    var cgsttot = (cgst_tot.text).toString()
                    var sgsttot = (sgst_tot.text).toString()
                    var cesstot = (cess_tot.text).toString()
                    var grosstot = (gross_tot.text).toString()
                    var img = imgslnks


                    if (compstatus.text == "Approved") {
                        val map = mutableMapOf<String, Any?>()
                        map.put("status", compstatus.text.toString())
                        mapsub = map

                    }
                    else if(compstatus.text == "Pending"){
                        val map = mutableMapOf<String, Any?>()
                        map.put("status", compstatus.text.toString())
                        mapsub = map
                    }


                    val data = s(req_id = requestid, brid = brid, req_date = requestdate, req_name = requ_name, req_mail = requ_mail,
                            req_estimated = requ_esti, supplier_name = supp_name, supplier_Phone = supp_phone, supplier_GST = supp_gst,
                            supplier_City = supp_city, supplier_State = supp_state, supplier_address = supp_add1, supplier_addressLine1 = supp_add2,
                            supplier_addressLine2 = supp_add3, IGST_tot = igsttot, CGST_tot = cgsttot, SGST_tot = sgsttot, Cess_tot = cesstot,
                            Gross_tot = grosstot, prod_nms = pronms, imglinks = img,supplier_Key = supplieridfr)
                    var db = FirebaseFirestore.getInstance()
                    println(Arrays.toString(ids))




                    //Update request-------------------//
                    if ((listoids.text != "") && (errrnm.visibility == View.INVISIBLE) && (errsnm.visibility == View.INVISIBLE)  && (errsgt.visibility == View.INVISIBLE) && (errsad1.visibility == View.INVISIBLE) && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {












                        var refid = listoids.text.toString()
                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                        var path = "${orikys}_Purchase Request/$refid/Stock_products"



                        if((listListener=="listadded")&&(listListenergross!="listaddedgross")) {


                            try {
                                pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                pDialogs!!.setTitleText("Saving...");
                                pDialogs!!.setCancelable(false);
                                pDialogs!!.show();
                            }
                            catch (e:Exception){

                            }

                            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                    .set(data)
                                    .addOnCompleteListener {
                                        db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                                .update(mapsub)
                                        try {
                                            pDialogs!!.dismiss()
                                        }
                                        catch (e:Exception){

                                        }


                                        val j = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
                                        j.putExtra("from_ver", "frmaddact")



                                        j.putExtra("viewsuppin", viewsuppin)
                                        j.putExtra("addsuppin", addsuppin)
                                        j.putExtra("deletesuppin", deletesuppin)
                                        j.putExtra("editsuppin", editesuppin)
                                        j.putExtra("transfersuppin", transfersuppin)
                                        j.putExtra("exportsuppin", exportsuppin)


                                        j.putExtra("viewpurord", viewpurord)
                                        j.putExtra("addpurord", addpurord)
                                        j.putExtra("deletepurord", deletepurord)
                                        j.putExtra("editpurord", editepurord)
                                        j.putExtra("transferpurord", transferpurord)
                                        j.putExtra("exportpurord", exportpurord)
                                        j.putExtra("sendpurord", sendpurpo)




                                        j.putExtra("viewpurreq", viewpurreq)
                                        j.putExtra("addpurreq", addpurreq)
                                        j.putExtra("deletepurreq", deletepurreq)
                                        j.putExtra("editpurreq", editepurreq)
                                        j.putExtra("transferpurreq", transferpurreq)
                                        j.putExtra("exportpurreq", exportpurreq)


                                        j.putExtra("oriky", orikys)
                                        startActivity(j)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                        finish()

                                    }
                        }

                        else if((listListener!="listadded")&&(listListenergross=="listaddedgross")) {

                            val map = mutableMapOf<String, Any?>()






                            map.put("prod_nms",names.text.toString())
                            map.put("igst_tot",igst_tot.text.toString())
                            map.put("cgst_tot",cgst_tot.text.toString())
                            map.put("sgst_tot",sgst_tot.text.toString())
                            map.put("cess_tot",cess_tot.text.toString())
                            map.put("gross_tot",gross_tot.text.toString())


                            try {
                                pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                pDialogs!!.setTitleText("Saving...");
                                pDialogs!!.setCancelable(false);
                                pDialogs!!.show();
                            }
                            catch (e:Exception){

                            }

                            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                    .update(map)
                                    .addOnSuccessListener {

                                    }


                            if (compstatus.text == "Approved") {
                                val map = mutableMapOf<String, Any?>()
                                map.put("status", compstatus.text.toString())
                                mapsub = map

                            }
                            else if(compstatus.text == "Pending"){
                                val map = mutableMapOf<String, Any?>()
                                map.put("status", compstatus.text.toString())
                                mapsub = map
                            }



                            for (m in 0 until ids.size) {
                                db.collection(path).document(ids[m].toString())
                                        .delete()
                                        .addOnCompleteListener {










                                        }
                            }

                            updatelist(path, pDialogs!!)
                        }
                        else if((listListener=="listadded")&&(listListenergross=="listaddedgross")) {
                            try {
                                pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                pDialogs!!.setTitleText("Saving...");
                                pDialogs!!.setCancelable(false);
                                pDialogs!!.show();
                            }
                            catch (e:Exception){

                            }

                            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                    .set(data)
                                    .addOnCompleteListener {
                                        db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                                .update(mapsub)
                                                .addOnSuccessListener {

                                                }

                                    }
                                    .addOnSuccessListener {
                                        for (m in 0 until ids.size) {
                                            db.collection(path).document(ids[m].toString())
                                                    .delete()
                                                    .addOnCompleteListener {







                                                    }
                                                    }
                                        updatelist(path, pDialogs!!)  //save the product lists to db
                                    }
                        }
                        else if((listListener!="listadded")&&(listListenergross!="listaddedgross")) {

                            Toast.makeText(applicationContext,"No changes happened for save",Toast.LENGTH_SHORT).show()

                        }




                    }
                } else {
                    if (transferpurreq == "false") {
                        popup("Purchase request")
                    }
                    else if(pronameArray.isEmpty()){  //Unable to make purchase if products doesnt exist
                        val dialog= android.support.v7.app.AlertDialog.Builder(this)
                        with(dialog){
                            setTitle("Unable to make purchase")
                            setMessage("Please select some products.")
                            setCancelable(false)
                            setPositiveButton("Ok"){dialog,button ->
                                dialog.dismiss()
                            }
                            val builders=dialog.create()
                            builders.show()
                        }
                    }
                }
            }
            else
            {
                Toast.makeText(applicationContext,"Please turn on you connection",Toast.LENGTH_SHORT).show()
            }
        }



userback.setOnClickListener {
  onBackPressed()
}








       /*purreq_list.setOnItemClickListener { parent, view, position, id ->

           val b = Intent(applicationContext, RequestUpdateActivity::class.java)
           b.putExtra("from_req", "update_req")
           b.putExtra("pnm", pronameArray)
           b.putExtra("pmanu", manufacturerArray)
           b.putExtra("phsn", hsnArray)
           b.putExtra("barcode", barcodeArray)
           b.putExtra("price", priceArray)
           b.putExtra("quan", quantityArray)
           b.putExtra("tot", totArray)
           b.putExtra("pos", position)
           b.putExtra("cessup", cessArray)
           b.putExtra("igst", igstArray)
           b.putExtra("cgst", cgstArray)
           b.putExtra("sgst", sgstArray)
           b.putExtra("igsttotal", igsttotArray)
           b.putExtra("cesstotarray", cesstotalArray)
           b.putExtra("tallyarray", tallyArray)
           b.putExtra("receivedarray", receivedArray)
           b.putExtra("idsofli",keyArray)
           b.putExtra("smlistids",smlistids)
           b.putExtra("image", imageArray)
           b.putExtra("reqid", req_id.text.toString())
           b.putExtra("reqliid", listoids.text.toString())
           b.putExtra("reprnms", names.text.toString())
           b.putExtra("reqname", req_name.text.toString())
           b.putExtra("reqdate", request_date.text.toString())
           b.putExtra("reqest", reqest_date.text.toString())
           b.putExtra("reqmail", req_mail.text.toString())
           b.putExtra("reqph", req_phone.text.toString())
           b.putExtra("supnm", supp_name.text.toString())
           b.putExtra("supadd1", supp_addre.text.toString())
           b.putExtra("supadd2", addre1.text.toString())
           b.putExtra("supadd3", addre2.text.toString())
           b.putExtra("supcity", supp_city.text.toString())
           b.putExtra("supstate", supp_state.text.toString())
           b.putExtra("supph", supp_phone.text.toString())
           b.putExtra("supgst", supp_gst.text.toString())
           b.putExtra("status", status)
           b.putExtra("viewpurreq", viewpurreq)
           b.putExtra("addpurreq", addpurreq)
           b.putExtra("deletepurreq", deletepurreq)
           b.putExtra("editpurreq", editepurreq)
           b.putExtra("transferpurreq", transferpurreq)
           b.putExtra("exportpurreq", exportpurreq)
           b.putExtra("imlinks", imgslnks)
           b.putExtra("brky", orikys)

            startActivity(b)
            finish()
        }*/






    }


    fun updatelist(path:String,dialog:SweetAlertDialog){  //save the product lists to db
        for (i in 0 until priceArray.size) {

            println("I VALUE  "+i)
            println("PRI SIZE  VALUE  "+priceArray.size)

            var stk_name = pronameArray[i]
            var stk_mfr = manufacturerArray[i]
            var stk_hsn = hsnArray[i]
            var stk_bcode = barcodeArray[i]
            var stk_quan = quantityArray[i]
            var stk_pri = priceArray[i]
            var stk_tot = totArray[i]
            var stk_grosstot = grosstotArray[i]
            var stk_cess = cessArray[i]
            var stk_igst = igstArray[i]
            var stk_cgst = cgstArray[i]
            var stk_sgst = sgstArray[i]
            var stk_igsttot = igsttotArray[i]
            var stk_cesstot = cesstotalArray[i]
            var stk_tally = tallyArray[i]
            var img_arr = imageArray[i]
            var stk_received = receivedArray[i]
            var stk_key = keyArray[i]
            var idpro_ar = idproarray[i]


            var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                    stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                    otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                    otherstk_tally = stk_tally, otherstk_received = stk_received, otherstk_img = img_arr,stk_prokey = idpro_ar)
            db.collection(path)
                    .add(d)
                    .addOnCompleteListener {

Toast.makeText(applicationContext,"Saved",Toast.LENGTH_SHORT).show()

                        /* val j = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
                         j.putExtra("from_ver", "frmaddact")



                         j.putExtra("viewsuppin", viewsuppin)
                         j.putExtra("addsuppin", addsuppin)
                         j.putExtra("deletesuppin", deletesuppin)
                         j.putExtra("editsuppin", editesuppin)
                         j.putExtra("transfersuppin", transfersuppin)
                         j.putExtra("exportsuppin", exportsuppin)


                         j.putExtra("viewpurord", viewpurord)
                         j.putExtra("addpurord", addpurord)
                         j.putExtra("deletepurord", deletepurord)
                         j.putExtra("editpurord", editepurord)
                         j.putExtra("transferpurord", transferpurord)
                         j.putExtra("exportpurord", exportpurord)
                         j.putExtra("sendpurord", sendpurpo)




                         j.putExtra("viewpurreq", viewpurreq)
                         j.putExtra("addpurreq", addpurreq)
                         j.putExtra("deletepurreq", deletepurreq)
                         j.putExtra("editpurreq", editepurreq)
                         j.putExtra("transferpurreq", transferpurreq)
                         j.putExtra("exportpurreq", exportpurreq)


                         j.putExtra("oriky", orikys)
                         startActivity(j)
                         overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                         finish()*/

                    }



        }
        Handler().postDelayed(Runnable {
            dialog.dismiss()
            val j = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
            j.putExtra("from_ver", "frmaddact")



            j.putExtra("viewsuppin", viewsuppin)
            j.putExtra("addsuppin", addsuppin)
            j.putExtra("deletesuppin", deletesuppin)
            j.putExtra("editsuppin", editesuppin)
            j.putExtra("transfersuppin", transfersuppin)
            j.putExtra("exportsuppin", exportsuppin)


            j.putExtra("viewpurord", viewpurord)
            j.putExtra("addpurord", addpurord)
            j.putExtra("deletepurord", deletepurord)
            j.putExtra("editpurord", editepurord)
            j.putExtra("transferpurord", transferpurord)
            j.putExtra("exportpurord", exportpurord)
            j.putExtra("sendpurord", sendpurpo)




            j.putExtra("viewpurreq", viewpurreq)
            j.putExtra("addpurreq", addpurreq)
            j.putExtra("deletepurreq", deletepurreq)
            j.putExtra("editpurreq", editepurreq)
            j.putExtra("transferpurreq", transferpurreq)
            j.putExtra("exportpurreq", exportpurreq)


            j.putExtra("oriky", orikys)
            startActivity(j)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
            finish()
        },2000)

    }


    override fun onBackPressed() {

        listListener=""
        println("listListener"+listListener)
        println("listListenergross"+listListenergross)

        println("befnm"+befnm)

        println("request_datedup"+request_datedup)

        println("reqest_datedup"+reqest_datedup)

        println("supp_namedup"+supp_namedup)
        println("supp_addredup"+supp_addredup)


        println("supp_gstdup"+supp_gstdup)


        if((befnm!=req_name.text.toString())||(request_datedup!=request_date.text.toString())||(reqest_datedup!=reqest_date.text.toString())||
                (supp_namedup!=supp_name.text.toString())||(supp_gstdup!=supp_gst.text.toString())||(supp_addredup!=supp_addre.text.toString()))
        {
            if(pronameArray.isNotEmpty()) {
                listListener="listadded"
            }
            else if(pronameArray.isEmpty()){
                listListener="listadded"

            }

            println("listListener inside"+listListener)
        }


        if((listListener=="listadded")||(deletelistener=="listdelete")||(listListenergross=="listaddedgross")){

            savepopup() ///Save alert popup

        }

        else if((listListener.isEmpty())&&(deletelistener.isEmpty())&&(listListenergross.isEmpty())){
            val o=Intent(this@RequestAddActivity,PurchaseRequestActivity::class.java)
            o.putExtra("from_ver","frmsave")

           o.putExtra("viewsuppin", viewsuppin)
           o.putExtra("addsuppin", addsuppin)
           o.putExtra("deletesuppin", deletesuppin)
           o.putExtra("editsuppin", editesuppin)
           o.putExtra("transfersuppin", transfersuppin)
           o.putExtra("exportsuppin", exportsuppin)


           o.putExtra("viewpurord", viewpurord)
           o.putExtra("addpurord", addpurord)
           o.putExtra("deletepurord", deletepurord)
           o.putExtra("editpurord", editepurord)
           o.putExtra("transferpurord", transferpurord)
           o.putExtra("exportpurord", exportpurord)
           o.putExtra("sendpurord", sendpurpo)




           o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)


            o.putExtra("brky",orikys)
            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }

    fun savepopup(){

        val builder = AlertDialog.Builder(this@RequestAddActivity)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->

                if (net_status() == true) {
                    savecli = "clicked"
                    if (supp_name.length() == 0) {
                        errsnm.visibility = View.VISIBLE
                        errsnm.setText("Required field*")


                        Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                    }

                    if (req_name.length() == 0) {
                        errrnm.visibility = View.VISIBLE
                        errrnm.setText("Required field*")


                        Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                    }


                    if (supp_phone.length() == 0) {





                    }
                    if (supp_gst.length() == 0) {
                        errsgt.visibility = View.VISIBLE
                        errsgt.setText("Required field*")


                        Toast.makeText(applicationContext, "please fill required fields", Toast.LENGTH_SHORT).show()


                    }
                    if ((supp_addre.length() !== 0)) {

                    }
                    if ((supp_addre.length() == 0)) {
                        errsad1.visibility = View.VISIBLE
                        errsad1.setText("Required field*")



                    }



                    if ((listoids.text == "") && (errrnm.visibility == View.INVISIBLE) && (errsnm.visibility == View.INVISIBLE) && (errsgt.visibility == View.INVISIBLE) && (errsad1.visibility == View.INVISIBLE) && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {
try {
    pDialogs = SweetAlertDialog(this@RequestAddActivity, SweetAlertDialog.PROGRESS_TYPE)
    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
    pDialogs!!.setTitleText("Saving...")
    pDialogs!!.setCancelable(false)
    pDialogs!!.show();
}
catch (e:Exception){

}

                            //Save new purchase request
                        onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray,
                                totArray,grosstotArray, cessArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray,
                                receivedArray, keyArray, imageArray, idproarray)

                    } else if ((listoids.text != "") && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {
                        try {
                            pDialogs = SweetAlertDialog(this@RequestAddActivity, SweetAlertDialog.PROGRESS_TYPE)
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialogs!!.setTitleText("Saving...")
                            pDialogs!!.setCancelable(false)
                            pDialogs!!.show();
                        }
                        catch (e:Exception){

                        }

                        var pronms = (names.text).toString()
                        var brid = orikys
                        var requestid = (req_id.text).toString()
                        var requestdate = (request_date.text).toString()
                        var requ_name = (req_name.text).toString()
                        var requ_mail = (req_mail.text).toString()
                        var requ_esti = (reqest_date.text).toString()

                        var supp_name = (supp_name.text).toString()
                        var supp_phone = (supp_phone.text).toString()
                        var supp_gst = (supp_gst.text).toString()
                        var supp_city = (supp_city.text).toString()
                        var supp_state = (supp_state.text).toString()
                        var supp_add1 = (supp_addre.text).toString()
                        var supp_add2 = (addre1.text).toString()
                        var supp_add3 = (addre2.text).toString()

                        var igsttot = (igst_tot.text).toString()
                        var cgsttot = (cgst_tot.text).toString()
                        var sgsttot = (sgst_tot.text).toString()
                        var cesstot = (cess_tot.text).toString()
                        var grosstot = (gross_tot.text).toString()
                        var img = imgslnks

                        if (compstatus.text == "Approved") {
                            val map = mutableMapOf<String, Any?>()
                            map.put("status", compstatus.text.toString())
                            mapsub = map

                        } else if (compstatus.text == "Pending") {
                            val map = mutableMapOf<String, Any?>()
                            map.put("status", compstatus.text.toString())
                            mapsub = map

                        }


                        val data = s(req_id = requestid, brid = brid, req_date = requestdate, req_name = requ_name,
                                req_mail = requ_mail, req_estimated = requ_esti, supplier_name = supp_name, supplier_Phone = supp_phone,
                                supplier_GST = supp_gst, supplier_City = supp_city, supplier_State = supp_state, supplier_address = supp_add1,
                                supplier_addressLine1 = supp_add2, supplier_addressLine2 = supp_add3, IGST_tot = igsttot, CGST_tot = cgsttot,
                                SGST_tot = sgsttot, Cess_tot = cesstot, Gross_tot = grosstot, prod_nms = pronms, imglinks = img,supplier_Key = supplieridfr)


                        //---------------------  //Update new purchase request----------------------//

                        var db = FirebaseFirestore.getInstance()
                        println(Arrays.toString(ids))
                        if ((listoids.text != "") && (errrnm.visibility == View.INVISIBLE) && (errsnm.visibility == View.INVISIBLE) && (errsgt.visibility == View.INVISIBLE) && (errsad1.visibility == View.INVISIBLE) && (transferpurreq == "true")&&(pronameArray.isNotEmpty())) {

                            var refid = listoids.text.toString()
                            println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                            var path = "${orikys}_Purchase Request/$refid/Stock_products"

                            if ((listListener == "listadded") && (listListenergross != "listaddedgross")) {
                                try {
                                    pDialogs = SweetAlertDialog(this@RequestAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialogs!!.setTitleText("Saving...");
                                    pDialogs!!.setCancelable(false);
                                    pDialogs!!.show();
                                }
                                catch (e:Exception){

                                }

                                db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                        .set(data)
                                        .addOnCompleteListener {
                                            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                                    .update(mapsub)
                                            try{
                                                pDialogs!!.dismiss()

                                            }
                                            catch (e:Exception){

                                            }

                                            val j = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
                                            j.putExtra("from_ver", "frmaddact")



                                            j.putExtra("viewsuppin", viewsuppin)
                                            j.putExtra("addsuppin", addsuppin)
                                            j.putExtra("deletesuppin", deletesuppin)
                                            j.putExtra("editsuppin", editesuppin)
                                            j.putExtra("transfersuppin", transfersuppin)
                                            j.putExtra("exportsuppin", exportsuppin)


                                            j.putExtra("viewpurord", viewpurord)
                                            j.putExtra("addpurord", addpurord)
                                            j.putExtra("deletepurord", deletepurord)
                                            j.putExtra("editpurord", editepurord)
                                            j.putExtra("transferpurord", transferpurord)
                                            j.putExtra("exportpurord", exportpurord)
                                            j.putExtra("sendpurord", sendpurpo)




                                            j.putExtra("viewpurreq", viewpurreq)
                                            j.putExtra("addpurreq", addpurreq)
                                            j.putExtra("deletepurreq", deletepurreq)
                                            j.putExtra("editpurreq", editepurreq)
                                            j.putExtra("transferpurreq", transferpurreq)
                                            j.putExtra("exportpurreq", exportpurreq)


                                            j.putExtra("oriky", orikys)
                                            startActivity(j)
                                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                            finish()

                                        }
                            } else if ((listListener != "listadded") && (listListenergross == "listaddedgross")) {

                                val map = mutableMapOf<String, Any?>()
                                map.put("prod_nms",names.text.toString())
                                map.put("igst_tot",igst_tot.text.toString())
                                map.put("cgst_tot",cgst_tot.text.toString())
                                map.put("sgst_tot",sgst_tot.text.toString())
                                map.put("cess_tot",cess_tot.text.toString())
                                map.put("gross_tot",gross_tot.text.toString())
                                try {
                                    pDialogs = SweetAlertDialog(this@RequestAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialogs!!.setTitleText("Saving...");
                                    pDialogs!!.setCancelable(false);
                                    pDialogs!!.show();
                                }
                                catch (e:Exception){

                                }

                                db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                        .update(map)
                                        .addOnSuccessListener {

                                        }
                                for (m in 0 until ids.size) {
                                    db.collection(path).document(ids[m].toString())
                                            .delete()
                                            .addOnCompleteListener {







                                            }
                                }
                                updatelist(path, pDialogs!!)
                            } else if ((listListener == "listadded") && (listListenergross == "listaddedgross")) {
                                try {
                                    pDialogs = SweetAlertDialog(this@RequestAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialogs!!.setTitleText("Saving...");
                                    pDialogs!!.setCancelable(false);
                                    pDialogs!!.show();
                                }
                                catch (e:Exception){

                                }

                                db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                        .set(data)
                                        .addOnCompleteListener {

                                            db.collection("${orikys}_Purchase Request").document(listoids.text.toString())
                                                    .update(mapsub)

                                        }
                                        .addOnSuccessListener {
                                            for (m in 0 until ids.size) {
                                                db.collection(path).document(ids[m].toString())
                                                        .delete()
                                                        .addOnCompleteListener {






                                                        }
                                            }
                                            updatelist(path, pDialogs!!)
                                        }
                            } else if ((listListener != "listadded") && (listListenergross != "listaddedgross")) {

                                Toast.makeText(applicationContext, "No changes happened for save", Toast.LENGTH_SHORT).show()

                            }
                        } else {
                            if (transferpurreq == "false") {
                                popup("Purchase request")
                            }
                            else if(pronameArray.isEmpty()){
                                val dialog= AlertDialog.Builder(this@RequestAddActivity)
                                with(dialog){
                                    setTitle("Unable to make purchase")
                                    setMessage("Please select some products.")
                                    setCancelable(false)
                                    setPositiveButton("Ok"){dialog,button ->
                                        dialog.dismiss()
                                    }
                                    val builders=dialog.create()
                                    builders.show()
                                }
                            }
                        }
                    } else {
                        dialog.dismiss()
                    }
                }
            }
            setNegativeButton("No") { dialog, whichButton ->
                val o=Intent(this@RequestAddActivity,PurchaseRequestActivity::class.java)
                o.putExtra("from_ver","frmsave")

               o.putExtra("viewsuppin", viewsuppin)
               o.putExtra("addsuppin", addsuppin)
               o.putExtra("deletesuppin", deletesuppin)
               o.putExtra("editsuppin", editesuppin)
               o.putExtra("transfersuppin", transfersuppin)
               o.putExtra("exportsuppin", exportsuppin)


               o.putExtra("viewpurord", viewpurord)
               o.putExtra("addpurord", addpurord)
               o.putExtra("deletepurord", deletepurord)
               o.putExtra("editpurord", editepurord)
               o.putExtra("transferpurord", transferpurord)
               o.putExtra("exportpurord", exportpurord)
               o.putExtra("sendpurord", sendpurpo)




                o.putExtra("viewpurreq", viewpurreq)
                o.putExtra("addpurreq", addpurreq)
                o.putExtra("deletepurreq", deletepurreq)
                o.putExtra("editpurreq", editepurreq)
                o.putExtra("transferpurreq", transferpurreq)
                o.putExtra("exportpurreq", exportpurreq)


                o.putExtra("brky",orikys)
                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }
            // Dialog
            val dialog = builder.create()
            dialog.show()
        }
        }


fun updatelistpopup(path:String,dialog:SweetAlertDialog){
    for (i in 0 until priceArray.size) {
        var stk_name = pronameArray[i]
        var stk_mfr = manufacturerArray[i]
        var stk_hsn = hsnArray[i]
        var stk_bcode = barcodeArray[i]
        var stk_quan = quantityArray[i]
        var stk_pri = priceArray[i]
        var stk_tot = totArray[i]
        var stk_grosstot = grosstotArray[i]
        var stk_cess = cessArray[i]
        var stk_igst = igstArray[i]
        var stk_cgst = cgstArray[i]
        var stk_sgst = sgstArray[i]
        var stk_igsttot = igsttotArray[i]
        var stk_cesstot = cesstotalArray[i]
        var stk_tally = tallyArray[i]
        var img_arr = imageArray[i]
        var stk_received = receivedArray[i]
        var stk_key = keyArray[i]
        var idpro_ar = idproarray[i]

        var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                otherstk_tally = stk_tally, otherstk_received = stk_received, otherstk_img = img_arr,stk_prokey = idpro_ar)
        db.collection(path)
                .add(d)
                .addOnCompleteListener {

                    Toast.makeText(applicationContext,"Saved",Toast.LENGTH_SHORT).show()

                }


    }
    dialog.dismiss()
    val j = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
    j.putExtra("from_ver", "frmaddact")



    j.putExtra("viewsuppin", viewsuppin)
    j.putExtra("addsuppin", addsuppin)
    j.putExtra("deletesuppin", deletesuppin)
    j.putExtra("editsuppin", editesuppin)
    j.putExtra("transfersuppin", transfersuppin)
    j.putExtra("exportsuppin", exportsuppin)


    j.putExtra("viewpurord", viewpurord)
    j.putExtra("addpurord", addpurord)
    j.putExtra("deletepurord", deletepurord)
    j.putExtra("editpurord", editepurord)
    j.putExtra("transferpurord", transferpurord)
    j.putExtra("exportpurord", exportpurord)
    j.putExtra("sendpurord", sendpurpo)




    j.putExtra("viewpurreq", viewpurreq)
    j.putExtra("addpurreq", addpurreq)
    j.putExtra("deletepurreq", deletepurreq)
    j.putExtra("editpurreq", editepurreq)
    j.putExtra("transferpurreq", transferpurreq)
    j.putExtra("exportpurreq", exportpurreq)


    j.putExtra("oriky", orikys)
    startActivity(j)
    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
    finish()
}








            //Create and write pdf document for 'Send this request' option.

    fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqemail:String, reqestidate:String, supplnm:String, supplph:String,
                            suppladdress1:String, suppladdress2:String, suppladdress3:String, supplgst:String, igsttotal:String, cgsttotal:String, sgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Purchase Request"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f=id+"_request"

            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Purchase Request",fontsubheading)

            val a1=  Paragraph("Request Id:"+'\t'+'\t'+"         "+id,font)


            val b1=  Paragraph("Request Date:"+'\t'+'\t'+"      "+requestdt,font)
            val b122=  Paragraph("Requestor Details:",fontsubheading)

            val c1=  Paragraph("Requestor Name:"+'\t'+'\t'+"     "+reqname,font)


            val f1=  Paragraph("Requestor Email:"+'\t'+'\t'+"          "+reqemail,font)
            val g1=  Paragraph("Estimated Date:"+'\t'+'\t'+"       "+reqestidate,font)
            val hg1dd =  Paragraph("Supplier Details:",fontsubheading)

            val hg1 =  Paragraph("Supplier Name:"+'\t'+'\t'+"        "+supplnm,font)
            val i2 =  Paragraph("Supplier Phone:"+'\t'+'\t'+"        "+supplph,font)
            val j3 =  Paragraph("Supplier Address:"+'\t'+'\t'+"        "+suppladdress1+suppladdress2+suppladdress3,font)

            val k4 =  Paragraph("GST:"+'\t'+'\t'+"          "+supplgst,font)

            /*       val p12 =  Paragraph("IGST Total:                  "+igsttotal,font)
                   val p13 =  Paragraph("CGST Total:                  "+cgsttotal,font)
                   val p14 =  Paragraph("SGST Total:                  "+sgsttotal,font)
                   val p15 =  Paragraph("CESS Total:                  "+cesstotal,font)
                   val p7 =  Paragraph("Gross Total:                 "+grosstot,font)*/
            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell("S.No");
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Taxes");
            table.addCell("Quantity");
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var gros=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)

                var grossrealtot=gttt+gros

                /*var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var div=2
                var e=igsttotArray[i]
                var eflo=e.toFloat()
                ee=ee+eflo
                ig= ee
                var csgsts=ig
                var csgttotalss=csgsts/div
                cg=csgttotalss
                sg=csgttotalss



                var f=cesstotalArray[i]
                var fflo=f.toFloat()
                cc=fflo+cc
                ces=cc
                var gg=ig.toFloat()
                var jj=ces.toFloat()
                var grtt=gg+jj
                var grflo=grtt.toFloat()
                var gttt=grflo+(pri*quan)



                var grossrealtot=gttt+gros

                singrosstot=singrosstot.plusElement(grossrealtot.toString())*/

                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell( hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell( quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell( gttt.toString())
            }

        /*    var ttgross=0.0F

            for(l in 0 until singrosstot.size)

            {

                var arrgrosstt=singrosstot[l].toFloat()
                ttgross=ttgross+arrgrosstt
                grosstt=ttgross.toString()
                println("TOTAL"+ttgross+l)
                println("GROSS TOTAL"+grosstt+l)



            }*/

            table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igsttotal)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgsttotal)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgsttotal)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesstotal)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstot)
            /*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*/





            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE );
            doc.add(hs1)

            doc.add( Chunk.NEWLINE );
            doc.add(a1)
            doc.add( Chunk.NEWLINE );
            doc.add(b1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(b122)
            doc.add( Chunk.NEWLINE );
            doc.add(c1)

            doc.add( Chunk.NEWLINE );
            doc.add(f1)
            doc.add( Chunk.NEWLINE );
            doc.add(g1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(hg1dd)
            doc.add( Chunk.NEWLINE );
            doc.add(hg1)
            doc.add( Chunk.NEWLINE );
            doc.add(i2)
            doc.add( Chunk.NEWLINE );
            doc.add(j3)
            doc.add( Chunk.NEWLINE );
            doc.add(k4)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(table)

            downstatus="success"


        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }




    //Navigate to RequestActivityPdf for export as pdf document of this request.

    fun pdfnav() {
        val b = Intent(applicationContext, RequestActivityPdf::class.java)
        b.putExtra("from_req", "request_pdf")

        b.putExtra("pnm", pronameArray)
        b.putExtra("pmanu", manufacturerArray)
        b.putExtra("phsn", hsnArray)
        b.putExtra("barcode", barcodeArray)
        b.putExtra("price", priceArray)

        b.putExtra("quan", quantityArray)
        b.putExtra("tot", totArray)
        b.putExtra("grosstotarr", grosstotArray)
        b.putExtra("cessup", cessArray)
        b.putExtra("igst", igstArray)
        b.putExtra("cgst", cgstArray)
        b.putExtra("sgst", sgstArray)
        b.putExtra("igsttotal", igsttotArray)
        b.putExtra("cesstotarray", cesstotalArray)
        b.putExtra("tallyarray", tallyArray)
        b.putExtra("receivedarray", receivedArray)
        b.putExtra("idsofli",keyArray)
        b.putExtra("idpro",idproarray)
        b.putExtra("smlistids",smlistids)
        b.putExtra("edclick",editclick)
        b.putExtra("supplieridfr",supplieridfr)
        b.putExtra("updatestatus",updatestatus)

        b.putExtra("request_datedup",request_datedup)
        b.putExtra("reqest_datedup",reqest_datedup)
        b.putExtra("supp_namedup",supp_namedup)
        b.putExtra("supp_gstdup",supp_gstdup)
        b.putExtra("supp_addredup",supp_addredup)
        b.putExtra("befnm",befnm)

        b.putExtra("image", imageArray)
        b.putExtra("reqid", req_id.text.toString())
        b.putExtra("reqliid", listoids.text.toString())
        b.putExtra("reprnms", names.text.toString())
        b.putExtra("reqname", req_name.text.toString())
        b.putExtra("reqdate", request_date.text.toString())
        b.putExtra("reqest", reqest_date.text.toString())
        b.putExtra("reqmail", req_mail.text.toString())

        b.putExtra("supnm", supp_name.text.toString())
        b.putExtra("supadd1", supp_addre.text.toString())
        b.putExtra("supadd2", addre1.text.toString())
        b.putExtra("supadd3", addre2.text.toString())
        b.putExtra("supcity", supp_city.text.toString())
        b.putExtra("supstate", supp_state.text.toString())
        b.putExtra("supph", supp_phone.text.toString())
        b.putExtra("supgst",  supp_gst.text.toString())
        b.putExtra("igsttot", igst_tot.text.toString())
        b.putExtra("cgsttot", cgst_tot.text.toString())
        b.putExtra("sgsttot", sgst_tot.text.toString())
        b.putExtra("cesstot", cess_tot.text.toString())
        b.putExtra("grosstot", gross_tot.text.toString())
        b.putExtra("names", names.text.toString())
        b.putExtra("nm",comttname.text.toString())
        b.putExtra("addre",comphone.text.toString())



        b.putExtra("status", status)
        b.putExtra("viewsuppin", viewsuppin)
        b.putExtra("addsuppin", addsuppin)
        b.putExtra("deletesuppin", deletesuppin)
        b.putExtra("editsuppin", editesuppin)
        b.putExtra("transfersuppin", transfersuppin)
        b.putExtra("exportsuppin", exportsuppin)


        b.putExtra("viewpurord", viewpurord)
        b.putExtra("addpurord", addpurord)
        b.putExtra("deletepurord", deletepurord)
        b.putExtra("editpurord", editepurord)
        b.putExtra("transferpurord", transferpurord)
        b.putExtra("exportpurord", exportpurord)
        b.putExtra("sendpurord", sendpurpo)




        b.putExtra("viewpurreq", viewpurreq)
        b.putExtra("addpurreq", addpurreq)
        b.putExtra("deletepurreq", deletepurreq)
        b.putExtra("editpurreq", editepurreq)
        b.putExtra("transferpurreq", transferpurreq)
        b.putExtra("exportpurreq", exportpurreq)


        b.putExtra("imlinks", imgslnks)
        b.putExtra("brky", orikys)

        b.putExtra("ids",ids)

        startActivity(b)
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
        finish()
    }




    //REQUEST COUNt
    private fun onStarClicked1(pronameArray:ArrayList<String>, manufacturerArray:ArrayList<String>, hsnArray:ArrayList<String>,
                               barcodeArray:ArrayList<String>, quantityArray:ArrayList<String>, priceArray:ArrayList<String>,
                               totArray:ArrayList<String>,grosstotArray:ArrayList<String>, cessArray:ArrayList<String>, igstArray:ArrayList<String>,
                               cgstArray:ArrayList<String>, sgstArray:ArrayList<String>, igsttotArray:ArrayList<String>,
                               cesstotalArray:ArrayList<String>, tallyArray: ArrayList<String>,receivedArray: ArrayList<String>,
                               keyArray:ArrayList<String>,imageArray: ArrayList<String>,idproArray:ArrayList<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("Purchase_Requests")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray,manufacturerArray,hsnArray,
                        barcodeArray,quantityArray,priceArray,totArray,grosstotArray,cessArray,
                        igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,
                        tallyArray,receivedArray,keyArray,imageArray,idproArray)


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }




    fun prod_insert(id1: String, pronameArray: ArrayList<String>, manufacturerArray: ArrayList<String>, hsnArray: ArrayList<String>,
                    barcodeArray: ArrayList<String>, quantityArray: ArrayList<String>, priceArray: ArrayList<String>, totArray: ArrayList<String>,
                    grosstotArray: ArrayList<String>, cessArray: ArrayList<String>, igstArray:ArrayList<String>, cgstArray:ArrayList<String>, sgstArray:ArrayList<String>,
                    igsttotArray:ArrayList<String>, cesstotalArray:ArrayList<String>, tallyArray:ArrayList<String>,
                    receivedArray:ArrayList<String>, keyArray:ArrayList<String>, imageArray: ArrayList<String>, idproArray: ArrayList<String>) {



        if((id1=="1")||(id1=="2")||(id1=="3")||(id1=="4")||(id1=="5")
            ||(id1=="6")||(id1=="7")||(id1=="8")||(id1=="9")){
             requestid = "PR0"+id1
        }
        else{
            requestid = "PR"+id1
        }


        var brid = orikys
        var pronms=(names.text).toString()
        var requestdate = (request_date.text).toString()
        var requ_name = (req_name.text).toString()
        var requ_mail = (req_mail.text).toString()
        var requ_esti = (reqest_date.text).toString()

        var supp_name = (supp_name.text).toString()
        var supp_phone = (supp_phone.text).toString()
        var supp_gst = (supp_gst.text).toString()
        var supp_city = (supp_city.text).toString()
        var supp_state = (supp_state.text).toString()
        var supp_add1 = (supp_addre.text).toString()
        var supp_add2 = (addre1.text).toString()
        var supp_add3 = (addre2.text).toString()
        var igst = (igst_ed.text).toString()
        var cgstii = (cgst_ed.text).toString()
        var sgstii = (sgst_ed.text).toString()
        var igsttot = (igst_tot.text).toString()
        var cgsttot = (cgst_tot.text).toString()
        var sgsttot = (sgst_tot.text).toString()
        var cesstot = (cess_tot.text).toString()
        var grosstot = (gross_tot.text).toString()
        var imgsl=imgslnks

        var st="Pending"

        val data = s(req_id = requestid, brid=brid,req_date = requestdate, req_name = requ_name,req_mail = requ_mail,req_estimated = requ_esti,supplier_name = supp_name,supplier_Phone = supp_phone,supplier_GST = supp_gst,supplier_City = supp_city,supplier_State = supp_state,supplier_address = supp_add1,
                supplier_addressLine1 = supp_add2,supplier_addressLine2 = supp_add3,
                IGST_tot = igsttot,CGST_tot = cgsttot,SGST_tot = sgsttot,Cess_tot = cesstot,
                Gross_tot = grosstot,prod_nms = pronms,imglinks = imgsl,supplier_Key = supplieridfr)
        var db = FirebaseFirestore.getInstance()
        db.collection("${orikys}_Purchase Request")
                .add(data)

                .addOnSuccessListener { documentReference ->

                    var ffl = documentReference.id


                    val map = mutableMapOf<String, Any?>()
                    map.put("status", "Pending")
                    mapsub = map
                    db.collection("${orikys}_Purchase Request").document(ffl)
                            .update(mapsub)

                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var refid = documentReference.id

                    if ((prodnms.isEmpty()) && (priceArray.isEmpty())) {

                        Toast.makeText(applicationContext, "Data saved successfully", Toast.LENGTH_SHORT).show()

                        val o = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)
                        o.putExtra("from_ver", "frmsave")

                        o.putExtra("viewsuppin", viewsuppin)
                        o.putExtra("addsuppin", addsuppin)
                        o.putExtra("deletesuppin", deletesuppin)
                        o.putExtra("editsuppin", editesuppin)
                        o.putExtra("transfersuppin", transfersuppin)
                        o.putExtra("exportsuppin", exportsuppin)


                        o.putExtra("viewpurord", viewpurord)
                        o.putExtra("addpurord", addpurord)
                        o.putExtra("deletepurord", deletepurord)
                        o.putExtra("editpurord", editepurord)
                        o.putExtra("transferpurord", transferpurord)
                        o.putExtra("exportpurord", exportpurord)
                        o.putExtra("sendpurord", sendpurpo)




                        o.putExtra("viewpurreq", viewpurreq)
                        o.putExtra("addpurreq", addpurreq)
                        o.putExtra("deletepurreq", deletepurreq)
                        o.putExtra("editpurreq", editepurreq)
                        o.putExtra("transferpurreq", transferpurreq)
                        o.putExtra("exportpurreq", exportpurreq)


                        o.putExtra("brky", orikys)
                        startActivity(o)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                        finish()


                    }

                    if (priceArray.isNotEmpty()) {
                        var path = "${orikys}_Purchase Request/$refid/Stock_products"
                        for (i in 0 until priceArray.size) {

                            var stk_name = pronameArray[i]
                            var stk_mfr = manufacturerArray[i]
                            var stk_hsn = hsnArray[i]
                            var stk_bcode = barcodeArray[i]
                            var stk_quan = quantityArray[i]
                            var stk_pri = priceArray[i]
                            var stk_tot = totArray[i]
                            var stk_grosstot = grosstotArray[i]
                            var stk_cess = cessArray[i]
                            var stk_igst = igstArray[i]
                            var stk_cgst = cgstArray[i]
                            var stk_sgst = sgstArray[i]
                            var stk_igsttot = igsttotArray[i]
                            var img_arr = imageArray[i]
                            var stk_cesstot = cesstotalArray[i]
                            var stk_tally = tallyArray[i]
                            var stk_received = receivedArray[i]
                            var stk_key = keyArray[i]
                            var idpro_ar = idproArray[i]
                            var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri,
                                    stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst, otherstk_sgst = stk_sgst,
                                    otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally,
                                    otherstk_received = stk_received, otherstk_img = img_arr, stk_prokey = idpro_ar)
                            db.collection(path)
                                    .add(d)

                                    .addOnSuccessListener { documentReference ->

                                        var resid = documentReference.id
                                        Toast.makeText(applicationContext, "Data saved successfully", Toast.LENGTH_SHORT).show()

                                        try{
                                            pDialogs!!.dismiss()
                                        }
                                        catch (e:Exception){

                                        }

                                    }

                        }
                        val o = Intent(this@RequestAddActivity, PurchaseRequestActivity::class.java)



                        o.putExtra("from_ver", "frmsave")

                        o.putExtra("viewsuppin", viewsuppin)
                        o.putExtra("addsuppin", addsuppin)
                        o.putExtra("deletesuppin", deletesuppin)
                        o.putExtra("editsuppin", editesuppin)
                        o.putExtra("transfersuppin", transfersuppin)
                        o.putExtra("exportsuppin", exportsuppin)


                        o.putExtra("viewpurord", viewpurord)
                        o.putExtra("addpurord", addpurord)
                        o.putExtra("deletepurord", deletepurord)
                        o.putExtra("editpurord", editepurord)
                        o.putExtra("transferpurord", transferpurord)
                        o.putExtra("exportpurord", exportpurord)
                        o.putExtra("sendpurord", sendpurpo)




                        o.putExtra("viewpurreq", viewpurreq)
                        o.putExtra("addpurreq", addpurreq)
                        o.putExtra("deletepurreq", deletepurreq)
                        o.putExtra("editpurreq", editepurreq)
                        o.putExtra("transferpurreq", transferpurreq)
                        o.putExtra("exportpurreq", exportpurreq)


                        o.putExtra("brky", orikys)
                        startActivity(o)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                        finish()
                    }


                    }

                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                                Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                                /* save_progress.visibility = android.view.View.GONE*/
                            }


    }

    fun sendMail(path: String) {  //Send this purchase request to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("muthumadhavan.vinitas@gmail.com","it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "Purchase PO")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        emailIntent.type = "application/pdf"
        val myUri = Uri.parse("file://" + path)
        emailIntent.putExtra(Intent.EXTRA_STREAM, myUri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        finish()
    }

    fun popup(st:String){  //Access Denied alert
        val pop= android.support.v7.app.AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    companion object {
 //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        private var bottnav: LinearLayout? = null
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var consermaindis: ConstraintLayout? = null
        private var req_iddis: EditText? = null
        private var req_savedis: Button? = null
        private var mnudis: ImageButton? = null
        private var userbackdis: ImageButton? = null
        private var req_namedis:EditText?=null
        private var request_datedis:EditText?=null
        private var reqest_datedis:EditText?=null
        private var supp_addredis:EditText?=null
        private var supp_gstdis:EditText?=null
        private var supp_namedis:EditText?=null
        private var editdis:ImageButton? =null
        private var compstatusdis:TextView?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {


            if(log=="NOT_CONNECT"){

                                 /// if connection is off then all views becomes disable


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE
                req_savedis!!.isEnabled=false
                mnudis!!.isEnabled=false
                userbackdis!!.isEnabled=false
                req_namedis!!.isEnabled=false
                request_datedis!!.isEnabled=false
                reqest_datedis!!.isEnabled=false
                supp_addredis!!.isEnabled=false
                supp_gstdis!!.isEnabled=false
                supp_namedis!!.isEnabled=false
                editdis!!.isEnabled=false
                bottnav!!.visibility=View.GONE
                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {


                /// if connection is off then all views becomes enabled

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                bottnav!!.visibility=View.VISIBLE

                if((editdis!!.visibility!=View.VISIBLE)&&(compstatusdis!!.text!="Approved")){
                    req_namedis!!.isEnabled=true
                    request_datedis!!.isEnabled=true
                    reqest_datedis!!.isEnabled=true
                    supp_addredis!!.isEnabled=true
                    supp_gstdis!!.isEnabled=true
                    supp_namedis!!.isEnabled=true
                }


                editdis!!.isEnabled=true
                req_savedis!!.isEnabled=true
                mnudis!!.isEnabled=true
                userbackdis!!.isEnabled=true

                relativeslayoutdis!!.visibility=View.GONE







                req_iddis!!.isEnabled=false
            }
        }
    }
    fun setDate(view: View) {
        showDialog(999)

    }
    fun setDate1(view: View) {
        showDialog(998)

    }

    override fun onCreateDialog(id: Int): Dialog? {
        // TODO Auto-generated method stub
        return if (id == 999) {
            DatePickerDialog(this,
                    myDateListener, year, month, day)
        }
        else if(id==998){
            DatePickerDialog(this,
                    myDateListener1, year, month, day)
        }
        else null
    }

    private fun showDate(year: Int, month: Int, day: Int) {
        dateView!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)




        if(dateView!!.text.isNotEmpty()){
            var f=dateView!!.text.toString()
reqest_date.setText(f)
        }



    }
    private fun showDate1(year: Int, month: Int, day: Int) {
        dateView1!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)


        if(dateView1!!.text.isNotEmpty()){
            var f=dateView1!!.text.toString()
            request_date.setText(f)
        }
    }

}
