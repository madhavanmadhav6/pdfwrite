package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot

import kotlinx.android.synthetic.main.activity_with_state.*

class WithStateActivity : AppCompatActivity() {

    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var ids= arrayOf<String>()


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    var s = String()
    var states= String()

    var brsupky=String()

    var pins= String()
    var liids= arrayOf<String>()
    var bridd= arrayOf<String>()
  var nameArrayori= arrayOf<String>()
    var orinameArrayori= arrayOf<String>()
    var dateArrayori= arrayOf<String>()
    var priceArrayori= arrayOf<String>()
    var datearr=arrayOf<String>()
    var descrip=arrayOf<String>()
    var oriid= String()
    var orgval= String()
    var orgcty= String()
    var orgst= String()
    var esc= String()
    var upstr= String()
    var numberstr= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
    var a=arrayOf<String>()
    var origisearch= arrayOf<String>()

    var origid= String()

    var frms= String()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""



    var sd= String()
    var x= String()
    var reg= String()
    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_with_state)

                //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@WithStateActivity) > 0)
        {

        }
        else{

        }

        //Define No connection view and other views when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.withcont)

        addLogText(NetworkUtil.getConnectivityStatusString(this@WithStateActivity))


        net_status()   //Check net status



        try {
    val bundle = intent.extras
    var frm = bundle!!.get("from_br").toString()
            frms=frm
}
catch (e:Exception){

}








        search.setOnClickListener {
            cardsearch.visibility= View.VISIBLE
                       cardsearch.startAnimation(AnimationUtils.loadAnimation(this@WithStateActivity,R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }


        imageButton2.setOnClickListener({// Vert menu popup with 'LOGOUT' option


            val popup = PopupMenu(this@WithStateActivity, imageButton2)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item -> //navigate to pinActivity


                if (item.title == "Logout") {
                    Toast.makeText(this@WithStateActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@WithStateActivity, PinActivity::class.java)
                    startActivity(f)
                    finish()
                }
                true
            }

            popup.show()
        })


        back.setOnClickListener {
        onBackPressed()
        }

        if(frms=="main") {
            try {
                val p = intent.getStringExtra("bkey")
                oriid = p
            } catch (e: Exception) {

            }

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }




            println("STATE ACTIVITY KEYSSS" + oriid)
            println("ADD STARTING" + addtrans)


/*try {
    db.collection("Branches").document(oriid)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    if (task.result != null) {
                        var document = task.result
                        origid = document.id

                        var orig = document.get("br_nm").toString()
                        orgval = orig

                        println("VALUE OF ORIGIN IDDD " + orgval)
                    } else {
                        Log.d("data", "is not here")
                    }
                } else {
                    Log.d("task is not success", "full" + task.exception)
                }
            }
}
catch(e:Exception){

}*/



            db.collection("${oriid}_Stock_Transfer").whereEqualTo("stk_origin",oriid)

                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if(value.isEmpty==false) {
                            gets()
                        }
                        else{

                            imageView10.visibility=View.VISIBLE
                        }
                    })


            /*  swipeContainer.setOnRefreshListener {
            try {
                db.collection("branch").document(oriid)
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                if (task.result != null) {
                                    var document = task.result
                                    origid = document.id
                                    Log.d("data", "is" + task.result.data)
                                    var orig = document.get("nm").toString()
                                    var origcty = document.get("cty").toString()
                                    orgcty=origcty
                                    orgval = orig

                                    println("VALUE OF ORIGIN IDDD" + orgval)
                                } else {
                                    Log.d("data", "is not here")
                                }
                            } else {
                                Log.d("task is not success", "full" + task.exception)
                            }
                        }
            }
            catch(e:Exception){

            }
            gets()
        }*/
            // Configure the refreshing colors
            /*  swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/
        }
       else if(frms=="brsave"){


            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }











            val bky=intent.getStringExtra("brky")
            val orky=intent.getStringExtra("orky")

            oriid=orky

            println("ORIID"+oriid)


            gets()
        }

        ///Select list item and navigate to  'Mainstk_branch_one'

       wlist.setOnItemClickListener { parent, views, position, id ->

           val b = Intent(applicationContext, Mainstk_branch_one::class.java)

           b.putExtra("from", "startlist")
           b.putExtra("brnm", nameArrayori[position])
           b.putExtra("date", datearr[position])
           b.putExtra("description", descrip[position])
           b.putExtra("Stockids", ids[position])
           b.putExtra("listids", liids[position])
           b.putExtra("brids", bridd[position])
           b.putExtra("orignm", orinameArrayori[position])
           b.putExtra("origiid", oriid)





           b.putExtra("viewtrans", viewtrans)
           b.putExtra("addtrans", addtrans)
           b.putExtra("edittrans", editetrans)
           b.putExtra("deletetrans", deletetrans)
           b.putExtra("transfertrans", transfertrans)
           b.putExtra("exporttrans", exporttrans)
           b.putExtra("sendtrans", sendtrans)


           b.putExtra("viewtransano", viewtransano)
           b.putExtra("addtransano", addtransano)
           b.putExtra("edittransano", editetransano)
           b.putExtra("deletetransano", deletetransano)
           b.putExtra("transfertransano", transfertransano)
           b.putExtra("exporttransano", exporttransano)
           b.putExtra("sendtransano", sendtransano)

           b.putExtra("viewrec", viewrec)
           b.putExtra("addrec", addrec)
           b.putExtra("deleterec", deleterec)
           b.putExtra("editrec", editrec)
           b.putExtra("transferrec", transferrec)
           b.putExtra("exportrec", exportrec)
           b.putExtra("sendstrec",sendstrec)





           startActivity(b)
           overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
           finish()
       }




        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar11.visibility = View.VISIBLE
                wlist.visibility = View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                println("TYPED VALUED" + x)


                val ps = "^[a-zA-Z ]+$"


                val datev = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"



                if (x.trim().matches(datev.toRegex())) {
                    upstr = x
                    println("CAME INTO DATE NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr

                    regtr = "num"
                    dateget()

                    //write code here for success
                }
                fun dateget() {
                   if ((s.length>=2)||(s.length>=2)) {
                       noresfo.visibility = View.GONE
                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var bridArray = arrayOf<String>()

                        db.collection("${oriid}_Stock_Transfer").orderBy("stkdate").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_origin"]).toString()



                                                if (oriid == orid) {
                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                                      i=idss
                                                      println(id)
                                                      println(i)*/

                                                    var name = (dt["stk_destination"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()
                                                    var descr = (dt["stk_Desc"]).toString()
                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brid = (dt["stk_brid"]).toString()
                                                    var orinm = (dt["stk_originname"]).toString()
                                                    orinameArrayori = orinameArrayori.plusElement(orinm)
                                                    brsupky=orid
                                                    if(orgcty.isNotEmpty()){
                                                        text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                                    }
                                                    else if(orgcty.isEmpty()){
                                                        text = text.plusElement("Origin: " + orgval)

                                                    }
                                                    nameArray = nameArray.plusElement("Destination : " + name)
                                                    dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    descriptionArray = descriptionArray.plusElement(descr)
                                                    descrip = descriptionArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    bridArray = bridArray.plusElement(brid)
                                                    bridd = bridArray
                                                    origisearch = origisearch.plusElement(orid)

                                                    progressBar11.visibility = View.GONE
                                                    wlist.visibility = View.VISIBLE
                                                    noresfo.visibility = View.GONE
                                                    println("SAVE KEYYYY" + oriid)
                                                    val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                    val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                                    wlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    progressBar11.visibility = View.GONE
                                                    wlist.visibility = View.GONE
                                                }
                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + oriid)



                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility = View.VISIBLE
                                            progressBar11.visibility = View.GONE
                                            wlist.visibility = View.GONE
                                        }


                                    /*} else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }

                //---------------------------------PRICE SEARCH-----------------------------------//

                fun priget() {
                    if (x.length >= 2) {
                        noresfo.visibility=View.GONE

                        var text=arrayOf<String>()
                        var idss= arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray= arrayOf<String>()
                        var bridArray= arrayOf<String>()

                        db.collection("${oriid}_Stock_Transfer").orderBy("stk_total").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_origin"]).toString()



                                                if (oriid == orid) {
                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/

                                                    var name = (dt["stk_destination"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()
                                                    var descr = (dt["stk_Desc"]).toString()
                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brid = (dt["stk_brid"]).toString()

                                                    var orinm=(dt["stk_originname"]).toString()
                                                    orinameArrayori=orinameArrayori.plusElement(orinm)
                                                    if(orgcty.isNotEmpty()){
                                                        text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                                    }
                                                    else if(orgcty.isEmpty()){
                                                        text = text.plusElement("Origin: " + orgval)

                                                    }
                                                    nameArray = nameArray.plusElement("Destination : " + name)
                                                    dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    descriptionArray = descriptionArray.plusElement(descr)
                                                    descrip = descriptionArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    bridArray = bridArray.plusElement(brid)
                                                    bridd = bridArray
                                                    origisearch = origisearch.plusElement(orid)

                                                    noresfo.visibility = View.GONE
                                                    progressBar11.visibility=View.GONE
                                                    wlist.visibility=View.VISIBLE
                                                    println("SAVE KEYYYY" + oriid)
                                                    val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                    val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                                    wlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    wlist.visibility = View.GONE
                                                    progressBar11.visibility=View.GONE

                                                }
                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + oriid)



                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            dateget()

                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }


                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    priget()

                    //write code here for success
                }

                if ((x != reg)&&(!s.contains("/"))) {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper string" + upstr)
                    println("STRINGSSSS" + upstr)

                }
                else if(s.contains("/")){
                    dateget()
                }


                //----------------------------------------NAME SEARCH-------------------------------------------///

                fun nameget() {

                    println("d get name")
                    if ((s.length >= 3) && (x != reg)) {
                        noresfo.visibility = View.GONE
                        var text=arrayOf<String>()
                        var idss= arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray= arrayOf<String>()
                        var bridArray= arrayOf<String>()

                        db.collection("${oriid}_Stock_Transfer").orderBy("stk_originname").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_origin"]).toString()





                                                if (oriid == orid) {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/

                                                    var name = (dt["stk_destination"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()
                                                    var descr = (dt["stk_Desc"]).toString()
                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brid = (dt["stk_brid"]).toString()

                                                    var orinm=(dt["stk_originname"]).toString()
                                                    orinameArrayori=orinameArrayori.plusElement(orinm)
                                                    if(orgcty.isNotEmpty()){
                                                        text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                                    }
                                                    else if(orgcty.isEmpty()){
                                                        text = text.plusElement("Origin: " + orgval)

                                                    }
                                                    nameArray = nameArray.plusElement("Destination : " + name)
                                                    dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    descriptionArray = descriptionArray.plusElement(descr)
                                                    descrip = descriptionArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    bridArray = bridArray.plusElement(brid)
                                                    bridd = bridArray
                                                    origisearch = origisearch.plusElement(orid)


                                                    noresfo.visibility = View.GONE
                                                    progressBar11.visibility=View.GONE
                                                    wlist.visibility=View.VISIBLE
                                                    println("SAVE KEYYYY" + oriid)
                                                    val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                    val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                                    wlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    wlist.visibility = View.GONE
                                                    progressBar11.visibility=View.GONE

                                                }


                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + oriid)



                                        }
                                        else {



//-----------------------------Stovk destination search---------------------------------------//
                                            db.collection("${oriid}_Stock_Transfer").orderBy("stk_destination").startAt(upstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)

                                                                    var dt = document.data
                                                                    var orid = (dt["stk_origin"]).toString()



                                                                    if (oriid == orid) {


                                                                        var id = (document.id)
                                                                        idss = idss.plusElement(id)
                                                                        println(idss)

                                                                        /*  idss=idss.plusElement(path)
                                                                  i=idss
                                                                  println(id)
                                                                  println(i)*/

                                                                        var name = (dt["stk_destination"]).toString()
                                                                        var date = (dt["stkdate"]).toString()
                                                                        var tot = (dt["stk_total"]).toString()
                                                                        var descr = (dt["stk_Desc"]).toString()
                                                                        var manufacturer = (dt["stkid"]).toString()
                                                                        var brid = (dt["stk_brid"]).toString()

                                                                        var orinm=(dt["stk_originname"]).toString()
                                                                        orinameArrayori=orinameArrayori.plusElement(orinm)
                                                                        if(orgcty.isNotEmpty()){
                                                                            text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                                                        }
                                                                        else if(orgcty.isEmpty()){
                                                                            text = text.plusElement("Origin: " + orgval)

                                                                        }
                                                                        nameArray = nameArray.plusElement("Destination : " + name)
                                                                        dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                                                        priceArray = priceArray.plusElement(tot)
                                                                        nameArrayori = nameArrayori.plusElement(name)
                                                                        dateArrayori = dateArray
                                                                        priceArrayori = priceArray
                                                                        datearr = datearr.plusElement(date)
                                                                        descriptionArray = descriptionArray.plusElement(descr)
                                                                        descrip = descriptionArray
                                                                        ids = ids.plusElement(manufacturer)
                                                                        liids = idss
                                                                        bridArray = bridArray.plusElement(brid)
                                                                        bridd = bridArray
                                                                        origisearch = origisearch.plusElement(orid)



                                                                        noresfo.visibility = View.GONE
                                                                        progressBar11.visibility=View.GONE
                                                                        wlist.visibility=View.VISIBLE
                                                                        println("SAVE KEYYYY" + oriid)
                                                                        val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                                        val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                                                        wlist.adapter = whatever
                                                                    } else {
                                                                        noresfo.visibility = View.VISIBLE
                                                                        wlist.visibility = View.GONE
                                                                        progressBar11.visibility=View.GONE

                                                                    }


                                                                }

                                                                println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                                                println("SAVE KEYYYY" + oriid)



                                                            } else {
                                                                println("NO RECORDSSSS FOUNDD")
                                                                noresfo.visibility=View.VISIBLE
                                                                wlist.visibility=View.GONE
                                                                progressBar11.visibility=View.GONE

                                                            }


                                                        /*} else {
                                                            Log.w(TAG, "Error getting documents.", task.exception)
                                                        }*/
                                                    })
                                        }


                                    /*} else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }

                }
                if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper names" + upstr)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }



                if ((s.length >= 3) && (x != reg)&&((!s.contains("/")))) {
                    noresfo.visibility = View.GONE
                    var text = arrayOf<String>()
                    var idss = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var descriptionArray = arrayOf<String>()
                    var bridArray = arrayOf<String>()

                    db.collection("${oriid}_Stock_Transfer").orderBy("stkid").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)

                                            var dt = document.data


                                            var orid = (dt["stk_origin"]).toString()





                                            if (oriid == orid) {
                                                var id = (document.id)
                                                idss = idss.plusElement(id)
                                                println(idss)

                                                /*  idss=idss.plusElement(path)
                                                  i=idss
                                                  println(id)
                                                  println(i)*/

                                                var name = (dt["stk_destination"]).toString()
                                                var date = (dt["stkdate"]).toString()
                                                var tot = (dt["stk_total"]).toString()
                                                var descr = (dt["stk_Desc"]).toString()
                                                var manufacturer = (dt["stkid"]).toString()
                                                var brid = (dt["stk_brid"]).toString()
                                                brsupky=orid
                                                var orinm = (dt["stk_originname"]).toString()
                                                orinameArrayori = orinameArrayori.plusElement(orinm)
                                                if(orgcty.isNotEmpty()){
                                                    text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                                }
                                                else if(orgcty.isEmpty()){
                                                    text = text.plusElement("Origin: " + orgval)

                                                }
                                                nameArray = nameArray.plusElement("Destination : " + name)
                                                dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                                priceArray = priceArray.plusElement(tot)
                                                nameArrayori = nameArrayori.plusElement(name)
                                                dateArrayori = dateArray
                                                priceArrayori = priceArray
                                                datearr = datearr.plusElement(date)
                                                descriptionArray = descriptionArray.plusElement(descr)
                                                descrip = descriptionArray
                                                ids = ids.plusElement(manufacturer)
                                                liids = idss
                                                bridArray = bridArray.plusElement(brid)
                                                bridd = bridArray
                                                origisearch = origisearch.plusElement(orid)


                                                progressBar11.visibility = View.GONE
                                                wlist.visibility = View.VISIBLE
                                                noresfo.visibility = View.GONE
                                                println("SAVE KEYYYY" + oriid)
                                                val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                                wlist.adapter = whatever
                                            } else {

                                                println("ELSE INSIDE CAME Y")

                                                noresfo.visibility = View.VISIBLE
                                                progressBar11.visibility = View.GONE
                                                wlist.visibility = View.GONE
                                            }

                                        }

                                        println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                        println("SAVE KEYYYY" + oriid)



                                    } else {
                                        println("NO RECORDSSSS FOUNDD")
                                        nameget()
                                    }


                                /*} else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }*/
                            })

                }
                else if(s.contains("/")){
                    dateget()
                }











                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    wlist.visibility=View.VISIBLE
                    progressBar11.visibility=View.GONE
                    noresfo.visibility=View.GONE
                    if(imageView10.visibility==View.GONE)
                    {
                        gets()
                    }
                }
            }
        })

        var category = arrayListOf<String>()
        var d = arrayListOf<String>()
        var dlt = arrayListOf<String>()
        var idsforup=ArrayList<Any>()
        val list_item = ArrayList<String>()
        var checkcount=arrayListOf<Int>()


        /*wlist.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL
        wlist.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = wlist.checkedItemPosition
                var l = a[position]
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                if (checked) {
                    list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    Log.i(TAG,"itm "+dlt.size)
                    //Log.i(TAG,"itm "+dlt.get(position))
                } else {
                    list_item.remove(id.toString())
                    dlt.remove(l)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                }

            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                toolbar.visibility = View.GONE
                mode.getMenuInflater().inflate(R.menu.list, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                val deleteSize = dlt.size
                Log.i("tsdfs","  "+dlt.size)
                val cate = null

                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                val itemId = item.getItemId()
                if ((itemId == R.id.delete)&&(deletetrans=="true")) {
                    progressBar11.visibility=View.VISIBLE
                    for (i in dlt) {


                        db.collection("${oriid}_Stock_Transfer").document(i)
                                .delete()
                                .addOnSuccessListener {

                                    dlt.clear()
                                    Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                    gets()
                                    progressBar11.visibility=View.GONE



                                    // save_progress.visibility = android.view.View.GONE

                                }
                                .addOnFailureListener {
                                    Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                    //save_progress.visibility = android.view.View.GONE
                                }
                    }
                }
                else{
                    popup("delete")
                }
                if (itemId == R.id.selectAll){

                }

                list_item.clear()
                mode.finish()
                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                toolbar.visibility =View.VISIBLE
            }
        })*/



        searback1.setOnClickListener { //Image button Search back action
            searchedit.setText("")
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@WithStateActivity,R.anim.slide_to_left))
            cardsearch.visibility=View.GONE
            noresfo.visibility=View.GONE
            wlist.visibility=View.VISIBLE
            if(imageView10.visibility==View.GONE)
            {
                gets()
            }
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }


        //Click add button (FAB) and navigate to 'SelectBranchActivity'

        add1.setOnClickListener {
            println("ADDD"+addtrans)
            if(addtrans=="true") {
                val b = Intent(applicationContext, SelectBranchActivity::class.java)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec",sendstrec)


                b.putExtra("rbky", oriid)
                startActivity(b)

                finish()
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            }
            else if(addtrans=="false"){
                popup("Add")
            }
        }


                }


    fun brget() {
        try {

        } catch (e: Exception) {

        }

    }







///---------------------------------------------Get all transfers from online db------------------------------//

    fun gets() {

        progressBar11.visibility=View.VISIBLE



        db.collection("branch").document(oriid)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if (task.result != null) {
                            var document = task.result
                            origid = document.id
                            Log.d("data", "is" + task.result.data)
                            var orig = document.get("nm").toString()
                            var origcty = document.get("cty").toString()
                            var origst = document.get("st").toString()

                            orgval = orig
                            orgcty=origcty

                            println("VALUE OF ORIGIN IDDD" + orgval)
                        } else {
                            Log.d("data", "is not here")
                        }
                    } else {
                        Log.d("task is not success", "full" + task.exception)
                    }
                }
                .addOnSuccessListener {


                    db.collection("${oriid}_Stock_Transfer").whereEqualTo("stk_origin",oriid).orderBy("stkid",Query.Direction.DESCENDING).limit(10)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                var text = arrayOf<String>()
                                var idss = arrayOf<String>()
                                var nameArray = arrayOf<String>()
                                var dateArray = arrayOf<String>()
                                var priceArray = arrayOf<String>()
                                var descriptionArray = arrayOf<String>()
                                var bridArray = arrayOf<String>()




                                if (e != null) {
                                    Log.w("", "Listen failed.", e)
                                    return@EventListener
                                }


                                if (value.isEmpty == false) {
                                    progressBar11.visibility=View.GONE

                                 /*   try {
                                        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialog.setTitleText("Loading...")
                                        pDialog.setCancelable(false)
                                        pDialog.show();
                                    }
                                    catch (e:Exception){

                                    }*/

                                    imageView10.visibility = View.GONE
                                    for (document in value) {

                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                        println(document.data)

                                        var dt = document.data
                                        var id = (document.id)
                                        idss = idss.plusElement(id)
                                        println(idss)

                                        /*  idss=idss.plusElement(path)
                            i=idss
                            println(id)
                            println(i)*/

                                        println("ORG VAL" + orgval)
                                        if(orgcty.isNotEmpty()){
                                            text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                        }
                                        else if(orgcty.isEmpty()){
                                            text = text.plusElement("Origin: " + orgval)

                                        }
                                        var name = (dt["stk_destination"]).toString()
                                        var date = (dt["stkdate"]).toString()
                                        var tot = (dt["stk_total"]).toString()
                                        var descr = (dt["stk_Desc"]).toString()
                                        var manufacturer = (dt["stkid"]).toString()
                                        var brid = (dt["stk_brid"]).toString()

                                        var orinm=(dt["stk_originname"]).toString()

                                        nameArray = nameArray.plusElement("Destination : " + name)
                                        dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                        priceArray = priceArray.plusElement(tot)
                                        nameArrayori = nameArrayori.plusElement(name)
                                        orinameArrayori=orinameArrayori.plusElement(orinm)
                                        dateArrayori = dateArray
                                        priceArrayori = priceArray
                                        datearr = datearr.plusElement(date)
                                        descriptionArray = descriptionArray.plusElement(descr)
                                        descrip = descriptionArray
                                        ids = ids.plusElement(manufacturer)
                                        liids = idss
                                        bridArray = bridArray.plusElement(brid)
                                        bridd = bridArray
                                        /*   swipeContainer.setRefreshing(false);*/

                                    }
                                   /* pDialog.dismiss()*/


                                    val whatever = withstateAdapter(this, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                    val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                    wlist.adapter = whatever
                                } else {
                                    imageView10.visibility = View.VISIBLE
                                    progressBar11.visibility=View.GONE
                                }

                            })

                    /*     var path="${oriid}_Stock_Transfer/$i/Stock_products"
            println(path)
            db.collection(path)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        println("hello")
                        var listidArray= arrayOf<String>()
                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        for (document in value) {
                            var idli = (document.id)
                            listidArray.plusElement(idli)

                            liids=listidArray
                            println(liids)

                        }
                    })*/
                }
    }

    fun popup(st:String){   //Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {

        //Back action
        if((cardsearch.visibility==View.VISIBLE)){
            cardsearch.visibility=View.GONE


            if(imageView10.visibility==View.GONE)
            {
                gets()
            }
            else{
                val b=Intent(this@WithStateActivity,StockTransferActivity::class.java)
                b.putExtra("skey",oriid)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec",sendstrec)


                startActivity(b)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }




        }
        else{
            val b=Intent(this@WithStateActivity,StockTransferActivity::class.java)
            b.putExtra("skey",oriid)




            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()


        }
    }

    fun dateget() {
        if((s.length>=2)||(s.length>=2)) {
            noresfo.visibility = View.GONE
            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var bridArray = arrayOf<String>()

            db.collection("${oriid}_Stock_Transfer").orderBy("stkdate").startAt(numberstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)

                                    var dt = document.data
                                    var orid = (dt["stk_origin"]).toString()



                                    if (oriid == bsupkyval) {

                                        var id = (document.id)
                                        idss = idss.plusElement(id)
                                        println(idss)

                                        /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/

                                        var name = (dt["stk_destination"]).toString()
                                        var date = (dt["stkdate"]).toString()
                                        var tot = (dt["stk_total"]).toString()
                                        var descr = (dt["stk_Desc"]).toString()
                                        var manufacturer = (dt["stkid"]).toString()
                                        var brid = (dt["stk_brid"]).toString()
                                        var orinm = (dt["stk_originname"]).toString()
                                        orinameArrayori = orinameArrayori.plusElement(orinm)
                                        if(orgcty.isNotEmpty()){
                                            text = text.plusElement("Origin: " + orgval + " , " + orgcty)

                                        }
                                        else if(orgcty.isEmpty()){
                                            text = text.plusElement("Origin: " + orgval)

                                        }
                                        nameArray = nameArray.plusElement("Destination : " + name)
                                        dateArray = dateArray.plusElement(date + ", " + "Stock transfer No " + manufacturer)
                                        priceArray = priceArray.plusElement(tot)
                                        nameArrayori = nameArrayori.plusElement(name)
                                        dateArrayori = dateArray
                                        priceArrayori = priceArray
                                        datearr = datearr.plusElement(date)
                                        descriptionArray = descriptionArray.plusElement(descr)
                                        descrip = descriptionArray
                                        ids = ids.plusElement(manufacturer)
                                        liids = idss
                                        bridArray = bridArray.plusElement(brid)
                                        bridd = bridArray
                                        origisearch = origisearch.plusElement(orid)



                                        progressBar11.visibility = View.GONE
                                        wlist.visibility = View.VISIBLE
                                        println("SAVE KEYYYY" + oriid)
                                        val whatever = withstateAdapter(this@WithStateActivity, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                        val wlist = findViewById<ListView>(R.id.wlist) as ListView
                                        wlist.adapter = whatever
                                    } else {
                                        noresfo.visibility = View.VISIBLE
                                        progressBar11.visibility = View.GONE
                                        wlist.visibility = View.GONE
                                    }


                                }

                                println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                println("SAVE KEYYYY" + oriid)



                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                noresfo.visibility = View.VISIBLE
                                progressBar11.visibility = View.GONE
                                wlist.visibility = View.GONE
                            }

/*
                        } else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })

        }
    }
    companion object {
 //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                  /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                 /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }
    fun net_status():Boolean{  //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
