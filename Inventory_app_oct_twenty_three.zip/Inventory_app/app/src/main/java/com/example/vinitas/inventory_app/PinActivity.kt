package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_pin.*
import java.text.SimpleDateFormat
import java.util.*
import android.os.Vibrator
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil


class PinActivity : AppCompatActivity() {




    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null






    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private  var view=String()
    private  var add=String()
    private  var delete=String()
    private  var edit=String()
    private  var import=String()
    private  var export= String()

    private  var viewpro=String()
    private  var addpro=String()
    private  var deletepro=String()
    private  var editpro=String()
    private  var importpro=String()
    private  var exportpro=String()
    private  var stockin_hand=String()



    private  var viewsupp=String()
    private  var addsupp=String()
    private  var deletesupp=String()
    private  var editsupp=String()
    private  var importsupp=String()
    private  var exportsupp=String()

    private  var viewtrans=String()
    private  var addtrans=String()
    private  var deletetrans=String()
    private  var edittrans=String()
    private  var transfertrans=String()
    private  var exporttrans=String()
    private  var sendtrans=String()

    private  var viewtransano=String()
    private  var addtransano=String()
    private  var deletetransano=String()
    private  var edittransano=String()
    private  var transfertransano=String()
    private  var exporttransano=String()
    private  var sendtransano=String()

    private  var viewrec=String()
    private  var addrec=String()
    private  var deleterec=String()
    private  var editrec=String()
    private  var transferrec=String()
    private  var exportrec=String()
    private  var sendstrec=String()

    private  var viewpurreq=String()
    private  var addpurreq=String()
    private  var deletepurreq=String()
    private  var editpurreq=String()
    private  var transferpurreq=String()
    private  var exportpurreq=String()


    //Purchase order

    private  var viewpurord=String()
    private  var addpurord=String()
    private  var deletepurord=String()
    private  var editpurord=String()
    private  var transferpurord=String()
    private  var exportpurord=String()
    private  var  sendpurpo=String()


    //Supplier Invoice

    private  var viewsuppin=String()
    private  var addsuppin=String()
    private  var deletesuppin=String()
    private  var editsuppin=String()
    private  var transfersuppin=String()
    private  var exportsuppin=String()


    //Stock levels

    private  var viewstklvls=String()

    lateinit var date:String
    lateinit var Time:String
    lateinit var Name:String
    lateinit var branch:String
    lateinit var Pass:String
    var lt ="977666"
    private var firstTimeprod: Boolean? = null

var db= FirebaseFirestore.getInstance()
    // Session Manager Class
    internal lateinit var session: SessionManagement
    var ids= String()

    var bg = ArrayList<Int>()
    var pass = ArrayList<String>()


    data class  s(var date : String,var time: String,var name:String,var branch:String,var pass: String)

    private fun isFirstTimeProd(): Boolean {
        if (firstTimeprod == null) {
            val mPreferences = this.getSharedPreferences("first_times", Context.MODE_PRIVATE)
            firstTimeprod = mPreferences.getBoolean("firstTimes", true)
            if (firstTimeprod!!) {
                val editor = mPreferences.edit()
                editor.putBoolean("firstTimes", false)
                editor.commit()

             /*   val i = IntentFilter("android.net.conn.CONNECTIVITY_CHANGE")
                registerReceiver(NetworkChangeReceiver(), i)*/




            }

        }
        return firstTimeprod!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pin)
        // Session class instance
        session = SessionManagement(applicationContext)


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@PinActivity) > 0)
        {

        }
        else{
Toast.makeText(applicationContext,"you are offline",Toast.LENGTH_SHORT).show()
        }

        isFirstTimeProd()




        val vibe = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        //emp()

        /*val timer = Timer()
        val hourlyTask = object : TimerTask() {
            override fun run() {
                //println("run")
                runOnUiThread {
                    val c = Calendar.getInstance()
                    //System.out.println("Current time =&gt; " + c.time)//Current time =&gt; Mon Feb 12 11:01:42 GMT+05:30 2018
                    val df = SimpleDateFormat("mm:ss")
                    val hour = df.format(c.time)
                    //println(hour)
                    if (hour == "00:00") {
                        //stuff that updates ui
                        ///println("true")
                        //timer.cancel()
                        //timeclock(id,nm)
                        emp()
                    }
                }
            }
        }
        // schedule the task to run starting now and then every hour...
        timer.schedule(hourlyTask, 0L, 1000)*/








        try {
            val o = intent.getStringExtra("brid")
            ids = o
        } catch (e: Exception) {

        }

        println("ID OF BRANCH" + ids)

        /*   Toast.makeText(applicationContext, "User Login Status: " + session.isLoggedIn, Toast.LENGTH_LONG).show()*/
        Toast.makeText(applicationContext, "Enter your pin", Toast.LENGTH_LONG).show()


        /**
         * Call this function whenever you want to check user login
         * This will redirect user to LoginActivity is he is not
         * logged in
         */
        session.checkLogin()

        // get user data from session
        val user = session.userDetails

        // name
        val name = user[SessionManagement.KEY_NAME]
        ids = name.toString()

        // email



        var dpass = ArrayList<String>()






        button1.setOnClickListener {
            vibe.vibrate(60);
            val s = button1.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun) //White background add
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            }
            else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            }
            else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            }
            else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            }
            else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            }
            else if (pass.size == 6) {                 //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button2.setOnClickListener {
            vibe.vibrate(60);
            val s = button2.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            }
            else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            }
            else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            }
            else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            }
            else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {
                p6.setBackgroundResource(bg[5])    //If 'pass' array contains six values then check the password using 'check_password(password)' function
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button3.setOnClickListener {
            vibe.vibrate(60);
            val s = button3.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {
                p6.setBackgroundResource(bg[5])       //If 'pass' array contains six values then check the password using 'check_password(password)' function
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button4.setOnClickListener {
            vibe.vibrate(60);
            val s = button4.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {              //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button5.setOnClickListener {
            vibe.vibrate(60);
            val s = button5.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {                  //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)

            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button6.setOnClickListener {
            vibe.vibrate(60);
            val s = button6.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {                  //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button7.setOnClickListener {
            vibe.vibrate(60);
            val s = button7.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {                      //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button8.setOnClickListener {
            vibe.vibrate(60);
            val s = button8.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {              //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button9.setOnClickListener {
            vibe.vibrate(60);
            val s = button9.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {                  //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)
            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)

        }
        button0.setOnClickListener {
            vibe.vibrate(60);
            val s = button0.text.toString()
            if (pass.size != 6 && bg.size != 6) {
                pass.add(s)
                bg.add(R.drawable.shaperun)
            }
            println(pass)
            if (pass.size == 1) {
                p1.setBackgroundResource(bg[0])
            } else if (pass.size == 2) {
                p2.setBackgroundResource(bg[1])
            } else if (pass.size == 3) {
                p3.setBackgroundResource(bg[2])
            } else if (pass.size == 4) {
                p4.setBackgroundResource(bg[3])
            } else if (pass.size == 5) {
                p5.setBackgroundResource(bg[4])
            } else if (pass.size == 6) {              //If 'pass' array contains six values then check the password using 'check_password(password)' function
                p6.setBackgroundResource(bg[5])
                val q = pass.get(0)
                val w = pass.get(1)
                val e = pass.get(2)
                val r = pass.get(3)
                val t = pass.get(4)
                val y = pass.get(5)
                val password = q + w + e + r + t + y
                println(password)
                check_password(password)


            }
            Log.d("gtrgb  " + pass.toString(), "Hellllooo  " + pass.size)
        }
            buttondel.setOnClickListener {
                vibe.vibrate(60);
                val i = bg.size
                println(i)
                if (i == 6) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)  ///Remove background of last element in array
                    pass.removeAt(i - 1)  //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p6.setBackgroundResource(R.drawable.shaperorund)  //Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                } else if (i == 5) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)      ///Remove background of last element in array
                    pass.removeAt(i - 1)         //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p5.setBackgroundResource(R.drawable.shaperorund)        //Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                } else if (i == 4) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)///Remove background of last element in array
                    pass.removeAt(i - 1) //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p4.setBackgroundResource(R.drawable.shaperorund)//Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                } else if (i == 3) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)      ///Remove background of last element in array
                    pass.removeAt(i - 1)         //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p3.setBackgroundResource(R.drawable.shaperorund)        //Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                } else if (i == 2) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)      ///Remove background of last element in array
                    pass.removeAt(i - 1)         //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p2.setBackgroundResource(R.drawable.shaperorund)        //Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                } else if (i == 1) {
                    Log.d("click", "clicked  true")
                    bg.removeAt(i - 1)      ///Remove background of last element in array
                    pass.removeAt(i - 1)         //Remove value of last element in array
                    println(bg)
                    println(pass)
                    p1.setBackgroundResource(R.drawable.shaperorund)        //Change background unfilled
                    /*val b = Intent(applicationContext, MainActivity::class.java)
                startActivity(b)*/
                }
            }


        }
    fun net_status():Boolean{   //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


    //--------------------------Compare the password to db,if the entered value and the db value is same then the access will be given to that user.-------//

    fun check_password(password:String){
        if (net_status()==true) {
            var pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Authenticating...")
            pDialog.setCancelable(false);
            pDialog.show();
            val d = Date()
            val dt = SimpleDateFormat("dd/MM/yyyy").format(d)
            db.collection("pass").whereEqualTo("pass",password).whereEqualTo("date",dt)
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result.isEmpty==false) {
                                if (task.result != null) {
                                    Log.d("data", "is" + task.result)
                                    for (doc in task.result) {
                                        val getpass = doc.data.get("pass").toString()
                                        val dbtime=doc.data.get("time").toString()
                                        val name=doc.data.get("name").toString()
                                        val c = Calendar.getInstance()
                                        val df = SimpleDateFormat("HH")
                                        val hour = df.format(c.time)
                                        val my_time = dbtime
                                        val sdf2 = SimpleDateFormat("HH")
                                        val strtime = sdf2.parse(my_time)
                                        val dbhour = df.format(strtime)
                                        if (getpass == password) {
                                            val session = SessionManagement(this)
                                            session.emplky(doc.id.toString())
                                            //if (dbhour >= hour) {
                                                pDialog.dismiss()



                                            //Access granted popup and navigate to main dashboard activity (MainActivity)

                                                pDialog = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                                                pDialog.progressHelper.barColor = resources.getColor(R.color.toolbar)
                                                pDialog.titleText = "Verified!"
                                                pDialog.contentText = "$name logged in successfully!"
                                                pDialog.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                                pDialog.setCancelable(false);
                                                pDialog.show()
                                                pDialog.findViewById<Button>(R.id.confirm_button).setVisibility(View.GONE);
                                                //pDialog.setConfirmClickListener {
                                                Handler().postDelayed(
                                                        Runnable {
                                                            //session.createLoginSession(doc.id, "mail")
                                                            val b = Intent(this, MainActivity::class.java)



                                                            pDialog.dismiss()
                                                            startActivity(b)
                                                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                                                            finish()
                                                        },2000)
                                                ///}
                                                progressBar2.visibility = View.GONE


                                          /* // }else{
                                                pDialog.dismiss()
                                                //Toast.makeText(this, "password is wrong", Toast.LENGTH_LONG).show()
                                                SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                                                        .setTitleText("Incorrect password")

                                                        .setConfirmText("Retry")
                                                        .setConfirmClickListener(null)
                                                        .show()
                                                Toast.makeText(this, "Check Your PassWord", Toast.LENGTH_LONG).show()
                                                val i = bg.size
                                                println(i)

                                                Log.d("click", "clicked  true")
                                                bg.removeAll(bg)
                                                pass.removeAll(pass)
                                                println(bg)
                                                println(pass)
                                                p6.setBackgroundResource(R.drawable.shaperorund)
                                                p5.setBackgroundResource(R.drawable.shaperorund)
                                                p4.setBackgroundResource(R.drawable.shaperorund)
                                                p3.setBackgroundResource(R.drawable.shaperorund)
                                                p2.setBackgroundResource(R.drawable.shaperorund)
                                                p1.setBackgroundResource(R.drawable.shaperorund)
                                            }*/
                                        } else {
                                            pDialog.dismiss()

                                            //Access denied popup unfill backgrouns of the views.

                                            SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                                                    .setTitleText("Incorrect password")

                                                    .setConfirmText("Retry")
                                                    .setConfirmClickListener(null)
                                                    .show()
                                            Toast.makeText(this, "Check Your PassWord", Toast.LENGTH_LONG).show()
                                            bg.removeAll(bg)
                                            pass.removeAll(pass)
                                            println(bg)
                                            println(pass)
                                            p6.setBackgroundResource(R.drawable.shaperorund)
                                            p5.setBackgroundResource(R.drawable.shaperorund)
                                            p4.setBackgroundResource(R.drawable.shaperorund)
                                            p3.setBackgroundResource(R.drawable.shaperorund)
                                            p2.setBackgroundResource(R.drawable.shaperorund)
                                            p1.setBackgroundResource(R.drawable.shaperorund)
                                            progressBar2.visibility = View.GONE
                                            return@addOnCompleteListener
                                        }
                                    }
                                }
                            } else {
                                pDialog.dismiss()
                                SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                                        .setTitleText("Incorrect password")

                                        .setConfirmText("Retry")
                                        .setConfirmClickListener(null)
                                        .show()
                                Toast.makeText(this, "Check Your PassWord", Toast.LENGTH_LONG).show()
                                bg.removeAll(bg)
                                pass.removeAll(pass)
                                println(bg)
                                println(pass)
                                p6.setBackgroundResource(R.drawable.shaperorund)
                                p5.setBackgroundResource(R.drawable.shaperorund)
                                p4.setBackgroundResource(R.drawable.shaperorund)
                                p3.setBackgroundResource(R.drawable.shaperorund)
                                p2.setBackgroundResource(R.drawable.shaperorund)
                                p1.setBackgroundResource(R.drawable.shaperorund)
                                progressBar2.visibility = View.GONE
                                return@addOnCompleteListener
                            }
                        }
                    }
                    .addOnSuccessListener {
                        progressBar2.visibility = View.GONE
                        return@addOnSuccessListener
                    }
        }
        else if(net_status()==false){


            //If the connection status is in offline,then the 'You're offline' popup will be shown.

            pDialogs=SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
            pDialogs!!.setTitleText("You're offline")
            pDialogs!!.setCancelable(false)

            pDialogs!!.setConfirmText("Retry")
                    .setConfirmClickListener{
                        bg.removeAll(bg)
                        pass.removeAll(pass)
                        println(bg)
                        println(pass)
                        p6.setBackgroundResource(R.drawable.shaperorund)
                        p5.setBackgroundResource(R.drawable.shaperorund)
                        p4.setBackgroundResource(R.drawable.shaperorund)
                        p3.setBackgroundResource(R.drawable.shaperorund)
                        p2.setBackgroundResource(R.drawable.shaperorund)
                        p1.setBackgroundResource(R.drawable.shaperorund)
                        pDialogs!!.dismiss()



                    }
            pDialogs!!.show()
            bg.removeAll(bg)
            pass.removeAll(pass)
            println(bg)
            println(pass)
            p6.setBackgroundResource(R.drawable.shaperorund)
            p5.setBackgroundResource(R.drawable.shaperorund)
            p4.setBackgroundResource(R.drawable.shaperorund)
            p3.setBackgroundResource(R.drawable.shaperorund)
            p2.setBackgroundResource(R.drawable.shaperorund)
            p1.setBackgroundResource(R.drawable.shaperorund)
            Toast.makeText(this, "Turn on your connection", Toast.LENGTH_LONG).show()

            progressBar2.visibility = View.GONE
        }
    }

    /*fun check_password(password:String){
        val pDialog = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE)

        if(password.length==6) {

            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Authenticating...")
            pDialog.setCancelable(false);
            pDialog.show();


        }
        db.collection("pass").whereEqualTo("pass",password)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if (task.result.isEmpty==false) {
                            if (task.result != null) {
                                for (doc in task.result) {
                                    Log.d("data", "is" + doc.data)
                                    val getpass = doc.data.get("pass").toString()
                                    //date comparisons
                                    if (getpass == password) {

                                        pDialog.dismiss();

                                        val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)


                                        pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)

                                        pDialog1.titleText = "Verified!"
                                        pDialog1.contentText = "You are logged in successfully!"
                                        pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                        pDialog1.show()


                                        val b = Intent(applicationContext, MainActivity::class.java)


                                        b.putExtra("view", view)
                                        b.putExtra("add", add)
                                        b.putExtra("delete", delete)
                                        b.putExtra("edit", edit)
                                        b.putExtra("import", import)
                                        b.putExtra("export", export)

                                        //Product

                                        b.putExtra("viewpro", viewpro)
                                        b.putExtra("addpro", addpro)
                                        b.putExtra("deletepro", deletepro)
                                        b.putExtra("editpro", editpro)
                                        b.putExtra("importpro", importpro)
                                        b.putExtra("exportpro", exportpro)
                                        b.putExtra("changestock", stockin_hand)


                                        //supplier
                                        //Product
                                        b.putExtra("viewsupp", viewsupp)
                                        b.putExtra("addsupp", addsupp)
                                        b.putExtra("deletesupp", deletesupp)
                                        b.putExtra("editsupp", editsupp)
                                        b.putExtra("importsupp", importsupp)
                                        b.putExtra("exportsupp", exportsupp)


                                        //Transfer
                                        //supplier
                                        //Product
                                        b.putExtra("viewtrans", viewtrans)
                                        b.putExtra("addtrans", addtrans)
                                        b.putExtra("deletetrans", deletetrans)
                                        b.putExtra("edittrans", edittrans)
                                        b.putExtra("transfertrans", transfertrans)
                                        b.putExtra("exporttrans", exporttrans)
                                        b.putExtra("sendtrans", sendtrans)



                                        b.putExtra("viewtransano", viewtransano)
                                        b.putExtra("addtransano", addtransano)
                                        b.putExtra("deletetransano", deletetransano)
                                        b.putExtra("edittransano", edittransano)
                                        b.putExtra("transfertransano", transfertransano)
                                        b.putExtra("exporttransano", exporttransano)
                                        b.putExtra("sendtransano", sendtransano)


                                        //Receive

                                        b.putExtra("viewrec", viewrec)
                                        b.putExtra("addrec", addrec)
                                        b.putExtra("deleterec", deleterec)
                                        b.putExtra("editrec", editrec)
                                        b.putExtra("transferrec", transferrec)
                                        b.putExtra("exportrec", exportrec)
                                        b.putExtra("sendstrec", sendstrec)


                                        //Purchase request

                                        b.putExtra("viewpurreq", viewpurreq)
                                        b.putExtra("addpurreq", addpurreq)
                                        b.putExtra("deletepurreq", deletepurreq)
                                        b.putExtra("editpurreq", editpurreq)
                                        b.putExtra("transferpurreq", transferpurreq)
                                        b.putExtra("exportpurreq", exportpurreq)


                                        //Purchase Order

                                        b.putExtra("viewpurord", viewpurord)
                                        b.putExtra("addpurord", addpurord)
                                        b.putExtra("deletepurord", deletepurord)
                                        b.putExtra("editpurord", editpurord)
                                        b.putExtra("transferpurord", transferpurord)
                                        b.putExtra("exportpurord", exportpurord)
                                        b.putExtra("sendpurpo", sendpurpo)


                                        //Supplier Invoice

                                        b.putExtra("viewsuppin", viewsuppin)
                                        b.putExtra("addsuppin", addsuppin)
                                        b.putExtra("deletesuppin", deletesuppin)
                                        b.putExtra("editsuppin", editsuppin)
                                        b.putExtra("transfersuppin", transfersuppin)
                                        b.putExtra("exportsuppin", exportsuppin)

                                        b.putExtra("viewstklvl", viewstklvls)


                                        b.putExtra("bid", ids)
                                        Handler().postDelayed({
                                            pDialog1.hide()
                                            startActivity(b)
                                            finish()
                                        }, 2000)

                                    } else if(getpass != password) {


                                    }
                                }
                            }
                        } else {
                            pDialog.dismiss()

                            Toast.makeText(this, "password is wrong", Toast.LENGTH_LONG).show()
                            SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                                    .setTitleText("Incorrect password")
                                    .setContentText("Please enter correct password!!")
                                    .setConfirmText("Retry")
                                    .setConfirmClickListener(null)
                                    .show()
                            val i = bg.size
                            println(i)
                            if (i == 6) {
                                Log.d("click", "clicked  true")
                                bg.removeAll(bg)
                                pass.removeAll(pass)
                                println(bg)
                                println(pass)
                                p6.setBackgroundResource(R.drawable.shaperorund)
                                p5.setBackgroundResource(R.drawable.shaperorund)
                                p4.setBackgroundResource(R.drawable.shaperorund)
                                p3.setBackgroundResource(R.drawable.shaperorund)
                                p2.setBackgroundResource(R.drawable.shaperorund)
                                p1.setBackgroundResource(R.drawable.shaperorund)

                                *//*val b = Intent(applicationContext, MainActivity::class.java)
                        startActivity(b)*//*
                            }

                            return@addOnCompleteListener
                        }
                    }
                }
                .addOnSuccessListener {
                    progressBar2.visibility=View.GONE
                    return@addOnSuccessListener
                }
    }*/


    fun getAccess() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("service")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        view=dd.get("view").toString()
                        add=dd.get("add").toString()
                        delete=dd.get("delete").toString()
                        edit=dd.get("edit").toString()
                        import=dd.get("import").toString()
                        export=dd.get("export").toString()
                        println("view : "+view)
                        println("add : "+add)
                        println("delete : "+delete)
                        println("edit : "+edit)
                        println("import : "+import)
                        println("export : "+export)
                    }
                }
    }


    fun getAccessstklvl() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("stocklevels")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewstklvls=dd.get("view").toString()

                        println("view : "+viewstklvls)

                    }
                }
    }





    fun getAccesspro() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("product")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewpro=dd.get("view").toString()
                        addpro=dd.get("add").toString()
                        deletepro=dd.get("delete").toString()
                        editpro=dd.get("edit").toString()
                        importpro=dd.get("import").toString()
                        exportpro=dd.get("export").toString()
                        stockin_hand=dd.get("stockin_hand").toString()
                        println("view : "+viewpro)
                        println("add : "+addpro)
                        println("delete : "+deletepro)
                        println("edit : "+editpro)
                        println("import : "+importpro)
                        println("export : "+exportpro)
                    }
                }
    }


    fun getAccesssupp() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("supplier")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewsupp=dd.get("view").toString()
                        addsupp=dd.get("add").toString()
                        deletesupp=dd.get("delete").toString()
                        editsupp=dd.get("edit").toString()
                        importsupp=dd.get("import").toString()
                        exportsupp=dd.get("export").toString()
                        println("view : "+viewsupp)
                        println("add : "+addsupp)
                        println("delete : "+deletesupp)
                        println("edit : "+editsupp)
                        println("import : "+importsupp)
                        println("export : "+exportsupp)
                    }
                }
    }


    fun getAccesstrans() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("transfer")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewtrans=dd.get("view").toString()
                        addtrans=dd.get("add").toString()
                        deletetrans=dd.get("delete").toString()
                        edittrans=dd.get("edit").toString()
                        transfertrans=dd.get("transfer").toString()
                        exporttrans=dd.get("export").toString()
                        sendtrans=dd.get("send_st").toString()
                        println("view : "+viewtrans)
                        println("add : "+addtrans)
                        println("delete : "+deletetrans)
                        println("edit : "+edittrans)
                        println("import : "+transfertrans)
                        println("export : "+exporttrans)
                    }
                }
    }


    fun getAccesstransano() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("another_transfer")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewtransano=dd.get("view").toString()
                        addtransano=dd.get("add").toString()
                        deletetransano=dd.get("delete").toString()
                        edittransano=dd.get("edit").toString()
                        transfertransano=dd.get("transfer").toString()
                        exporttransano=dd.get("export").toString()
                        sendtransano=dd.get("send_st").toString()
                        println("view : "+viewtransano)
                        println("add : "+addtransano)
                        println("delete : "+deletetransano)
                        println("edit : "+edittransano)
                        println("import : "+transfertransano)
                        println("export : "+exporttransano)
                    }
                }
    }


    fun getAccessreceive() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("receive")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewrec=dd.get("view").toString()
                        addrec=dd.get("add").toString()
                        deleterec=dd.get("delete").toString()
                        editrec=dd.get("edit").toString()
                        transferrec=dd.get("transfer").toString()
                        exportrec=dd.get("export").toString()
                        sendstrec=dd.get("send_st").toString()
                        println("view : "+viewrec)
                        println("add : "+addrec)
                        println("delete : "+deleterec)
                        println("edit : "+editrec)
                        println("import : "+transferrec)
                        println("export : "+exportrec)
                        println("sendst : "+ sendstrec)

                    }
                }
    }

    fun getAccesspurchasereq() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("purchase_request")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewpurreq=dd.get("view").toString()
                        addpurreq=dd.get("add").toString()
                        deletepurreq=dd.get("delete").toString()
                        editpurreq=dd.get("edit").toString()
                        transferpurreq=dd.get("transfer").toString()
                        exportpurreq=dd.get("export").toString()

                        println("view : "+viewpurreq)
                        println("add : "+addpurreq)
                        println("delete : "+deletepurreq)
                        println("edit : "+editpurreq)
                        println("import : "+transferpurreq)
                        println("export : "+exportpurreq)


                    }
                }
    }


    fun getAccesspurchaseord() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("purchase_order")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewpurord=dd.get("view").toString()
                        addpurord=dd.get("add").toString()
                        deletepurord=dd.get("delete").toString()
                        editpurord=dd.get("edit").toString()
                        transferpurord=dd.get("transfer").toString()
                        exportpurord=dd.get("export").toString()
                        sendpurpo=dd.get("send_po").toString()

                        println("view : "+viewpurord)
                        println("add : "+addpurord)
                        println("delete : "+deletepurord)
                        println("edit : "+editpurord)
                        println("import : "+transferpurord)
                        println("export : "+exportpurord)


                    }
                }
    }

    fun getAccesssuppinvoice() {
        //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
        val id ="ArdTKkE1mqX3TvLX3r3J"
        val path ="emp_access/$id/inventory"
        val collection = ArrayList<String>()
        db.collection(path).document("supplier_invoice")
                .get()
                .addOnCompleteListener { task ->
                    if (task.getResult().exists()){
                        val dd = task.result.data
                        viewsuppin=dd.get("view").toString()
                        addsuppin=dd.get("add").toString()
                        deletesuppin=dd.get("delete").toString()
                        editsuppin=dd.get("edit").toString()
                        transfersuppin=dd.get("transfer").toString()
                        exportsuppin=dd.get("export").toString()

                        println("view : "+viewsuppin)
                        println("add : "+addsuppin)
                        println("delete : "+deletesuppin)
                        println("edit : "+editsuppin)
                        println("import : "+transfersuppin)
                        println("export : "+exportsuppin)


                    }
                }
    }
    fun emp(){
        db.collection("employee").get()
                .addOnCompleteListener {task ->
                    if (task.result!=null){
                        for (doc in task.result){
                            val id=doc.id.toString()
                            val nm=doc.data.get("nm").toString()
                            timeclock(id,nm)
                        }
                    }
                }
                .addOnSuccessListener {

                }
    }
    fun timeclock(id:String,nm:String) {
        //progress.visibility= View.VISIBLE
        //pass.visibility= View.GONE
        //textView.visibility= View.GONE
        db.collection("pass").document(id)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if (task.getResult().exists()) {
                            if (task.result != null) {
                                Log.d("data", "is" + task.result.data)
                                val date = task.result.get("date").toString()
                                //date comparisons
                                val d = Date()
                                val my_date = date  // "11/02/2018" //
                                val dt = SimpleDateFormat("dd/MM/yyyy").format(d)
                                val currentdate = getStamp(dt)
                                val dbdate = getStamp(my_date)
                                if (currentdate > dbdate) {
                                    println("true " + currentdate + "  before date " + dbdate)
                                    db.collection("pass").document(id).delete()
                                            .addOnSuccessListener {
                                                return@addOnSuccessListener
                                            }
                                } else if (currentdate == dbdate) {
                                    println("true " + currentdate + "  today " + dbdate)
                                } else {
                                    println("false " + currentdate + " after date " + dbdate)
                                }
                            }
                        } else {
                            return@addOnCompleteListener
                        }
                    }
                }
                .addOnSuccessListener {
                    println("successListener")
                    db.collection("pass").document(id)
                            .get()
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    if (task.getResult().exists()) {
                                        if (task.result != null) {
                                            Log.d("data", "is" + task.result.data)
                                            date = task.result.get("date").toString()
                                            Time = task.result.get("time").toString()
                                            Name = task.result.get("name").toString()
                                            branch = task.result.get("branch").toString()
                                            Pass = task.result.get("pass").toString()

                                            val c = Calendar.getInstance()
                                            System.out.println("Current time =&gt; " + c.time)//Current time =&gt; Mon Feb 12 11:01:42 GMT+05:30 2018
                                            val df = SimpleDateFormat("HH:mm")
                                            val hour = df.format(c.time)
                                            println(hour)//current time 11:01
                                            val min = SimpleDateFormat("mm")
                                            val minute = min.format(c.time)
                                            println(minute)//current minute 01
                                            val amd = SimpleDateFormat("a")
                                            val amday = amd.format(c.time)
                                            println(amday)//am or pm AM
                                            val sdf = SimpleDateFormat("EEEE,")
                                            val d = Date()
                                            val dayOfTheWeek = sdf.format(d)
                                            println(dayOfTheWeek)//day name Monday
                                            val dt = SimpleDateFormat("dd/MM/yyyy")
                                            val date = dt.format(d)
                                            println(date)//current date formate is 12.02.2018
                                            //minute comparisons
                                            if (minute >= "00") {
                                                println("minute is greater than 00")
                                                val c = Calendar.getInstance()
                                                val df = SimpleDateFormat("HH")
                                                val hour = df.format(c.time)
                                                val my_time = Time
                                                val sdf2 = SimpleDateFormat("HH")
                                                val strtime = sdf2.parse(my_time)
                                                val dbhour = df.format(strtime)
                                                println(strtime)
                                                if (dbhour >= hour) {//nothing changed
                                                    println("current  " + dbhour + " get < time  " + hour)
                                                    //val pass = findViewById<TextView>(R.id.pass) as TextView
                                                    runOnUiThread {
                                                        //stuff that updates ui
                                                        //pass.text = Pass
                                                        //progress.visibility= View.GONE
                                                        //pass.visibility= View.VISIBLE
                                                        //textView.visibility= View.VISIBLE

                                                    }


                                                /*    val mBuilder = NotificationCompat.Builder(this@PinActivity)


                                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                                    val mNotifyManager = this@PinActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                                    mBuilder.setContentText("PIN")
                                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                                    mBuilder.setContentTitle("Hello "+nm+" your login pin "+Pass)
                                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                                                    mNotifyManager.notify(0, mBuilder.build());*/

                                                } else if (dbhour < hour) {//when its hour is hole number therefore its getting next number password is updated
                                                    println("current  " + dbhour + " get < time  " + hour)
                                                    val d = Date()
                                                    val dt = SimpleDateFormat("dd/MM/yyyy")
                                                    val date = dt.format(d)
                                                    val c = Calendar.getInstance()
                                                    System.out.println("Current time =&gt; " + c.time)//Current time =&gt; Mon Feb 12 11:01:42 GMT+05:30 2018
                                                    val df = SimpleDateFormat("HH:mm")
                                                    val hour = df.format(c.time)
                                                    val emp_name = nm
                                                    val emp_branch = "k.k.nagar"
                                                    //val pass = findViewById<TextView>(R.id.pass) as TextView
                                                    val list = ArrayList<Int>()
                                                    var l: Int = 0
                                                    for (i in 100000..999999) {
                                                        list.add(i)
                                                    }
                                                    Collections.shuffle(list)
                                                    for (i in 0..0) {
                                                        l = list[i]
                                                        Log.d("sli", "   " + list[i])
                                                    }
                                                    Log.d("l", "  " + l)
                                                    db.collection("pass").whereEqualTo("pass",l.toString()).get()
                                                            .addOnCompleteListener {tasc ->
                                                                if (tasc.result!=null){
                                                                    if (tasc.result.isEmpty==false){
                                                                        println("tasc.result not empty  "+tasc.result)
                                                                        timeclock(id,nm)
                                                                    }else{
                                                                        println("tasc result is empty")
                                                                        return@addOnCompleteListener
                                                                    }
                                                                }else{
                                                                    println("tasc result null")
                                                                }
                                                            }
                                                            .addOnSuccessListener {
                                                                println("successlistener")
                                                                runOnUiThread {
                                                                    //stuff that updates ui
                                                                    //pass.text = l.toString()
                                                                    //progress.visibility= View.GONE
                                                                    //pass.visibility= View.VISIBLE
                                                                    //textView.visibility= View.VISIBLE
                                                                }

                                                            /*    val mBuilder = NotificationCompat.Builder(this@PinActivity)


                                                                val intent = Intent(Intent.ACTION_GET_CONTENT)
                                                                val mNotifyManager = this@PinActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                                                mBuilder.setContentText("PIN")
                                                                mBuilder.setSmallIcon(R.drawable.ic_logo)
                                                                mBuilder.setContentTitle("Hello "+nm+" your login pin "+Pass)
                                                                mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                                                                mNotifyManager.notify(0, mBuilder.build());*/
                                                                val data = s(date = date, time = hour, name = emp_name, branch = emp_branch, pass = l.toString())
                                                                db.collection("pass").document(id)
                                                                        .set(data)
                                                                        .addOnSuccessListener {
                                                                            Toast.makeText(this, "password is updated", Toast.LENGTH_LONG).show()
                                                                        }
                                                                        .addOnFailureListener {
                                                                            Toast.makeText(this, "password is not updated", Toast.LENGTH_LONG).show()
                                                                        }
                                                            }
                                                }

                                            }

                                        } else {
                                            Log.d("data", "is not here")
                                        }
                                    } else {
                                        Log.d("document does'nt exists", " ")
                                        val d = Date()
                                        val dt = SimpleDateFormat("dd/MM/yyyy")
                                        val date = dt.format(d)
                                        val c = Calendar.getInstance()
                                        System.out.println("Current time =&gt; " + c.time)//Current time =&gt; Mon Feb 12 11:01:42 GMT+05:30 2018
                                        val df = SimpleDateFormat("HH:mm")
                                        val hour = df.format(c.time)
                                        val emp_name = nm
                                        val emp_branch = "k.k.nagar"
                                        //val pass = findViewById<TextView>(R.id.pass) as TextView
                                        val list = ArrayList<Int>()
                                        var l: Int = 0
                                        for (i in 100000..999999) {
                                            list.add(i)
                                        }
                                        Collections.shuffle(list)
                                        for (i in 0..0) {
                                            l = list[i]
                                            Log.d("sli", "   " + list[i])
                                        }
                                        Log.d("l", "  " + l)
                                        db.collection("pass").whereEqualTo("pass",l.toString()).get()
                                                .addOnCompleteListener {tasc ->
                                                    if (tasc.result!=null){
                                                        if (tasc.result.isEmpty==false){
                                                            println("tasc.result not empty  "+tasc.result)
                                                            timeclock(id,nm)
                                                        }else{
                                                            println("tasc result is empty")
                                                            return@addOnCompleteListener
                                                        }
                                                    }else{
                                                        println("tasc result null")
                                                    }
                                                }
                                                .addOnSuccessListener {
                                                    println("successlistener")
                                                    runOnUiThread {
                                                        //stuff that updates ui
                                                        //pass.text = l.toString()
                                                        //progress.visibility= View.GONE
                                                        //pass.visibility= View.VISIBLE
                                                        //textView.visibility= View.VISIBLE
                                                    }
                                                    /*val mBuilder = NotificationCompat.Builder(this@PinActivity)


                                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                                    val mNotifyManager = this@PinActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                                    mBuilder.setContentText("PIN")
                                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                                    mBuilder.setContentTitle("Hello "+nm+" your login pin "+Pass)
                                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                                                    mNotifyManager.notify(0, mBuilder.build());*/
                                                    val data = s(date = date, time = hour, name = emp_name, branch = emp_branch, pass = l.toString())
                                                    db.collection("pass").document(id)
                                                            .set(data)
                                                            .addOnSuccessListener {
                                                                Toast.makeText(this, "first adding",Toast.LENGTH_LONG).show()
                                                            }
                                                            .addOnFailureListener {
                                                                Toast.makeText(this, "not updated",Toast.LENGTH_LONG).show()
                                                            }
                                                }
                                    }
                                } else {
                                    Log.d("task is not success", "full " + task.exception)
                                }
                            }
                            .addOnSuccessListener {

                            }
                }



    }
    companion object {
        //Listens internet status whether net is on/off.

        var onbkinside:String?=null
        var pDialogs: SweetAlertDialog? = null




        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable

                onbkinside="came"

            }
            else
            {

                /// if connection is off then all views becomes enabled

                onbkinside="not"
try {
    pDialogs!!.dismiss()
}
catch (e:Exception){

}
            }
        }
    }

    override fun onBackPressed() {

        //Back to home

        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }
    private fun getStamp(date:String):Long{
        val formatter =  SimpleDateFormat("dd/MM/yyyy");
        return formatter.parse(date).getTime()
    }

}
