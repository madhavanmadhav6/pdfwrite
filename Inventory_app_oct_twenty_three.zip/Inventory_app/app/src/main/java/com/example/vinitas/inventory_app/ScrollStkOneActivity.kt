package com.example.vinitas.inventory_app

import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.design.widget.FloatingActionButton
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.*
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter



import kotlinx.android.synthetic.main.scroll_stk_one.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class ScrollStkOneActivity : AppCompatActivity() {


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""




    data class s(

            var  receivedstk_count: Any,
            var  receivedstk_date: Any,
            var  receivedstk_total: Any,
            var  status:Any

    )
    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_received: Any,
            var stk_proid: Any,
            var stk_key:Any
    )

    var idstk = String()
    var cgstt = String()
    var sgstt = String()
    var cesst = String()
    var pdfFile= String()
    var grosstt = String()
    var recon = String()
    var reccnt = String()
    var names= String()
    var address= String()
    var bridd= String()
    var downstatus = String()

    var listlistener= String()
    var descriplistener= String()
    var reccntlistener= String()
    var recdatelistener= String()
    var reconlistener= String()

    var descriplistenersave= String()

    var pronameArray = arrayOf<String>()
    var hsnArray = arrayOf<String>()
    var manufacturerArray = arrayOf<String>()
    var barcodeArray = arrayOf<String>()
    var quantityArray = arrayOf<String>()
    var priceArray = arrayOf<String>()
    var totArray = arrayOf<String>()
    var cessArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var igstArray = arrayOf<String>()
    var igsttotArray = arrayOf<String>()
    var cesstotalArray = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var receivedArraycpy = arrayOf<String>()
    var imageArray = arrayOf<String>()

    var oriproidArray= arrayOf<String>()



    var stcntotherdescrip=0
    var stcntrec_count=0
    var stcntstkreceiveon=0



    var tallychks= String()
    var TAG="some"
    var db= FirebaseFirestore.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll_stk_one)


                net_status()  //Check internet status.


        //Listens internet changing movements


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()



        //Define No connection view and other views when inetrnet connection is off.

        if (NetworkUtil.getConnectivityStatus(this@ScrollStkOneActivity) > 0)
            println("Connect")
        else
            println("No connection")
        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        pur_savedis=findViewById(R.id.save_rec)

        userbackdis=findViewById(R.id.userback)
        mnudis=findViewById(R.id.mnu)
        ponodis=findViewById(R.id.otherstno)
        orddatedis=findViewById(R.id.otherstdate)

        descripdis=findViewById(R.id.otherdescrip)
        reccntdis=findViewById(R.id.rec_count)
        stkrecdis=findViewById(R.id.stkreceiveon)
        pur_listdis=findViewById(R.id.st_list)
        editdis=findViewById(R.id.edit)

        addLogText(NetworkUtil.getConnectivityStatusString(this@ScrollStkOneActivity))


        var datestk = String()
        var descstk = String()
        var ididdb = String()
        var stkidstock = String()
        var reccount = String()
        var othersmlistids = String()
        var otherdescstk = String()
        var otherstkidstock = String()
        var otherididdb = String()
        var ids = arrayOf<String>()



        val bundle = intent.extras
        var frm = bundle!!.get("fromreceive").toString()



        //------------------------arrow mark displays when the list items is greater than 4 -------------------------------------//


        img_arrow.setOnClickListener {


            st_list.setSelection(st_list.getCount() - 1)


        }





        otherstdate.setOnClickListener(View.OnClickListener {
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@ScrollStkOneActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> otherstdate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })



        //-------------------Comes from receive list activity---------------------------//

        if (frm == "receivelist") {

            save_rec.visibility=View.INVISIBLE
            edit.visibility=View.VISIBLE

            mnu.visibility=View.GONE
            otherstno.isEnabled=false
            otherstdate.isEnabled=false
            otherdescrip.isEnabled=false
            rec_count.isEnabled=false
            st_list.isEnabled=false
            stkreceiveon.isEnabled=false

            try {
                val name = intent.getStringExtra("brnm")
                val date = intent.getStringExtra("date")
                val description = intent.getStringExtra("description")
                val receiveon = intent.getStringExtra("receive")
                val receiveoncnt = intent.getStringExtra("receive_cnt")
                val Stockids = intent.getStringExtra("Stockids")
                val listids = intent.getStringExtra("listids")
                var fbrid= intent.getStringExtra("brid")


                //For receive

                val ad = intent.getStringExtra("addtrans")
                val ed = intent.getStringExtra("edittrans")
                val del = intent.getStringExtra("deletetrans")
                val vi=intent.getStringExtra("viewtrans")
                val tran=intent.getStringExtra("transfertrans")
                val ex=intent.getStringExtra("exporttrans")
                sendtrans=intent.getStringExtra("sendtrans")

                if (ad != null) {
                    addtrans = ad
                }
                if (ed != null) {
                    editetrans = ed
                }
                if (del != null) {
                    deletetrans = del
                }
                if (vi != null) {
                    viewtrans = vi
                }
                if (tran != null) {
                    transfertrans = tran
                }
                if (ex != null) {
                    exporttrans = ex
                }

                println("ADD TRANSFER"+addtrans)


                val adano = intent.getStringExtra("addtransano")
                val edano = intent.getStringExtra("edittransano")
                val delano = intent.getStringExtra("deletetransano")
                val viano=intent.getStringExtra("viewtransano")
                val tranano=intent.getStringExtra("transfertransano")
                val exano=intent.getStringExtra("exporttransano")
                sendtransano=intent.getStringExtra("sendtransano")
                if (adano != null) {
                    addtransano = adano
                }
                if (edano != null) {
                    editetransano = edano
                }
                if (delano != null) {
                    deletetransano = delano
                }
                if (viano != null) {
                    viewtransano = viano
                }
                if (tranano != null) {
                    transfertransano = tranano
                }
                if (exano != null) {
                    exporttransano = exano
                }


                val adrec = intent.getStringExtra("addrec")
                val edrec = intent.getStringExtra("editrec")
                val delrec = intent.getStringExtra("deleterec")
                val virec=intent.getStringExtra("viewrec")
                val tranrec=intent.getStringExtra("transferrec")
                val exrec=intent.getStringExtra("exportrec")
                val sendrec=intent.getStringExtra("sendstrec")

                if (adrec != null) {
                    addrec = adrec
                }
                if (edrec != null) {
                    editrec = edrec
                }
                if (delrec != null) {
                    deleterec = delrec
                }
                if (virec != null) {
                    viewrec = virec
                }
                if (tranrec != null) {
                    transferrec = tranrec
                }
                if (exrec != null) {
                    exportrec = exrec
                }
                if (sendrec != null) {
                    sendstrec = sendrec
                }




                bridd=fbrid
                comttname.setText(name)
                otherstdate.setText(date.toString())
                otherdescrip.setText(description.toString())
                otherstno.setText(Stockids)
                relistoids.setText(listids)

                descriplistener=description.toString()

                recdatelistener=date.toString()

                if(receiveon.isNullOrEmpty()){
                    val c = Calendar.getInstance()
                    System.out.println("Current time =&gt; " + c.time)

                    val df = SimpleDateFormat("dd/MM/yyyy")
                    val formattedDate = df.format(c.time)
                    stkreceiveon.setText(formattedDate)
                    reconlistener=stkreceiveon.text.toString()
                    println("RECEIVED COUNT3" + reconlistener)

                }
                else{
                    stkreceiveon.setText(receiveon)
                    reconlistener=receiveon
                    println("RECEIVED COUNT2" + reconlistener)


                }

                if(receiveoncnt.isNullOrEmpty()){
                    rec_count.setText("0")
                    reccntlistener=rec_count.text.toString()
                    println("RECEIVED COUNT1" + reccntlistener)

                }
                else{
                    rec_count.setText(receiveoncnt)
                    reccntlistener=receiveoncnt
                    println("RECEIVED COUNT4" + reccntlistener)

                }


                datestk = otherstdate.text.toString()
                println("DATE DUDEEEE" + datestk)
                println("RECEIVED COUNT" + receiveoncnt)
                descstk = otherdescrip.text.toString()

                stkidstock = otherstno.text.toString()
                ididdb = relistoids.text.toString()
            }
            catch (e:Exception){
                rec_count.setText("0")


            }

            var lista = arrayListOf<String>()
            var d = arrayListOf<String>()
            var dp = arrayListOf<String>()
            var upret = arrayListOf<String>()
            var dpu = arrayListOf<String>()
            var dlt = arrayOf<String>()


            val dl = intent.getStringArrayListExtra("dlt")


            val t = intent.getStringExtra("reid")
            Log.d("gfdgdhd", "RE_   ID OUTTTTT" + t)

            println("LIST OOOO IDS" +relistoids.text)


            //--------------------------------Get received stock items from db-------------------------//

            db.collection("${bridd}_Receive Stock/${relistoids.text}/Received stock items")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        if(value.isEmpty==false) {
                            for (document in value) {

                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                println(document.data)

                                var dt = document.data
                                var id = (document.id)

                                ids = ids.plusElement(id)
                                /*idsforup=ids*/
                                println("Heyyyyyyy" + Arrays.toString(ids))
                                println("HELLOOOOOOOOO" + id)
                                pronameArray = pronameArray.plusElement(dt["stk_name"].toString())
                                manufacturerArray = manufacturerArray.plusElement(dt["stk_mfr"].toString())
                                hsnArray = hsnArray.plusElement(dt["stk_hsn"].toString())
                                quantityArray = quantityArray.plusElement(dt["stk_received"].toString())
                                priceArray = priceArray.plusElement(dt["stk_price"].toString())
                                totArray = totArray.plusElement(dt["stk_total"].toString())
                                barcodeArray = barcodeArray.plusElement(dt["stk_barcode"].toString())

                                cessArray = cessArray.plusElement(dt["stk_cess"].toString())
                                igstArray = igstArray.plusElement(dt["otherstk_igst"].toString())
                                igsttotArray = igsttotArray.plusElement(dt["otherstk_igsttotal"].toString())
                                cesstotalArray = cesstotalArray.plusElement(dt["otherstk_cesstotal"].toString())
                                keyArray = keyArray.plusElement(id)
                                tallyArray = tallyArray.plusElement(dt["otherstk_tally"].toString())
                                receivedArray = receivedArray.plusElement(dt["otherstk_received"].toString())
                                receivedArraycpy = receivedArraycpy.plusElement(dt["otherstk_received"].toString())
                                oriproidArray=oriproidArray.plusElement(dt["stk_proid"].toString())
                                try {
                                    var im = (dt["otherstk_img"].toString())
                                    if (im.isNotEmpty()) {

                                        imageArray = imageArray.plusElement(im)
                                    } else {
                                        imageArray = imageArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                    }
                                } catch (e: Exception) {

                                }

                            }
                        }
                        else{

                        }
                        val whatever = receive_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                        st_list.adapter = whatever
                        val  footer = View.inflate(this@ScrollStkOneActivity,R.layout.footer, null);
                        st_list.addFooterView(footer,null,false)


                        save_progress.visibility = View.INVISIBLE
                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                         var receivecnt=0
                        var b = 2
                        for (i in 0 until priceArray.count()) {
                            var c = (priceArray[i])
                            var cy=(igsttotArray[i])
                            var cyz=(cesstotalArray[i])
                            var qyz=(quantityArray[i])

                            var cdec=c.toBigDecimal()
                            var qyzdec=qyz.toBigDecimal()
                            var totquanpri=(cdec*qyzdec)

                    /*        var hh=(receivedArray[i].toInt())
                            receivecnt=receivecnt+hh

                            rec_count.setText(receivecnt.toString())*/


                            total = total.plus(totquanpri.toInt())

                            igsttot = igsttot.plus(cy.toFloat())
                            cesstotals = cesstotals.plus(cyz.toFloat())






                            igst_tot.setText((String.format("%.2f",igsttot)))
                            var l = igst_tot.text.toString()
                            var ss = l.toBigDecimal()
                            var tt = ss / b.toBigDecimal()
                            cgst_tot.setText((String.format("%.2f",tt)))
                            sgst_tot.setText((String.format("%.2f",tt)))

                            cess_tot.setText((String.format("%.2f",cesstotals)))

                            var f=cesstotals
                            var g=igsttot

                            var op=total
                            var m=f.toFloat()
                            var n=g.toFloat()

                            var yy=m+n+op

                            try {
                                gross_tot.setText((String.format("%.2f",yy)))
                            }
                            catch (e:Exception){
                                gross_tot.setText((String.format("%.2f",yy)))
                            }


                            var dup = pronameArray[i]
                            var tup = dup.removeSuffix("- ml")










                            Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)

                        }


                        if(priceArray.size>4){


                            img_arrow.visibility=View.VISIBLE

                        }
                        val a=tallyArray.contains("Not tallied")
                        println("TALLIEDDDD"+a)
                        println("ARRRAY ITEEEMSSSS"+tallyArray)
                        if(a){
                            tallnottall.setText("Not Tallied")

                        }
                        else{
                            tallnottall.setText("Tallied")
                        }



                    })
        }




        //-------------------------------------Comes from receive update activty (Main_scroll_second)----------------//

        else if (frm == "updatereceive") {

println("TALLY CHECK UPDREC"+tallychks)

            /*val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MMM/yyyy")
            val formattedDate = df.format(c.time)

            stkreceiveon.setText(formattedDate)*/
            val av = bundle!!.get("otheruprenm") as Array<String>
            val bv = bundle!!.get("otheruprehsn") as Array<String>
            val mv = bundle!!.get("otherupremanu") as Array<String>
               val dv=bundle!!.get("otherupreprice") as Array<String>
            val ev = bundle!!.get("otheruprequan") as Array<String>
            val fv = bundle!!.get("otheruprebc") as Array<String>
            val hv = bundle!!.get("otherupretotal") as Array<String>
            val gv = bundle!!.get("otheruprecess") as Array<String>
            val iv = bundle!!.get("otherreigst") as Array<String>
            val jv = bundle!!.get("otherreigst_total") as Array<String>
            val kv = bundle!!.get("otherrecesstotal") as Array<String>
            val rekey = bundle!!.get("otheruprekey") as Array<String>
            val retally = bundle!!.get("othertally") as Array<String>
            val rerec = bundle!!.get("otherreceive") as Array<String>
            val rereccpy = bundle!!.get("otherreceivecpy") as Array<String>

            val otherorpro=bundle!!.get("otheroriproid") as Array<String>
            val changecom=intent.getStringExtra("comchange")

            if(changecom=="changed")
            {
                listlistener="listupdate"
            }
            else{

            }




            val n = intent.getStringExtra("otherupbranch")
            val pp = intent.getStringExtra("otherupaddress")
            val pdate = intent.getStringExtra("otherupredate")
            val pstkid = intent.getStringExtra("otheruprestkid")
            val pdesc = intent.getStringExtra("otherupredesc")
            val piddb = intent.getStringExtra("otherupreiddb")
            val piddli = intent.getStringExtra("otherupreiddofli")
            val branid = intent.getStringExtra("otherbrid")
            val nm = intent.getStringExtra("receive_name")
            val jj=intent.getStringExtra("othertallydis")
            val addre = intent.getStringExtra("receive_addre")
            comttname.setText(nm)
            comphone.setText(addre)

            val recon=intent.getStringExtra("recons")
            stkreceiveon.setText(recon)

   try {
            descriplistener=intent.getStringExtra("descriplistener")
            reccntlistener=intent.getStringExtra("reccntlistener")
            recdatelistener=intent.getStringExtra("recdatelistener")
            reconlistener=intent.getStringExtra("reconlistener")
}
        catch (e:Exception){

        }

                save_rec.visibility = View.VISIBLE





            /* var smli = intent.getStringExtra("otherupsmlistidss")*/


            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }






            /* igstedt.add(igedit)
             igstedttot.add(igtt.toString())
             cestotal.add(cesstotal)
             alltotal.add(overtot)*/




            println("UPDATE IDDDDDD" + Arrays.toString(ids))
            liids.setText(piddli)

            bridd=branid

            val immv = bundle!!.get("otherupreimmg") as Array<String>
            comttname.setText(n)
            comphone.setText(pp)
            otherstdate.setText(pdate)
            otherdescrip.setText(pdesc)
            otherstno.setText(pstkid)


            relistoids.setText(piddb)
            var otherdatestk = String()
            otherdescstk = otherdescrip.text.toString()
            datestk= otherstdate.text.toString()
            otherstkidstock = otherstno.text.toString()
            println("STOCK IDDDDSSSS" + otherstkidstock)
            otherididdb = relistoids.text.toString()
            descstk = otherdescrip.text.toString()

            stkidstock = otherstno.text.toString()
            ididdb = relistoids.text.toString()



            pronameArray = (av.clone())
            manufacturerArray = mv.clone()
            quantityArray = ev.clone()
            priceArray = dv.clone()
            hsnArray = bv.clone()
            barcodeArray = fv.clone()
            totArray = hv.clone()
            cessArray = gv.clone()
            keyArray = rekey.clone()
            igstArray = iv.clone()
            igsttotArray = jv.clone()
            cesstotalArray = kv.clone()
            tallyArray = retally.clone()
            receivedArray = rerec.clone()
            receivedArraycpy = rereccpy.clone()

            imageArray = immv.clone()
            oriproidArray=otherorpro.clone()

            val whatever = receive_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            st_list.adapter = whatever
            val  footer = View.inflate(this@ScrollStkOneActivity,R.layout.footer, null);
            st_list.addFooterView(footer,null,false)

            var total = 0.0F
            var igsttot = 0.0F
            var cesstotals = 0.0F
            var receivecnt=0
            var b = 2
            for (i in 0 until priceArray.count()) {
                var c = (priceArray[i])
                var cy=(igsttotArray[i])
                var cyz=(cesstotalArray[i])
                var qyz=(quantityArray[i])


                    var hh = (receivedArray[i].toInt())
                    receivecnt = receivecnt + hh




                rec_count.setText(receivecnt.toString())

                var cdec=c.toBigDecimal()
                var qyzdec=qyz.toBigDecimal()
                var totquanpri=(cdec*qyzdec)






                total = total.plus(totquanpri.toInt())

                igsttot = igsttot.plus(cy.toFloat())
                cesstotals = cesstotals.plus(cyz.toFloat())

                 igst_tot.setText((String.format("%.2f",igsttot)))
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / b.toBigDecimal()
               cgst_tot.setText((String.format("%.2f",tt)))

               sgst_tot.setText((String.format("%.2f",tt)))

                cess_tot.setText((String.format("%.2f",cesstotals)))

                var f=cesstotals
                var g=igsttot

                var op=total
                var m=f.toFloat()
                var n=g.toFloat()

                var yy=m+n+op

                try {
                    gross_tot.setText((String.format("%.2f",yy)))
                }
                catch (e:Exception){
                    gross_tot.setText((String.format("%.2f",yy)))
                }
                var dup = pronameArray[i]
                var tup = dup.removeSuffix("- ml")










                Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)
            }

            if(priceArray.size>4){


                img_arrow.visibility=View.VISIBLE

            }
            val a=tallyArray.contains("Not tallied")
            println("TALLIEDDDD"+a)
            println("ARRRAY ITEEEMSSSS"+tallyArray)
            if(a){
                tallnottall.setText("Not Tallied")

            }
            else{
                tallnottall.setText("Tallied")
            }



        }

        else if(frm=="frmpdfreceive")

        {







            val av = bundle!!.get("otheruprenm") as Array<String>
            val bv = bundle!!.get("otheruprehsn") as Array<String>
            val mv = bundle!!.get("otherupremanu") as Array<String>
               val dv=bundle!!.get("otherupreprice") as Array<String>
            val ev = bundle!!.get("otheruprequan") as Array<String>
            val fv = bundle!!.get("otheruprebc") as Array<String>
            val hv = bundle!!.get("otherupretotal") as Array<String>
            val gv = bundle!!.get("otheruprecess") as Array<String>
            val iv = bundle!!.get("otherreigst") as Array<String>
            val jv = bundle!!.get("otherreigst_total") as Array<String>
            val kv = bundle!!.get("otherrecesstotal") as Array<String>
            val rekey = bundle!!.get("otheruprekey") as Array<String>
            val retally = bundle!!.get("othertally") as Array<String>
            val rerec = bundle!!.get("otherreceive") as Array<String>
            val rereccpy = bundle!!.get("otherreceivecpy") as Array<String>

            val otherorpro=bundle!!.get("otheroriproid") as Array<String>


            val n = intent.getStringExtra("otherupbranch")
            val pp = intent.getStringExtra("otherupaddress")
            val pdate = intent.getStringExtra("otherupredate")
            val pstkid = intent.getStringExtra("otheruprestkid")
            val pdesc = intent.getStringExtra("otherupredesc")
            val piddb = intent.getStringExtra("otherupreiddb")
            val piddli = intent.getStringExtra("otherupreiddofli")
            val idbr = intent.getStringExtra("otherbrid")

            bridd=idbr

            /* var smli = intent.getStringExtra("otherupsmlistidss")*/


            val recon = intent.getStringExtra("recon")
            val reccnt = intent.getStringExtra("reccnt")


            val cess = intent.getStringExtra("cesstot")


            val cgst = intent.getStringExtra("cgsttot")


            val sgst = intent.getStringExtra("sgsttot")


            val grosst = intent.getStringExtra("grosstot")

            cgst_tot.setText((String.format("%.2f",cgst.toFloat())))
            sgst_tot.setText((String.format("%.2f",sgst.toFloat())))
            cess_tot.setText((String.format("%.2f",cess.toFloat())))
            gross_tot.setText((String.format("%.2f",grosst.toFloat())))


            try{

                listlistener=intent.getStringExtra("listlistener")
            }
            catch (e:Exception){

            }
            try{
                descriplistenersave=intent.getStringExtra("descriplistenersave")

            }
            catch (e:Exception){

            }


            rec_count.setText(reccnt)
            stkreceiveon.setText(recon)

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }





            /* igstedt.add(igedit)
             igstedttot.add(igtt.toString())
             cestotal.add(cesstotal)
             alltotal.add(overtot)*/




            println("UPDATE IDDDDDD" + Arrays.toString(ids))
            liids.setText(piddli)

            val immv = bundle!!.get("otherupreimmg") as Array<String>
            comttname.setText(n)
            comphone.setText(pp)
            otherstdate.setText(pdate)
            otherdescrip.setText(pdesc)
            otherstno.setText(pstkid)


            relistoids.setText(piddb)
            var otherdatestk = String()
            otherdescstk = otherdescrip.text.toString()
            otherdatestk = otherstdate.text.toString()
            otherstkidstock = otherstno.text.toString()
            println("STOCK IDDDDSSSS" + otherstkidstock)
            otherididdb = relistoids.text.toString()
            descstk = otherdescrip.text.toString()

            stkidstock = otherstno.text.toString()
            ididdb = relistoids.text.toString()

            try {
                descriplistener=intent.getStringExtra("descriplistener")
                reccntlistener=intent.getStringExtra("reccntlistener")
                recdatelistener=intent.getStringExtra("recdatelistener")
                reconlistener=intent.getStringExtra("reconlistener")

                println("STOCK IDDDDSSSS1" + descriplistener)
                println("STOCK IDDDDSSSS2" + reccntlistener)
                println("STOCK IDDDDSSS3" + recdatelistener)


            }
            catch (e:Exception){

            }

            pronameArray = (av.clone())
            manufacturerArray = mv.clone()
            quantityArray = ev.clone()
            priceArray = dv.clone()
            hsnArray = bv.clone()
            barcodeArray = fv.clone()
            totArray = hv.clone()
            cessArray = gv.clone()
            keyArray = rekey.clone()
            igstArray = iv.clone()
            igsttotArray = jv.clone()
            cesstotalArray = kv.clone()
            tallyArray = retally.clone()
            receivedArray = rerec.clone()
            receivedArraycpy = rereccpy.clone()

            imageArray = immv.clone()
            oriproidArray=otherorpro.clone()

            val whatever = receive_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                    quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray,
                    cesstotalArray, tallyArray, receivedArray, imageArray)
            st_list.adapter = whatever
            val  footer = View.inflate(this@ScrollStkOneActivity,R.layout.footer, null);
            st_list.addFooterView(footer,null,false)
            if(priceArray.size>4){


                img_arrow.visibility=View.VISIBLE

            }
            /*var total = 0.0F
            var igsttot = 0.0F
            var cesstotals = 0.0F
            var b = 2
            for (i in 0 until priceArray.count())
            {
                var c = (priceArray[i])
                var cy=(igsttotArray[i])
                var cyz=(cesstotalArray[i])
                var qyz=(quantityArray[i])

                var cdec=c.toBigDecimal()
                var qyzdec=qyz.toBigDecimal()
                var totquanpri=(cdec*qyzdec)




                total = total.plus(totquanpri.toInt())

                igsttot = igsttot.plus(cy.toFloat())
                cesstotals = cesstotals.plus(cyz.toFloat())

                igst_tot.text = igsttot.toString()
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / b.toBigDecimal()
                cgst_tot.text = tt.toString()
                sgst_tot.text = tt.toString()

                cess_tot.text=cesstotals.toString()

                var f=cesstotals
                var g=igsttot

                var op=total
                var m=f.toFloat()
                var n=g.toFloat()

                var yy=m+n+op

                try {
                    gross_tot.setText(yy.toString())
                }
                catch (e:Exception){
                    gross_tot.text=yy.toString()
                }
                var dup = pronameArray[i]
                var tup = dup.removeSuffix("- ml")









                cess_tot.text = cesstotals.toString()
                Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)
            }*/


            if(priceArray.size>4){


                img_arrow.visibility=View.VISIBLE

            }

            val a=tallyArray.contains("Not tallied")
            println("TALLIEDDDD"+a)
            println("ARRRAY ITEEEMSSSS"+tallyArray)
            if(a){
                tallnottall.setText("Not Tallied")

            }
            else{
                tallnottall.setText("Tallied")
            }

        }


        //-------------------------Edit click ------------------------//

        edit.setOnClickListener {

            if(editrec=="true") {

                st_list.isEnabled=true

                edit.visibility = View.GONE

                mnu.visibility=View.VISIBLE

            /*    otherstdate.isEnabled = true
                otherstno.isEnabled = true*/
                otherdescrip.isEnabled = true

                stkreceiveon.isEnabled = true

                val whatever = receive_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                st_list.adapter = whatever
                val  footer = View.inflate(this@ScrollStkOneActivity,R.layout.footer, null);
                st_list.addFooterView(footer,null,false)
                save_rec.visibility = View.VISIBLE


            }
            else if(editrec=="false"){
                popup("Receive")
            }

        }

        otherdescrip.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {










            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })

        rec_count.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {








            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })
        stkreceiveon.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {







            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })


        //SEND TO UPDATE  ----------  Main_scroll_second ------------///


        st_list.setOnItemClickListener { parent, views, position, id ->

            val b = Intent(applicationContext, Main_scroll_second::class.java)

            b.putExtra("fromreceive", "receiveupdatelist")
            b.putExtra("receivepnm", pronameArray)
            b.putExtra("receivepmanu", manufacturerArray)
            b.putExtra("receivephsn", hsnArray)
            b.putExtra("receivebarcode", barcodeArray)
            b.putExtra("receiveprice", priceArray)

            b.putExtra("receive_quan", quantityArray)
            b.putExtra("receive_tot", totArray)
            b.putExtra("receive_cessup", cessArray)
            b.putExtra("receive_igst", igstArray)
            b.putExtra("receive_igsttotal", igsttotArray)
            b.putExtra("receive_cesstotarray", cesstotalArray)
            b.putExtra("tallyarray", tallyArray)
            b.putExtra("receivedarray", receivedArray)
            b.putExtra("receivedarraycpy", receivedArraycpy)

            b.putExtra("oriproarray", oriproidArray)



            b.putExtra("receive_image", imageArray)
            /*     b.putExtra("otherst_branch", othernameofbrnch)
            b.putExtra("otherst_address", otherlocofbrnch)*/
            b.putExtra("receive_sstkdate",datestk)
            b.putExtra("receive_name",comttname.text.toString())
            b.putExtra("receive_addre",comphone.text.toString())

            b.putExtra("recon",stkreceiveon.text.toString())
            println("BRANCH NAM NOW AND ADDRESS:"+comttname.text.toString())

            b.putExtra("receive_ssstockid", stkidstock)
            b.putExtra("receive_ssstkdesc", descstk)
            b.putExtra("receive_idofdb", ididdb)
            b.putExtra("receive_idsofli", keyArray)
            /* b.putExtra("otherst_smlistids",othersmlistids)*/
            b.putExtra("receive_pos", position)

            b.putExtra("brid",bridd)

            b.putExtra("descriplistener",descriplistener)
            b.putExtra("reccntlistener",reccntlistener)
            b.putExtra("recdatelistener",recdatelistener)
            b.putExtra("reconlistener",reconlistener)



            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)




            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()
        }



        //-----------------------Save action----------------------///


    save_rec.setOnClickListener {

        if(net_status()==true) {


            if (transferrec == "true") {


                if ((descriplistener != otherdescrip.text.toString()) || (reccntlistener != rec_count.text.toString()) ||
                        (recdatelistener != otherstdate.text.toString()) || (reconlistener != stkreceiveon.text.toString())) {
                    descriplistenersave = "descchanged"
                }

                if ((descriplistenersave == "descchanged") && (listlistener != "listupdate")) {
                    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialogs!!.setTitleText("Saving...")
                    pDialogs!!.setCancelable(false)
                    pDialogs!!.show()
                    val map = mutableMapOf<String, Any?>()
                    map.put("Receive_count", rec_count.text.toString())
                    map.put("Receive_date", stkreceiveon.text.toString())
                    map.put("Receive_total", gross_tot.text.toString())
                    map.put("Status", tallnottall.text.toString())
                    map.put("stk_Desc", otherdescrip.text.toString())
                    db.collection("${bridd}_Receive Stock").document(relistoids.text.toString())
                            .update(map)
                            .addOnSuccessListener {
                                pDialogs!!.dismiss()
                                Toast.makeText(applicationContext, "Data Saved Successfully", Toast.LENGTH_SHORT).show()
                                val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
                                kk.putExtra("from_rec", "recsave")



                                kk.putExtra("viewtrans", viewtrans)
                                kk.putExtra("addtrans", addtrans)
                                kk.putExtra("edittrans", editetrans)
                                kk.putExtra("deletetrans", deletetrans)
                                kk.putExtra("transfertrans", transfertrans)
                                kk.putExtra("exporttrans", exporttrans)
                                kk.putExtra("sendtrans", sendtrans)


                                kk.putExtra("viewtransano", viewtransano)
                                kk.putExtra("addtransano", addtransano)
                                kk.putExtra("edittransano", editetransano)
                                kk.putExtra("deletetransano", deletetransano)
                                kk.putExtra("transfertransano", transfertransano)
                                kk.putExtra("exporttransano", exporttransano)
                                kk.putExtra("sendtransano", sendtransano)

                                kk.putExtra("viewrec", viewrec)
                                kk.putExtra("addrec", addrec)
                                kk.putExtra("deleterec", deleterec)
                                kk.putExtra("editrec", editrec)
                                kk.putExtra("transferrec", transferrec)
                                kk.putExtra("exportrec", exportrec)
                                kk.putExtra("sendstrec", sendstrec)



                                kk.putExtra("brid", bridd)
                                startActivity(kk)
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                finish()

                            }
                }
                else if(((descriplistenersave == "descchanged") && (listlistener == "listupdate"))||((descriplistenersave != "descchanged") && (listlistener == "listupdate")))
                {
                     pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialogs!!.setTitleText("Saving...")
                    pDialogs!!.setCancelable(false)
                    pDialogs!!.show()
                    val map = mutableMapOf<String, Any?>()
                    map.put("Receive_count", rec_count.text.toString())
                    map.put("Receive_date", stkreceiveon.text.toString())
                    map.put("Receive_total", gross_tot.text.toString())
                    map.put("Status", tallnottall.text.toString())
                    map.put("stk_Desc", otherdescrip.text.toString())
                    db.collection("${bridd}_Receive Stock").document(relistoids.text.toString())
                            .update(map)
                            .addOnSuccessListener {

                            }


                            var refid = relistoids.text.toString()

                            var receive_path = "${bridd}_Receive Stock/$refid/Received stock items"

                            for (i in 0 until priceArray.size) {
                                var stk_name = pronameArray[i]
                                var stk_mfr = manufacturerArray[i]
                                var stk_hsn = hsnArray[i]
                                var stk_bcode = barcodeArray[i]
                                var stk_quan = quantityArray[i]
                                var stk_pri = priceArray[i]
                                var stk_tot = totArray[i]
                                var stk_cess = cessArray[i]
                                var stk_igst = igstArray[i]
                                var stk_igsttot = igsttotArray[i]
                                var stk_cesstot = cesstotalArray[i]
                                var stk_received = receivedArray[i]

                                var stk_tally = tallyArray[i]
                                var stk_key = keyArray[i]
                                var oripid=oriproidArray[i]




                                var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode,stk_proid =oripid,  stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received)

                                db.collection(receive_path).document(keyArray[i])
                                        .set(d)
                                        .addOnSuccessListener { documentReference ->
                                            var qntval = receivedArray[i]
                                            var proids = oriproidArray[i]
                                            var duprec=receivedArraycpy[i]
                                            var pathfrbs = oriproidArray[i] + "_" + bridd
                                            stock_in_hand(i, pathfrbs, qntval, proids,duprec)  ///Update stock on hand of that branch


                                        }


                            }
                    Handler().postDelayed(Runnable {


                    pDialogs!!.dismiss()
                    Toast.makeText(applicationContext, "Data Saved Successfully", Toast.LENGTH_SHORT).show()
                    val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
                    kk.putExtra("from_rec", "recsave")



                    kk.putExtra("viewtrans", viewtrans)
                    kk.putExtra("addtrans", addtrans)
                    kk.putExtra("edittrans", editetrans)
                    kk.putExtra("deletetrans", deletetrans)
                    kk.putExtra("transfertrans", transfertrans)
                    kk.putExtra("exporttrans", exporttrans)
                    kk.putExtra("sendtrans", sendtrans)


                    kk.putExtra("viewtransano", viewtransano)
                    kk.putExtra("addtransano", addtransano)
                    kk.putExtra("edittransano", editetransano)
                    kk.putExtra("deletetransano", deletetransano)
                    kk.putExtra("transfertransano", transfertransano)
                    kk.putExtra("exporttransano", exporttransano)
                    kk.putExtra("sendtransano", sendtransano)

                    kk.putExtra("viewrec", viewrec)
                    kk.putExtra("addrec", addrec)
                    kk.putExtra("deleterec", deleterec)
                    kk.putExtra("editrec", editrec)
                    kk.putExtra("transferrec", transferrec)
                    kk.putExtra("exportrec", exportrec)
                    kk.putExtra("sendstrec", sendstrec)



                    kk.putExtra("brid", bridd)
                    startActivity(kk)
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                    finish()
                    },2000)
                        }
                else if((descriplistenersave.isEmpty()) && (listlistener.isEmpty())){
                    Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()

                }




            } else {
                popup("Receive")
            }
        }
        else{
            Toast.makeText(applicationContext,"Please turn on your connection",Toast.LENGTH_SHORT).show()
        }
    }


        mnu.setOnClickListener({


            val popup = PopupMenu(this@ScrollStkOneActivity, mnu)

            popup.menuInflater.inflate(R.menu.scrollstk_one, popup.menu)

            popup.setOnMenuItemClickListener { item ->   //'Send this ST' option is used to send this ST to another person as a pdf document.
                if(item.title=="Send this ST"){
                    idstk=otherstno.text.toString()
                    grosstt=gross_tot.text.toString()
                    cesst=cess_tot.text.toString()

                    names=comttname.text.toString()
                    address=comphone.text.toString()
                    reccnt=rec_count.text.toString()
                    recon=stkreceiveon.text.toString()


                    //Create and write pdf document

                    createandDisplayPdf(idstk, datestk, names, address,descstk, reccnt, recon, cesst,grosstt,cgst_tot.text.toString(),sgst_tot.text.toString())
                    var f = idstk + "_receive stock"

                    var y = f + ".pdf"
                    val share = Intent(Intent.ACTION_SEND)
                    share.type = "application/pdf"
                    pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer" + "/" + y).toString()
                    try {
                        sendMail(pdfFile)
                    } catch (e: IOException) {
                        Toast.makeText(applicationContext,"Couldn't Send",Toast.LENGTH_SHORT).show()
                    }



                    return@setOnMenuItemClickListener true
                }



                //Export as pdf - Navigate to pdf activity
                else if(item.title=="Export as pdf"){
                    val b = Intent(this@ScrollStkOneActivity, MainReceivePdf::class.java)

                    b.putExtra("fromreceive", "mainpdf")
                    b.putExtra("receivepnm", pronameArray)
                    b.putExtra("receivepmanu", manufacturerArray)
                    b.putExtra("receivephsn", hsnArray)
                    b.putExtra("receivebarcode", barcodeArray)
                    b.putExtra("receiveprice", priceArray)

                    b.putExtra("receive_quan", quantityArray)
                    b.putExtra("receive_tot", totArray)
                    b.putExtra("receive_cessup", cessArray)
                    b.putExtra("receive_igst", igstArray)
                    b.putExtra("receive_igsttotal", igsttotArray)
                    b.putExtra("receive_cesstotarray", cesstotalArray)
                    b.putExtra("tallyarray", tallyArray)
                    b.putExtra("receivedarray", receivedArray)
                    b.putExtra("receivedarraycpy", receivedArraycpy)

                    b.putExtra("oriproarray", oriproidArray)
                    b.putExtra("receive_image", imageArray)
                    b.putExtra("otherst_branch", comttname.text.toString())
                    b.putExtra("otherst_address", comphone.text.toString())
                    b.putExtra("receive_sstkdate", datestk)
                    b.putExtra("receive_ssstockid", stkidstock)
                    b.putExtra("receive_ssstkdesc",otherdescrip.text.toString())
                    b.putExtra("receive_idofdb", ididdb)
                    b.putExtra("receive_idsofli", keyArray)

                     b.putExtra("cgsttot",cgst_tot.text.toString())
                     b.putExtra("sgsttot", sgst_tot.text.toString())
                    b.putExtra("cesstot", cess_tot.text.toString())
                    b.putExtra("grosstot", gross_tot.text.toString())
                    b.putExtra("stkreccnt", rec_count.text.toString())
                    b.putExtra("stkrecon", stkreceiveon.text.toString())
                    b.putExtra("brid",bridd)

                    b.putExtra("descriplistener",descriplistener)
                    b.putExtra("reccntlistener",reccntlistener)
                    b.putExtra("recdatelistener",recdatelistener)
                    b.putExtra("reconlistener",reconlistener)
                    b.putExtra("listlistener",listlistener)
                    b.putExtra("descriplistenersave",descriplistenersave)



                    b.putExtra("viewtrans", viewtrans)
                    b.putExtra("addtrans", addtrans)
                    b.putExtra("edittrans", editetrans)
                    b.putExtra("deletetrans", deletetrans)
                    b.putExtra("transfertrans", transfertrans)
                    b.putExtra("exporttrans", exporttrans)
                    b.putExtra("sendtrans", sendtrans)


                    b.putExtra("viewtransano", viewtransano)
                    b.putExtra("addtransano", addtransano)
                    b.putExtra("edittransano", editetransano)
                    b.putExtra("deletetransano", deletetransano)
                    b.putExtra("transfertransano", transfertransano)
                    b.putExtra("exporttransano", exporttransano)
                    b.putExtra("sendtransano", sendtransano)

                    b.putExtra("viewrec", viewrec)
                    b.putExtra("addrec", addrec)
                    b.putExtra("deleterec", deleterec)
                    b.putExtra("editrec", editrec)
                    b.putExtra("transferrec", transferrec)
                    b.putExtra("exportrec", exportrec)
                    b.putExtra("sendstrec",sendstrec)


                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                    finish()


                }

                true

            }

            popup.show()

        })



            userback.setOnClickListener {
              onBackPressed()
            }
        }

    //Create file path for pdf document and write pdf document

    fun createandDisplayPdf(id: String, requestdt: String, reqname: String, reqphone: String, reqestidate: String, cgsttotal: String, sgsttotal: String, cesstotal: String, grosstot: String,cgstte:String,sgstte:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()
            var f = idstk + "_receive stock"

            var y = f + ".pdf"

            val file = File(dir, y)
            val fOut = FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f
            val fntSizeheading = 14.5f
            val fntSizesubheading = 12.5f

            val b = Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizeheading, b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizesubheading, b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSize);
            val h1 = Paragraph("Vinitas Enterprises Pvt Ltd", fontheading)
            val hs1 = Paragraph("Stock Transfer", fontsubheading)

            val a1 = Paragraph("Branch Name:                         " + reqname, font)
            val b1 = Paragraph("Branch Address:                     " + reqphone, font)
            val c1 = Paragraph("ST No:                                     " + id, font)
            val d1 = Paragraph("Date:                                       " + requestdt, font)
            val e1 = Paragraph("Description:                             " + reqestidate, font)
            val p13 = Paragraph("Stock Received Count:           " + cgsttotal, font)
            val p14 = Paragraph("Stock Received On:                " + sgsttotal, font)
            val p15 = Paragraph("CESS Total:                               " + cesstotal, font)
            val p7 = Paragraph("Gross Total:                               " + grosstot, font)
            val p8 = Paragraph("Product Details", fontsubheading)

            val pnm = Paragraph("Product Name")
            val pri = Paragraph("Price")

            val table = PdfPTable(floatArrayOf(2F,6F,5F, 5F, 4F,6F,4F))

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER)

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for (j in 0 until cells.size) {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)


                table.addCell(i.toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            /* table.addCell("")

             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("IGST Total")
             table.addCell(igstto)*/

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgstte)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstte)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)
            /*val table =  PdfPTable(10);
        val  cell = PdfPCell(pnm);
       cell.colspan=1
       cell.setBorder(PdfPCell.NO_BORDER);
       cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        table.addCell(cell);
        val cellCaveat =  PdfPCell(pri);
        cellCaveat.setColspan(1);
        cellCaveat.setBorder(PdfPCell.NO_BORDER);
        table.addCell(cellCaveat);
       table.addCell(cellCaveat);
       doc.add(table)*/


            //add paragraph to document
            doc.add(h1)
            doc.add(Chunk.NEWLINE);
            doc.add(hs1)
            doc.add(Chunk.NEWLINE);
            doc.add(c1)
            doc.add(Chunk.NEWLINE);
            doc.add(d1)
            doc.add(Chunk.NEWLINE);
            doc.add(a1)
            doc.add(Chunk.NEWLINE);
            doc.add(b1)
            doc.add(Chunk.NEWLINE);
            doc.add(e1)
            doc.add(Chunk.NEWLINE);
            doc.add(p13)
            doc.add(Chunk.NEWLINE);
            doc.add(p14)
            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);
            doc.add(p8)
            doc.add(Chunk.NEWLINE);
            doc.add(table)

            downstatus = "success"


        } catch (de: DocumentException) {
            downstatus = "not"
        } catch (e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        } finally {
            doc.close()
        }


    }


    override fun onBackPressed()
    {

        ///Back action

        println("LIST"+listlistener)
        println("DESCRIP"+descriplistener)
        println("RECEIVE COUNT"+reccntlistener)
        println("RECEIVE DATE"+recdatelistener)
        println("RECEIVE DATE"+reconlistener)

        if((descriplistener!=otherdescrip.text.toString())||(reccntlistener!=rec_count.text.toString())||
                (recdatelistener!=otherstdate.text.toString())||(reconlistener!=stkreceiveon.text.toString()))

        {
            descriplistenersave="descchanged"
        }





        if((listlistener=="listupdate")||(descriplistenersave=="descchanged"))
        {
            savepop()  //Save popup
        }
        else if((listlistener.isEmpty())&&(descriplistenersave.isEmpty())){
            val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
            kk.putExtra("from_rec", "recsave")




            kk.putExtra("viewtrans", viewtrans)
            kk.putExtra("addtrans", addtrans)
            kk.putExtra("edittrans", editetrans)
            kk.putExtra("deletetrans", deletetrans)
            kk.putExtra("transfertrans", transfertrans)
            kk.putExtra("exporttrans", exporttrans)
            kk.putExtra("sendtrans", sendtrans)


            kk.putExtra("viewtransano", viewtransano)
            kk.putExtra("addtransano", addtransano)
            kk.putExtra("edittransano", editetransano)
            kk.putExtra("deletetransano", deletetransano)
            kk.putExtra("transfertransano", transfertransano)
            kk.putExtra("exporttransano", exporttransano)
            kk.putExtra("sendtransano", sendtransano)

            kk.putExtra("viewrec", viewrec)
            kk.putExtra("addrec", addrec)
            kk.putExtra("deleterec", deleterec)
            kk.putExtra("editrec", editrec)
            kk.putExtra("transferrec", transferrec)
            kk.putExtra("exportrec", exportrec)
            kk.putExtra("sendstrec",sendstrec)



            kk.putExtra("brid", bridd)
            startActivity(kk)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
        else{

        }

    }

    fun sendMail(path: String) {        //Send this purchase order to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("muthumadhavan.vinitas@gmail.com","it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "STOCK TRANSFER - Receive Stock")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        emailIntent.type = "application/pdf"
        val myUri = Uri.parse("file://" + path)
        emailIntent.putExtra(Intent.EXTRA_STREAM, myUri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        finish()
    }

    fun popup(st:String){   //Access Denied
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
    fun savepop() {
        val builder = AlertDialog.Builder(this@ScrollStkOneActivity)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->

                if(net_status()==true) {

                    if (transferrec == "true") {
                        if ((descriplistenersave == "descchanged") && (listlistener != "listupdate")) {
                       pDialogs = SweetAlertDialog(this@ScrollStkOneActivity, SweetAlertDialog.PROGRESS_TYPE)
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialogs!!.setTitleText("Saving...")
                            pDialogs!!.setCancelable(false)
                            pDialogs!!.show()
                            val map = mutableMapOf<String, Any?>()
                            map.put("Receive_count", rec_count.text.toString())
                            map.put("Receive_date", stkreceiveon.text.toString())
                            map.put("Receive_total", gross_tot.text.toString())
                            map.put("Status", tallnottall.text.toString())
                            map.put("stk_Desc", otherdescrip.text.toString())
                            db.collection("${bridd}_Receive Stock").document(relistoids.text.toString())
                                    .update(map)
                                    .addOnSuccessListener {
                                        pDialogs!!.dismiss()
                                        Toast.makeText(applicationContext, "Data Saved Successfully", Toast.LENGTH_SHORT).show()
                                        val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
                                        kk.putExtra("from_rec", "recsave")



                                        kk.putExtra("viewtrans", viewtrans)
                                        kk.putExtra("addtrans", addtrans)
                                        kk.putExtra("edittrans", editetrans)
                                        kk.putExtra("deletetrans", deletetrans)
                                        kk.putExtra("transfertrans", transfertrans)
                                        kk.putExtra("exporttrans", exporttrans)
                                        kk.putExtra("sendtrans", sendtrans)


                                        kk.putExtra("viewtransano", viewtransano)
                                        kk.putExtra("addtransano", addtransano)
                                        kk.putExtra("edittransano", editetransano)
                                        kk.putExtra("deletetransano", deletetransano)
                                        kk.putExtra("transfertransano", transfertransano)
                                        kk.putExtra("exporttransano", exporttransano)
                                        kk.putExtra("sendtransano", sendtransano)

                                        kk.putExtra("viewrec", viewrec)
                                        kk.putExtra("addrec", addrec)
                                        kk.putExtra("deleterec", deleterec)
                                        kk.putExtra("editrec", editrec)
                                        kk.putExtra("transferrec", transferrec)
                                        kk.putExtra("exportrec", exportrec)
                                        kk.putExtra("sendstrec", sendstrec)



                                        kk.putExtra("brid", bridd)
                                        startActivity(kk)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                        finish()

                                    }
                        } else if (((descriplistenersave == "descchanged") && (listlistener == "listupdate")) || ((descriplistenersave != "descchanged") && (listlistener == "listupdate"))) {
                            pDialogs = SweetAlertDialog(this@ScrollStkOneActivity, SweetAlertDialog.PROGRESS_TYPE)
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialogs!!.setTitleText("Saving...")
                            pDialogs!!.setCancelable(false)
                            pDialogs!!.show()
                            val map = mutableMapOf<String, Any?>()
                            map.put("Receive_count", rec_count.text.toString())
                            map.put("Receive_date", stkreceiveon.text.toString())
                            map.put("Receive_total", gross_tot.text.toString())
                            map.put("Status", tallnottall.text.toString())
                            map.put("stk_Desc", otherdescrip.text.toString())
                            db.collection("${bridd}_Receive Stock").document(relistoids.text.toString())
                                    .update(map)
                                    .addOnSuccessListener {

                                    }


                            var refid = relistoids.text.toString()

                            var receive_path = "${bridd}_Receive Stock/$refid/Received stock items"

                            for (i in 0 until priceArray.size) {
                                var stk_name = pronameArray[i]
                                var stk_mfr = manufacturerArray[i]
                                var stk_hsn = hsnArray[i]
                                var stk_bcode = barcodeArray[i]
                                var stk_quan = quantityArray[i]
                                var stk_pri = priceArray[i]
                                var stk_tot = totArray[i]
                                var stk_cess = cessArray[i]
                                var stk_igst = igstArray[i]
                                var stk_igsttot = igsttotArray[i]
                                var stk_cesstot = cesstotalArray[i]
                                var stk_received = receivedArray[i]
                                var stk_tally = tallyArray[i]
                                var stk_key = keyArray[i]
                                var stk_ori=oriproidArray[i]


                                var qntval = receivedArray[i]

                                var proids = oriproidArray[i]

                                var pathfrbs = oriproidArray[i] + "_" + bridd
                                var duprec=receivedArraycpy[i]


                                var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode,  stk_proid =stk_ori, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received)

                                db.collection(receive_path).document(keyArray[i])
                                        .set(d)
                                        .addOnSuccessListener { documentReference ->

                                            stock_in_hand(i, pathfrbs, qntval, proids,duprec)


                                        }


                            }
                            Handler().postDelayed(Runnable {

                            pDialogs!!.dismiss()
                            Toast.makeText(applicationContext, "Data Saved Successfully", Toast.LENGTH_SHORT).show()
                            val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
                            kk.putExtra("from_rec", "recsave")



                            kk.putExtra("viewtrans", viewtrans)
                            kk.putExtra("addtrans", addtrans)
                            kk.putExtra("edittrans", editetrans)
                            kk.putExtra("deletetrans", deletetrans)
                            kk.putExtra("transfertrans", transfertrans)
                            kk.putExtra("exporttrans", exporttrans)
                            kk.putExtra("sendtrans", sendtrans)


                            kk.putExtra("viewtransano", viewtransano)
                            kk.putExtra("addtransano", addtransano)
                            kk.putExtra("edittransano", editetransano)
                            kk.putExtra("deletetransano", deletetransano)
                            kk.putExtra("transfertransano", transfertransano)
                            kk.putExtra("exporttransano", exporttransano)
                            kk.putExtra("sendtransano", sendtransano)

                            kk.putExtra("viewrec", viewrec)
                            kk.putExtra("addrec", addrec)
                            kk.putExtra("deleterec", deleterec)
                            kk.putExtra("editrec", editrec)
                            kk.putExtra("transferrec", transferrec)
                            kk.putExtra("exportrec", exportrec)
                            kk.putExtra("sendstrec", sendstrec)



                            kk.putExtra("brid", bridd)
                            startActivity(kk)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            finish()
                            },2000)
                        } else if ((descriplistenersave.isEmpty()) && (listlistener.isEmpty())) {
                            Toast.makeText(applicationContext, "Nothing happened for save", Toast.LENGTH_SHORT).show()

                        }
                    }

  else {
                        popup("Receive")
                    }
                }
                else{
                    dialog.dismiss()
                    Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                }


            }
            setNegativeButton("No") { dialog, whichButton ->

                //showMessage("Close the game or anything!")
                val kk = Intent(this@ScrollStkOneActivity, ReceiveActivity::class.java)
                kk.putExtra("from_rec", "recsave")




                kk.putExtra("viewtrans", viewtrans)
                kk.putExtra("addtrans", addtrans)
                kk.putExtra("edittrans", editetrans)
                kk.putExtra("deletetrans", deletetrans)
                kk.putExtra("transfertrans", transfertrans)
                kk.putExtra("exporttrans", exporttrans)
                kk.putExtra("sendtrans", sendtrans)


                kk.putExtra("viewtransano", viewtransano)
                kk.putExtra("addtransano", addtransano)
                kk.putExtra("edittransano", editetransano)
                kk.putExtra("deletetransano", deletetransano)
                kk.putExtra("transfertransano", transfertransano)
                kk.putExtra("exporttransano", exporttransano)
                kk.putExtra("sendtransano", sendtransano)

                kk.putExtra("viewrec", viewrec)
                kk.putExtra("addrec", addrec)
                kk.putExtra("deleterec", deleterec)
                kk.putExtra("editrec", editrec)
                kk.putExtra("transferrec", transferrec)
                kk.putExtra("exportrec", exportrec)
                kk.putExtra("sendstrec",sendstrec)



                kk.putExtra("brid", bridd)
                startActivity(kk)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }

            // Dialog
            val dialog = builder.create()

            dialog.show()
        }
    }
    companion object {

 //Listens internet status whether net is on/off.

        private var relativeslayoutdis: RelativeLayout?=null
        private var pur_savedis: Button?=null
        private var userbackdis: ImageButton?=null
        private var mnudis: ImageButton?=null
        private var constraintLayout3dis: ConstraintLayout?=null
        private var editdis: ImageButton?=null
        private val log_str: String? = null
        private var pDialogs: SweetAlertDialog? = null

        private var ponodis: EditText?=null
        private var orddatedis: EditText?=null
        private var reccntdis:EditText?=null
        private var stkrecdis:EditText?=null

        private var descripdis: EditText?=null

        private var pur_listdis: ListView?=null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                 /// if connection is off then all views becomes disable

                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                pur_savedis!!.isEnabled=false
                userbackdis!!.isEnabled=false
                mnudis!!.isEnabled=false
                editdis!!.isEnabled=false
                reccntdis!!.isEnabled=false
                stkrecdis!!.isEnabled=false
                ponodis!!.isEnabled=false
                orddatedis!!.isEnabled=false

                descripdis!!.isEnabled=false

                pur_listdis!!.isClickable=false
                pur_listdis!!.isEnabled=false
                pur_listdis!!.isLongClickable=false

                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }
            }
            else
            {

                                 /// if connection is off then all views becomes enabled


                relativeslayoutdis!!.visibility=View.GONE
                constraintLayout3dis!!.visibility=View.GONE
                pur_savedis!!.isEnabled=true
                userbackdis!!.isEnabled=true
                mnudis!!.isEnabled=true
                editdis!!.isEnabled=true




                ponodis!!.isEnabled=false
                orddatedis!!.isEnabled=false
                if(editdis!!.visibility!=View.VISIBLE){

                    reccntdis!!.isEnabled=true
                    stkrecdis!!.isEnabled=true
                    descripdis!!.isEnabled=true
                    pur_listdis!!.isEnabled=true

                    pur_listdis!!.isClickable=true
                    pur_listdis!!.isLongClickable=true
                }


            }
        }
    }
    fun stock_in_hand(i:Int,path:String,qnt:String,prid:String,duprecs:String){

        data class Count(var number: Int)
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if(p == null)
                {
                    p =  0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p =  0
                    p = Integer.parseInt(p.toString())+qnt.toInt()

                } else {
                    // Star the post and add self to stars

                    if(qnt.toInt()<duprecs.toInt()){
                        var g=duprecs.toInt()-qnt.toInt()
                        p = Integer.parseInt(p.toString()) - g


                    }
                    else if(duprecs.toInt()<qnt.toInt()){
                        var g=qnt.toInt()-duprecs.toInt()
                        p = Integer.parseInt(p.toString()) + g
                    }




                    /*else if (rr.isNotEmpty()||cls.isEmpty()){

                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$bridd",p)
                db.collection("product").document(prid)
                        .update(map)
                        .addOnSuccessListener {


                        }


                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override  fun onComplete(databaseError : DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

            // Transaction completed
            // Log.d("", "postTransaction:onComplete:" + databaseError)

        })
    }

    fun net_status():Boolean{  ////Check internet status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


    }

