package com.example.vinitas.inventory_app

import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.RelativeLayout
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_supplier_five_main.*
import java.util.*

class supplierFiveMainAct : AppCompatActivity() {





    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var recprice = String()
    var cess = String()
    var tot = String()
    var taxtot = String()
    var pri = String()
    var gtot = String()
    var idkey = String()
    var reckey = String()
    var nwkey = String()

    var stadupspin=String()
    var vounodup=String()
    var invoicedatedup=String()
    var payduedatedup=String()
    var suppdescripdup=String()

    var datest= String()

    var idli = String()
    var imurl = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()

    var frmvali= String()
    var brnchid= String()

    var edclick= String()

    var spinsta=String()

    var pronameArray = arrayOf<String>()
    var hsnArray = arrayOf<String>()
    var manufacturerArray = arrayOf<String>()
    var barcodeArray = arrayOf<String>()
    var quantityArray = arrayOf<String>()
    var priceArray = arrayOf<String>()
    var totArray = arrayOf<String>()
    var cessArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var igstArray = arrayOf<String>()
    var cgstArray = arrayOf<String>()
    var sgstArray = arrayOf<String>()
    var igsttotArray = arrayOf<String>()
    var cesstotalArray = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var receivedpriceArray = arrayOf<String>()
    var receivedtotalArray = arrayOf<String>()
    var receivedcesstotArray = arrayOf<String>()
    var receivedtaxtotalArray = arrayOf<String>()
    var receivedgrosstotArray = arrayOf<String>()
    var imageArray = arrayOf<String>()
    var ids = arrayOf<String>()

    var descriplistener= String()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supplier_five_main)

        //Listens internet changing movements


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@supplierFiveMainAct) > 0)
        {

        }
        else{

        }

        //Define No connection view and other views when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.suppfivecont)
        bottonNavBardis=findViewById(R.id.bottonNavBar)


        userback.setOnClickListener {

            onBackPressed()
        }





        val bundle = intent.extras
        var frm = bundle!!.get("from_suppin").toString()



        edit.setOnClickListener {

            edclick="clicked"

            edit.visibility=View.GONE

            supp_third_list.isClickable=true

            val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,
                    cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray,
                    receivedtaxtotalArray, receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, imageArray)
            supp_third_list.adapter = whatever

        }




        //Comes from 'Supplier_third_MainAct', 'supplier_fourMainAct'
        if (frm == "update_suppinvoice") {



            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            try{
                vounodup=intent.getStringExtra("vounodup")
                invoicedatedup=intent.getStringExtra("invoicedatedup")
                payduedatedup=intent.getStringExtra("payduedatedup")
                suppdescripdup=intent.getStringExtra("suppdescripdup")
                stadupspin=intent.getStringExtra("stadup")
            }
            catch (e:Exception){

            }


            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }


            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            var a = bundle.get("pnm") as Array<String>
            println(a)
            /*     val b=bundle.get("id") as Array<String>*/

            val dsy = bundle.get("phsn") as Array<String>
            val ly = bundle.get("pmanu") as Array<String>
            val fy = bundle.get("barcode") as Array<String>
            val gy = bundle.get("quan") as Array<String>
            val hy = bundle.get("price") as Array<String>
            val ky = bundle.get("tot") as Array<String>
            val my = bundle.get("cessup") as Array<String>
            val ny = bundle.get("igst") as Array<String>
            val cy = bundle.get("cgst") as Array<String>
            val sy = bundle.get("sgst") as Array<String>
            val oy = bundle.get("igsttotal") as Array<String>
            val py = bundle.get("cesstotarray") as Array<String>
            val iddd = bundle.get("idsofli") as Array<String>
            val idtally = bundle.get("tallyarray") as Array<String>
            val idrec = bundle.get("receivedarray") as Array<String>
            println("REEECCCCIIIEEEVVVVEEE" + Arrays.toString(idrec))
            println("KYYYY OOOFFFFF REEECCCCIIIEEEVVVVEEE" + Arrays.toString(iddd))
            val spri = bundle.get("received_price") as Array<String>
            val stot = bundle.get("received_total") as Array<String>
            val staxt = bundle.get("received_taxtot") as Array<String>
            val scesstot = bundle.get("received_cesstot") as Array<String>
            val sgross = bundle.get("received_grosstot") as Array<String>
            val immy = bundle.get("image") as Array<String>



            pronameArray = a
            hsnArray = dsy
            manufacturerArray = ly
            barcodeArray = fy
            quantityArray = gy
            priceArray = hy
            totArray = ky
            cessArray = my
            keyArray = iddd
            igstArray = ny
            cgstArray = cy
            sgstArray = sy
            igsttotArray = oy
            cesstotalArray = py
            tallyArray = idtally
            receivedArray = idrec
            receivedpriceArray = spri
            receivedtotalArray = stot
            receivedcesstotArray = scesstot
            receivedtaxtotalArray = staxt
            receivedgrosstotArray = sgross
            imageArray = immy

            val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                    quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                    igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray, receivedtaxtotalArray,
                    receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, imageArray)
            supp_third_list.adapter = whatever


            try {


                val e = intent.getStringExtra("desc")
                desc = e
            } catch (e: Exception) {

            }
            try {
                val f = intent.getStringExtra("reqdate")
                reqdt = f
            } catch (e: Exception) {

            }
            try {
                val ff = intent.getStringExtra("orddate")
                orddate = ff
            } catch (e: Exception) {

            }
            try {
                val stat = intent.getStringExtra("duedate")
                postatus = stat
            } catch (e: Exception) {

            }
            try {
                val im = intent.getStringExtra("imgurl")
                imurl = im

                Picasso.with(this)
                        .load(im)
                        .into(comp_toolimg)

            } catch (e: Exception) {

            }


            try{
                spinsta=intent.getStringExtra("status")
            }
            catch (e:Exception){

            }


            println("PO STATUSSS" + postatus)

            val aa = intent.getStringExtra("nms")
            comttname.setText(aa)
            val liis = intent.getStringExtra("reqliid")
            reqliid = liis
            val b = intent.getStringExtra("ph")
            comphone.setText(b)
            val lii = intent.getStringExtra("pono")
            pono = lii

            val nm = intent.getStringExtra("reprnms")
            reprnms = nm

            val bridss = intent.getStringExtra("bridkey")
            brnchid = bridss

            frmvali = intent.getStringExtra("backvald")


            try {
                datest = intent.getStringExtra("datest")
            } catch (e: Exception) {

            }

            try {
                descriplistener = intent.getStringExtra("descriplistn")
            } catch (e: Exception) {

            }

            try{

                edclick=intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }


            if(edclick.isEmpty()==true)
            {

                edit.visibility= View.VISIBLE


                supp_third_list.isClickable=false

            }
            else if(edclick=="suppinv"){
                edit.visibility=View.GONE
                supp_third_list.isClickable=true
            }
            else if(edclick=="clicked"){
                edit.visibility= View.GONE
                supp_third_list.isClickable=true
            }

        } else if (frm == "update_supplier") {


            frmvali = intent.getStringExtra("backvald")







            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")



            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            try{
                vounodup=intent.getStringExtra("vounodup")
                invoicedatedup=intent.getStringExtra("invoicedatedup")
                payduedatedup=intent.getStringExtra("payduedatedup")
                suppdescripdup=intent.getStringExtra("suppdescripdup")
                stadupspin=intent.getStringExtra("stadupspin")

            }
            catch (e:Exception){

            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }


            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            val av = bundle!!.get("renm") as Array<String>
            val bv = bundle!!.get("rehsn") as Array<String>
            val mv = bundle!!.get("remanu") as Array<String>
               val dv=bundle!!.get("reprice") as Array<String>
            val ev = bundle!!.get("requan") as Array<String>
            val fv = bundle!!.get("rebc") as Array<String>
            val hv = bundle!!.get("retotal") as Array<String>
            val gv = bundle!!.get("recess") as Array<String>
            val iv = bundle!!.get("reigst") as Array<String>
            val idv = bundle!!.get("recgst") as Array<String>
            val isv = bundle!!.get("resgst") as Array<String>
            val jv = bundle!!.get("reigst_total") as Array<String>
            val kv = bundle!!.get("recesstotal") as Array<String>
            val rekey = bundle!!.get("rekey") as Array<String>
            val ktally = bundle!!.get("retally") as Array<String>
            val rereceive = bundle!!.get("rereceived") as Array<String>
            val rereceivepri = bundle!!.get("rereceived_pri") as Array<String>
            val rereceivetot = bundle!!.get("rereceived_tot") as Array<String>
            val rereceivetaxtot = bundle!!.get("rereceived_taxtot") as Array<String>
            val rereceivecesstot = bundle!!.get("rereceived_cesstot") as Array<String>
            val rereceivegrosstot = bundle!!.get("rereceived_grosstot") as Array<String>
            val immv = bundle!!.get("reimmg") as Array<String>

            val uppono = intent.getStringExtra("pono")
            val orddtup = intent.getStringExtra("reorddate")
            val reqdtup = intent.getStringExtra("reestdt")
            val descup = intent.getStringExtra("redesc")
            val postatusup = intent.getStringExtra("restatus")
            val mainidup = intent.getStringExtra("reids")
            val prnmsup = intent.getStringExtra("names")
            val comnmup = intent.getStringExtra("titnm")
            val comphup = intent.getStringExtra("tiphone")
            val im = intent.getStringExtra("reimgurl")

            val branchids = intent.getStringExtra("brnchids")
            try {

                descriplistener = intent.getStringExtra("descriplistn")
            }
            catch (e:Exception){

            }

            try{
                Picasso.with(this)
                        .load(im)
                        .into(comp_toolimg)
            }
            catch (e:Exception){

            }

            try{
                spinsta=intent.getStringExtra("status")
            }
            catch (e:Exception){

            }


            try{
                edclick=intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }

            if(edclick.isEmpty()==true){
                edit.visibility=View.VISIBLE
                supp_third_list.isClickable=false
            }
            else if(edclick=="suppinv"){
                edit.visibility=View.GONE
                supp_third_list.isClickable=true
            }
            else if(edclick=="clicked"){
                edit.visibility=View.GONE
                supp_third_list.isClickable=true
            }

            val datests = intent.getStringExtra("datest")



            pono = uppono
            orddate = orddtup
            reqdt = reqdtup
            postatus = postatusup
            desc = descup
            reqliid = mainidup
            reprnms = prnmsup
            comttname.setText(comnmup)
            comphone.setText(comphup)
            imurl = im
            datest = datests

            brnchid = branchids







            pronameArray = (av.clone())
            manufacturerArray = mv.clone()
            quantityArray = ev.clone()
            priceArray = dv.clone()
            hsnArray = bv.clone()
            barcodeArray = fv.clone()
            totArray = hv.clone()
            cessArray = gv.clone()
            keyArray = rekey.clone()
            igstArray = iv.clone()
            cgstArray = idv.clone()
            sgstArray = isv.clone()
            igsttotArray = jv.clone()
            cesstotalArray = kv.clone()
            tallyArray = ktally.clone()
            receivedArray = rereceive.clone()
            receivedpriceArray = rereceivepri.clone()
            receivedtaxtotalArray = rereceivetaxtot.clone()
            receivedcesstotArray = rereceivecesstot.clone()
            receivedgrosstotArray = rereceivegrosstot.clone()
            receivedtotalArray = rereceivetot.clone()
            imageArray = immv.clone()


            val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray, receivedtaxtotalArray, receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, imageArray)
            supp_third_list.adapter = whatever

            var kk = priceArray.count()

            watchList.setText("Products ($kk)")
            /*   procnt.setText(kk.toString())*/


        }



        //Supplier invoice list item click and navigate to 'Supplier_fourMainActivity' view the product details
        supp_third_list.setOnItemClickListener { parent, views, position, id ->





                val b = Intent(this@supplierFiveMainAct, Supplier_fourMainActivity::class.java)

                b.putExtra("from_suppin", "update_suppinvoice")
                b.putExtra("pnm", pronameArray)
                b.putExtra("pmanu", manufacturerArray)
                b.putExtra("phsn", hsnArray)
                b.putExtra("barcode", barcodeArray)
                b.putExtra("price", priceArray)
                b.putExtra("quan", quantityArray)
                b.putExtra("tot", totArray)
                b.putExtra("pos", position)
                b.putExtra("cessup", cessArray)
                b.putExtra("igst", igstArray)
                b.putExtra("cgst", cgstArray)
                b.putExtra("sgst", sgstArray)
                b.putExtra("igsttotal", igsttotArray)
                b.putExtra("cesstotarray", cesstotalArray)
                b.putExtra("tallyarray", tallyArray)
                b.putExtra("receivedarray", receivedArray)
                b.putExtra("received_price", receivedpriceArray)
                b.putExtra("received_total", receivedtotalArray)
                b.putExtra("received_taxtot", receivedtaxtotalArray)
                b.putExtra("received_cesstot", receivedcesstotArray)
                b.putExtra("received_grosstot", receivedgrosstotArray)
                b.putExtra("idsofli", keyArray)
                b.putExtra("datest", datest)
                b.putExtra("image", imageArray)
                b.putExtra("reprnms", reprnms)
                b.putExtra("reqliid", reqliid)
                b.putExtra("nms", comttname.text.toString())
                b.putExtra("ph", comphone.text.toString())
                b.putExtra("pono", pono)
                b.putExtra("orddate", orddate)
                b.putExtra("desc", desc)
                b.putExtra("reqdate", reqdt)
                b.putExtra("duedate", postatus)
                b.putExtra("imgurl", imurl)
                b.putExtra("bridkey", brnchid)

                b.putExtra("vounodup",vounodup)
                b.putExtra("invoicedatedup",invoicedatedup)
                b.putExtra("payduedatedup",payduedatedup)
                b.putExtra("suppdescripdup",suppdescripdup)



                b.putExtra("stadupspin",stadupspin)
                b.putExtra("viewsuppin", viewsuppin)
                b.putExtra("addsuppin", addsuppin)
                b.putExtra("deletesuppin", deletesuppin)
                b.putExtra("editsuppin", editesuppin)
                b.putExtra("transfersuppin", transfersuppin)
                b.putExtra("exportsuppin", exportsuppin)


                b.putExtra("viewpurord", viewpurord)
                b.putExtra("addpurord", addpurord)
                b.putExtra("deletepurord", deletepurord)
                b.putExtra("editpurord", editepurord)
                b.putExtra("transferpurord", transferpurord)
                b.putExtra("exportpurord", exportpurord)

                b.putExtra("sendpurord", sendpurpo)



                b.putExtra("viewpurreq", viewpurreq)
                b.putExtra("addpurreq", addpurreq)
                b.putExtra("deletepurreq", deletepurreq)
                b.putExtra("editpurreq", editepurreq)
                b.putExtra("transferpurreq", transferpurreq)
                b.putExtra("exportpurreq", exportpurreq)





b.putExtra("edclick",edclick)


                b.putExtra("backvald", frmvali)
                b.putExtra("desclistn", descriplistener)
                b.putExtra("status",spinsta)

                startActivity(b)
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                finish()



        }



        //-----------------------------Bottom navigation click and navigate to 'Supplier_thirdMainActivity'

        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val `in`: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.matching -> {

                    val o = Intent(this@supplierFiveMainAct,Supplier_thirdMainActivity::class.java)
                    o.putExtra("from_suppin", "update_supplier")






                    o.putExtra("renm", pronameArray)

                    o.putExtra("remanu", manufacturerArray)
                    o.putExtra("rekey", keyArray)
                    o.putExtra("rehsn", hsnArray)
                    o.putExtra("reprice", priceArray)
                    o.putExtra("requan", quantityArray)
                    o.putExtra("rebc", barcodeArray)
                    o.putExtra("retotal", totArray)
                    o.putExtra("recess", cessArray)
                    o.putExtra("reigst", igstArray)
                    o.putExtra("recgst", cgstArray)
                    o.putExtra("resgst", sgstArray)
                    o.putExtra("retally",tallyArray)
                    o.putExtra("rereceived", receivedArray)
                    o.putExtra("rereceived_pri", receivedpriceArray)
                    o.putExtra("rereceived_tot", receivedtotalArray)
                    o.putExtra("rereceived_taxtot", receivedtaxtotalArray)
                    o.putExtra("rereceived_cesstot", receivedcesstotArray)
                    o.putExtra("rereceived_grosstot", receivedgrosstotArray)
                    o.putExtra("reigst_total", igsttotArray)
                    o.putExtra("recesstotal", cesstotalArray)
                    o.putExtra("reimmg", imageArray)
                    o.putExtra("pono", pono)
                    o.putExtra("names", reprnms)
                    o.putExtra("redesc", desc)
                    o.putExtra("reorddate", orddate)
                    o.putExtra("reestdt", reqdt)
                    o.putExtra("restatus", postatus)
                    o.putExtra("vounodup",vounodup)
                    o.putExtra("invoicedatedup",invoicedatedup)
                    o.putExtra("payduedatedup",payduedatedup)
                    o.putExtra("suppdescripdup",suppdescripdup)
                    o.putExtra("stadupspin",stadupspin)


                    o.putExtra("reids", reqliid)
                    o.putExtra("titnm", comttname.text.toString())
                    o.putExtra("tiphone", comphone.text.toString())
                    o.putExtra("status",spinsta)
                    o.putExtra("reimgurl",imurl)
                    o.putExtra("brnchids",brnchid)
                    o.putExtra("backvald",frmvali)
                    o.putExtra("datest",datest)

                    o.putExtra("viewsuppin",  viewsuppin)
                    o.putExtra("addsuppin",   addsuppin)
                    o.putExtra("deletesuppin",deletesuppin)
                    o.putExtra("editsuppin",     editesuppin)
                    o.putExtra("transfersuppin", transfersuppin)
                    o.putExtra("exportsuppin", exportsuppin)



                    o.putExtra("viewpurord", viewpurord)
                    o.putExtra("addpurord", addpurord)
                    o.putExtra("deletepurord", deletepurord)
                    o.putExtra("editpurord", editepurord)
                    o.putExtra("transferpurord", transferpurord)
                    o.putExtra("exportpurord", exportpurord)
                    o.putExtra("sendpurord", sendpurpo)


                    o.putExtra("viewpurreq", viewpurreq)
                    o.putExtra("addpurreq", addpurreq)
                    o.putExtra("deletepurreq", deletepurreq)
                    o.putExtra("editpurreq", editepurreq)
                    o.putExtra("transferpurreq", transferpurreq)
                    o.putExtra("exportpurreq", exportpurreq)




o.putExtra("edclick",edclick)


                    startActivity(o)
                    overridePendingTransition(0, 0)
                    finish()
                }
                    R.id.watchList -> {


                    }

                    else -> {
                    }
                }

        })

    }


    companion object {

                //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private var bottonNavBardis:LinearLayout?=null

        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                bottonNavBardis!!.visibility=View.GONE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                bottonNavBardis!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }




    override fun onBackPressed() {


        //Back action


        val o = Intent(this@supplierFiveMainAct,Supplier_thirdMainActivity::class.java)
        o.putExtra("from_suppin", "update_supplier")






        o.putExtra("renm", pronameArray)

        o.putExtra("remanu", manufacturerArray)
        o.putExtra("rekey", keyArray)
        o.putExtra("rehsn", hsnArray)
        o.putExtra("reprice", priceArray)
        o.putExtra("requan", quantityArray)
        o.putExtra("rebc", barcodeArray)
        o.putExtra("retotal", totArray)
        o.putExtra("recess", cessArray)
        o.putExtra("reigst", igstArray)
        o.putExtra("recgst", cgstArray)
        o.putExtra("resgst", sgstArray)
        o.putExtra("retally",tallyArray)
        o.putExtra("rereceived", receivedArray)
        o.putExtra("rereceived_pri", receivedpriceArray)
        o.putExtra("rereceived_tot", receivedtotalArray)
        o.putExtra("rereceived_taxtot", receivedtaxtotalArray)
        o.putExtra("rereceived_cesstot", receivedcesstotArray)
        o.putExtra("rereceived_grosstot", receivedgrosstotArray)
        o.putExtra("reigst_total", igsttotArray)
        o.putExtra("recesstotal", cesstotalArray)
        o.putExtra("reimmg", imageArray)
        o.putExtra("pono", pono)
        o.putExtra("names", reprnms)
        o.putExtra("redesc", desc)
        o.putExtra("reorddate", orddate)
        o.putExtra("reestdt", reqdt)
        o.putExtra("restatus", postatus)
        o.putExtra("status",spinsta)

        o.putExtra("reids", reqliid)
        o.putExtra("titnm", comttname.text.toString())
        o.putExtra("tiphone", comphone.text.toString())
        o.putExtra("reimgurl",imurl)
        o.putExtra("brnchids",brnchid)
        o.putExtra("backvald",frmvali)
        o.putExtra("datest",datest)

        o.putExtra("viewsuppin",  viewsuppin)
        o.putExtra("addsuppin",   addsuppin)
        o.putExtra("deletesuppin",deletesuppin)
        o.putExtra("editsuppin",     editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)

        o.putExtra("vounodup",vounodup)
        o.putExtra("invoicedatedup",invoicedatedup)
        o.putExtra("payduedatedup",payduedatedup)
        o.putExtra("suppdescripdup",suppdescripdup)
        o.putExtra("stadupspin",stadupspin)

        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)
        o.putExtra("edclick",edclick)


        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)




        startActivity(o)
        overridePendingTransition(0, 0)
        finish()
    }
}
