package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter
import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_main_branch_pdf.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class MainAnotherBranchPdf : AppCompatActivity(),View.OnClickListener {


    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""


    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    private var view=String()
    private var add=String()
    private var delete=String()
    private var edits=String()
    private var import=String()
    private var export=String()

    private var viewpro=String()
    private var addpro=String()
    private var deletepro=String()
    private var editpro=String()
    private var importpro=String()
    private var exportpro=String()
    private var stockin_hand= String()

    private var viewsupp=String()
    private var addsupp=String()
    private var deletesupp=String()
    private var editsupp=String()
    private var importsupp=String()
    private var exportsupp=String()

    private  var viewstklvls=String()

    var orikys= String()
    var names = String()
    var addressnames = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var smlistidss= String()
    var brkey= String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var receivear= String()
    var igstt= String()
    var sgstt= String()
    var cesst= String()
    var grosstt= String()
    var downstatus= String()

    var singrosstot= arrayOf<String>()
    var pronameArray = arrayOf<String>()
    var hsnArray = arrayOf<String>()
    var manufacturerArray = arrayOf<String>()
    var barcodeArray = arrayOf<String>()
    var quantityArray = arrayOf<String>()
    var priceArray = arrayOf<String>()
    var totArray = arrayOf<String>()
    var cessArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var igstArray = arrayOf<String>()
    var cgstArray = arrayOf<String>()
    var sgstArray = arrayOf<String>()
    var igsttotArray = arrayOf<String>()
    var cesstotalArray = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var imageArray = arrayOf<String>()

    var tt=arrayOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_another_branch_pdf)

        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)
        view=intent.getStringExtra("view")
        add=intent.getStringExtra("add")
        delete=intent.getStringExtra("delete")
        edits=intent.getStringExtra("edit")
        import=intent.getStringExtra("import")
        export=intent.getStringExtra("export")


        //Product

        viewpro=intent.getStringExtra("viewpro")
        addpro=intent.getStringExtra("addpro")
        deletepro=intent.getStringExtra("deletepro")
        editpro=intent.getStringExtra("editpro")
        importpro=intent.getStringExtra("importpro")
        exportpro=intent.getStringExtra("exportpro")
        stockin_hand=intent.getStringExtra("changestock")


        //supplier
        viewsupp=intent.getStringExtra("viewsupp")
        addsupp=intent.getStringExtra("addsupp")
        deletesupp=intent.getStringExtra("deletesupp")
        editsupp=intent.getStringExtra("editsupp")
        importsupp=intent.getStringExtra("importsupp")
        exportsupp=intent.getStringExtra("exportsupp")

        viewstklvls=intent.getStringExtra("viewstklvl")

        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }


        //Purchase order
        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }
        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }
        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")
        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }


        val bundle = intent.extras
        var frm = bundle!!.get("fromstate").toString()





        var a= bundle.get("otherst_pnm") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy=bundle.get("otherst_phsn") as Array<String>
        val ly=bundle.get("otherst_pmanu")    as Array<String>
        val fy=bundle.get("otherst_barcode") as Array<String>
        val gy=bundle.get("otherst_quan")    as Array<String>
        val hy=bundle.get("otherst_price")   as Array<String>
        val ky=bundle.get("otherst_tot")     as Array<String>
        val my=bundle.get("otherst_cessup")  as Array<String>
        val ny=bundle.get("otherst_igst") as Array<String>
        val oy=bundle.get("otherst_igsttotal") as Array<String>
        val py=bundle.get("otherst_cesstotarray") as Array<String>
        val idtally=bundle.get("tallyarray") as Array<String>
        val idrec=bundle.get("receivedarray") as Array<String>
        val iddd=bundle.get("otherst_idsofli") as Array<String>

/*
        val namebr=intent.getStringExtra("otherst_branch")
        val dates=intent.getStringExtra("otherst_sstkdate")
        val smlistid=intent.getStringExtra("otherst_smlistids")
        val locbr=intent.getStringExtra("otherst_address")
        val stockid=intent.getStringExtra("otherst_ssstockid")
        val stockdesc=intent.getStringExtra("otherst_ssstkdesc")
        val iddb=intent.getStringExtra("otherst_idofdb")*/
        try {
            val immy=bundle.get("otherst_image") as Array<String>
            tt=immy.clone()
        }
        catch(e:Exception){

        }

        pronameArray = a.clone()
        hsnArray = dsy.clone()
        manufacturerArray = ly.clone()
        barcodeArray = fy.clone()
        quantityArray = gy.clone()
        priceArray = hy.clone()
        totArray = ky.clone()
        cessArray = my.clone()
        igstArray = ny.clone()
        igsttotArray = oy.clone()
        cesstotalArray = py.clone()
        keyArray = iddd.clone()
        tallyArray = idtally.clone()
        receivedArray = idrec.clone()
        try {
            imageArray = tt.clone()
        } catch (e: Exception) {

        }

        try {

            val kybrnch=intent.getStringExtra("keybrnch")
            brkey=kybrnch

            val namebr = intent.getStringExtra("otherst_branch")

            names = namebr

            println("Names" + names)

           /* val kybrnch = intent.getStringExtra("keybrnch")

            brkey = kybrnch*/


            val smlistid = intent.getStringExtra("otherst_smlistids")
            smlistidss = smlistid

            val locbr = intent.getStringExtra("otherst_address")
            addressnames = locbr

            val stockid = intent.getStringExtra("otherst_ssstockid")
            idstk = stockid

            val stockdesc = intent.getStringExtra("otherst_ssstkdesc")
            descstk = stockdesc

            val iddb = intent.getStringExtra("otherst_idofdb")
            iddbs = iddb

            val cgst = intent.getStringExtra("igsttot")
            igstt = cgst

            val cess = intent.getStringExtra("cesstot")
            cesst = cess




            println("address" + addressnames)
            println("ID" + idstk)
        }
        catch (e:Exception)
        {

        }
        val datest = intent.getStringExtra("otherst_sstkdate")
        datestk = datest

        val grosst = intent.getStringExtra("gross")
        grosstt = grosst
        println("GROSS TOT"+grosstt)

        val oribrnky=intent.getStringExtra("originkeys")
        orikys=oribrnky

        /*try {
            //names

            if (names.isNotEmpty()) {
                branchnm.setText(names)
            } else {
                branchnm.setText("-")
            }


            //address

            if (addressnames.isNotEmpty()) {
                branchaddress.setText(addressnames)
            } else {
                branchaddress.setText("-")
            }


            //Gross tot
            if (grosstt.isNotEmpty()) {
                gross.setText(grosstt)
            } else {
                gross.setText("-")
            }

            //cgst

            if (igstt.isNotEmpty()) {
                cgsttot.setText(igstt)
            } else {
                cgsttot.setText("-")
            }

            //Date
            if (datestk.isNotEmpty()) {
                date.setText(datestk)
            } else {
               date.setText("-")
            }

            //sgst


            //stock id
            if (idstk.isNotEmpty()) {
                stno.setText(idstk)
            } else {
                stno.setText("-")
            }

            //description
            if (descstk.isNotEmpty()) {
                descrition.setText(descstk)
            } else {
                descrition.setText("-")
            }

            //cess
            if (cesst.isNotEmpty()) {
                cesstot.setText(cesst)
            } else {
                cesstot.setText("-")
            }
        }
        catch(e:Exception){

        }*/



        addHeaders();
        addData();



        pdf.setOnClickListener {


            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = idstk + "_stock Another_state transfer"

            var y = f + ".pdf"

            val file = File(dir, y)

            if (file.exists()) {


                val builder = AlertDialog.Builder(this)
                with(builder) {
                    setTitle("File Already Exist")
                    setMessage("Do you want to overwrite the existing file?")





                    setPositiveButton("Yes") { dialog, whichButton ->
                        // continue with delete



                        val dialo = SpotsDialog(context, "Downloading pdf...")

                        dialo.show();
                        createandDisplayPdf(idstk, datestk, names, addressnames,descstk, igstt,cesst, grosstt)


                        val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {


                                if(downstatus=="success"){
                                    val mBuilder = NotificationCompat.Builder(this@MainAnotherBranchPdf)
                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                                    intent.setDataAndType(uri, "application/pdf")

                                    val pendingIntent = PendingIntent.getActivity(this@MainAnotherBranchPdf, 0, intent, 0)
                                    mBuilder.setContentIntent(pendingIntent)


                                    val mNotifyManager = this@MainAnotherBranchPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                                    mBuilder.setContentTitle(idstk + "_stock transfer.pdf")
                                    mBuilder.setContentText("Downloaded")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                                    mBuilder.setProgress(100, 100, false)
                                    mNotifyManager.notify(0, mBuilder.build());
                                }

                                dialo.dismiss()

                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)

                        val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF" + a)
                            if (file.exists()) {
                                val builder = AlertDialog.Builder(this@MainAnotherBranchPdf)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->
                                        var f = idstk + "_stock transfer"


                                        var y = f + ".pdf"
                                        viewPdf("Stock Transfer", y)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            } else {

                            }
                        }, 4000)

                    }

                    setNegativeButton("NO") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }


                /* val u = findViewById<ScrollView>(R.id.ss) as ScrollView
            val zx=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView
            val yx=findViewById<RelativeLayout>(R.id.relative) as RelativeLayout
            val cx=findViewById<TableLayout>(R.id.table) as TableLayout

            val totalHeight = cx.height+u.height
            val totalWidth = cx.width+u.width

            val b = getBitmapFromView(yx, totalHeight, totalWidth)
            *//*  val share = Intent(Intent.ACTION_SEND)
              share.type = "image/jpeg"*//*
            val bytes = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

            val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            try {
                f.createNewFile()
                val fo = FileOutputStream(f)
                fo.write(bytes.toByteArray())
                imageToPDF()

            } catch (e: IOException) {
                e.printStackTrace()
            }*/


            } else {

                val dialo = SpotsDialog(this, "Downloading pdf...")

                dialo.show();

                createandDisplayPdf(idstk, datestk, names, addressnames,descstk, igstt, cesst, grosstt)

                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {

                        if(downstatus=="success"){
                            val mBuilder = NotificationCompat.Builder(this@MainAnotherBranchPdf)
                            val intent = Intent(Intent.ACTION_CHOOSER)
                            val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                            intent.setDataAndType(uri, "application/pdf")

                            val pendingIntent = PendingIntent.getActivity(this@MainAnotherBranchPdf, 0, intent, 0)
                            mBuilder.setContentIntent(pendingIntent)


                            val mNotifyManager = this@MainAnotherBranchPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                            mBuilder.setContentTitle(idstk + "_stock transfer.pdf")
                            mBuilder.setContentText("Downloaded")
                            mBuilder.setSmallIcon(R.drawable.ic_logo)
                            mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                            mBuilder.setProgress(100, 100, false)
                            mNotifyManager.notify(0, mBuilder.build());
                        }

                        dialo.dismiss()
                        var b = "null"

                        timer2.cancel() //this will cancel the timer of the system
                    }


                }, 3000)

                val handler = Handler()
                handler.postDelayed({
                    println("INSIDE IF" + a)
                    if (file.exists()) {
                        val builder = AlertDialog.Builder(this@MainAnotherBranchPdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->

                                var f = idstk + "_stock Another_state transfer"


                                var y = f + ".pdf"
                                viewPdf("Stock Transfer", y)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    } else {

                    }

                }, 4000)
            }
        }
        back.setOnClickListener {


            val o= Intent(this@MainAnotherBranchPdf,Main_stk_delhi::class.java)
            o.putExtra("otheruprenm",a)
            o.putExtra("fromstate","frmotherpdf")
            o.putExtra("otherupremanu",ly)
            o.putExtra("otheruprekey",iddd)
            o.putExtra("otheruprehsn",dsy)
            o.putExtra("otherupreprice",hy)
            o.putExtra("otheruprequan",gy)
            o.putExtra("otheruprebc",fy)
            o.putExtra("otherupretotal",ky)
            o.putExtra("otheruprecess",my)
            o.putExtra("otherupreimmg",tt)
            o.putExtra("otherupbranch",names)
            o.putExtra("otherupaddress",addressnames)
            o.putExtra("otherupredate",datestk)
            o.putExtra("otherupredesc",descstk)
            o.putExtra("otheruprestkid",idstk)
            o.putExtra("otherupreiddb",iddbs)
            o.putExtra("otherupsmlistidss",smlistidss)
            o.putExtra("otherupreiddofli",idli)
            o.putExtra("retally",idtally)
            o.putExtra("rereceived",idrec)
            o.putExtra("otherreigst",ny)
            o.putExtra("otherreigst_total",oy)
            o.putExtra("otherrecesstotal",py)
            o.putExtra("brnchky",brkey)
            o.putExtra("oribrnky",orikys)
            o.putExtra("viewsuppin", viewsuppin)
            o.putExtra("addsuppin", addsuppin)
            o.putExtra("deletesuppin", deletesuppin)
            o.putExtra("editsuppin", editesuppin)
            o.putExtra("transfersuppin", transfersuppin)
            o.putExtra("exportsuppin", exportsuppin)


            o.putExtra("viewpurord", viewpurord)
            o.putExtra("addpurord", addpurord)
            o.putExtra("deletepurord", deletepurord)
            o.putExtra("editpurord", editepurord)
            o.putExtra("transferpurord", transferpurord)
            o.putExtra("exportpurord", exportpurord)
            o.putExtra("sendpurord", sendpurpo)




            o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)


            o.putExtra("viewpro", viewpro)
            o.putExtra("addpro", addpro)
            o.putExtra("editpro", editpro)
            o.putExtra("deletepro", deletepro)
            o.putExtra("importpro", importpro)
            o.putExtra("exportpro", exportpro)
            o.putExtra("changestock", stockin_hand)


            o.putExtra("view", view)
            o.putExtra("add", add)
            o.putExtra("edit", edits)
            o.putExtra("delete", delete)
            o.putExtra("import", import)
            o.putExtra("export", export)


            o.putExtra("viewsupp", viewsupp)
            o.putExtra("addsupp", addsupp)
            o.putExtra("editsupp", editsupp)
            o.putExtra("deletesupp", deletesupp)
            o.putExtra("importsupp", importsupp)
            o.putExtra("exportsupp", exportsupp)



            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


            o.putExtra("viewtransano", viewtransano)
            o.putExtra("addtransano", addtransano)
            o.putExtra("edittransano", editetransano)
            o.putExtra("deletetransano", deletetransano)
            o.putExtra("transfertransano", transfertransano)
            o.putExtra("exporttransano", exporttransano)
            o.putExtra("sendtransano", sendtransano)

            o.putExtra("viewrec", viewrec)
            o.putExtra("addrec", addrec)
            o.putExtra("deleterec", deleterec)
            o.putExtra("editrec", editrec)
            o.putExtra("transferrec", transferrec)
            o.putExtra("exportrec", exportrec)
            o.putExtra("sendstrec",sendstrec)


            o.putExtra("viewstklvl",viewstklvls)
            startActivity(o)
            finish()
        }
    }


    override fun onBackPressed() {
        val bundle = intent.extras
        var frm = bundle!!.get("fromstate").toString()





        var a= bundle.get("otherst_pnm") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy=bundle.get("otherst_phsn") as Array<String>
        val ly=bundle.get("otherst_pmanu")    as Array<String>
        val fy=bundle.get("otherst_barcode") as Array<String>
        val gy=bundle.get("otherst_quan")    as Array<String>
        val hy=bundle.get("otherst_price")   as Array<String>
        val ky=bundle.get("otherst_tot")     as Array<String>
        val my=bundle.get("otherst_cessup")  as Array<String>
        val ny=bundle.get("otherst_igst") as Array<String>
        val oy=bundle.get("otherst_igsttotal") as Array<String>
        val py=bundle.get("otherst_cesstotarray") as Array<String>
        val idtally=bundle.get("tallyarray") as Array<String>
        val idrec=bundle.get("receivedarray") as Array<String>
        val iddd=bundle.get("otherst_idsofli") as Array<String>

/*
        val namebr=intent.getStringExtra("otherst_branch")
        val dates=intent.getStringExtra("otherst_sstkdate")
        val smlistid=intent.getStringExtra("otherst_smlistids")
        val locbr=intent.getStringExtra("otherst_address")
        val stockid=intent.getStringExtra("otherst_ssstockid")
        val stockdesc=intent.getStringExtra("otherst_ssstkdesc")
        val iddb=intent.getStringExtra("otherst_idofdb")*/
        try {
            val immy=bundle.get("otherst_image") as Array<String>
            tt=immy.clone()
        }
        catch(e:Exception){

        }

        pronameArray = a.clone()
        hsnArray = dsy.clone()
        manufacturerArray = ly.clone()
        barcodeArray = fy.clone()
        quantityArray = gy.clone()
        priceArray = hy.clone()
        totArray = ky.clone()
        cessArray = my.clone()
        igstArray = ny.clone()
        igsttotArray = oy.clone()
        cesstotalArray = py.clone()
        keyArray = iddd.clone()
        tallyArray = idtally.clone()
        receivedArray = idrec.clone()
        try {
            imageArray = tt.clone()
        } catch (e: Exception) {

        }
        val o= Intent(this@MainAnotherBranchPdf,Main_stk_delhi::class.java)
        o.putExtra("otheruprenm",a)
        o.putExtra("fromstate","frmotherpdf")
        o.putExtra("otherupremanu",ly)
        o.putExtra("otheruprekey",iddd)
        o.putExtra("otheruprehsn",dsy)
        o.putExtra("otherupreprice",hy)
        o.putExtra("otheruprequan",gy)
        o.putExtra("otheruprebc",fy)
        o.putExtra("otherupretotal",ky)
        o.putExtra("otheruprecess",my)
        o.putExtra("otherupreimmg",tt)
        o.putExtra("otherupbranch",names)
        o.putExtra("otherupaddress",addressnames)
        o.putExtra("otherupredate",datestk)
        o.putExtra("otherupredesc",descstk)
        o.putExtra("otheruprestkid",idstk)
        o.putExtra("otherupreiddb",iddbs)
        o.putExtra("otherupsmlistidss",smlistidss)
        o.putExtra("otherupreiddofli",idli)
        o.putExtra("retally",idtally)
        o.putExtra("rereceived",idrec)
        o.putExtra("otherreigst",ny)
        o.putExtra("otherreigst_total",oy)
        o.putExtra("otherrecesstotal",py)
        o.putExtra("brnchky",brkey)
        o.putExtra("oribrnky",orikys)
        o.putExtra("viewsuppin", viewsuppin)
        o.putExtra("addsuppin", addsuppin)
        o.putExtra("deletesuppin", deletesuppin)
        o.putExtra("editsuppin", editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)


        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)




      o.putExtra("viewpurreq", viewpurreq)
      o.putExtra("addpurreq", addpurreq)
      o.putExtra("deletepurreq", deletepurreq)
      o.putExtra("editpurreq", editepurreq)
      o.putExtra("transferpurreq", transferpurreq)
      o.putExtra("exportpurreq", exportpurreq)


      o.putExtra("viewpro", viewpro)
      o.putExtra("addpro", addpro)
      o.putExtra("editpro", editpro)
      o.putExtra("deletepro", deletepro)
      o.putExtra("importpro", importpro)
      o.putExtra("exportpro", exportpro)
      o.putExtra("changestock", stockin_hand)


      o.putExtra("view", view)
      o.putExtra("add", add)
      o.putExtra("edit", edits)
      o.putExtra("delete", delete)
      o.putExtra("import", import)
      o.putExtra("export", export)


      o.putExtra("viewsupp", viewsupp)
      o.putExtra("addsupp", addsupp)
      o.putExtra("editsupp", editsupp)
      o.putExtra("deletesupp", deletesupp)
      o.putExtra("importsupp", importsupp)
      o.putExtra("exportsupp", exportsupp)



       o.putExtra("viewtrans", viewtrans)
       o.putExtra("addtrans", addtrans)
       o.putExtra("edittrans", editetrans)
       o.putExtra("deletetrans", deletetrans)
       o.putExtra("transfertrans", transfertrans)
       o.putExtra("exporttrans", exporttrans)
       o.putExtra("sendtrans", sendtrans)


       o.putExtra("viewtransano", viewtransano)
       o.putExtra("addtransano", addtransano)
       o.putExtra("edittransano", editetransano)
       o.putExtra("deletetransano", deletetransano)
       o.putExtra("transfertransano", transfertransano)
       o.putExtra("exporttransano", exporttransano)
       o.putExtra("sendtransano", sendtransano)

       o.putExtra("viewrec", viewrec)
       o.putExtra("addrec", addrec)
       o.putExtra("deleterec", deleterec)
       o.putExtra("editrec", editrec)
       o.putExtra("transferrec", transferrec)
       o.putExtra("exportrec", exportrec)
       o.putExtra("sendstrec",sendstrec)


       o.putExtra("viewstklvl",viewstklvls)
        startActivity(o)
        finish()
    }


    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {
        val tv = TextView(this)
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()
        tv.setOnClickListener(this)
        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {
        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)
        tr.layoutParams = getLayoutParams()

                tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
                tl.addView(tr, getTblLayoutParams())
    }
    var ee=0.0F
    var cc=0.0F
    var gros=0.0F
    var ig=0.0F
    var cg=0.0F
    var sg=0.0F
    var ces=0.0F

    fun addData() {

        val tl = findViewById<TableLayout>(R.id.table)
        for (i in 0 until priceArray.size) {
            val tr = TableRow(this)
            tr.layoutParams = getLayoutParams()

            var pri=priceArray[i].toFloat()
            var quan=quantityArray[i].toFloat()
            var e=igsttotArray[i].toFloat()
            var f=cesstotalArray[i].toFloat()

            var jj=e+f

            var grtt=jj
            var grflo=grtt
            var gttt=grflo+(pri*quan)

            var grossrealtot=gttt+gros

            singrosstot=singrosstot.plusElement(grossrealtot.toString())


            tr.addView(getTextView(i + 1, (i+1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr, getTblLayoutParams())
        }
        val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2= TableRow(this)
        val trval3= TableRow(this)
        val trval4= TableRow(this)
        val trval5= TableRow(this)
        val trval6= TableRow(this)



        tr2.layoutParams = getLayoutParams()

        trval3.addView(getTextView( 0,igstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        //trval4.addView(getTextView( 0,sgstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView( 0,cesst, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView( 0,grosstt,ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


      tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        //tr3.addView(getTextView( 1,"CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        //tr4.addView(getTextView( 1,"SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView( 1,"Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView( 1,"Gross TOTAL:",ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        t2.addView(tr2, getTblLayoutParams())
        //t2.addView(tr3, getTblLayoutParams())
        //t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        t3.addView(trval3, getTblLayoutParams())
        //t3.addView(trval3, getTblLayoutParams())
        //t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())
    }


    override fun onClick(v: View)
    {
        val id = v.id
        val tv = findViewById<TextView>(id)
        if (null != tv) {
            Log.i("onClick", "Clicked on row :: " + id)
            Toast.makeText(this, "Clicked on row :: " + id + ", Text :: " + tv.text, Toast.LENGTH_SHORT).show()
        }
    }
    fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqphone:String,reqestidate:String,cgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Stock Transfer"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f = idstk + "_stock Another_state transfer"

            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Stock Transfer",fontsubheading)

            val a1=  Paragraph("Branch Name:             "+reqname,font)
            val b1=  Paragraph("Branch Address:           "+reqphone,font)
            val c1=  Paragraph("ST No:                        "+id,font)
            val d1=  Paragraph("Date:                          "+requestdt,font)
            val e1=  Paragraph("Description:                    "+reqestidate,font)
            val p13 =  Paragraph("IGST Total:                  "+cgsttotal,font)

            val p15 =  Paragraph("CESS Total:                  "+cesstotal,font)
            val p7 =  Paragraph("Gross Total:                 "+grosstot,font)
            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)

                var grossrealtot=gttt+gros



                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


             table.addCell("")

             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("IGST Total")
             table.addCell(igstt)

         /*   table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgstt)*/

        /*    table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstt)*/

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)
            /*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*/





            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE );
            doc.add(hs1)
            doc.add( Chunk.NEWLINE );
            doc.add(c1)
            doc.add( Chunk.NEWLINE );
            doc.add(d1)
            doc.add( Chunk.NEWLINE );
            doc.add(a1)
            doc.add( Chunk.NEWLINE );
            doc.add(b1)
            doc.add( Chunk.NEWLINE );
            doc.add(e1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(p8)
         /*   doc.add( Chunk.NEWLINE );
            doc.add(p13)

            doc.add( Chunk.NEWLINE );
            doc.add(p15)
            doc.add( Chunk.NEWLINE );
            doc.add(p7)*/



            doc.add( Chunk.NEWLINE );
            doc.add(table)

            downstatus="success"


        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }
    fun viewPdf(folder:String,file:String) {
        try {




            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + folder,file)
            println("SD CARD URL" + pdfFile)
            val path = Uri.fromFile(pdfFile)

            // Setting the intent for pdf reader
            val pdfIntent = Intent(Intent.ACTION_VIEW)
            pdfIntent.setDataAndType(path,"application/pdf")
            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

            try {
                startActivity(pdfIntent);
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }


        }

        catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW)
            val k = folder.replace("%20", "")
            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + folder + "/" + file
            println("PATH"+path)
            val targetFile = File(path)
            println("TARGET PATH"+targetFile)
            val targetUri = Uri.fromFile(targetFile)


            try {
                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider",targetFile)
                println("URI"+photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(photoURI, "application/pdf")
                startActivity(intent);
                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }

        }

    }


}


