package com.example.vinitas.gallery.sampledata




object FolderListContent {

    val FOLDERS: MutableList<FolderItem> = ArrayList()
    val FOLDERS_MAP: MutableMap<String, FolderItem> = HashMap()

    // used to locate item in popupwindow
    lateinit var selectedFolder: FolderItem
    var selectedFolderIndex: Int = 0
    fun setSelectedFolder(currentFolder: FolderItem, index: Int) {
        FolderListContent.selectedFolder = currentFolder
        FolderListContent.selectedFolderIndex = index
    }


    fun clear() {
        FOLDERS.clear()
        FOLDERS_MAP.clear()
    }

    fun addItem(item: FolderItem) {
        FOLDERS.add(item)
        FOLDERS_MAP[item.path] = item
    }

    fun getItem(folderPath: String): FolderItem? {
        return if (FOLDERS_MAP.containsKey(folderPath)) {
            FOLDERS_MAP[folderPath]
        } else {
            null
        }
    }
}