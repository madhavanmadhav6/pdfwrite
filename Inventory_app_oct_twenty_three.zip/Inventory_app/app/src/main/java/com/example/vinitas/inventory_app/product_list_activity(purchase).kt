package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.EventListener

import android.widget.LinearLayout
import de.hdodenhof.circleimageview.CircleImageView
import android.view.Gravity
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.QuerySnapshot
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.product_list_activity_pur.*
import java.util.*


class product_list_activity_pur : AppCompatActivity() {

    var grosschk= String()
    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()

    var suppinv=String()

    var edclick=String()

    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""

var ids= arrayOf<String>()


    var descriplistener=String()
    var listListener=String()

    var supplieridfr=String()



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    var bcd= String()
    var sd = String()
    var x = String()
    var reg = String()
    var esc = String()
    var upstr = String()
    var numberstr = String()
    var regtr = String()
    var nmstr = String()




    var names = String()
    /* var reqid = String()
     var reqdt = String()
     var reqnm = String()
     var reqmail = String()
     var reqph = String()
     var reqest = String()
     var nms = String()
     var supadd1 = String()
     var supadd2 = String()
     var supadd3 = String()
     var supgst = String()
     var supph = String()
     var supcity = String()
     var supstate = String()*/
    var nms = String()
    var ph = String()
    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()
    var namesori = String()
    var namesphones = String()
    var keybrnch=String()
    var namesphonesori = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var idli= arrayOf<String>()
    var imli = String()

    var orddatedup=String()
    var reqdatedup=String()
    var descripdup=String()



    var pronameArraycpy     = arrayListOf<String>()
    var hsnArraycpy          = arrayListOf<String>()

    var manufacturerArraycpy = arrayListOf<String>()
    var barcodeArraycpy     = arrayListOf<String>()
    var quantityArraycpy     = arrayListOf<String>()
    var priceArraycpy       = arrayListOf<String>()
    var totArraycpy         = arrayListOf<String>()
    var grosstotArraycpy         = arrayListOf<String>()

    var cessArraycpy         = arrayListOf<String>()
    var igstArraycpy= arrayListOf<String>()
    var cgstArraycpy= arrayListOf<String>()
    var sgstArraycpy= arrayListOf<String>()

    var igsttotArraycpy = arrayListOf<String>()
    var cesstotalArraycpy = arrayListOf<String>()
    var tallyArraycpy = arrayListOf<String>()
    var receivedArraycpy = arrayListOf<String>()
    var receivedArraypricpy = arrayListOf<String>()
    var receivedArraytaxtotcpy = arrayListOf<String>()
    var receivedArraytotalcpy = arrayListOf<String>()
    var receivedArraygrosstotalcpy = arrayListOf<String>()
    var receivedArraycesstotalcpy = arrayListOf<String>()

    var imageArraycpy        = arrayListOf<String>()
    var idproArraycpy=arrayListOf<String>()
    var idupArraycpy=arrayListOf<String>()





    var  pronameArrayori     = arrayListOf<String>()
    var  hsnArrayori         = arrayListOf<String>()
    var  manufacturerArrayori= arrayListOf<String>()
    var  barcodeArrayori      = arrayListOf<String>()
    var  quantityArrayori     = arrayListOf<String>()
    var  priceArrayori        = arrayListOf<String>()
    var  totArrayori         = arrayListOf<String>()
    var  grosstotArrayori         = arrayListOf<String>()

    var  cessArrayori        = arrayListOf<String>()
    var igstArrayori =arrayListOf<String>()
    var cgstArrayori =arrayListOf<String>()
    var sgstArrayori =arrayListOf<String>()
    var igsttotArrayori =arrayListOf<String>()
    var cesstotalArrayori =arrayListOf<String>()
    var tallyArrayori =arrayListOf<String>()
    var receivedArrayori =arrayListOf<String>()
    var receivedArraypriori = arrayListOf<String>()
    var receivedArraytaxtotori = arrayListOf<String>()
    var receivedArraytotalori = arrayListOf<String>()
    var receivedArraygrosstotalori = arrayListOf<String>()
    var receivedArraycesstotalori = arrayListOf<String>()

    var  imageArrayori        = arrayListOf<String>()
    var  idproArrayori        = arrayListOf<String>()

    var keyArrayori=arrayListOf<String>()


    var  pronameArray       = arrayListOf<String>()
    var  hsnArray           = arrayListOf<String>()
    var  manufacturerArray  = arrayListOf<String>()
    var  barcodeArray       = arrayListOf<String>()
    var  quantityArray      = arrayListOf<String>()
    var  priceArray         = arrayListOf<String>()
    var  totArray           = arrayListOf<String>()
    var  grosstotArray           = arrayListOf<String>()

    var  cessArray          = arrayListOf<String>()
    var  imageArray         = arrayListOf<String>()
    var  igstArray         = arrayListOf<String>()
    var  cgstArray         = arrayListOf<String>()
    var  sgstArray         = arrayListOf<String>()
    var  igsttotArray         = arrayListOf<String>()
    var  cesstotalArray         = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var receivedArraypri = arrayListOf<String>()
    var receivedArraytaxtot = arrayListOf<String>()
    var receivedArraytotal = arrayListOf<String>()
    var receivedArraygrosstotal = arrayListOf<String>()
    var receivedArraycesstotal = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var keyArray=arrayListOf<String>()
    var idproArray=arrayListOf<String>()

    var d = arrayListOf<String>()

    var dlt = arrayListOf<String>()

    var brnchids= String()
    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
   /* var compnameArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
    var itemnmArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
    var orderArray = arrayOf<String>("BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273")
    var poArray = arrayOf<String>("60/100 Received","20/100 Received","30/100 Received","40/100 Received","50/100 Received")
    var completeArray = arrayOf<String>("200ml","300ml","400ml","500ml","600ml")
    var priceArray = arrayOf<String>("3000.00","4000.00","4500.00","5000.00","6000.00")
    var imageArray = arrayOf<Int>(R.drawable.promen,R.drawable.loreal_bottl,R.drawable.loreal_bottl,R.drawable.promen,R.drawable.loreal_bottl)
    var d = arrayListOf<String>("fireboost","loreal","fireboost","professional","pantine")*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.product_list_activity_pur)


       net_status()          //Check internet status.





       var idforarr=arrayListOf<String>()


       val bundle = intent.extras
       var frm = bundle!!.get("from_pur").toString()





       
       search.setOnClickListener {           //Image button search  action
           cardsearch.visibility = View.VISIBLE
           if(spinner.selectedItemPosition==0){
               searchedit.setHint("Search in $nms products" )
           }
           else if(spinner.selectedItemPosition==1){
               searchedit.setHint("Search in all products")
           }
           cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity_pur, R.anim.slide_to_right))
           searchedit.requestFocus()
           val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
           imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
       }


       searback1.setOnClickListener {           //Image button search back action
           searchedit.setText("")
           cardsearch.visibility = View.GONE

           cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity_pur, R.anim.slide_to_left))
           nores.visibility = View.INVISIBLE
           pur_product_list.visibility = View.VISIBLE
           progressBar3.visibility = View.GONE
           get()
           /* nores.visibility=View.INVISIBLE
            clilist1.visibility=View.VISIBLE
            searchedit.setText("")*/
           /* get()*/
       }


/*
       if(frm=="pur_emptylist")
       {
           val namebr=intent.getStringExtra("branch")
           val locbr=intent.getStringExtra("address")
           val brkey=intent.getStringExtra("brnchid")
           purpro_nm.setText(namebr)
           println("BRANCH NAME"+purpro_nm.text)
           purpro_loc.setText(locbr)
           purpro_brnchkey.setText(brkey)
           keybrnch=purpro_brnchkey.text.toString()
           names=purpro_nm.text.toString()
           namesphones=purpro_loc.text.toString()
       }*/


       /*private fun addImageView(layout: LinearLayout) {
            val imageView = ImageView(this)
            imageView.setImageResource(R.drawable.ic_launcher)
            layout.addView(imageView)
        }*/
       if(frm=="emptylist"){

           //Purchase order




           //Purchase order

           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")
           sendpurpo=intent.getStringExtra("sendpurord")

           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }




           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }

           try {
               orddatedup = intent.getStringExtra("orddatedup")
               reqdatedup = intent.getStringExtra("reqdatedup")
               descripdup = intent.getStringExtra("descripdup")
           }
           catch (e:Exception){

           }

           try {
               descriplistener = intent.getStringExtra("descriplistener")
               listListener = intent.getStringExtra("listListener")

           }
           catch (e:Exception){

           }



           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")
           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")

           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
           }

           try{

               suppinv=intent.getStringExtra("suppinv")
           }
           catch (e:Exception){

           }

           try {
               val e = intent.getStringExtra("desc")
               desc = e
               val f = intent.getStringExtra("reqdate")
               reqdt = f
               val ff = intent.getStringExtra("orddate")
               orddate = ff

               val stat = intent.getStringExtra("postatus")
               postatus = stat
               println("PO STATUSSS"+postatus)
           } catch (e: Exception) {

           }
           val aa = intent.getStringExtra("nms")
           nms=aa
           val categories1 = ArrayList<String>()
           categories1.add("$aa products")
           categories1.add("All products")
           val dataAdaptermob = ArrayAdapter(this@product_list_activity_pur, R.layout.support_simple_spinner_dropdown_item, categories1)
           dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
           spinner.adapter = dataAdaptermob

           val brid = intent.getStringExtra("brids")
           brnchids=brid
           val liis = intent.getStringExtra("reqliid")
           reqliid = liis
           val b = intent.getStringExtra("ph")
           ph=b
           val lii = intent.getStringExtra("pono")
           pono = lii

           val nm = intent.getStringExtra("reprnms")
           reprnms = nm


           val grochk=intent.getStringExtra("grosschk")

           grosschk=grochk


           try{
               supplieridfr=intent.getStringExtra("supplieridfr")
           }
           catch (e:Exception){

           }

           try{
               edclick=intent.getStringExtra("edclick")
           }
           catch (e:Exception){

           }

       }

       else if(frm=="pur_datalist") {

           //Purchase order





           //Purchase order

           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")
           sendpurpo=intent.getStringExtra("sendpurord")

           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }




           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }



           try {
               orddatedup = intent.getStringExtra("orddatedup")
               reqdatedup = intent.getStringExtra("reqdatedup")
               descripdup = intent.getStringExtra("descripdup")
           }
           catch (e:Exception){

           }



           try {
               descriplistener = intent.getStringExtra("descriplistener")
               listListener = intent.getStringExtra("listListener")

           }
           catch (e:Exception){

           }

           try{

               suppinv=intent.getStringExtra("suppinv")
           }
           catch (e:Exception){

           }

           try{
               edclick=intent.getStringExtra("edclick")
           }
           catch (e:Exception){

           }

           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")
           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")

           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
         }


           var a = bundle.get("namess") as ArrayList<String>
           println(a)
           /*     val b=bundle.get("id") as Array<SListtring>*/
           val c = bundle.get("orderarray") as ArrayList<String>
           val ds = bundle.get("hsn") as ArrayList<String>
           /*    val l=bundle.get("item") as Array<SListtring>*/
           val f = bundle.get("poarray") as ArrayList<String>
           val g = bundle.get("complete") as ArrayList<String>
           val h = bundle.get("price") as ArrayList<String>
           val i = bundle.get("total") as ArrayList<String>
           val igro = bundle.get("grosstotal") as ArrayList<String>

           val j = bundle.get("cess") as ArrayList<String>
           val r = bundle.get("igst") as ArrayList<String>
           val p = bundle.get("cgst") as ArrayList<String>
           val sg = bundle.get("sgst") as ArrayList<String>
           val s = bundle.get("igsttotal") as ArrayList<String>
           val q = bundle.get("cesstotarray") as ArrayList<String>
           val qtall = bundle.get("tallyarray") as ArrayList<String>
           val rec = bundle.get("receivedarray") as ArrayList<String>
           val idddpri = bundle.get("receivedarray_pri") as ArrayList<String>
           val idddtaxtot = bundle.get("receivedarray_taxtot") as ArrayList<String>
           val idddtot = bundle.get("receivedarray_tot") as ArrayList<String>
           val idddcesstot = bundle.get("receivedarray_cesstot") as ArrayList<String>
           val idddgrosstot = bundle.get("receivedarray_grosstot") as ArrayList<String>
           val iddd = bundle.get("idsofli") as ArrayList<String>
           val k = bundle.get("im") as ArrayList<String>
           val idpr= bundle.get("idpro") as ArrayList<String>

           ids=bundle.get("ids") as Array<String>


           try {
               val e = intent.getStringExtra("desc")
               desc = e
               val f = intent.getStringExtra("reqdate")
               reqdt = f
               val ff = intent.getStringExtra("orddate")
               orddate = ff

               val stat = intent.getStringExtra("postatus")
               postatus = stat
               println("PO STATUSSS" + postatus)
           } catch (e: Exception) {

           }
           val aa = intent.getStringExtra("nms")
           nms = aa
           val brid = intent.getStringExtra("brids")
           brnchids = brid
           val liis = intent.getStringExtra("reqliid")
           reqliid = liis
           val b = intent.getStringExtra("ph")
           ph = b
           val lii = intent.getStringExtra("pono")
           pono = lii

           val nm = intent.getStringExtra("reprnms")
           reprnms = nm

           val categories1 = ArrayList<String>()
           categories1.add("$nms products")
           categories1.add("All products")
           val dataAdaptermob = ArrayAdapter(this@product_list_activity_pur, R.layout.support_simple_spinner_dropdown_item, categories1)
           dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
           spinner.adapter = dataAdaptermob


           try{
               val grochk=intent.getStringExtra("grosschk")
               grosschk=grochk

               println("grosschk "+grosschk)

           }
           catch (e:Exception){

           }

           try{
               supplieridfr=intent.getStringExtra("supplieridfr")
           }
           catch (e:Exception){

           }

           pronameArrayori = a
           hsnArrayori = ds
           manufacturerArrayori = c
           barcodeArrayori = f
           quantityArrayori = g
           priceArrayori = h
           totArrayori = i
           grosstotArrayori = igro

           receivedArrayori = rec
           cessArrayori = j
           igstArrayori = r
           cgstArrayori = p
           sgstArrayori = sg
           igsttotArrayori = s
           cesstotalArrayori = q
           tallyArrayori = qtall
           receivedArraypriori = idddpri
           receivedArraytotalori = idddtot
           receivedArraytaxtotori = idddtaxtot
           receivedArraycesstotalori = idddcesstot
           receivedArraygrosstotalori = idddgrosstot
           imageArrayori = k
           keyArrayori = iddd
           idproArrayori=idpr

       }

       pur_product_list.setOnItemClickListener { parent, views, position, id ->


           ///--------------------------Single select on product lis------------------------------//


           val az=pronameArray.get(position)
           val bz=hsnArray.get(position)
           val t = manufacturerArray.get(position)
           val cz=quantityArray.get(position)
           val mz=barcodeArray.get(position)
           val fz=priceArray.get(position)
           val oz=totArray.get(position)
           val ozgro=grosstotArray.get(position)

           val qz=cessArray.get(position)
           val qigz=igstArray.get(position)
           val higz=cgstArray.get(position)
           val digz=sgstArray.get(position)
           val qigtotz=igsttotArray.get(position)
           val qcesstotz=cesstotalArray.get(position)
           val qtallyz=tallyArray.get(position)
           val qtallypri=receivedArraypri.get(position)
           val qtallytot=receivedArraytotal.get(position)
           val qtallytaxtot=receivedArraytaxtot.get(position)
           val qtallycesstot=receivedArraycesstotal.get(position)
           val qtallygross=receivedArraygrosstotal.get(position)
           val rece=receivedArray.get(position)
           val imz=imageArray.get(position)
           val idprz=idproArray.get(position)
           val li=keyArray.get(position)


           pronameArraycpy.add(az)
           manufacturerArraycpy.add(t)
           hsnArraycpy.add(bz)
           quantityArraycpy.add(cz)
           barcodeArraycpy.add(mz)
           priceArraycpy.add(fz)
           totArraycpy.add(oz)
           grosstotArraycpy.add(ozgro)

           cessArraycpy.add(qz)
           igstArraycpy.add(qigz)
           cgstArraycpy.add(higz)
           sgstArraycpy.add(digz)
           igsttotArraycpy.add(qigtotz)
           cesstotalArraycpy.add(qcesstotz)
           tallyArraycpy.add(qtallyz)
           receivedArraypricpy.add(qtallypri)
           receivedArraytaxtotcpy.add(qtallytaxtot)
           receivedArraycesstotalcpy.add(qtallycesstot)
           receivedArraygrosstotalcpy.add(qtallygross)
           receivedArraytotalcpy.add(qtallytot)
           receivedArraycpy.add(rece)
           imageArraycpy.add(imz.toString())
           idupArraycpy.add(li)
           imageArraycpy.add(imli)
           idproArraycpy.add(idprz)



           var a=pronameArraycpy.toString()
           var atr=a.removeSurrounding("[","]")

           var bs=manufacturerArraycpy.toString()
           var btr=bs.removeSurrounding("[","]")

           var cs=hsnArraycpy.toString()
           var cstr=cs.removeSurrounding("[","]")

           var ds=quantityArraycpy.toString()
           var dstr=ds.removeSurrounding("[","]")

           var es=barcodeArraycpy.toString()
           var estr=es.removeSurrounding("[","]")

           var fs=priceArraycpy.toString()
           var fstr=fs.removeSurrounding("[","]")

           var gs=totArraycpy.toString()
           var gstr=gs.removeSurrounding("[","]")

           var gsgross=grosstotArraycpy.toString()
           var gstrgross=gsgross.removeSurrounding("[","]")

           var hs=cessArraycpy.toString()
           var hstr=hs.removeSurrounding("[","]")


           var ijs=igstArraycpy.toString()
           var ijsstr=ijs.removeSurrounding("[","]")


           var rjs=cgstArraycpy.toString()
           var rjsstr=rjs.removeSurrounding("[","]")


           var sjs=sgstArraycpy.toString()
           var sjsstr=sjs.removeSurrounding("[","]")





           var jjs=igsttotArraycpy.toString()
           var jjsstr=jjs.removeSurrounding("[","]")

           var kjs=cesstotalArraycpy.toString()
           var kjsstr=kjs.removeSurrounding("[","]")

           var ljs=tallyArraycpy.toString()
           var ljsstr=ljs.removeSurrounding("[","]")


           var ujs=receivedArraypricpy.toString()
           var ujsstr=ujs.removeSurrounding("[","]")




           var vjs=receivedArraytaxtotcpy.toString()
           var vjsstr=vjs.removeSurrounding("[","]")



           var wjs=receivedArraycesstotalcpy.toString()
           var wjsstr=wjs.removeSurrounding("[","]")


           var xjs=receivedArraygrosstotalcpy.toString()
           var xjsstr=xjs.removeSurrounding("[","]")

           var yjs=receivedArraytotalcpy.toString()
           var yjsstr=yjs.removeSurrounding("[","]")



           var mjs=receivedArraycpy.toString()
           var mjsstr=mjs.removeSurrounding("[","]")

           var njs=imageArraycpy.toString()
           var njsstr=njs.removeSurrounding("[","]")

           var idprss=idproArraycpy.toString()
           var idprsstr=idprss.removeSurrounding("[","]")

           pronameArrayori.add(atr)
           manufacturerArrayori.add(btr)
           hsnArrayori.add(cstr)
           quantityArrayori.add(dstr)
           barcodeArrayori.add(estr)
           priceArrayori.add(fstr)
           totArrayori.add(gstr)
           grosstotArrayori.add(gstrgross)

           cessArrayori.add(hstr)
           igstArrayori.add(ijsstr)
           cgstArrayori.add(rjsstr)
           sgstArrayori.add(sjsstr)
           igsttotArrayori.add(jjsstr)
           cesstotalArrayori.add(kjsstr)
           tallyArrayori.add(ljsstr)
           receivedArrayori.add(mjsstr)
           receivedArraypriori.add(ujsstr)
           receivedArraytotalori.add(yjsstr)
           receivedArraytaxtotori.add(vjsstr)
           receivedArraygrosstotalori.add(xjsstr)
           receivedArraycesstotalori.add(wjsstr)
           imageArrayori.add(njsstr)
           idproArrayori.add(idprsstr)
           keyArrayori.add("")

           namesori=names
           namesphonesori=namesphones
           println(pronameArraycpy.lastIndex)


           val b = Intent(applicationContext,PurcathirdMainActivity::class.java)
                   .putStringArrayListExtra("dlt",dlt)


           b.putExtra("from_pur","pur_list_single")
           b.putExtra("pur_pname",pronameArrayori)
           b.putExtra("pur_pitem",manufacturerArrayori)
           b.putExtra("pur_phsn",hsnArrayori)
           b.putExtra("pur_porder",quantityArrayori)

           b.putExtra("pur_pprice",priceArrayori)
           b.putExtra("pur_ptot",totArrayori)
           b.putExtra("pur_pgrosstot",grosstotArrayori)

           b.putExtra("pur_poarray",barcodeArrayori)
           b.putExtra("pur_cessarray",cessArrayori)
           b.putExtra("pur_igstarray",igstArrayori)
           b.putExtra("pur_cgstarray",cgstArrayori)
           b.putExtra("pur_sgstarray",sgstArrayori)
           b.putExtra("pur_igsttotarray",igsttotArrayori)
           b.putExtra("pur_cesstotalarray",cesstotalArrayori)
           b.putExtra("pur_reiddofli",keyArrayori)
           b.putExtra("pur_tallyarray",tallyArrayori)
           b.putExtra("pur_receivedarray",receivedArrayori)
           b.putExtra("pur_receivedarraypri",receivedArraypriori)
           b.putExtra("pur_receivedarraytotal",receivedArraytotalori)
           b.putExtra("pur_receivedarraytaxtot",receivedArraytaxtotori)
           b.putExtra("pur_receivedarraycesstot",receivedArraycesstotalori)
           b.putExtra("pur_receivedarraygrosstot",receivedArraygrosstotalori)

           /* b.putExtra("pur_branch",namesori)
            b.putExtra("pur_address",namesphonesori)
            b.putExtra("pur_brkey",keybrnch)
            b.putExtra("pur_redate",datestk)
            b.putExtra("pur_redesc",descstk)
            b.putExtra("pur_restkid",idstk)
            b.putExtra("pur_reiddb",iddbs)
            b.putExtra("pur_reiddofli",keyArrayori)*/

           b.putExtra("pur_imi",imageArrayori)
           b.putExtra("idpro",idproArrayori)
           b.putExtra("pono",pono)
           b.putExtra("names",reprnms)
           b.putExtra("redesc",desc)
           b.putExtra("reorddate",orddate)
           b.putExtra("reestdt",reqdt)
           b.putExtra("restatus",postatus)
           b.putExtra("descriplistener",descriplistener)
           b.putExtra("listListener",listListener)
           b.putExtra("reids",reqliid)
           b.putExtra("titnm",nms)
           b.putExtra("groschk",grosschk)
           b.putExtra("suppinv",suppinv)
           b.putExtra("supplieridfr",supplieridfr)

           b.putExtra("tiphone",ph)
           b.putExtra("brid",brnchids)
           b.putExtra("viewsuppin", viewsuppin)
           b.putExtra("addsuppin", addsuppin)
           b.putExtra("deletesuppin", deletesuppin)
           b.putExtra("editsuppin", editesuppin)
           b.putExtra("transfersuppin", transfersuppin)
           b.putExtra("exportsuppin", exportsuppin)


           b.putExtra("viewpurord", viewpurord)
           b.putExtra("addpurord", addpurord)
           b.putExtra("deletepurord", deletepurord)
           b.putExtra("editpurord", editepurord)
           b.putExtra("transferpurord", transferpurord)
           b.putExtra("exportpurord", exportpurord)
           b.putExtra("sendpurord", sendpurpo)

           b.putExtra("edclick",edclick)

           b.putExtra("orddatedup",orddatedup)
           b.putExtra("reqdatedup",reqdatedup)
           b.putExtra("descripdup",descripdup)


           try {
               orddatedup = intent.getStringExtra("orddatedup")
               reqdatedup = intent.getStringExtra("reqdatedup")
               descripdup = intent.getStringExtra("descripdup")
           }
           catch (e:Exception){

           }



           b.putExtra("viewpurreq", viewpurreq)
           b.putExtra("addpurreq", addpurreq)
           b.putExtra("deletepurreq", deletepurreq)
           b.putExtra("editpurreq", editepurreq)
           b.putExtra("transferpurreq", transferpurreq)
           b.putExtra("exportpurreq", exportpurreq)



           b.putExtra("ids",ids)



           startActivity(b)
           finish()
       }


       //-----------------------------SEARCH ACTION-----------------------------//



       searchedit.addTextChangedListener(object : TextWatcher {
           override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {


               progressBar3.visibility = View.VISIBLE
               pur_product_list.visibility = View.INVISIBLE

               if(searchedit.length()==1){

                   pur_product_list.visibility = View.VISIBLE

               }
               
               nores.visibility=View.GONE
               if(searchedit.length()==0){
                   nores.visibility = View.GONE
               }

               sd = des.toString()
               x = sd
               val ps = "^[a-zA-Z ]+$"
               val regexStr = "^[0-9]*$"
               val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

               fun priget() {

                   nores.visibility = View.INVISIBLE
                   if ((des.length >= 1)&&(spinner.selectedItemPosition==0)) {
                       db.collection("product").orderBy("price").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {

                                               nores.visibility = View.INVISIBLE
                                               spinner.visibility=View.VISIBLE
                                               pur_product_list.visibility = View.VISIBLE
                                               progressBar3.visibility = View.GONE
                                               textView52.visibility=View.INVISIBLE
                                               already.visibility = View.GONE
                                               idproArraydup.add(document.id)



                                               var statuss = dd["status"].toString()
                                               var supky=dd["supp_key"].toString()

                                               if ((statuss == "Active")&&(supky==supplieridfr)){


                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {
                                                   progressBar3.visibility = View.GONE


                                                   nores.visibility=View.VISIBLE

                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{

                                       if(searchedit.text.toString().isNotEmpty()){
                                           nores.visibility=View.VISIBLE
                                       }
                                       progressBar3.visibility = View.GONE


                                   }
                               })

                   }
                   else if((des.length >= 1)&&(spinner.selectedItemPosition==1)){
                       db.collection("product").orderBy("price").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {


                                               nores.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               pur_product_list.visibility = View.VISIBLE
                                               already.visibility   =  View.GONE
                                               textView52.visibility=View.GONE
                                               println("Elsessssss")

                                               idproArraydup.add(document.id)
                                               var statuss = dd["status"].toString()

                                               if (statuss == "Active") {

                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {



                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{
                                       if(searchedit.text.toString().isNotEmpty()){
                                           nores.visibility=View.VISIBLE
                                       }
                                       progressBar3.visibility = View.GONE

                                   }
                               })
                   }
               }
               fun bcodeget() {

                   nores.visibility = View.INVISIBLE

                   if ((des.length >= 3) && (bcd == "bcode")&&(spinner.selectedItemPosition==0)) {

                       db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {


                                               nores.visibility = View.INVISIBLE
                                               spinner.visibility=View.VISIBLE
                                               pur_product_list.visibility = View.VISIBLE
                                               progressBar3.visibility = View.GONE
                                               textView52.visibility=View.INVISIBLE
                                               already.visibility = View.GONE
                                               idproArraydup.add(document.id)



                                               var statuss = dd["status"].toString()
                                               var supky=dd["supp_key"].toString()

                                               if ((statuss == "Active")&&(supky==supplieridfr)){


                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {
                                                   nores.visibility=View.VISIBLE
                                                   progressBar3.visibility = View.GONE


                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{

priget()

                                   }
                               })


                       println("AZ"+pronameArray)



                   }
                   else if(((des.length >= 3) && (bcd == "bcode")&&(spinner.selectedItemPosition==1))) {

                       db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {


                                               nores.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               pur_product_list.visibility = View.VISIBLE
                                               already.visibility = View.GONE
                                               textView52.visibility=View.GONE
                                               println("Elsessssss")

                                               idproArraydup.add(document.id)
                                               var statuss = dd["status"].toString()

                                               if (statuss == "Active") {

                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {



                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{

                                      priget()
                                   }
                               })

                   }
               }













               if (x.trim().matches(regexStr.toRegex())) {
                   upstr = x
                   println("CAME INTO NUMBER" + upstr)
                   var escp = x + '\uf8ff'
                   esc = escp
                   reg = upstr
                   numberstr = upstr
                   bcd = "bcode"
                   bcodeget()
                   //write code here for success
               }
               fun nameget() {
                   nores.visibility = View.INVISIBLE
                   if ((des.length >= 3) && (x != reg)&&(spinner.selectedItemPosition==0)) {
                       db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {

                                               nores.visibility = View.INVISIBLE
                                               spinner.visibility=View.VISIBLE
                                               pur_product_list.visibility = View.VISIBLE
                                               progressBar3.visibility = View.GONE
                                               textView52.visibility=View.INVISIBLE
                                               already.visibility = View.GONE
                                               idproArraydup.add(document.id)



                                               var statuss = dd["status"].toString()
                                               var supky=dd["supp_key"].toString()

                                               if ((statuss == "Active")&&(supky==supplieridfr)){


                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {



                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{
                                       db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                                   if (e != null) {
                                                   }
                                                   if (value.isEmpty == false) {
                                                       for (document in value) {

                                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                           val dd = document.data


                                                           var kk=document.id

                                                           if(!idproArrayori.contains(kk)) {


                                                               nores.visibility = View.INVISIBLE
                                                               spinner.visibility=View.VISIBLE
                                                               pur_product_list.visibility = View.VISIBLE
                                                               progressBar3.visibility = View.GONE
                                                               textView52.visibility=View.INVISIBLE
                                                               already.visibility = View.GONE
                                                               idproArraydup.add(document.id)



                                                               var statuss = dd["status"].toString()
                                                               var supky=dd["supp_key"].toString()

                                                               if ((statuss == "Active")&&(supky==supplieridfr)){


                                                                   var pnm = (dd["p_nm"].toString())

                                                                       var wgvols=(dd["wg_vol"].toString())
                                                                       var uts=(dd["ut"].toString())

                                                                       if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                           pnm=pnm+" - "+wgvols+" "+uts
                                                                       }

                                                                       else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                           pnm=pnm
                                                                       }
                                                                       else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                           pnm=pnm
                                                                       }
                                                                       else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                           pnm=pnm
                                                                       }
                                                                       else{
                                                                           pnm=pnm
                                                                       }

                                                                       if (pnm.isNotEmpty()) {
                                                                           pronameArraydup.add(pnm)

                                                                       } else {

                                                                       }
                                                                       val high = dd["img1urlhigh"].toString()
                                                                       val highnm = dd["img1nhigh"].toString()
                                                                       icohighnmArray=icohighnmArray.plusElement(highnm)
                                                                       icohighArray=icohighArray.plusElement(high)

                                                                       //Manu

                                                                       var manunm = (dd["mfr"].toString())


                                                                       if (manunm.isNotEmpty()) {
                                                                           manufacturerArraydup.add(manunm)

                                                                       } else {
                                                                           manufacturerArraydup.add("No title")
                                                                       }


                                                                       //Hsn
                                                                       var hsnnm = (dd["hsn"].toString())
                                                                       if (hsnnm.isNotEmpty()) {
                                                                           hsnArraydup.add(hsnnm)

                                                                       } else {
                                                                           hsnArraydup.add("0")
                                                                       }


                                                                       quantityArraydup.add("1")

                                                                       //price

                                                                       var pri = (dd["price"].toString())
                                                                       if (pri.isNotEmpty()) {
                                                                           priceArraydup.add(pri)

                                                                       } else {
                                                                           priceArraydup.add("0.0")
                                                                       }

                                                                       //Total

                                                                       var tot = (dd["price"].toString())
                                                                       if (tot.isNotEmpty()) {
                                                                           totArraydup.add(tot)

                                                                       } else {
                                                                           totArraydup.add("0.0")
                                                                       }

                                                                       //Total

                                                                       var totgro = (dd["mrp"].toString())
                                                                       if (totgro.isNotEmpty()) {
                                                                           grosstotArraydup.add(tot)

                                                                       } else {
                                                                           grosstotArraydup.add("0.0")
                                                                       }

                                                                       //barcode
                                                                       var bc = (dd["bc"].toString())
                                                                       if (bc.isNotEmpty()) {
                                                                           barcodeArraydup.add(bc)

                                                                       } else {
                                                                           barcodeArraydup.add(" - ")
                                                                       }

                                                                       //cess
                                                                       var cess = (dd["cess"].toString())
                                                                       if (cess.isNotEmpty()) {

                                                                           cessArraydup.add(cess)

                                                                       } else {

                                                                           cessArraydup.add("0.0")
                                                                       }

                                                                       //igst
                                                                       var igst = (dd["igst"].toString())

                                                                       if (igst.isNotEmpty()) {

                                                                           igstArraydup.add(igst)

                                                                       } else {

                                                                           igstArraydup.add("0.0")
                                                                       }

                                                                       //ccgst
                                                                       var cgst = (dd["cgst"].toString())

                                                                       if (cgst.isNotEmpty()) {

                                                                           cgstArraydup.add(cgst)

                                                                       } else {

                                                                           cgstArraydup.add("0.0")
                                                                       }

                                                                       var sgst = (dd["sgst"].toString())

                                                                       if (sgst.isNotEmpty()) {

                                                                           sgstArraydup.add(sgst)

                                                                       } else {

                                                                           sgstArraydup.add("0.0")
                                                                       }

                                                                       var taxtot = (dd["taxtot"].toString())

                                                                       if (taxtot.isNotEmpty()) {

                                                                           igsttotArraydup.add(taxtot)

                                                                       } else {

                                                                           igsttotArraydup.add("0.0")
                                                                       }

                                                                       //cesstot

                                                                       var spcestot = (dd["cesstot"].toString())

                                                                       if (spcestot.isNotEmpty()) {

                                                                           cesstotalArraydup.add(spcestot)

                                                                       } else {

                                                                           cesstotalArraydup.add("0.0")
                                                                       }


                                                                       tallyArraydup.add("InComplete")
                                                                       receivedArraydup.add("")
                                                                       receivedArraypridup.add("0.0")
                                                                       receivedArraytaxtotdup.add("00.00")
                                                                       receivedArraytotaldup.add("0.0")
                                                                       receivedArraygrosstotaldup.add("00.00")
                                                                       receivedArraycesstotaldup.add("0.0")

                                                                       try {
                                                                           var im = dd["img1url"].toString()

                                                                           if (im.isNotEmpty()) {
                                                                               imli = im
                                                                               imageArraydup.add(im)
                                                                           } else {

                                                                               imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                                               imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                                           }
                                                                       } catch (e: Exception) {

                                                                       }
                                                                       keyArraydup.add("")

                                                                       d.add(document.id.toString())


                                                                       /*swipeContainer.setRefreshing(false);*/


                                                                   }

                                                                   else {



                                                                       /*  swipeContainer.setRefreshing(false);*/


                                                                   }
                                                                   pronameArray       =pronameArraydup
                                                                   hsnArray           =hsnArraydup
                                                                   manufacturerArray  =manufacturerArraydup
                                                                   barcodeArray       =barcodeArraydup
                                                                   quantityArray      =quantityArraydup
                                                                   priceArray         =priceArraydup
                                                                   totArray           =totArraydup
                                                                   grosstotArray           =grosstotArraydup

                                                                   cessArray          =cessArraydup
                                                                   imageArray         =imageArraydup
                                                                   igstArray         = igstArraydup
                                                                   cgstArray         = cgstArraydup
                                                                   sgstArray         = sgstArraydup
                                                                   igsttotArray         = igsttotArraydup
                                                                   cesstotalArray         = cesstotalArraydup
                                                                   receivedArray = receivedArraydup
                                                                   receivedArraypri = receivedArraypridup
                                                                   receivedArraytaxtot = receivedArraytaxtotdup
                                                                   receivedArraytotal = receivedArraytotaldup
                                                                   receivedArraygrosstotal = receivedArraygrosstotaldup
                                                                   receivedArraycesstotal = receivedArraycesstotaldup
                                                                   tallyArray = tallyArraydup
                                                                   keyArray=keyArraydup
                                                                   idproArray=idproArraydup

                                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                                       icohighArray)

                                                                   pur_product_list.adapter = whatever
                                                           }
                                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                                           {



                                                               println("Array of idspro else if"+idproArray)

                                                               pur_product_list.visibility = View.INVISIBLE
                                                               progressBar3.visibility = View.GONE
                                                               already.setText("You have already added all $nms products")
                                                               already.visibility = View.VISIBLE

                                                           }

                                                           progressBar3.visibility = View.GONE
                                                       }
                                                   }
                                                   else{

                                                       if(searchedit.text.toString().isNotEmpty()){
                                                           nores.visibility=View.VISIBLE
                                                       }
                                                       progressBar3.visibility = View.GONE

                                                   }
                                               })


                                   }
                               })

                   }
                   else if((des.length >= 3) && (x != reg)&&(spinner.selectedItemPosition==1)){
                       db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                   var  pronameArraydup       = arrayListOf<String>()
                                   var  hsnArraydup           = arrayListOf<String>()
                                   var  manufacturerArraydup  = arrayListOf<String>()
                                   var  barcodeArraydup       = arrayListOf<String>()
                                   var  quantityArraydup      = arrayListOf<String>()
                                   var  priceArraydup         = arrayListOf<String>()
                                   var  totArraydup           = arrayListOf<String>()
                                   var  grosstotArraydup           = arrayListOf<String>()

                                   var  cessArraydup          = arrayListOf<String>()
                                   var  imageArraydup         = arrayListOf<String>()
                                   var  igstArraydup         = arrayListOf<String>()
                                   var  cgstArraydup         = arrayListOf<String>()
                                   var  sgstArraydup         = arrayListOf<String>()
                                   var  igsttotArraydup         = arrayListOf<String>()
                                   var  cesstotalArraydup         = arrayListOf<String>()
                                   var receivedArraydup = arrayListOf<String>()
                                   var receivedArraypridup = arrayListOf<String>()
                                   var receivedArraytaxtotdup = arrayListOf<String>()
                                   var receivedArraytotaldup = arrayListOf<String>()
                                   var receivedArraygrosstotaldup = arrayListOf<String>()
                                   var receivedArraycesstotaldup = arrayListOf<String>()
                                   var tallyArraydup = arrayListOf<String>()
                                   var keyArraydup=arrayListOf<String>()
                                   var idproArraydup=arrayListOf<String>()
                                   var icohighArray = arrayOf<String>()
                                   var icohighnmArray = arrayOf<String>()






                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var kk=document.id

                                           if(!idproArrayori.contains(kk)) {

                                               nores.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               pur_product_list.visibility = View.VISIBLE
                                               already.visibility = View.GONE
                                               textView52.visibility=View.GONE
                                               println("Elsessssss")

                                               idproArraydup.add(document.id)
                                               var statuss = dd["status"].toString()

                                               if (statuss == "Active") {

                                                   var pnm = (dd["p_nm"].toString())

                                                   var wgvols=(dd["wg_vol"].toString())
                                                   var uts=(dd["ut"].toString())

                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                   }

                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                       pnm=pnm
                                                   }
                                                   else{
                                                       pnm=pnm
                                                   }

                                                   if (pnm.isNotEmpty()) {
                                                       pronameArraydup.add(pnm)

                                                   } else {

                                                   }
                                                   val high = dd["img1urlhigh"].toString()
                                                   val highnm = dd["img1nhigh"].toString()
                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                   icohighArray=icohighArray.plusElement(high)

                                                   //Manu

                                                   var manunm = (dd["mfr"].toString())


                                                   if (manunm.isNotEmpty()) {
                                                       manufacturerArraydup.add(manunm)

                                                   } else {
                                                       manufacturerArraydup.add("No title")
                                                   }


                                                   //Hsn
                                                   var hsnnm = (dd["hsn"].toString())
                                                   if (hsnnm.isNotEmpty()) {
                                                       hsnArraydup.add(hsnnm)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }


                                                   quantityArraydup.add("1")

                                                   //price

                                                   var pri = (dd["price"].toString())
                                                   if (pri.isNotEmpty()) {
                                                       priceArraydup.add(pri)

                                                   } else {
                                                       priceArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var tot = (dd["price"].toString())
                                                   if (tot.isNotEmpty()) {
                                                       totArraydup.add(tot)

                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }

                                                   //Total

                                                   var totgro = (dd["mrp"].toString())
                                                   if (totgro.isNotEmpty()) {
                                                       grosstotArraydup.add(tot)

                                                   } else {
                                                       grosstotArraydup.add("0.0")
                                                   }

                                                   //barcode
                                                   var bc = (dd["bc"].toString())
                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add(" - ")
                                                   }

                                                   //cess
                                                   var cess = (dd["cess"].toString())
                                                   if (cess.isNotEmpty()) {

                                                       cessArraydup.add(cess)

                                                   } else {

                                                       cessArraydup.add("0.0")
                                                   }

                                                   //igst
                                                   var igst = (dd["igst"].toString())

                                                   if (igst.isNotEmpty()) {

                                                       igstArraydup.add(igst)

                                                   } else {

                                                       igstArraydup.add("0.0")
                                                   }

                                                   //ccgst
                                                   var cgst = (dd["cgst"].toString())

                                                   if (cgst.isNotEmpty()) {

                                                       cgstArraydup.add(cgst)

                                                   } else {

                                                       cgstArraydup.add("0.0")
                                                   }

                                                   var sgst = (dd["sgst"].toString())

                                                   if (sgst.isNotEmpty()) {

                                                       sgstArraydup.add(sgst)

                                                   } else {

                                                       sgstArraydup.add("0.0")
                                                   }

                                                   var taxtot = (dd["taxtot"].toString())

                                                   if (taxtot.isNotEmpty()) {

                                                       igsttotArraydup.add(taxtot)

                                                   } else {

                                                       igsttotArraydup.add("0.0")
                                                   }

                                                   //cesstot

                                                   var spcestot = (dd["cesstot"].toString())

                                                   if (spcestot.isNotEmpty()) {

                                                       cesstotalArraydup.add(spcestot)

                                                   } else {

                                                       cesstotalArraydup.add("0.0")
                                                   }


                                                   tallyArraydup.add("InComplete")
                                                   receivedArraydup.add("")
                                                   receivedArraypridup.add("0.0")
                                                   receivedArraytaxtotdup.add("00.00")
                                                   receivedArraytotaldup.add("0.0")
                                                   receivedArraygrosstotaldup.add("00.00")
                                                   receivedArraycesstotaldup.add("0.0")

                                                   try {
                                                       var im = dd["img1url"].toString()

                                                       if (im.isNotEmpty()) {
                                                           imli = im
                                                           imageArraydup.add(im)
                                                       } else {

                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

                                                   d.add(document.id.toString())


                                                   /*swipeContainer.setRefreshing(false);*/


                                               }

                                               else {



                                                   /*  swipeContainer.setRefreshing(false);*/


                                               }
                                               pronameArray       =pronameArraydup
                                               hsnArray           =hsnArraydup
                                               manufacturerArray  =manufacturerArraydup
                                               barcodeArray       =barcodeArraydup
                                               quantityArray      =quantityArraydup
                                               priceArray         =priceArraydup
                                               totArray           =totArraydup
                                               grosstotArray           =grosstotArraydup

                                               cessArray          =cessArraydup
                                               imageArray         =imageArraydup
                                               igstArray         = igstArraydup
                                               cgstArray         = cgstArraydup
                                               sgstArray         = sgstArraydup
                                               igsttotArray         = igsttotArraydup
                                               cesstotalArray         = cesstotalArraydup
                                               receivedArray = receivedArraydup
                                               receivedArraypri = receivedArraypridup
                                               receivedArraytaxtot = receivedArraytaxtotdup
                                               receivedArraytotal = receivedArraytotaldup
                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                               receivedArraycesstotal = receivedArraycesstotaldup
                                               tallyArray = tallyArraydup
                                               keyArray=keyArraydup
                                               idproArray=idproArraydup

                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                       icohighArray)

                                               pur_product_list.adapter = whatever
                                           }
                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                           {



                                               println("Array of idspro else if"+idproArray)

                                               pur_product_list.visibility = View.INVISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.setText("You have already added all $nms products")
                                               already.visibility = View.VISIBLE

                                           }

                                           progressBar3.visibility = View.GONE
                                       }
                                   }
                                   else{

                                       db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                   if (e != null) {
                                                   }
                                                   if (value.isEmpty == false) {
                                                       for (document in value) {

                                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                           val dd = document.data


                                                           var kk=document.id

                                                           if(!idproArrayori.contains(kk))
                                                           {
                                                               progressBar3.visibility = View.GONE
                                                               pur_product_list.visibility = View.VISIBLE
                                                               already.visibility = View.GONE
                                                               textView52.visibility=View.GONE
                                                               println("Elsessssss")

                                                               idproArraydup.add(document.id)
                                                               var statuss = dd["status"].toString()

                                                               if (statuss == "Active") {

                                                                   var pnm = (dd["p_nm"].toString())

                                                                   var wgvols=(dd["wg_vol"].toString())
                                                                   var uts=(dd["ut"].toString())

                                                                   if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                       pnm=pnm+" - "+wgvols+" "+uts
                                                                   }

                                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                       pnm=pnm
                                                                   }
                                                                   else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                       pnm=pnm
                                                                   }
                                                                   else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                       pnm=pnm
                                                                   }
                                                                   else{
                                                                       pnm=pnm
                                                                   }

                                                                   if (pnm.isNotEmpty()) {
                                                                       pronameArraydup.add(pnm)

                                                                   } else {

                                                                   }
                                                                   val high = dd["img1urlhigh"].toString()
                                                                   val highnm = dd["img1nhigh"].toString()
                                                                   icohighnmArray=icohighnmArray.plusElement(highnm)
                                                                   icohighArray=icohighArray.plusElement(high)

                                                                   //Manu

                                                                   var manunm = (dd["mfr"].toString())


                                                                   if (manunm.isNotEmpty()) {
                                                                       manufacturerArraydup.add(manunm)

                                                                   } else {
                                                                       manufacturerArraydup.add("No title")
                                                                   }


                                                                   //Hsn
                                                                   var hsnnm = (dd["hsn"].toString())
                                                                   if (hsnnm.isNotEmpty()) {
                                                                       hsnArraydup.add(hsnnm)

                                                                   } else {
                                                                       hsnArraydup.add("0")
                                                                   }


                                                                   quantityArraydup.add("1")

                                                                   //price

                                                                   var pri = (dd["price"].toString())
                                                                   if (pri.isNotEmpty()) {
                                                                       priceArraydup.add(pri)

                                                                   } else {
                                                                       priceArraydup.add("0.0")
                                                                   }

                                                                   //Total

                                                                   var tot = (dd["price"].toString())
                                                                   if (tot.isNotEmpty()) {
                                                                       totArraydup.add(tot)

                                                                   } else {
                                                                       totArraydup.add("0.0")
                                                                   }

                                                                   //Total

                                                                   var totgro = (dd["mrp"].toString())
                                                                   if (totgro.isNotEmpty()) {
                                                                       grosstotArraydup.add(tot)

                                                                   } else {
                                                                       grosstotArraydup.add("0.0")
                                                                   }

                                                                   //barcode
                                                                   var bc = (dd["bc"].toString())
                                                                   if (bc.isNotEmpty()) {
                                                                       barcodeArraydup.add(bc)

                                                                   } else {
                                                                       barcodeArraydup.add(" - ")
                                                                   }

                                                                   //cess
                                                                   var cess = (dd["cess"].toString())
                                                                   if (cess.isNotEmpty()) {

                                                                       cessArraydup.add(cess)

                                                                   } else {

                                                                       cessArraydup.add("0.0")
                                                                   }

                                                                   //igst
                                                                   var igst = (dd["igst"].toString())

                                                                   if (igst.isNotEmpty()) {

                                                                       igstArraydup.add(igst)

                                                                   } else {

                                                                       igstArraydup.add("0.0")
                                                                   }

                                                                   //ccgst
                                                                   var cgst = (dd["cgst"].toString())

                                                                   if (cgst.isNotEmpty()) {

                                                                       cgstArraydup.add(cgst)

                                                                   } else {

                                                                       cgstArraydup.add("0.0")
                                                                   }

                                                                   var sgst = (dd["sgst"].toString())

                                                                   if (sgst.isNotEmpty()) {

                                                                       sgstArraydup.add(sgst)

                                                                   } else {

                                                                       sgstArraydup.add("0.0")
                                                                   }

                                                                   var taxtot = (dd["taxtot"].toString())

                                                                   if (taxtot.isNotEmpty()) {

                                                                       igsttotArraydup.add(taxtot)

                                                                   } else {

                                                                       igsttotArraydup.add("0.0")
                                                                   }

                                                                   //cesstot

                                                                   var spcestot = (dd["cesstot"].toString())

                                                                   if (spcestot.isNotEmpty()) {

                                                                       cesstotalArraydup.add(spcestot)

                                                                   } else {

                                                                       cesstotalArraydup.add("0.0")
                                                                   }


                                                                   tallyArraydup.add("InComplete")
                                                                   receivedArraydup.add("")
                                                                   receivedArraypridup.add("0.0")
                                                                   receivedArraytaxtotdup.add("00.00")
                                                                   receivedArraytotaldup.add("0.0")
                                                                   receivedArraygrosstotaldup.add("00.00")
                                                                   receivedArraycesstotaldup.add("0.0")

                                                                   try {
                                                                       var im = dd["img1url"].toString()

                                                                       if (im.isNotEmpty()) {
                                                                           imli = im
                                                                           imageArraydup.add(im)
                                                                       } else {

                                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                                           imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                                       }
                                                                   } catch (e: Exception) {

                                                                   }
                                                                   keyArraydup.add("")

                                                                   d.add(document.id.toString())


                                                                   /*swipeContainer.setRefreshing(false);*/


                                                               }

                                                               else {



                                                                   /*  swipeContainer.setRefreshing(false);*/


                                                               }
                                                               pronameArray       =pronameArraydup
                                                               hsnArray           =hsnArraydup
                                                               manufacturerArray  =manufacturerArraydup
                                                               barcodeArray       =barcodeArraydup
                                                               quantityArray      =quantityArraydup
                                                               priceArray         =priceArraydup
                                                               totArray           =totArraydup
                                                               grosstotArray           =grosstotArraydup

                                                               cessArray          =cessArraydup
                                                               imageArray         =imageArraydup
                                                               igstArray         = igstArraydup
                                                               cgstArray         = cgstArraydup
                                                               sgstArray         = sgstArraydup
                                                               igsttotArray         = igsttotArraydup
                                                               cesstotalArray         = cesstotalArraydup
                                                               receivedArray = receivedArraydup
                                                               receivedArraypri = receivedArraypridup
                                                               receivedArraytaxtot = receivedArraytaxtotdup
                                                               receivedArraytotal = receivedArraytotaldup
                                                               receivedArraygrosstotal = receivedArraygrosstotaldup
                                                               receivedArraycesstotal = receivedArraycesstotaldup
                                                               tallyArray = tallyArraydup
                                                               keyArray=keyArraydup
                                                               idproArray=idproArraydup

                                                               val whatever = purchse_list_adaps(this@product_list_activity_pur, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup,
                                                                       quantityArraydup, priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, cgstArraydup, sgstArraydup, igsttotArraydup,
                                                                       cesstotalArraydup, tallyArraydup,receivedArraydup, receivedArraypridup, receivedArraytaxtotdup, receivedArraycesstotaldup,
                                                                       receivedArraygrosstotaldup,receivedArraytotaldup,imageArraydup,icohighnmArray,
                                                                       icohighArray)

                                                               pur_product_list.adapter = whatever

                                                           }
                                                           else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                                           {



                                                               pur_product_list.visibility = View.INVISIBLE
                                                               progressBar3.visibility = View.GONE
                                                               already.setText("You have already added all $nms products")
                                                               already.visibility = View.VISIBLE

                                                           }






                                                           progressBar3.visibility = View.GONE
                                                       }
                                                   }
                                                   else{
                                                       if(searchedit.text.toString().isNotEmpty()){
                                                           nores.visibility=View.VISIBLE
                                                       }
                                                       progressBar3.visibility = View.GONE


                                                   }
                                               })

                                   }
                               })

                   }
               }

               if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                   val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                   upstr = upperString
                   /*nmstr = upstr*/
                   var escp = upperString + '\uf8ff'
                   esc = escp
                   println("CAPPPSSSS" + upperString)
                   println("CAME INTO NUMBER upper names" + upstr)
                   println("STRINGSSSS" + upstr)
                   nameget()
               }



















               return
           }
           override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                          arg3: Int) {
               // TODO Auto-generated method stub


           }
           override fun afterTextChanged(arg0: Editable) {
               // TODO Auto-generated method stub
               if(searchedit.text.toString().isEmpty())
               {

                   progressBar3.visibility=View.GONE
                   spinner.visibility=View.VISIBLE

                   nores.visibility=View.GONE
                   if(spinner.selectedItemPosition==0){
                       get()
                   }
                   else if(spinner.selectedItemPosition==1){
                       gets()
                   }

               }
           }
       })


       product_list_back_btn.setOnClickListener {

           //Back action

           val b = Intent(applicationContext,PurcathirdMainActivity::class.java)
                   .putStringArrayListExtra("dlt",dlt)


           b.putExtra("from_pur","pur_list")
           b.putExtra("pur_pname",pronameArrayori)
           b.putExtra("pur_pitem",manufacturerArrayori)
           b.putExtra("pur_phsn",hsnArrayori)
           b.putExtra("pur_porder",quantityArrayori)

           b.putExtra("pur_pprice",priceArrayori)
           b.putExtra("pur_ptot",totArrayori)
           b.putExtra("pur_pgrosstot",grosstotArrayori)

           b.putExtra("pur_poarray",barcodeArrayori)
           b.putExtra("pur_cessarray",cessArrayori)
           b.putExtra("pur_igstarray",igstArrayori)
           b.putExtra("pur_cgstarray",cgstArrayori)
           b.putExtra("pur_sgstarray",sgstArrayori)
           b.putExtra("pur_igsttotarray",igsttotArrayori)
           b.putExtra("pur_cesstotalarray",cesstotalArrayori)
           b.putExtra("pur_reiddofli",keyArrayori)
           b.putExtra("pur_tallyarray",tallyArrayori)
           b.putExtra("pur_receivedarray",receivedArrayori)
           b.putExtra("pur_receivedarraypri",receivedArraypriori)
           b.putExtra("pur_receivedarraytotal",receivedArraytotalori)
           b.putExtra("pur_receivedarraytaxtot",receivedArraytaxtotori)
           b.putExtra("pur_receivedarraycesstot",receivedArraycesstotalori)
           b.putExtra("pur_receivedarraygrosstot",receivedArraygrosstotalori)
           b.putExtra("idpro",idproArrayori)

           /* b.putExtra("pur_branch",namesori)
            b.putExtra("pur_address",namesphonesori)
            b.putExtra("pur_brkey",keybrnch)
            b.putExtra("pur_redate",datestk)
            b.putExtra("pur_redesc",descstk)
            b.putExtra("pur_restkid",idstk)
            b.putExtra("pur_reiddb",iddbs)
            b.putExtra("pur_reiddofli",keyArrayori)*/

           b.putExtra("pur_imi",imageArrayori)
           b.putExtra("pono",pono)
           b.putExtra("names",reprnms)
           b.putExtra("redesc",desc)
           b.putExtra("reorddate",orddate)
           b.putExtra("reestdt",reqdt)
           b.putExtra("restatus",postatus)
           b.putExtra("supplieridfr",supplieridfr)

           b.putExtra("edclick",edclick)

           b.putExtra("reids",reqliid)
           b.putExtra("titnm",nms)
           b.putExtra("groschk",grosschk)

           b.putExtra("tiphone",ph)
           b.putExtra("brid",brnchids)
           b.putExtra("viewsuppin", viewsuppin)
           b.putExtra("addsuppin", addsuppin)
           b.putExtra("deletesuppin", deletesuppin)
           b.putExtra("editsuppin", editesuppin)
           b.putExtra("transfersuppin", transfersuppin)
           b.putExtra("exportsuppin", exportsuppin)


           b.putExtra("viewpurord", viewpurord)
           b.putExtra("addpurord", addpurord)
           b.putExtra("deletepurord", deletepurord)
           b.putExtra("editpurord", editepurord)
           b.putExtra("transferpurord", transferpurord)
           b.putExtra("exportpurord", exportpurord)
           b.putExtra("sendpurord", sendpurpo)

           b.putExtra("descriplistener",descriplistener)
           b.putExtra("listListener",listListener)
           b.putExtra("orddatedup",orddatedup)
           b.putExtra("reqdatedup",reqdatedup)
           b.putExtra("descripdup",descripdup)
           b.putExtra("suppinv",suppinv)


           b.putExtra("viewpurreq", viewpurreq)
           b.putExtra("addpurreq", addpurreq)
           b.putExtra("deletepurreq", deletepurreq)
           b.putExtra("editpurreq", editepurreq)
           b.putExtra("transferpurreq", transferpurreq)
           b.putExtra("exportpurreq", exportpurreq)


           b.putExtra("ids",ids)




           startActivity(b)
           finish()
       }


       ///------------------------ Multi select the products to (PurcathirdMainActivity)----------------------------------------///


       pur_product_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
       pur_product_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
           override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
               //capture total checked items
               var checkedCount = pur_product_list.getCheckedItemCount()
               val l = d.get(position)
               val az=pronameArray.get(position)
               val bz=hsnArray.get(position)
               val t = manufacturerArray.get(position)
               val cz=quantityArray.get(position)
               val mz=barcodeArray.get(position)
               val fz=priceArray.get(position)
               val oz=totArray.get(position)
               val ozgro=grosstotArray.get(position)

               val qz=cessArray.get(position)
               val qigz=igstArray.get(position)
               val higz=cgstArray.get(position)
               val digz=sgstArray.get(position)
               val qigtotz=igsttotArray.get(position)
               val qcesstotz=cesstotalArray.get(position)
               val qtallyz=tallyArray.get(position)
               val qtallypri=receivedArraypri.get(position)
               val qtallytot=receivedArraytotal.get(position)
               val qtallytaxtot=receivedArraytaxtot.get(position)
               val qtallycesstot=receivedArraycesstotal.get(position)
               val qtallygross=receivedArraygrosstotal.get(position)
               val rece=receivedArray.get(position)
               val imz=imageArray.get(position)
               val li=keyArray.get(position)
               val idp=idproArray.get(position)
               Log.i(TAG," "+l)
               //setting CAB title
               mode.setTitle(""+checkedCount + " Selected")
               Log.d(TAG," "+id)
               //list_item.add(id);
               val tex =CircleImageView(this@product_list_activity_pur)
               val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
               textLayoutParams.setMargins(20, 0, 0, 0)
               textLayoutParams.height=100
               textLayoutParams.width=100
               tex.setBorderColor(Color.BLACK)
               tex.setBorderWidth(1)
               tex.setPadding(4,4,4,4)
               tex.setLayoutParams(textLayoutParams)
               try {
                   Picasso.with(this@product_list_activity_pur)
                           .load(imageArray[position])
                           .into(tex);
               }
               catch (e:Exception){

               }

               tex.setTag(l)
               linearlayout.setGravity(Gravity.CENTER)
               tex.setOnClickListener {
                   val r = linearlayout.findViewWithTag<View>(l)
                   linearlayout.removeView(r)
                   Log.d("list","    "+pur_product_list.setItemChecked(position,false))
               }
               if (checked) {
                   // list_item.add(id.toString()) // Add to list when checked ==  true

                   dlt.add(l)
                   pronameArraycpy.add(az)
                   manufacturerArraycpy.add(t)
                   hsnArraycpy.add(bz)
                   quantityArraycpy.add(cz)
                   barcodeArraycpy.add(mz)
                   priceArraycpy.add(fz)
                   totArraycpy.add(oz)
                   grosstotArraycpy.add(ozgro)

                   cessArraycpy.add(qz)
                   igstArraycpy.add(qigz)
                   cgstArraycpy.add(higz)
                   sgstArraycpy.add(digz)
                   igsttotArraycpy.add(qigtotz)
                   cesstotalArraycpy.add(qcesstotz)
                   tallyArraycpy.add(qtallyz)
                   receivedArraypricpy.add(qtallypri)
                   receivedArraytaxtotcpy.add(qtallytaxtot)
                   receivedArraycesstotalcpy.add(qtallycesstot)
                   receivedArraygrosstotalcpy.add(qtallygross)
                   receivedArraytotalcpy.add(qtallytot)
                   receivedArraycpy.add(rece)
                   imageArraycpy.add(imz.toString())
                   idupArraycpy.add(li)
                   idproArraycpy.add(idp)
                   imageArray.add(imli)
                   Log.i(TAG,"itm "+dlt.size)
                   Log.d("list","    "+pur_product_list.getCheckedItemPositions())
                   linearlayout.addView(tex)
                   horizontalScrollView.visibility=View.VISIBLE



               } else {
                   val r = linearlayout.findViewWithTag<View>(l)
                   dlt.remove(l)
                   pronameArraycpy.remove(az)
                   manufacturerArraycpy.remove(t)
                   hsnArraycpy.remove(bz)
                   quantityArraycpy.remove(cz)
                   barcodeArraycpy.remove(mz)
                   priceArraycpy.remove(fz)
                   totArraycpy.remove(oz)
                   grosstotArraycpy.remove(ozgro)

                   cessArraycpy.remove(qz)
                   igstArraycpy.remove(qigz)
                   cgstArraycpy.remove(higz)
                   sgstArraycpy.remove(digz)
                   igsttotArraycpy.remove(qigtotz)
                   cesstotalArraycpy.remove(qcesstotz)
                   tallyArraycpy.remove(qtallyz)
                   receivedArraycpy.remove(rece)
                   receivedArraypricpy.remove(qtallypri)
                   receivedArraytaxtotcpy.remove(qtallytaxtot)
                   receivedArraycesstotalcpy.remove(qtallycesstot)
                   receivedArraygrosstotalcpy.remove(qtallygross)
                   receivedArraytotalcpy.remove(qtallytot)
                   imageArraycpy.remove(imz.toString())
                   idproArraycpy.remove(idp)

                   idupArraycpy.remove(li)
                   /*       imageArray=imageArray.plusElement(R.drawable.loreal_bottl)*/


                   Log.d("tag","   "+r)
                   linearlayout.removeView(r)
                   Log.i(TAG,"itm "+dlt.size)
                   Log.d(TAG,"id  "+id)
                   Log.d(TAG,"id  "+position)
               }


           }


           override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
               //Inflate the CAB
               pur_product_list_toolbar.visibility = View.GONE
               product_page_title.visibility=View.GONE
               product_list_back_btn.visibility=View.GONE
               search.visibility=View.GONE
               mode.getMenuInflater().inflate(R.menu.product_select, menu);

               if(cardsearch.visibility==View.VISIBLE) {
                   searchedit.setText("")
                   cardsearch.visibility = View.GONE

                   cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity_pur, R.anim.slide_to_left))
               }
               return true;
           }

           override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
               return false
           }

           override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
               val deleteSize =dlt.size
               Log.i("tsdfs","  "+dlt.size)
               /*val cate = null
               val data = s(cat = cate)*/
               val i = 0
               Log.d("dlt"," "+dlt.get(i))
               val itemId = item.getItemId()
               if (itemId == R.id.ok) {
                   println(pronameArraycpy.size)
                   //if (this@product_list_activity.equals("product_list_activity"))
                   for(i in 0 until pronameArraycpy.size)
                   {
                       pronameArrayori.add(pronameArraycpy.get(i))
                       manufacturerArrayori.add(manufacturerArraycpy.get(i))
                       hsnArrayori.add(hsnArraycpy.get(i))
                       quantityArrayori.add(quantityArraycpy.get(i))
                       barcodeArrayori.add(barcodeArraycpy.get(i))
                       priceArrayori.add(priceArraycpy.get(i))
                       totArrayori.add(totArraycpy.get(i))
                       grosstotArrayori.add(grosstotArraycpy.get(i))

                       cessArrayori.add(cessArraycpy.get(i))
                       igstArrayori.add(igstArraycpy.get(i))
                       cgstArrayori.add(cgstArraycpy.get(i))
                       sgstArrayori.add(sgstArraycpy.get(i))
                       igsttotArrayori.add(igsttotArraycpy.get(i))
                       cesstotalArrayori.add(cesstotalArraycpy.get(i))
                       tallyArrayori.add(tallyArraycpy.get(i))
                       receivedArrayori.add(receivedArraycpy.get(i))
                       receivedArraypriori.add(receivedArraypricpy.get(i))
                       receivedArraytotalori.add(receivedArraytotalcpy.get(i))
                       receivedArraytaxtotori.add(receivedArraytaxtotcpy.get(i))
                       receivedArraygrosstotalori.add(receivedArraygrosstotalcpy.get(i))
                       receivedArraycesstotalori.add(receivedArraycesstotalcpy.get(i))
                       imageArrayori.add(imageArraycpy.get(i))
                       idproArrayori.add(idproArraycpy.get(i))
                       keyArrayori.add("")

                       namesori=names
                       namesphonesori=namesphones
                       println(pronameArraycpy.lastIndex)
                       if(pronameArraycpy.lastIndex == i)
                       {
                           Log.d("fdgshgtgh","NAMESSSSSSSSSSSSSSSSS             "   + (pronameArrayori))
                       }
                   }
                   val b = Intent(applicationContext,PurcathirdMainActivity::class.java)
                           .putStringArrayListExtra("dlt",dlt)


                   b.putExtra("from_pur","pur_list")
                   b.putExtra("pur_pname",pronameArrayori)
                   b.putExtra("pur_pitem",manufacturerArrayori)
                   b.putExtra("pur_phsn",hsnArrayori)
                   b.putExtra("pur_porder",quantityArrayori)

                   b.putExtra("pur_pprice",priceArrayori)
                   b.putExtra("pur_ptot",totArrayori)
                   b.putExtra("pur_pgrosstot",grosstotArrayori)

                   b.putExtra("pur_poarray",barcodeArrayori)
                   b.putExtra("pur_cessarray",cessArrayori)
                   b.putExtra("pur_igstarray",igstArrayori)
                   b.putExtra("pur_cgstarray",cgstArrayori)
                   b.putExtra("pur_sgstarray",sgstArrayori)
                   b.putExtra("pur_igsttotarray",igsttotArrayori)
                   b.putExtra("pur_cesstotalarray",cesstotalArrayori)
                   b.putExtra("pur_reiddofli",keyArrayori)
                   b.putExtra("pur_tallyarray",tallyArrayori)
                   b.putExtra("pur_receivedarray",receivedArrayori)
                   b.putExtra("pur_receivedarraypri",receivedArraypriori)
                   b.putExtra("pur_receivedarraytotal",receivedArraytotalori)
                   b.putExtra("pur_receivedarraytaxtot",receivedArraytaxtotori)
                   b.putExtra("pur_receivedarraycesstot",receivedArraycesstotalori)
                   b.putExtra("pur_receivedarraygrosstot",receivedArraygrosstotalori)
                   b.putExtra("idpro",idproArrayori)
                   b.putExtra("edclick",edclick)

                   b.putExtra("descriplistener",descriplistener)
                   b.putExtra("listListener",listListener)

                   b.putExtra("orddatedup",orddatedup)
                   b.putExtra("reqdatedup",reqdatedup)
                   b.putExtra("descripdup",descripdup)
                   /* b.putExtra("pur_branch",namesori)
                    b.putExtra("pur_address",namesphonesori)
                    b.putExtra("pur_brkey",keybrnch)
                    b.putExtra("pur_redate",datestk)
                    b.putExtra("pur_redesc",descstk)
                    b.putExtra("pur_restkid",idstk)
                    b.putExtra("pur_reiddb",iddbs)
                    b.putExtra("pur_reiddofli",keyArrayori)*/

                   b.putExtra("pur_imi",imageArrayori)
                   b.putExtra("pono",pono)
                   b.putExtra("names",reprnms)
                   b.putExtra("redesc",desc)
                   b.putExtra("reorddate",orddate)
                   b.putExtra("reestdt",reqdt)
                   b.putExtra("restatus",postatus)

                   b.putExtra("reids",reqliid)
                   b.putExtra("titnm",nms)
                   b.putExtra("supplieridfr",supplieridfr)

                   b.putExtra("groschk",grosschk)
                   b.putExtra("suppinv",suppinv)

                   b.putExtra("tiphone",ph)
                   b.putExtra("brid",brnchids)

                   b.putExtra("viewsuppin", viewsuppin)
                   b.putExtra("addsuppin", addsuppin)
                   b.putExtra("deletesuppin", deletesuppin)
                   b.putExtra("editsuppin", editesuppin)
                   b.putExtra("transfersuppin", transfersuppin)
                   b.putExtra("exportsuppin", exportsuppin)


                   b.putExtra("viewpurord", viewpurord)
                   b.putExtra("addpurord", addpurord)
                   b.putExtra("deletepurord", deletepurord)
                   b.putExtra("editpurord", editepurord)
                   b.putExtra("transferpurord", transferpurord)
                   b.putExtra("exportpurord", exportpurord)
                   b.putExtra("sendpurord", sendpurpo)

                   b.putExtra("ids",ids)


                   b.putExtra("viewpurreq", viewpurreq)
                   b.putExtra("addpurreq", addpurreq)
                   b.putExtra("deletepurreq", deletepurreq)
                   b.putExtra("editpurreq", editepurreq)
                   b.putExtra("transferpurreq", transferpurreq)
                   b.putExtra("exportpurreq", exportpurreq)




                   startActivity(b)
                   finish()


                   /*for (i in dlt) {
                       Log.d("dlt","  "+i)
                   }*/
               }
               /* checkedCount = 0*/
               // list_item.clear()


               return true
           }
           override fun onDestroyActionMode(mode: ActionMode) {
               // refresh list after deletion
               dlt.clear()
               linearlayout.removeAllViews()
               horizontalScrollView.visibility=View.GONE
               pur_product_list_toolbar.visibility = View.VISIBLE
               product_list_back_btn.visibility=View.VISIBLE
               product_page_title.visibility=View.VISIBLE
           }
       })
       get()


       //Select product list option - 'Supplier product' or 'All products'

       spinner.onItemSelectedListener=object : AdapterView.OnItemSelectedListener{
           override fun onNothingSelected(p0: AdapterView<*>?) {
               return
           }
           override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
               if(spinner.selectedItemPosition==0){
                   searchedit.setHint("Search in $nms products")
                   get()
               }
               else if(spinner.selectedItemPosition==1){
                   searchedit.setHint("Search in all products")

                   gets()
               }

           }
       }

     /*  swipeContainer.setOnRefreshListener {

           get()
       }
       swipeContainer.setColorSchemeResources(R.color.tool,
               android.R.color.holo_green_light,
               android.R.color.holo_orange_light,
               android.R.color.holo_red_light)*/








   }
    fun gets() {











                ///-----------------------Get all products from db----------------------------------//




        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();


        println("PRO ID ARRAY DUPLI"+idproArrayori)
        nores.visibility = View.INVISIBLE
        progressBar3.visibility = View.VISIBLE
        db.collection("product")
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                    var  pronameArraydup       = arrayListOf<String>()
                    var  hsnArraydup           = arrayListOf<String>()
                    var  manufacturerArraydup  = arrayListOf<String>()
                    var  barcodeArraydup       = arrayListOf<String>()
                    var  quantityArraydup      = arrayListOf<String>()
                    var  priceArraydup         = arrayListOf<String>()
                    var  totArraydup           = arrayListOf<String>()
                    var  grosstotArraydup           = arrayListOf<String>()

                    var  cessArraydup          = arrayListOf<String>()
                    var  imageArraydup         = arrayListOf<String>()
                    var  igstArraydup         = arrayListOf<String>()
                    var  cgstArraydup         = arrayListOf<String>()
                    var  sgstArraydup         = arrayListOf<String>()
                    var  igsttotArraydup         = arrayListOf<String>()
                    var  cesstotalArraydup         = arrayListOf<String>()
                    var receivedArraydup = arrayListOf<String>()
                    var receivedArraypridup = arrayListOf<String>()
                    var receivedArraytaxtotdup = arrayListOf<String>()
                    var receivedArraytotaldup = arrayListOf<String>()
                    var receivedArraygrosstotaldup = arrayListOf<String>()
                    var receivedArraycesstotaldup = arrayListOf<String>()
                    var tallyArraydup = arrayListOf<String>()
                    var keyArraydup=arrayListOf<String>()
                    var idproArraydup=arrayListOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    pronameArray       =pronameArraydup
                    hsnArray           =hsnArraydup
                    manufacturerArray  =manufacturerArraydup
                    barcodeArray       =barcodeArraydup
                    quantityArray      =quantityArraydup
                    priceArray         =priceArraydup
                    totArray           =totArraydup
                    grosstotArray           =grosstotArraydup

                    cessArray          =cessArraydup
                    imageArray         =imageArraydup
                    igstArray         = igstArraydup
                    cgstArray         = cgstArraydup
                    sgstArray         = sgstArraydup
                    igsttotArray         = igsttotArraydup
                    cesstotalArray         = cesstotalArraydup
                    receivedArray = receivedArraydup
                    receivedArraypri = receivedArraypridup
                    receivedArraytaxtot = receivedArraytaxtotdup
                    receivedArraytotal = receivedArraytotaldup
                    receivedArraygrosstotal = receivedArraygrosstotaldup
                    receivedArraycesstotal = receivedArraycesstotaldup
                    tallyArray = tallyArraydup
                    keyArray=keyArraydup
                    idproArray=idproArraydup





                    if (e != null) {
                    }
                    if (value.isEmpty == false) {
                        for (document in value) {

                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                            val dd = document.data



                            var kk=document.id


                            println("ID PRO ARRAY         "+idproArrayori)

                            println("DOCUMENT OF ID ARRAY         "+kk)



                            if(!idproArrayori.contains(kk))
                            {
                                progressBar3.visibility = View.GONE
                                pur_product_list.visibility = View.VISIBLE
                                already.visibility = View.GONE
                                textView52.visibility=View.GONE
                                println("Elsessssss")

                                idproArray.add(document.id)
                                var statuss = dd["status"].toString()

                                if (statuss == "Active") {

                                    var pnm = (dd["p_nm"].toString() + " - " + dd["wg_vol"].toString() + "ml")

                                    if (pnm.isNotEmpty()) {
                                        pronameArray.add(pnm)

                                    } else {

                                    }
                                    val high = dd["img1urlhigh"].toString()
                                    val highnm = dd["img1nhigh"].toString()
                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                    icohighArray=icohighArray.plusElement(high)

                                    //Manu

                                    var manunm = (dd["mfr"].toString())


                                    if (manunm.isNotEmpty()) {
                                        manufacturerArray.add(manunm)

                                    } else {
                                        manufacturerArray.add("No title")
                                    }


                                    //Hsn
                                    var hsnnm = (dd["hsn"].toString())
                                    if (hsnnm.isNotEmpty()) {
                                        hsnArray.add(hsnnm)

                                    } else {
                                        hsnArray.add("0")
                                    }


                                    quantityArray.add("1")

                                    //price

                                    var pri = (dd["price"].toString())
                                    if (pri.isNotEmpty()) {
                                        priceArray.add(pri)

                                    } else {
                                        priceArray.add("0.0")
                                    }

                                    //Total

                                    var tot = (dd["price"].toString())
                                    if (tot.isNotEmpty()) {
                                        totArray.add(tot)

                                    } else {
                                        totArray.add("0.0")
                                    }

                                    //Total

                                    var totgro = (dd["mrp"].toString())
                                    if (totgro.isNotEmpty()) {
                                        grosstotArray.add(tot)

                                    } else {
                                        grosstotArray.add("0.0")
                                    }

                                    //barcode
                                    var bc = (dd["bc"].toString())
                                    if (bc.isNotEmpty()) {
                                        barcodeArray.add(bc)

                                    } else {
                                        barcodeArray.add(" - ")
                                    }

                                    //cess
                                    var cess = (dd["cess"].toString())
                                    if (cess.isNotEmpty()) {

                                        cessArray.add(cess)

                                    } else {

                                        cessArray.add("0.0")
                                    }

                                    //igst
                                    var igst = (dd["igst"].toString())

                                    if (igst.isNotEmpty()) {

                                        igstArray.add(igst)

                                    } else {

                                        igstArray.add("0.0")
                                    }

                                    //ccgst
                                    var cgst = (dd["cgst"].toString())

                                    if (cgst.isNotEmpty()) {

                                        cgstArray.add(cgst)

                                    } else {

                                        cgstArray.add("0.0")
                                    }

                                    var sgst = (dd["sgst"].toString())

                                    if (sgst.isNotEmpty()) {

                                        sgstArray.add(sgst)

                                    } else {

                                        sgstArray.add("0.0")
                                    }

                                    var taxtot = (dd["taxtot"].toString())

                                    if (taxtot.isNotEmpty()) {

                                        igsttotArray.add(taxtot)

                                    } else {

                                        igsttotArray.add("0.0")
                                    }

                                    //cesstot

                                    var spcestot = (dd["cesstot"].toString())

                                    if (spcestot.isNotEmpty()) {

                                        cesstotalArray.add(spcestot)

                                    } else {

                                        cesstotalArray.add("0.0")
                                    }


                                    tallyArray.add("InComplete")
                                    receivedArray.add("")
                                    receivedArraypri.add("0.0")
                                    receivedArraytaxtot.add("00.00")
                                    receivedArraytotal.add("0.0")
                                    receivedArraygrosstotal.add("00.00")
                                    receivedArraycesstotal.add("0.0")

                                    try {
                                        var im = dd["img1url"].toString()

                                        if (im.isNotEmpty()) {
                                            imli = im
                                            imageArray.add(im)
                                        } else {

                                            imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                        }
                                    } catch (e: Exception) {

                                    }
                                    keyArray.add("")

                                    d.add(document.id.toString())

                                    pDialog.dismiss()
                                    /*swipeContainer.setRefreshing(false);*/


                                }

                                else {


                                    pDialog.dismiss()
                                    /*  swipeContainer.setRefreshing(false);*/


                                }
                            }
                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                            {


                                pDialog.dismiss()
                                pur_product_list.visibility = View.INVISIBLE
                                progressBar3.visibility = View.GONE
                                already.visibility = View.VISIBLE

                            }





                            val whatever = purchse_list_adaps(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                                    quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray,
                                    cesstotalArray, tallyArray,receivedArray, receivedArraypri, receivedArraytaxtot, receivedArraycesstotal,
                                    receivedArraygrosstotal,receivedArraytotal,imageArray,icohighnmArray,
                                    icohighArray)

                            pur_product_list.adapter = whatever
                            progressBar3.visibility = View.GONE
                        }





                    }
                    else{
                        pDialog.dismiss()
                    }

                })




    }

    fun get() {










        ///-----------------------Get supplier products  from db----------------------------------//






        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();


        println("PRO ID ARRAY DUPLI"+idproArrayori)
        nores.visibility = View.INVISIBLE
        progressBar3.visibility = View.VISIBLE
        db.collection("product").whereEqualTo("supp_key",supplieridfr)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                    var  pronameArraydup       = arrayListOf<String>()
                    var  hsnArraydup           = arrayListOf<String>()
                    var  manufacturerArraydup  = arrayListOf<String>()
                    var  barcodeArraydup       = arrayListOf<String>()
                    var  quantityArraydup      = arrayListOf<String>()
                    var  priceArraydup         = arrayListOf<String>()
                    var  totArraydup           = arrayListOf<String>()
                    var  grosstotArraydup           = arrayListOf<String>()

                    var  cessArraydup          = arrayListOf<String>()
                    var  imageArraydup         = arrayListOf<String>()
                    var  igstArraydup         = arrayListOf<String>()
                    var  cgstArraydup         = arrayListOf<String>()
                    var  sgstArraydup         = arrayListOf<String>()
                    var  igsttotArraydup         = arrayListOf<String>()
                    var  cesstotalArraydup         = arrayListOf<String>()
                    var receivedArraydup = arrayListOf<String>()
                    var receivedArraypridup = arrayListOf<String>()
                    var receivedArraytaxtotdup = arrayListOf<String>()
                    var receivedArraytotaldup = arrayListOf<String>()
                    var receivedArraygrosstotaldup = arrayListOf<String>()
                    var receivedArraycesstotaldup = arrayListOf<String>()
                    var tallyArraydup = arrayListOf<String>()
                    var keyArraydup=arrayListOf<String>()
                    var idproArraydup=arrayListOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    pronameArray       =pronameArraydup
                    hsnArray           =hsnArraydup
                    manufacturerArray  =manufacturerArraydup
                    barcodeArray       =barcodeArraydup
                    quantityArray      =quantityArraydup
                    priceArray         =priceArraydup
                    totArray           =totArraydup
                    grosstotArray           =grosstotArraydup

                    cessArray          =cessArraydup
                    imageArray         =imageArraydup
                    igstArray         = igstArraydup
                    cgstArray         = cgstArraydup
                    sgstArray         = sgstArraydup
                    igsttotArray         = igsttotArraydup
                    cesstotalArray         = cesstotalArraydup
                    receivedArray = receivedArraydup
                    receivedArraypri = receivedArraypridup
                    receivedArraytaxtot = receivedArraytaxtotdup
                    receivedArraytotal = receivedArraytotaldup
                    receivedArraygrosstotal = receivedArraygrosstotaldup
                    receivedArraycesstotal = receivedArraycesstotaldup
                    tallyArray = tallyArraydup
                    keyArray=keyArraydup
                    idproArray=idproArraydup





                    if (e != null) {
                    }
                    if (value.isEmpty == false) {
                        for (document in value) {

                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                            val dd = document.data



                            var kk=document.id


                            println("ID PRO ARRAY         "+idproArrayori)

                            println("DOCUMENT OF ID ARRAY         "+kk)



                            if(!idproArrayori.contains(kk))
                            {
                                progressBar3.visibility = View.GONE
                                pur_product_list.visibility = View.VISIBLE
                                already.visibility = View.GONE
                                textView52.visibility=View.GONE
                                println("Elsessssss")

                                idproArray.add(document.id)
                                var statuss = dd["status"].toString()

                                if (statuss == "Active") {

                                    var pnm = (dd["p_nm"].toString())

                                    var wgvols=(dd["wg_vol"].toString())
                                    var uts=(dd["ut"].toString())

                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                        pnm=pnm+" - "+wgvols+" "+uts
                                    }

                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                        pnm=pnm
                                    }
                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                        pnm=pnm
                                    }
                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                        pnm=pnm
                                    }
                                    else{
                                        pnm=pnm
                                    }

                                    if (pnm.isNotEmpty()) {
                                        pronameArray.add(pnm)

                                    } else {

                                    }
                                    val high = dd["img1urlhigh"].toString()
                                    val highnm = dd["img1nhigh"].toString()
                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                    icohighArray=icohighArray.plusElement(high)

                                    //Manu

                                    var manunm = (dd["mfr"].toString())


                                    if (manunm.isNotEmpty()) {
                                        manufacturerArray.add(manunm)

                                    } else {
                                        manufacturerArray.add("No title")
                                    }


                                    //Hsn
                                    var hsnnm = (dd["hsn"].toString())
                                    if (hsnnm.isNotEmpty()) {
                                        hsnArray.add(hsnnm)

                                    } else {
                                        hsnArray.add("0")
                                    }


                                    quantityArray.add("1")

                                    //price

                                    var pri = (dd["price"].toString())
                                    if (pri.isNotEmpty()) {
                                        priceArray.add(pri)

                                    } else {
                                        priceArray.add("0.0")
                                    }

                                    //Total

                                    var tot = (dd["price"].toString())
                                    if (tot.isNotEmpty()) {
                                        totArray.add(tot)

                                    } else {
                                        totArray.add("0.0")
                                    }

                                    //Total

                                    var totgro = (dd["mrp"].toString())
                                    if (totgro.isNotEmpty()) {
                                        grosstotArray.add(tot)

                                    } else {
                                        grosstotArray.add("0.0")
                                    }

                                    //barcode
                                    var bc = (dd["bc"].toString())
                                    if (bc.isNotEmpty()) {
                                        barcodeArray.add(bc)

                                    } else {
                                        barcodeArray.add(" - ")
                                    }

                                    //cess
                                    var cess = (dd["cess"].toString())
                                    if (cess.isNotEmpty()) {

                                        cessArray.add(cess)

                                    } else {

                                        cessArray.add("0.0")
                                    }

                                    //igst
                                    var igst = (dd["igst"].toString())

                                    if (igst.isNotEmpty()) {

                                        igstArray.add(igst)

                                    } else {

                                        igstArray.add("0.0")
                                    }

                                    //ccgst
                                    var cgst = (dd["cgst"].toString())

                                    if (cgst.isNotEmpty()) {

                                        cgstArray.add(cgst)

                                    } else {

                                        cgstArray.add("0.0")
                                    }

                                    var sgst = (dd["sgst"].toString())

                                    if (sgst.isNotEmpty()) {

                                        sgstArray.add(sgst)

                                    } else {

                                        sgstArray.add("0.0")
                                    }

                                    var taxtot = (dd["taxtot"].toString())

                                    if (taxtot.isNotEmpty()) {

                                        igsttotArray.add(taxtot)

                                    } else {

                                        igsttotArray.add("0.0")
                                    }

                                    //cesstot

                                    var spcestot = (dd["cesstot"].toString())

                                    if (spcestot.isNotEmpty()) {

                                        cesstotalArray.add(spcestot)

                                    } else {

                                        cesstotalArray.add("0.0")
                                    }


                                    tallyArray.add("InComplete")
                                    receivedArray.add("")
                                    receivedArraypri.add("0.0")
                                    receivedArraytaxtot.add("00.00")
                                    receivedArraytotal.add("0.0")
                                    receivedArraygrosstotal.add("00.00")
                                    receivedArraycesstotal.add("0.0")

                                    try {
                                        var im = dd["img1url"].toString()

                                        if (im.isNotEmpty()) {
                                            imli = im
                                            imageArray.add(im)
                                        } else {

                                            imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                        }
                                    } catch (e: Exception) {

                                    }
                                    keyArray.add("")

                                    d.add(document.id.toString())

                                    pDialog.dismiss()
                                    /*swipeContainer.setRefreshing(false);*/


                                }

                                else {


                                    pDialog.dismiss()
                                    /*  swipeContainer.setRefreshing(false);*/


                                }
                            }
                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                            {


                                pDialog.dismiss()
                                pur_product_list.visibility = View.INVISIBLE
                                progressBar3.visibility = View.GONE
                                already.setText("You have already added all $nms products")
                                already.visibility = View.VISIBLE

                            }





                            val whatever = purchse_list_adaps(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                                    quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray,
                                    cesstotalArray, tallyArray,receivedArray, receivedArraypri, receivedArraytaxtot, receivedArraycesstotal,
                                    receivedArraygrosstotal,receivedArraytotal,imageArray,icohighnmArray,
                                    icohighArray)

                            pur_product_list.adapter = whatever
                            progressBar3.visibility = View.GONE
                        }





                    }
                    else{
                        pDialog.dismiss()
                        textView52.visibility=View.VISIBLE
                        pur_product_list.visibility=View.INVISIBLE
                        progressBar3.visibility = View.GONE


                    }
                    /* } else {
                         Log.w(TAG, "Error getting documents.", task.exception)
                     }*/
                })




    }

    override fun onBackPressed() {


        //Back action

        if (cardsearch.visibility == View.VISIBLE) {

        cardsearch.visibility = View.GONE
        nores.visibility=View.INVISIBLE
        pur_product_list.visibility=View.VISIBLE
        progressBar3.visibility=View.GONE
        searchedit.setText("")
        get()


    }
        else {
        val b = Intent(applicationContext, PurcathirdMainActivity::class.java)
                .putStringArrayListExtra("dlt", dlt)


        b.putExtra("from_pur", "pur_list")
        b.putExtra("pur_pname", pronameArrayori)
        b.putExtra("pur_pitem", manufacturerArrayori)
        b.putExtra("pur_phsn", hsnArrayori)
        b.putExtra("pur_porder", quantityArrayori)

        b.putExtra("pur_pprice", priceArrayori)
        b.putExtra("pur_ptot", totArrayori)
        b.putExtra("pur_pgrosstot", grosstotArrayori)

        b.putExtra("supplieridfr", supplieridfr)

        b.putExtra("pur_poarray", barcodeArrayori)
        b.putExtra("pur_cessarray", cessArrayori)
        b.putExtra("pur_igstarray", igstArrayori)
        b.putExtra("pur_cgstarray", cgstArrayori)
        b.putExtra("pur_sgstarray", sgstArrayori)
        b.putExtra("pur_igsttotarray", igsttotArrayori)
        b.putExtra("pur_cesstotalarray", cesstotalArrayori)
        b.putExtra("pur_reiddofli", keyArrayori)
        b.putExtra("pur_tallyarray", tallyArrayori)
        b.putExtra("pur_receivedarray", receivedArrayori)
        b.putExtra("pur_receivedarraypri", receivedArraypriori)
        b.putExtra("pur_receivedarraytotal", receivedArraytotalori)
        b.putExtra("pur_receivedarraytaxtot", receivedArraytaxtotori)
        b.putExtra("pur_receivedarraycesstot", receivedArraycesstotalori)
        b.putExtra("pur_receivedarraygrosstot", receivedArraygrosstotalori)
        b.putExtra("idpro", idproArrayori)

        b.putExtra("descriplistener", descriplistener)
        b.putExtra("listListener", listListener)

        /* b.putExtra("pur_branch",namesori)
         b.putExtra("pur_address",namesphonesori)
         b.putExtra("pur_brkey",keybrnch)
         b.putExtra("pur_redate",datestk)
         b.putExtra("pur_redesc",descstk)
         b.putExtra("pur_restkid",idstk)
         b.putExtra("pur_reiddb",iddbs)
         b.putExtra("pur_reiddofli",keyArrayori)*/

        b.putExtra("pur_imi", imageArrayori)
        b.putExtra("pono", pono)
        b.putExtra("names", reprnms)
        b.putExtra("redesc", desc)
        b.putExtra("reorddate", orddate)
        b.putExtra("reestdt", reqdt)
        b.putExtra("restatus", postatus)
        b.putExtra("supplieridfr", supplieridfr)
        b.putExtra("suppinv", suppinv)


        b.putExtra("reids", reqliid)
        b.putExtra("titnm", nms)
        b.putExtra("groschk", grosschk)

        b.putExtra("tiphone", ph)
        b.putExtra("brid", brnchids)
        b.putExtra("viewsuppin", viewsuppin)
        b.putExtra("addsuppin", addsuppin)
        b.putExtra("deletesuppin", deletesuppin)
        b.putExtra("editsuppin", editesuppin)
        b.putExtra("transfersuppin", transfersuppin)
        b.putExtra("exportsuppin", exportsuppin)


        b.putExtra("viewpurord", viewpurord)
        b.putExtra("addpurord", addpurord)
        b.putExtra("deletepurord", deletepurord)
        b.putExtra("editpurord", editepurord)
        b.putExtra("transferpurord", transferpurord)
        b.putExtra("exportpurord", exportpurord)
        b.putExtra("sendpurord", sendpurpo)

        b.putExtra("orddatedup", orddatedup)
        b.putExtra("reqdatedup", reqdatedup)
        b.putExtra("descripdup", descripdup)
            b.putExtra("edclick",edclick)



            b.putExtra("viewpurreq", viewpurreq)
        b.putExtra("addpurreq", addpurreq)
        b.putExtra("deletepurreq", deletepurreq)
        b.putExtra("editpurreq", editepurreq)
        b.putExtra("transferpurreq", transferpurreq)
        b.putExtra("exportpurreq", exportpurreq)


        b.putExtra("ids", ids)

        startActivity(b)
        finish()
    }
    }

    fun net_status():Boolean{   ////Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}
