package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_serv_cat_list.*
import java.net.URL


class serv_cat_list : AppCompatActivity() {
    var db = FirebaseFirestore.getInstance()
    var TAG = "tag"
    lateinit var di : String

    var del=String()
    data class s(var cat: String)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_serv_cat_list)


        net_status() //// Checks the net status.

        /*val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)*/



        //Get all service categories from db.

fun get() {
    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
    pDialog.setTitleText("Loading...")
    pDialog.setCancelable(false)
    pDialog.show();
    db.collection("servicecategory")
            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                serv_cate_progress.visibility = View.VISIBLE
                var category = arrayListOf<String>()//all list category name
                var ico = arrayListOf<String>()//all list image url
                var img_name = arrayListOf<String>()//all list image name
                var d = arrayListOf<String>()//all list id's
                var dlt = arrayListOf<String>()//delete id's
                var dltimagname = arrayListOf<String>()//delete image name's
                val list_item = ArrayList<String>()//temp
                Log.i(TAG, "e    " + e)
                Log.i(TAG, "value    " + value)
                if (e != null) {
                    Log.w("taaswrnglsigfdlmbl", "Listen failed.", e)
                    return@EventListener
                }
                if (value.isEmpty == false) {
                    imageView10.visibility=View.GONE

                    for (doc in value) {
                        val cate = doc.get("cat").toString()

                            val ur = doc.get("ur").toString()

                        val name = doc.get("imgname").toString()


                        ico.add(ur)
                        img_name.add(name)
                        d.add(doc.id)
                        category.add(cate)



                        serv_cate_progress.visibility = View.GONE
                    }
                }
                else{
                    serv_cate_progress.visibility = View.GONE
                    imageView10.visibility=View.VISIBLE
                }
                pDialog.dismiss()

                //list out the details
                val list = listAdapter_serv(this, ico, category, img_name, d)
                val lists = findViewById<ListView>(R.id.serv_cate_list) as ListView
                lists.adapter = list

                //Click list item and navigate to service category add activity
                serv_cate_list.setOnItemClickListener { adapterView, view, i, l ->
                    val b = Intent(this, Service_category::class.java)
                    b.putExtra("id", d[i])
                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                }

                //-----------------------delete action----------------------//

                serv_cate_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
                serv_cate_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                    override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                        //capture total checked items
                        val checkedCount = serv_cate_list.getCheckedItemCount()
                        val l = d.get(position)
                        val imgname = img_name.get(position)
                        Log.i(TAG, " " + l)
                        //setting CAB title
                        mode.setTitle("" + checkedCount + " Selected")
                        Log.d(TAG, " " + id)
                        //list_item.add(id);
                        if (checked) {
                            list_item.add(id.toString()) // Add to list when checked ==  true
                            dlt.add(l)
                            dltimagname.add(imgname)
                            Log.i(TAG, "itm " + dlt.size)
                            //Log.i(TAG,"itm "+dlt.get(position))
                        } else {
                            list_item.remove(id.toString())
                            dlt.remove(l)
                            dltimagname.remove(imgname)
                            Log.i(TAG, "itm " + dlt.size)
                            Log.d(TAG, "id  " + id)
                        }

                    }

                    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                        //Inflate the CAB
                        serv_cate_toolbar.visibility = View.GONE
                        mode.getMenuInflater().inflate(R.menu.list, menu);
                        return true;
                    }

                    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                        return false
                    }

                    override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {


                        val builder = AlertDialog.Builder(this@serv_cat_list,R.style.popup)
                        with(builder) {
                            setTitle("Delete from category?")
                            setMessage("Are you sure want to delete?")
                            setCancelable(false)
                            setPositiveButton("Yes") { dialog, whichButton ->

                                val deleteSize = dlt.size
                                Log.i("tsdfs", "  " + dlt.size)
                                /*val cate = null
                                    val data = s(cat = cate)*/
                                val itemId = item.getItemId()
                                if (itemId == R.id.delete) {
                                    for (a in 0 until  dlt.size) {
                                        del=dlt.get(a)

                                        db.collection("servicecategory").document(dlt.get(a))
                                                .delete()
                                                .addOnSuccessListener {
                                                    //val sub = a + "_subcategory"
                                                    //for (i in dltimagname) {
                                                    println("DELETE "+del)


                                                    db.collection("subcategory").whereEqualTo("main_id",del)
                                                            .get()
                                                            .addOnCompleteListener { task ->
                                                                if (task.isSuccessful) {
                                                                    Log.d(TAG, "cleared")
                                                                    Log.d(TAG, "cleared" + task.result)
                                                                    Log.d(TAG, "cleared" + taskId)
                                                                    Log.d(TAG, "cleared" + task.exception)
                                                                    if (task.result.isEmpty==true) {
                                                                        return@addOnCompleteListener
                                                                    }else {
                                                                        for (document in task.result) {
                                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                            val dd = document.data
                                                                            val img = dd["imgname"].toString()
                                                                            try {
                                                                                val storage = FirebaseStorage.getInstance()
                                                                                val storageRef = storage.getReference()
                                                                                val imagesRef = storageRef.child(img)
                                                                                imagesRef.delete()
                                                                                        .addOnSuccessListener {
                                                                                            println("..........................deleted.......................")
                                                                                            db.collection("subcategory").document(document.id)
                                                                                                    .delete()
                                                                                                    .addOnSuccessListener {
                                                                                                        println(document.id)

                                                                                                    }
                                                                                            //finish()
                                                                                        }
                                                                            }
                                                                            catch (e:Exception){
                                                                                db.collection("subcategory").document(document.id)
                                                                                        .delete()
                                                                                        .addOnSuccessListener {
                                                                                            println(document.id)

                                                                                        }
                                                                            }
                                                                        }
                                                                        dlt.clear()
                                                                    }
                                                                }
                                                                else {
                                                                    Log.w(TAG, "Error getting documents.", task.exception)
                                                                }
                                                            }
                                                            .addOnSuccessListener {
                                                                try {
                                                                    if (del == dlt.last()) {
                                                                        //finish()
                                                                        dialog.dismiss()
                                                                    }
                                                                }
                                                                catch (e:Exception){

                                                                }
                                                            }


                                                    Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()

                                                        val storage = FirebaseStorage.getInstance()
                                                        val storageRef = storage.getReference()
                                                    try {
                                                        val imagesRef = storageRef.child(dltimagname.get(a))
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    dltimagname.clear()
                                                                }
                                                    }
                                                    catch (e:Exception){

                                                    }
                                                    //}

                                                    println("DLT SIZE"+dlt)


                                                    // save_progress.visibility = android.view.View.GONE

                                                }
                                                .addOnFailureListener {
                                                    Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                                    //save_progress.visibility = android.view.View.GONE
                                                }
                                    }
                                }
                                /* checkedCount = 0*/
                                list_item.clear()
                                mode.finish()
                            }
                            setNegativeButton("No") { dialog, whichButton ->

                                list_item.clear()
                                mode.finish()
                                dialog.dismiss()
                            }
                            val dialog = builder.create()
                            dialog.show()
                        }

                        return true
                    }

                    override fun onDestroyActionMode(mode: ActionMode) {
                        // refresh list after deletion
                        dlt.clear()
                        serv_cate_toolbar.visibility = View.VISIBLE
                    }
                })
                Log.d("", "Current cites in CA: ")
            })
}
        get()

        /*swipeContainer.setOnRefreshListener {

            get()

        }*/
        // Configure the refreshing colors
        /*swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/




        unit_back.setOnClickListener {
            finish()
               overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        }

        sc_add.setOnClickListener {
            val intent = Intent(this,Service_category::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
    }

     override fun onBackPressed() {
        finish()
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

    }

    fun net_status():Boolean{ // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
