package com.example.vinitas.inventory_app


import android.app.Activity
import android.content.*
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log




import kotlinx.android.synthetic.main.fragment_list_vendors.*
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.*
import com.google.firebase.firestore.EventListener

import com.opencsv.CSVWriter
import java.io.*
import java.util.*
import kotlin.collections.ArrayList





class SupplierListFirstMAin : AppCompatActivity() {


    private var viewsupp=String()
    private var addsupp=String()
    private var deletesupp=String()
    private var editsupp=String()
    private var importsupp=String()
    private var exportsupp=String()

var importstring= ArrayList<String>()
    var idoflist=arrayOf<String>()
    private var firstTime: Boolean? = null
    val REQUESTCODE_PICK_VIDEO:Int = 0
var poss= listOf<String>()

 var ff=ArrayList<String>()
    var spidstat= String()
    var spmobcat4=String()
    var spids=arrayOf<String>()
    var spp= String()
    /**
     * Checks if the user is opening the app for the first time.
     * Note that this method should be placed inside an activity and it can be called multiple times.
     * @return boolean
     */
    private fun isFirstTime(): Boolean {
        if (firstTime == null) {
            val mPreferences = this.getSharedPreferences("first_time", Context.MODE_PRIVATE)
            firstTime = mPreferences.getBoolean("firstTime", true)
            if (firstTime!!) {
                val editor = mPreferences.edit()
                editor.putBoolean("firstTime", false)
                editor.commit()

            }
        }
        return firstTime!!
    }


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    internal lateinit var myDb: DatabaseSupplierhelper
    internal lateinit var session: SessionProductManagement
    internal lateinit var sessions: SessionManagement
    var a = arrayOf<String>()
    var suppro_kydel = arrayOf<String>()


    var db = FirebaseFirestore.getInstance()
    val TAG = "some"


    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_list_vendors)

        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SupplierListFirstMAin) > 0)
        {

        }
        else{

        }

//Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.constr)

        addLogText(NetworkUtil.getConnectivityStatusString(this@SupplierListFirstMAin))

        net_status()  //check net status


        val i = intent.extras
        var frm = i!!.get("frm_main")
        session = SessionProductManagement(applicationContext)
        sessions = SessionManagement(applicationContext)
        isFirstTime()
        myDb = DatabaseSupplierhelper(this)



        val supplier_access =SessionManagement(this)
        viewsupp=supplier_access.userDetails[SessionManagement.suppview].toString()
        addsupp=supplier_access.userDetails[SessionManagement.suppadd].toString()
        deletesupp=supplier_access.userDetails[SessionManagement.suppdelete].toString()
        editsupp=supplier_access.userDetails[SessionManagement.suppedit].toString()
        importsupp=supplier_access.userDetails[SessionManagement.suppimport].toString()
        exportsupp=supplier_access.userDetails[SessionManagement.suppexport].toString()




        back.setOnClickListener {

            onBackPressed()
        }


        imageButtonsrch.setOnClickListener {        //Image button search  action
            println("clicked")
            card.visibility = View.VISIBLE
            card.startAnimation(AnimationUtils.loadAnimation(this@SupplierListFirstMAin, R.anim.slide_to_right))
            editText.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
        }
        searchback.setOnClickListener {     //Image button search back action
            card.visibility = View.GONE
            progress.visibility=View.GONE
            supp_list_ven.visibility=View.VISIBLE
            editText.text.clear()
            card.startAnimation(AnimationUtils.loadAnimation(this@SupplierListFirstMAin, R.anim.slide_to_left))
        }



        d_fab.setOnClickListener {      //Add button click (Fab)
            if (addsupp == "true") {      //Navigate to supplier insert activity (SupplierAddMain) for adding new supplier

                val ag = Intent(this@SupplierListFirstMAin, SupplierAddMain::class.java)
                ag.putExtra("supppro", "addsupp")
                ag.putExtra("addsupps",addsupp)
                ag.putExtra("editsupp",editsupp)
                ag.putExtra("deletesupp",deletesupp)
                ag.putExtra("viewsupp",viewsupp)
                ag.putExtra("importsupp",importsupp)
                ag.putExtra("exportsupp",exportsupp)

                ag.putExtra("newid", db.collection("suppliers").document().id)
                startActivity(ag)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()
            } else {
                popup("add")
                d_fab.isEnabled = true
            }

        }
       /* imageButtonvert.setOnClickListener({


            val popup = PopupMenu(this@SupplierListFirstMAin, imageButtonvert)

            popup.menuInflater.inflate(R.menu.menu_suppliers, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@SupplierListFirstMAin, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()
                true
            }

            popup.show()

        })
*/







        if(frm=="main") {

            myDb = DatabaseSupplierhelper(this)


                        //Check if sql db supplier not exists, below code is going to insert a supplier to local sql table

            println("myDb.getNotesCount() : "+myDb.getNotesCount())
            textView2.setText(myDb.notesCount.toString() + " vendors")
            db.collection("suppliers")
                    .addSnapshotListener(EventListener<QuerySnapshot>{task,e->
                        println("e : "+e)
                        if (e==null) {
                            println("task.docchange : "+task.documentChanges)
                            for (change in task.getDocumentChanges()) {
                                when (change.getType()) {
                                    DocumentChange.Type.ADDED -> {
                                        val groupId = change.getDocument().getId()
                                        println("type added " + groupId)
                                        println("myDb.isin(groupId).moveToNext() " + myDb.checkIfRecordExist(groupId))
                                        val d=myDb.checkIfRecordExist(groupId)
                                        if (d==false) {
                                            db.collection("suppliers").document(groupId)
                                                    .addSnapshotListener(EventListener<DocumentSnapshot> { task1, e1 ->
                                                        if (task1.exists()) {
                                                            imageView10.visibility=View.GONE
                                                            val dd = task1.data
                                                            val id = task1.id;//0
                                                            val spnm = dd["spnm"].toString();//1
                                                            val spid = dd["spid"].toString();//2
                                                            val spmobcat1 = dd["spmobcat1"].toString();//3
                                                            val spmobcat2 = dd["spmobcat2"].toString();//4
                                                            val spmobcat3 = dd["spmobcat3"].toString();//5
                                                            val spmob1 = dd["spmob1"].toString();//6
                                                            val spmob2 = dd["spmob2"].toString();//7
                                                            val spmob3 = dd["spmob3"].toString();//8
                                                            val spmob4 = dd["spmob4"].toString();//9
                                                            val spaddress1 = dd["spaddress1"].toString();//10
                                                            val spaddress2 = dd["spaddress2"].toString();//11
                                                            val spaddress3 = dd["spaddress3"].toString();//12
                                                            val spcity = dd["spcity"].toString();//13
                                                            val spstate = dd["spstate"].toString();//14
                                                            val sppincode = dd["sppincode"].toString();//15
                                                            val sppgpsco_or = dd["sppgpsco_or"].toString();//16
                                                            val spemail = dd["spemail"].toString();//17
                                                            val spcontact_person = dd["spcontact_person"].toString();//18
                                                            val spgst = dd["spgst"].toString();//19
                                                            val spimglink = dd["spimglink"].toString();//20
                                                            val prodkey = dd["prodkey"].toString();//21spnm
                                                            val status = dd["status"].toString();//22
                                                            val img1n = dd["img1n"].toString();//23
                                                            val img2n = dd["img2n"].toString();//24
                                                            val img3n = dd["img3n"].toString();//25
                                                            val img4n = dd["img4n"].toString();//26
                                                            val img5n = dd["img5n"].toString();//27
                                                            val img1url = dd["img1url"].toString();//28
                                                            val img2url = dd["img2url"].toString();//29
                                                            val img3url = dd["img3url"].toString();//30
                                                            val img4url = dd["img4url"].toString();//31
                                                            val img5url = dd["img5url"].toString();//32

                                                            val img1nhigh = dd["img1nhigh"].toString();//23
                                                            val img2nhigh = dd["img2nhigh"].toString();//24
                                                            val img3nhigh = dd["img3nhigh"].toString();//25
                                                            val img4nhigh = dd["img4nhigh"].toString();//26
                                                            val img5nhigh = dd["img5nhigh"].toString();//27
                                                            val img1urlhigh = dd["img1urlhigh"].toString();//28
                                                            val img2urlhigh = dd["img2urlhigh"].toString();//29
                                                            val img3urlhigh = dd["img3urlhigh"].toString();//30
                                                            val img4urlhigh = dd["img4urlhigh"].toString();//31
                                                            val img5urlhigh = dd["img5urlhigh"].toString();//32high
                                                            try {
                                                                 spmobcat4 = dd["spmobcat4"].toString();//5
                                                            }
                                                            catch (e:Exception){

                                                            }

                                                            /*      val img1n = dd["img1n"].toString();//28
                                                                  val img2n = dd["img2n"].toString();//29
                                                                  val img3n = dd["img3n"].toString();//30
                                                                  val img4n = dd["img4n"].toString();//31
                                                                  val img5n = dd["img5n"].toString();//32
                                                                  val img1url = dd["img1url"].toString();//33
                                                                  val img2url = dd["img2url"].toString();//34
                                                                  val img3url = dd["img3url"].toString();//35
                                                                  val img4url = dd["img4url"].toString();//36
                                                                  val img5url = dd["img5url"].toString();//37*/
                                                            val isInserted = myDb.insertData(id, spnm, spid, spmobcat1, spmobcat2, spmobcat3, spmob1, spmob2, spmob3, spmob4, spaddress1, spaddress2,
                                                                    spaddress3, spcity, spstate, sppincode, sppgpsco_or, spemail, spcontact_person, spgst, spimglink, prodkey, status,img1n, img2n,
                                                                    img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh, img2nhigh,
                                                                    img3nhigh,img4nhigh,img5nhigh,img1urlhigh, img2urlhigh,img3urlhigh,img4urlhigh,img5urlhigh,spmobcat4)
                                                            textView2.setText(myDb.notesCount.toString() + " Suppliers")
                                                            if (isInserted==true) {
                                                                get()
                                                            }
                                                        }
                                                    })
                                        }
                                    }

                                        //when modified the existing data below code will be executed.

                                    DocumentChange.Type.MODIFIED -> {
                                        val groupId = change.getDocument().getId()
                                        println("type modified " + groupId)
                                        db.collection("suppliers").document(groupId)
                                                .addSnapshotListener(EventListener<DocumentSnapshot>{ task1, e1->
                                                    if (task1.exists()){
                                                        imageView10.visibility=View.GONE
                                                        val dd = task1.data
                                                        val id = task1.id;//0
                                                        val spnm = dd["spnm"].toString();//1
                                                        val spid = dd["spid"].toString();//2
                                                        val spmobcat1 = dd["spmobcat1"].toString();//3
                                                        val spmobcat2 = dd["spmobcat2"].toString();//4
                                                        val spmobcat3 = dd["spmobcat3"].toString();//5
                                                        val spmob1 = dd["spmob1"].toString();//6
                                                        val spmob2 = dd["spmob2"].toString();//7
                                                        val spmob3 = dd["spmob3"].toString();//8
                                                        val spmob4 = dd["spmob4"].toString();//9
                                                        val spaddress1 = dd["spaddress1"].toString();//10
                                                        val spaddress2 = dd["spaddress2"].toString();//11
                                                        val spaddress3 = dd["spaddress3"].toString();//12
                                                        val spcity = dd["spcity"].toString();//13
                                                        val spstate = dd["spstate"].toString();//14
                                                        val sppincode = dd["sppincode"].toString();//15
                                                        val sppgpsco_or = dd["sppgpsco_or"].toString();//16
                                                        val spemail = dd["spemail"].toString();//17
                                                        val spcontact_person = dd["spcontact_person"].toString();//18
                                                        val spgst = dd["spgst"].toString();//19
                                                        val spimglink = dd["spimglink"].toString();//20
                                                        val prodkey = dd["prodkey"].toString();//21spnm
                                                        val status = dd["status"].toString();//22
                                                        val img1n = dd["img1n"].toString();//23
                                                        val img2n = dd["img2n"].toString();//24
                                                        val img3n = dd["img3n"].toString();//25
                                                        val img4n = dd["img4n"].toString();//26
                                                        val img5n = dd["img5n"].toString();//27
                                                        val img1url = dd["img1url"].toString();//28
                                                        val img2url = dd["img2url"].toString();//29
                                                        val img3url = dd["img3url"].toString();//30
                                                        val img4url = dd["img4url"].toString();//31
                                                        val img5url = dd["img5url"].toString();//32
                                                        val img1nhigh = dd["img1nhigh"].toString();//23
                                                        val img2nhigh = dd["img2nhigh"].toString();//24
                                                        val img3nhigh = dd["img3nhigh"].toString();//25
                                                        val img4nhigh = dd["img4nhigh"].toString();//26
                                                        val img5nhigh = dd["img5nhigh"].toString();//27
                                                        val img1urlhigh = dd["img1urlhigh"].toString();//28
                                                        val img2urlhigh = dd["img2urlhigh"].toString();//29
                                                        val img3urlhigh = dd["img3urlhigh"].toString();//30
                                                        val img4urlhigh = dd["img4urlhigh"].toString();//31
                                                        val img5urlhigh = dd["img5urlhigh"].toString();//32high
                                                        try {
                                                            spmobcat4 = dd["spmobcat4"].toString();//5
                                                        }
                                                        catch (e:Exception){

                                                        }
                                                        val isInserted = myDb.updatedata(id, spnm, spid, spmobcat1, spmobcat2, spmobcat3, spmob1, spmob2, spmob3, spmob4, spaddress1, spaddress2,
                                                                spaddress3, spcity, spstate, sppincode, sppgpsco_or, spemail, spcontact_person, spgst, spimglink, prodkey, status,img1n, img2n,
                                                                img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh,img2nhigh, img3nhigh, img4nhigh,img5nhigh,img1urlhigh, img2urlhigh,
                                                                img3urlhigh, img4urlhigh, img5urlhigh,spmobcat4)
                                                        if (isInserted==true) {
                                                            get()
                                                        }
                                                    }
                                                })
                                    }

                                         //Check if remove the data.

                                    DocumentChange.Type.REMOVED ->{
                                        val groupId = change.getDocument().getId()
                                        println("type removed " + groupId)
                                        myDb.deleteData(groupId)
                                        textView2.setText(myDb.notesCount.toString() + " vendors")
                                    }
                                }
                            }
                        }

                    })





                //if local sql db's document count is 0 nothing to be executed.


            if (myDb.notesCount == 0) {

                imageView10.visibility=View.VISIBLE
                var category = arrayListOf<String>()
                var d = arrayListOf<String>()
                var dlt = arrayListOf<String>()
                val list_item = ArrayList<String>()
                /*supp_list_ven.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL;
                supp_list_ven.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                    override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                        //capture total checked items
                        var checkedCount = supp_list_ven.checkedItemCount
                        val l = a[position]
                        Log.i(TAG, " " + l)
                        //setting CAB title
                        mode.setTitle("" + checkedCount + " Selected")
                        Log.d(TAG, " " + id)
                        //list_item.add(id);
                        if (checked) {
                            list_item.add(id.toString()) // Add to list when checked ==  true
                            dlt.add(l)
                            Log.i(TAG, "itm " + dlt.size)
                            //Log.i(TAG,"itm "+dlt.get(position))
                        } else {
                            list_item.remove(id.toString())
                            dlt.remove(l)
                            Log.i(TAG, "itm " + dlt.size)
                            Log.d(TAG, "id  " + id)
                        }

                    }

                    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                        //Inflate the CAB
                        toolbar.visibility = View.GONE


                        imageButtonsrch.visibility=View.GONE
                        imageButtonvert.visibility=View.GONE




                        mode.getMenuInflater().inflate(R.menu.list, menu);
                        return true;
                    }

                    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                        return false
                    }

                    override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {



                        val alert=AlertDialog.Builder(this@SupplierListFirstMAin)
                        with(alert)

                        {
                            setTitle("Delete from list?")
                            setMessage("Are you sure want to delete?")
                            setPositiveButton("Yes") { dialog, whichButton ->

                                val deleteSize = dlt.size
                                Log.i("tsdfs", "  " + dlt.size)
                                val cate = null

                                val i = 0
                                Log.d("dlt", " " + dlt.get(i))
                                val itemId = item.getItemId()
                                if ((itemId == R.id.delete) && (deletesupp == "true")) {
                                    progress.visibility = View.VISIBLE
                                    for (i in dlt) {
                                        db.collection("suppliers").document(i)
                                                .delete()
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").orderBy("spsave_key")
                                                            .get()
                                                            .addOnCompleteListener { task ->
                                                                if (task.isSuccessful) {
                                                                    Log.d(TAG, "cleared")
                                                                    if (task.result.isEmpty == false) {
                                                                        for (document in task.result) {
                                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                            val dd = document.data

                                                                            val spnm = dd["spsave_key"].toString();//1
                                                                            if (spnm == i) {
                                                                                val id = document.id;//0

                                                                                db.collection("supplier_products").document(id)
                                                                                        .delete()
                                                                                        .addOnSuccessListener {


                                                                                        }


                                                                            }

                                                                        }
                                                                    }

                                                                }
                                                            }


                                                    myDb.deleteData(i)
                                                    dlt.clear()

                                                    get()
                                                    progress.visibility = View.GONE

                                                    imageButtonsrch.visibility=View.VISIBLE
                                                    imageButtonvert.visibility=View.VISIBLE


                                                    // save_progress.visibility = android.view.View.GONE

                                                }
                                                .addOnFailureListener {
                                                    Toast.makeText(this@SupplierListFirstMAin, "not updated", Toast.LENGTH_LONG).show()
                                                    //save_progress.visibility = android.view.View.GONE
                                                }
                                    }
                                    Toast.makeText(this@SupplierListFirstMAin, "Deleted", Toast.LENGTH_SHORT).show()
                                    Toast.makeText(applicationContext, "Supplier products deleted", Toast.LENGTH_SHORT).show()
                                } else {
                                    popup("delete")
                                }
                                if (itemId == R.id.selectAll) {

                                }
                                list_item.clear()
                                mode.finish()

                            }
                                setNegativeButton("No") { dialog, whichButton ->
                                    list_item.clear()
                                    mode.finish()
                                    dialog.dismiss()

                                }


                                val dialog = alert.create()
                                dialog.show()
                            }

                        return true
                    }

                    override fun onDestroyActionMode(mode: ActionMode) {
                        // refresh list after deletion
                        toolbar.visibility = View.VISIBLE

                        imageButtonsrch.visibility=View.VISIBLE
                        imageButtonvert.visibility=View.VISIBLE
                    }
                })*/


            } else {    //ELSE Supplier DETAILS WILL BE SHOWN AS LIST.



                var idsArray = arrayOf<String>()
                var nameArray = arrayOf<String>()
                var nameArray1 = arrayOf<String>()
                var spidArray=arrayOf<String>()
                var nm = arrayOf<String>()
                var mob = arrayOf<String>()
                var citysupplier = arrayOf<String>()
                var sunbnmArray = arrayOf<String>()
                var dissupArray = arrayOf<String>()
                var icohighArray = arrayOf<String>()
                var icohighnmArray = arrayOf<String>()
                var primgArray = arrayOf<String>()
                val dd = myDb.getAllData()

                while (dd.moveToNext()) {
                    imageView10.visibility=View.GONE
                    idsArray = idsArray.plusElement(dd.getString(0))
                    a = idsArray
                    var name = dd.getString(1)
                    nm = nm.plusElement(name)
                    var spidd=dd.getString(2)
                    spidArray=spidArray.plusElement(spidd)
                    var city = dd.getString(13)
                    var dissup = dd.getString(22)
                    icohighArray=icohighArray.plusElement( dd.getString(38))
                    icohighnmArray=icohighnmArray.plusElement( dd.getString(33))
                    citysupplier = citysupplier.plusElement(city)


                    var mobile = dd.getString(6)
                    mob = mob.plusElement(mobile)
                    nameArray = nameArray.plusElement(name)
                    if(city.isNotEmpty()) {
                        nameArray1 = nameArray1.plusElement(city + " " + mobile)
                    }
                    else if(city.isEmpty()){
                        nameArray1 = nameArray1.plusElement(mobile)
                    }
                    sunbnmArray = sunbnmArray.plusElement(mobile)
                    dissupArray = dissupArray.plusElement(dissup)

                    a = idsArray
                    try {
                        val ur = dd.getString(28) //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                        if (ur.isNotEmpty()) {

                            primgArray = primgArray.plusElement(ur)
                        } else {
                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                        }
                    } catch (e: Exception) {

                    }

                    for(i in 0 until idsArray.size){

                        var kk=spidArray[i]
                        idoflist=idoflist.plusElement(kk)


                    }
                    //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                    /* if (ur.isNotEmpty()) {

                         icoArray = icoArray.plusElement(ur)
                     }else{
                         icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                     }*/
                }
               textView2.setText("${dd.count} vendors")
                val whatever = supp_first_list_adap(this@SupplierListFirstMAin, idsArray, dissupArray, nameArray, nameArray1, sunbnmArray, primgArray, icohighnmArray,icohighArray)
                val supplist = findViewById<View>(R.id.supp_list_ven) as ListView
                supplist.adapter = whatever


                //Navigate to supplier details  activity (SupplierAddMain) for updating the supplier.

                supplist.setOnItemClickListener { parent, view, position, d ->
                    println("dfhidd  " + a)
                    val b = Intent(applicationContext, SupplierAddMain::class.java)
                    b.putExtra("supppro", "fromsuplist")

                    b.putExtra("id", a[position])

                    b.putExtra("addsupp",addsupp)
                    b.putExtra("editsupp",editsupp)
                    b.putExtra("deletesupp",deletesupp)
                    b.putExtra("viewsupp",viewsupp)
                    b.putExtra("importsupp",importsupp)
                    b.putExtra("exportsupp",exportsupp)
                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                    finish()
                }

            }






























            //-------------------------------IMPORT AND EXPORT-------------------------------------//


            imageButtonvert.setOnClickListener({


                val popup = PopupMenu(this@SupplierListFirstMAin, imageButtonvert)

                popup.menuInflater.inflate(R.menu.menu_suppliers, popup.menu)

                popup.setOnMenuItemClickListener { item ->    //Vert menu contains 'Logout','Export products','Import products' options.


                    if(item.title=="Logout"){
                        if(net_status()==true) {
                            Toast.makeText(this@SupplierListFirstMAin, "You are logged out", Toast.LENGTH_SHORT).show()
                            val f = Intent(this@SupplierListFirstMAin, PinActivity::class.java)
                            startActivity(f)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            finish()
                        }
                        else{
                            Toast.makeText(this@SupplierListFirstMAin, "You're offline", Toast.LENGTH_SHORT).show()

                        }
                    }

                    var ky = arrayOf<String>()
                    var spid = arrayOf<String>()
                    var spnm = arrayOf<String>()
                    var spmob1= arrayOf<String>()
                    var spmob2= arrayOf<String>()
                    var spstate= arrayOf<String>()
                    var sppincode= arrayOf<String>()
                    var spcity= arrayOf<String>()
                    var spaddress1= arrayOf<String>()
                    var spaddress2= arrayOf<String>()
                    var spaddress3= arrayOf<String>()
                    var spcontact_person= arrayOf<String>()
                    var spemail= arrayOf<String>()
                    var spgst= arrayOf<String>()
                    var spgpscoordinates= arrayOf<String>()
                    var prodkey=arrayOf<String>()
                    var status=arrayOf<String>()

                    val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)


                    var pri=arrayOf<String>()
                    var cat= arrayOf<String>()

                    if (item.itemId == R.id.export) {

                        if ((exportsupp == "true")&&(net_status()==true)) {  //If the user can select the 'Export suppliers' option below code to be executed.

                            db.collection("suppliers")
                                    .get()
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {

                                            if (task.result != null) {

                                                val pDialog = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE)
                                                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                                pDialog.setTitleText("Exporting...")
                                                pDialog.setCancelable(false);
                                                pDialog.show();

                                                for (doc in task.result) {
                                                    val dd = doc.data
                                                    ky = ky.plusElement(doc.id)
                                                    spid = spid.plusElement(dd["spid"].toString())
                                                    spnm = spnm.plusElement(dd["spnm"].toString())
                                                    spmob1 = spmob1.plusElement(dd["spmob1"].toString())
                                                    spmob2 = spmob2.plusElement(dd["spmob2"].toString())
                                                    spstate = spstate.plusElement(dd["spstate"].toString())
                                                    sppincode = sppincode.plusElement(dd["sppincode"].toString())
                                                    spcity = spcity.plusElement(dd["spcity"].toString())
                                                    spaddress1 = spaddress1.plusElement(dd["spaddress1"].toString())
                                                    spaddress2 = spaddress2.plusElement(dd["spaddress2"].toString())
                                                    spaddress3 = spaddress3.plusElement(dd["spaddress3"].toString())
                                                    spcontact_person = spcontact_person.plusElement(dd["spcontact_person"].toString())
                                                    spemail = spemail.plusElement(dd["spemail"].toString())
                                                    spgst = spgst.plusElement(dd["spgst"].toString())
                                                    spgpscoordinates = spgpscoordinates.plusElement(dd["sppgpsco_or"].toString())
                                                    prodkey=prodkey.plusElement(dd["prodkey"].toString())
                                                    status=status.plusElement(dd["status"].toString())


                                                }
                                                pDialog.dismiss()
                                            }
                                            else{

                                            }
                                        }
                                    }
                                    .addOnSuccessListener {
                                        val baseDir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                                        println(baseDir)
                                        val tsLong = System.currentTimeMillis() / 1000
                                        val ts = tsLong.toString()
                                        val fileName = "supplierlist$ts.xlsx";
                                        val filePath = baseDir + File.separator + fileName;
                                        println(filePath)
                                        val f = File(filePath);
                                        val writer: CSVWriter
                                        if (f.exists() && !f.isDirectory()) {
                                            val mFileWriter = FileWriter(filePath, true);
                                            writer = CSVWriter(mFileWriter,',', CSVWriter.NO_QUOTE_CHARACTER);
                                        } else {
                                            writer = CSVWriter(FileWriter(filePath),',', CSVWriter.NO_QUOTE_CHARACTER);
                                        }
                                        val otherStrings = arrayOf("Supplier id", "Supplier Name", "Mobile1","Mobile2","State","Pin Code","City","Address1","Address2","Address3",
                                                "Contact person","Email","GST","GPS Coordinates")
                                        writer.writeNext(otherStrings)
                                        for (i in 0 until ky.size) {
                                            val next = arrayOf(spid[i], spnm[i], spmob1[i],spmob2[i],spstate[i],sppincode[i],spcity[i],spaddress1[i],spaddress2[i],
                                                    spaddress3[i],spcontact_person[i],spemail[i],spgst[i],spgpscoordinates[i],prodkey[i],status[i])
                                            writer.writeNext(next)
                                        }
                                        writer.close();
                                        Toast.makeText(this, "file created", Toast.LENGTH_LONG).show()


                                        pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                                        Toast.makeText(this, "Exported:" + filePath + " - " + fileName, Toast.LENGTH_LONG).show()
                                        pDialog1.titleText = "Exported!"
                                        pDialog1.contentText = filePath
                                        pDialog1.setConfirmText("Open")
                                        pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                        pDialog1.setConfirmClickListener {


                                            try {

                                                pDialog1.dismiss()
                                                val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + filePath, fileName)
                                                println("SD CARD URL" + pdfFile)
                                                val path = Uri.fromFile(pdfFile)

                                                // Setting the intent for pdf reader
                                                val pdfIntent = Intent(Intent.ACTION_VIEW)
                                                pdfIntent.setDataAndType(path, "application/vnd.ms-excel")  //Read csv file by reader
                                                pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

                                                try {
                                                    startActivity(pdfIntent);
                                                } catch (e: ActivityNotFoundException) {
                                                    Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                }


                                            } catch (e: Exception) {
                                                val intent = Intent(Intent.ACTION_VIEW)
                                                val k = filePath.replace("%20", "")
                                                val path = Environment.getExternalStorageDirectory().absolutePath + "/" + filePath + "/" + fileName
                                                println("PATH" + path)
                                                val targetFile = File(path)
                                                println("TARGET PATH" + targetFile)
                                                val targetUri = Uri.fromFile(targetFile)


                                                try {
                                                    val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.inventory_app.provider", targetFile)
                                                    println("URI" + photoURI)
                                                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    intent.setDataAndType(photoURI, "application/vnd.ms-excel")  //Read csv file by reader
                                                    startActivity(intent);
                                                    Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

                                                } catch (e: Exception) {
                                                    Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                }

                                            }


                                        }
                                    }

                            pDialog1.show()
                        } else {
                            if(net_status()==false){
                                Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                            }
                            popup("Export")
                        }
                    }
                    if (item.itemId == R.id.im) {
                        if ((exportsupp == "true")&&(net_status()==true)) {
                            val file = File(Environment.getExternalStorageDirectory().absolutePath + File.separator)
                            val mediaIntent = Intent(Intent.ACTION_GET_CONTENT)
                            mediaIntent.setDataAndType(Uri.fromFile(file), "*/*"); //set mime type as per requirement
                            startActivityForResult(mediaIntent, REQUESTCODE_PICK_VIDEO)//Select csv file using this 'REQUESTCODE_PICK_VIDEO' code
                        } else {
                            if(net_status()==false) {
                                Toast.makeText(this@SupplierListFirstMAin, "You're offline", Toast.LENGTH_SHORT).show()

                            }
                            else{
                                popup("Import")
                            }

                        }
                    }
                    true

                    true

                }

                popup.show()

            })








        }
        else if(frm=="frm_save"){
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            if (sessions.isLoggedIn == true) {

                get()
                var category = arrayListOf<String>()
                var d = arrayListOf<String>()
                var dlt = arrayListOf<String>()
                val list_item = ArrayList<String>()




                //---------------------------Delete supplier-----------------------------//

                supp_list_ven.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL;
                supp_list_ven.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                    override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                        //capture total checked items
                        var checkedCount = supp_list_ven.checkedItemCount
                        val l = a[position]
                        Log.i(TAG, " " + l)
                        //setting CAB title
                        mode.setTitle("" + checkedCount + " Selected")
                        Log.d(TAG, " " + id)
                        //list_item.add(id);
                        if (checked) {
                            list_item.add(id.toString()) // Add to list when checked ==  true
                            dlt.add(l)
                            Log.i(TAG, "itm " + dlt.size)
                            //Log.i(TAG,"itm "+dlt.get(position))
                        } else {
                            list_item.remove(id.toString())
                            dlt.remove(l)
                            Log.i(TAG, "itm " + dlt.size)
                            Log.d(TAG, "id  " + id)
                        }

                    }

                    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                        //Inflate the CAB
                        toolbar.visibility = View.GONE
                        imageButtonsrch.visibility=View.GONE
                        imageButtonvert.visibility=View.GONE
                        mode.getMenuInflater().inflate(R.menu.list, menu);
                        return true;
                    }

                    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                        return false
                    }

                    override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                        val pDialog = SweetAlertDialog(this@SupplierListFirstMAin, SweetAlertDialog.PROGRESS_TYPE);

                        val builder = AlertDialog.Builder(this@SupplierListFirstMAin)
                        with(builder) {
                            setTitle("Delete from category?")
                            setMessage("Are you sure want to delete?")
                            setPositiveButton("Yes") { dialog, whichButton ->


                                val deleteSize = dlt.size
                                Log.i("tsdfs", "  " + dlt.size)
                                val cate = null

                                val i = 0
                                Log.d("dlt", " " + dlt.get(i))
                                val itemId = item.getItemId()
                                if ((itemId == R.id.delete) && (deletesupp == "true")) {
                                    progress.visibility = View.VISIBLE
                                    for (i in dlt) {
                                        db.collection("suppliers").document(i)
                                                .delete()
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").orderBy("spsave_key")
                                                            .get()
                                                            .addOnCompleteListener { task ->
                                                                if (task.isSuccessful) {
                                                                    Log.d(TAG, "cleared")
                                                                    if (task.result.isEmpty == false) {
                                                                        for (document in task.result) {
                                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                            val dd = document.data

                                                                            val spnm = dd["spsave_key"].toString();//1
                                                                            if (spnm == i) {
                                                                                val id = document.id;//0

                                                                                db.collection("supplier_products").document(id)
                                                                                        .delete()
                                                                                        .addOnSuccessListener {


                                                                                            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                                                                            pDialog.setTitleText("Deleting...");
                                                                                            pDialog.setCancelable(false);
                                                                                            pDialog.show();


                                                                                        }


                                                                            }

                                                                        }
                                                                    }

                                                                }
                                                            }


                                                    myDb.deleteData(i)

                                                    dlt.clear()
                                                    pDialog.dismiss();
                                                    Toast.makeText(this@SupplierListFirstMAin, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                                    Toast.makeText(applicationContext, "Supplier products deleted", Toast.LENGTH_SHORT).show()
                                                    get()
                                                    progress.visibility = View.GONE


                                                    // save_progress.visibility = android.view.View.GONE

                                                }
                                                .addOnFailureListener {
                                                    Toast.makeText(this@SupplierListFirstMAin, "not updated", Toast.LENGTH_LONG).show()
                                                    //save_progress.visibility = android.view.View.GONE
                                                }
                                    }
                                } else {
                                    popup("delete")
                                }


                                list_item.clear()
                                mode.finish()


                            }
                            setNegativeButton("No") { dialog, whichButton ->
                                list_item.clear()
                                mode.finish()
                                dialog.dismiss()
                            }
                            val dialog = builder.create()
                            dialog.show()
                        }
                        return true
                    }

                    override fun onDestroyActionMode(mode: ActionMode) {
                        // refresh list after deletion
                        toolbar.visibility = View.VISIBLE

                        imageButtonsrch.visibility=View.VISIBLE
                        imageButtonvert.visibility=View.VISIBLE
                    }
                })
                imageButtonvert.setOnClickListener({


                    val popup = PopupMenu(this@SupplierListFirstMAin, imageButtonvert)

                    popup.menuInflater.inflate(R.menu.menu_suppliers, popup.menu)

                    popup.setOnMenuItemClickListener { item ->


                        if(item.title=="Logout"){
                            if(net_status()==false) {
                                Toast.makeText(this@SupplierListFirstMAin, "You are logged out", Toast.LENGTH_SHORT).show()
                                val f=Intent(this@SupplierListFirstMAin,PinActivity::class.java)
                                startActivity(f)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()

                            }
                            else{
                                Toast.makeText(this@SupplierListFirstMAin, "You're offline", Toast.LENGTH_SHORT).show()

                            }

                        }
                        var ky = arrayOf<String>()
                        var spid = arrayOf<String>()
                        var spnm = arrayOf<String>()
                        var spmob1= arrayOf<String>()
                        var spmob2= arrayOf<String>()
                        var spstate= arrayOf<String>()
                        var sppincode= arrayOf<String>()
                        var spcity= arrayOf<String>()
                        var spaddress1= arrayOf<String>()
                        var spaddress2= arrayOf<String>()
                        var spaddress3= arrayOf<String>()
                        var spcontactperson= arrayOf<String>()
                        var spemail= arrayOf<String>()
                        var spgst= arrayOf<String>()
                        var spgpscoordinates= arrayOf<String>()
                        var prodkey=arrayOf<String>()
                        var status=arrayOf<String>()

                        val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)



                        if (item.itemId == R.id.export) {
                            if ((exportsupp == "true")&&(net_status()==true)) {
                                db.collection("suppliers")
                                        .get()
                                        .addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                if (task.result != null) {
                                                    for (doc in task.result) {
                                                        val dd = doc.data
                                                        ky = ky.plusElement(doc.id)
                                                        spid = spid.plusElement(dd["spid"].toString())
                                                        spnm = spnm.plusElement(dd["spnm"].toString())
                                                        spmob1 = spmob1.plusElement(dd["spmob1"].toString())
                                                        spmob2 = spmob2.plusElement(dd["spmob2"].toString())
                                                        spstate = spstate.plusElement(dd["spstate"].toString())
                                                        sppincode = sppincode.plusElement(dd["sppincode"].toString())
                                                        spcity = spcity.plusElement(dd["spcity"].toString())
                                                        spaddress1 = spaddress1.plusElement(dd["spaddress1"].toString())
                                                        spaddress2 = spaddress2.plusElement(dd["spaddress2"].toString())
                                                        spaddress3 = spaddress3.plusElement(dd["spaddress3"].toString())
                                                        spcontactperson = spcontactperson.plusElement(dd["spcontact_person"].toString())
                                                        spemail = spemail.plusElement(dd["spemail"].toString())
                                                        spgst = spgst.plusElement(dd["spgst"].toString())
                                                        spgpscoordinates = spgpscoordinates.plusElement(dd["sppgpsco_or"].toString())
                                                        prodkey=prodkey.plusElement(dd["prodkey"].toString())
                                                        status=status.plusElement(dd["status"].toString())


                                                    }
                                                }
                                            }
                                        }
                                        .addOnSuccessListener {
                                            val baseDir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                                            println(baseDir)
                                            val tsLong = System.currentTimeMillis() / 1000
                                            val ts = tsLong.toString()
                                            val fileName = "supplierlist$ts.xlsx";
                                            val filePath = baseDir + File.separator + fileName;
                                            println(filePath)
                                            val f = File(filePath);
                                            val writer: CSVWriter
                                            if (f.exists() && !f.isDirectory()) {
                                                val mFileWriter = FileWriter(filePath, true);
                                                writer = CSVWriter(mFileWriter,',', CSVWriter.NO_QUOTE_CHARACTER);
                                            } else {
                                                writer = CSVWriter(FileWriter(filePath),',', CSVWriter.NO_QUOTE_CHARACTER);
                                            }
                                            val otherStrings = arrayOf("Supplier id", "Supplier Name", "Mobile1","Mobile2","State","Pin Code","City","Address1","Address2","Address3",
                                                    "Contact person","Email","GST","GPS Coordinates","Product Keys","Status")
                                            writer.writeNext(otherStrings)
                                            for (i in 0 until ky.size) {
                                                val next = arrayOf(spid[i], spnm[i], spmob1[i],spmob2[i],spstate[i],sppincode[i],spcity[i],spaddress1[i],spaddress2[i],
                                                        spaddress3[i],spcontactperson[i],spemail[i],spgst[i],spgpscoordinates[i],prodkey[i],status[i])
                                                writer.writeNext(next)
                                            }
                                            writer.close();
                                            pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                                            Toast.makeText(this, "Exported:" + filePath + " - " + fileName, Toast.LENGTH_LONG).show()
                                            pDialog1.titleText = "Exported!"
                                            pDialog1.contentText = filePath
                                            pDialog1.setConfirmText("Open")
                                            pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                            pDialog1.setConfirmClickListener {
                                                try {

                                                    pDialog1.hide()
                                                    val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + filePath, fileName)
                                                    println("SD CARD URL" + pdfFile)
                                                    val path = Uri.fromFile(pdfFile)

                                                    // Setting the intent for pdf reader
                                                    val pdfIntent = Intent(Intent.ACTION_VIEW)
                                                    pdfIntent.setDataAndType(path, "application/vnd.ms-excel")
                                                    pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

                                                    try {
                                                        startActivity(pdfIntent);
                                                    } catch (e: ActivityNotFoundException) {
                                                        Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                    }


                                                } catch (e: Exception) {
                                                    val intent = Intent(Intent.ACTION_VIEW)
                                                    val k = filePath.replace("%20", "")
                                                    val path = Environment.getExternalStorageDirectory().absolutePath + "/" + filePath + "/" + fileName
                                                    println("PATH" + path)
                                                    val targetFile = File(path)
                                                    println("TARGET PATH" + targetFile)
                                                    val targetUri = Uri.fromFile(targetFile)


                                                    try {
                                                        val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider", targetFile)
                                                        println("URI" + photoURI)
                                                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                        intent.setDataAndType(photoURI, "application/vnd.ms-excel")
                                                        startActivity(intent);
                                                        Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

                                                    } catch (e: Exception) {
                                                        Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                    }

                                                }



                                            }

                                        }
                                pDialog1.show()
                            } else {
                                if(net_status()==false)
                                {
                                    Toast.makeText(this@SupplierListFirstMAin, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Export")

                                }

                            }
                        }
                        if (item.itemId == R.id.im) {
                            if ((exportsupp == "true")&&(net_status()==true)) {
                                val file = File(Environment.getExternalStorageDirectory().absolutePath + File.separator)
                                val mediaIntent = Intent(Intent.ACTION_GET_CONTENT)
                                mediaIntent.setDataAndType(Uri.fromFile(file), "*/*"); //set mime type as per requirement
                                startActivityForResult(mediaIntent, REQUESTCODE_PICK_VIDEO)
                            } else {
                                if(net_status()==false){
                                    Toast.makeText(this@SupplierListFirstMAin, "You're offline", Toast.LENGTH_SHORT).show()

                                }
                                else{
                                    popup("Import")

                                }
                            }
                        }
                        true

                        true

                    }

                    popup.show()

                })

            } else {

            }

        }






//------------------------------------------SEARCH ACTION-------------------------------------------//

        editText.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int)
            {

                supp_list_ven.visibility=View.GONE
                noresfo.visibility=View.GONE

                progress.visibility=View.VISIBLE
                var checkarray= arrayOf<String>()
                var idsArray = arrayOf<String>()
                var nameArray = arrayOf<String>()
                var nameArray1 = arrayOf<String>()
                var nm = arrayOf<String>()
                var mob = arrayOf<String>()
                var icohighArray = arrayOf<String>()
                var icohighnmArray = arrayOf<String>()




                var citysupplier = arrayOf<String>()
                var sunbnmArray = arrayOf<String>()
                var dissupArray = arrayOf<String>()
                var primgArray = arrayOf<String>()
                val dd = myDb.retrieve(des.toString())

                    while (dd.moveToNext()) {

                        idsArray = idsArray.plusElement(dd.getString(0))
                        a = idsArray
                        a=checkarray
                        var name = dd.getString(1)
                        nm = nm.plusElement(name)
                        var city = dd.getString(13)
                        var dissup = dd.getString(22)
                        citysupplier = citysupplier.plusElement(city)

                        val high = dd.getString(38)
                        val highnm = dd.getString(33)

                        icohighnmArray=icohighnmArray.plusElement(highnm)
                        icohighArray=icohighArray.plusElement(high)


                        var mobile = dd.getString(6)
                        mob = mob.plusElement(mobile)
                        nameArray = nameArray.plusElement(name)
                        if(city.isNotEmpty()) {
                            nameArray1 = nameArray1.plusElement(city + " " + mobile)
                        }
                        else if(city.isEmpty()){
                            nameArray1 = nameArray1.plusElement(mobile)
                        }
                        sunbnmArray = sunbnmArray.plusElement(mobile)
                        dissupArray = dissupArray.plusElement(dissup)

                        a = idsArray
                        try {
                            val ur = dd.getString(28) //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                            if (ur.isNotEmpty()) {

                                primgArray = primgArray.plusElement(ur)
                            } else {
                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                            }
                        } catch (e: Exception) {

                        }


                    }


                   supp_list_ven.visibility = View.VISIBLE
                    noresfo.visibility=View.GONE
                    progress.visibility = View.GONE


                if(nm.isEmpty()){
                    noresfo.visibility=View.VISIBLE
                    supp_list_ven.visibility = View.GONE

                    progress.visibility = View.GONE

                }

                    val whatever = supp_first_list_adap(this@SupplierListFirstMAin, idsArray, dissupArray, nameArray, nameArray1, sunbnmArray, primgArray,icohighnmArray,icohighArray)
                    val supplist = findViewById<View>(R.id.supp_list_ven) as ListView
                    supplist.adapter = whatever
                    whatever.notifyDataSetChanged()
                    supplist.getItemIdAtPosition(0)


                    supplist.setOnItemClickListener { parent, view, position, d ->
                        println("dfhidd  " + a)
                        val b = Intent(applicationContext, SupplierAddMain::class.java)
                        b.putExtra("supppro", "fromsuplist")
                        b.putExtra("id", a[position])
                        b.putExtra("addsupp", addsupp)
                        b.putExtra("editsupp", editsupp)
                        b.putExtra("deletesupp", deletesupp)
                        b.putExtra("viewsupp", viewsupp)
                        b.putExtra("importsupp", importsupp)
                        b.putExtra("exportsupp", exportsupp)


                        startActivity(b)
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                        finish()
                    }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if(editText.text.toString().isEmpty())
                {

                    supp_list_ven.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    progress.visibility=View.GONE
                }
            }
        })


    }

    //Get data from firestore and save to sqllite

    fun AddData() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("suppliers")
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "cleared")
                        if (task.result.isEmpty == false) {
                            textView2.visibility=View.VISIBLE
                            imageView10.visibility=View.GONE
                            pDialog.dismiss()
                            for (document in task.result) {
                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data
                                val id = document.id;//0
                                val spnm = dd["spnm"].toString();//1
                                val spid = dd["spid"].toString();//2
                                val spmobcat1 = dd["spmobcat1"].toString();//3
                                val spmobcat2 = dd["spmobcat2"].toString();//4
                                val spmobcat3 = dd["spmobcat3"].toString();//5
                                val spmob1 = dd["spmob1"].toString();//6
                                val spmob2 = dd["spmob2"].toString();//7
                                val spmob3 = dd["spmob3"].toString();//8
                                val spmob4 = dd["spmob4"].toString();//9
                                val spaddress1 = dd["spaddress1"].toString();//10
                                val spaddress2 = dd["spaddress2"].toString();//11
                                val spaddress3 = dd["spaddress3"].toString();//12
                                val spcity = dd["spcity"].toString();//13
                                val spstate = dd["spstate"].toString();//14
                                val sppincode = dd["sppincode"].toString();//15
                                val sppgpsco_or = dd["sppgpsco_or"].toString();//16
                                val spemail = dd["spemail"].toString();//17
                                val spcontact_person = dd["spcontact_person"].toString();//18
                                val spgst = dd["spgst"].toString();//19
                                val spimglink = dd["spimglink"].toString();//20
                                val prodkey = dd["prodkey"].toString();//21spnm
                                val status = dd["status"].toString();//22
                                val img1n = dd["img1n"].toString();//23
                                val img2n = dd["img2n"].toString();//24
                                val img3n = dd["img3n"].toString();//25
                                val img4n = dd["img4n"].toString();//26
                                val img5n = dd["img5n"].toString();//27
                                val img1url = dd["img1url"].toString();//28
                                val img2url = dd["img2url"].toString();//29
                                val img3url = dd["img3url"].toString();//30
                                val img4url = dd["img4url"].toString();//31
                                val img5url = dd["img5url"].toString();//32
                                val img1nhigh = dd["img1nhigh"].toString();//23
                                val img2nhigh = dd["img2nhigh"].toString();//24
                                val img3nhigh = dd["img3nhigh"].toString();//25
                                val img4nhigh = dd["img4nhigh"].toString();//26
                                val img5nhigh = dd["img5nhigh"].toString();//27
                                val img1urlhigh = dd["img1urlhigh"].toString();//28
                                val img2urlhigh = dd["img2urlhigh"].toString();//29
                                val img3urlhigh = dd["img3urlhigh"].toString();//30
                                val img4urlhigh = dd["img4urlhigh"].toString();//31
                                val img5urlhigh = dd["img5urlhigh"].toString();//32high

                                try {
                                    spmobcat4 = dd["spmobcat4"].toString();//5
                                }
                                catch (e:Exception){

                                }
                                /*      val img1n = dd["img1n"].toString();//28
                                      val img2n = dd["img2n"].toString();//29
                                      val img3n = dd["img3n"].toString();//30
                                      val img4n = dd["img4n"].toString();//31
                                      val img5n = dd["img5n"].toString();//32
                                      val img1url = dd["img1url"].toString();//33
                                      val img2url = dd["img2url"].toString();//34
                                      val img3url = dd["img3url"].toString();//35
                                      val img4url = dd["img4url"].toString();//36
                                      val img5url = dd["img5url"].toString();//37*/
                                val isInserted = myDb.insertData(id, spnm, spid, spmobcat1, spmobcat2, spmobcat3, spmob1, spmob2, spmob3, spmob4, spaddress1, spaddress2, spaddress3, spcity, spstate, sppincode,
                                        sppgpsco_or, spemail, spcontact_person, spgst, spimglink, prodkey, status,img1n, img2n, img3n, img4n, img5n, img1url,
                                        img2url, img3url, img4url, img5url,img1nhigh,img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                        img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,spmobcat4)
                                if (isInserted == true)
                                {

                                }
                                else{

                                }

                            }
                            return@addOnCompleteListener
                        } else {
                            imageView10.visibility=View.VISIBLE
                            textView2.visibility=View.GONE
                            pDialog.dismiss()
                            return@addOnCompleteListener
                        }
                    } else {
                        Log.w(TAG, "Error getting documents.", task.exception)
                        return@addOnCompleteListener
                    }
                }
                .addOnSuccessListener {
                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var nameArray1 = arrayOf<String>()
                    var nm = arrayOf<String>()
                    var mob = arrayOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    var citysupplier = arrayOf<String>()
                    var sunbnmArray = arrayOf<String>()
                    var dissupArray = arrayOf<String>()
                    var primgArray = arrayOf<String>()
                    val dd = myDb.getAllData()
                    while (dd.moveToNext()) {
                        idsArray = idsArray.plusElement(dd.getString(0))
                        a = idsArray


                        var name = dd.getString(1)
                        nm = nm.plusElement(name)
                        var city = dd.getString(13)
                        var dissup = dd.getString(22)
                        citysupplier = citysupplier.plusElement(city)
                        val high = dd.getString(38)
                        val highnm = dd.getString(33)

                        icohighnmArray=icohighnmArray.plusElement(highnm)
                        icohighArray=icohighArray.plusElement(high)

                        var mobile = dd.getString(6)
                        mob = mob.plusElement(mobile)
                        nameArray = nameArray.plusElement(name)
                        if(city.isNotEmpty()) {
                            nameArray1 = nameArray1.plusElement(city + " " + mobile)
                        }
                        else if(city.isEmpty()){
                            nameArray1 = nameArray1.plusElement(mobile)
                        }
                        sunbnmArray = sunbnmArray.plusElement(mobile)
                        dissupArray = dissupArray.plusElement(dissup)

                        a = idsArray
                        try {
                            val ur = dd.getString(28) //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                            if (ur.isNotEmpty()) {

                                primgArray = primgArray.plusElement(ur)
                            } else {
                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                            }
                        } catch (e: Exception) {

                        }
                        pDialog.dismiss()
                        val whatever = supp_first_list_adap(this@SupplierListFirstMAin, idsArray, dissupArray, nameArray, nameArray1, sunbnmArray, primgArray,icohighnmArray,icohighArray)
                        val supplist = findViewById<View>(R.id.supp_list_ven) as ListView
                        supplist.adapter = whatever

                        for(i in 0 until sunbnmArray.count()){


                            textView2.setText((i+1).toString()+" vendors")

                        }

                        whatever.notifyDataSetChanged()
                        supplist.getItemIdAtPosition(0)



                      /*  supplist.setOnItemClickListener { parent, view, position, d ->
                            println("dfhidd  " + a)
                            val b = Intent(applicationContext, SupplierAddMain::class.java)
                            b.putExtra("supppro", "fromsuplist")
                            b.putExtra("id", a[position])
                            b.putExtra("addsupp",addsupp)
                            b.putExtra("editsupp",editsupp)
                            b.putExtra("deletesupp",deletesupp)
                            b.putExtra("viewsupp",viewsupp)
                            b.putExtra("importsupp",importsupp)
                            b.putExtra("exportsupp",exportsupp)
                            startActivity(b)
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                        }*/


                        //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                        /* if (ur.isNotEmpty()) {

                         icoArray = icoArray.plusElement(ur)
                     }else{
                         icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                     }*/
                    }
                    /* val whatever = supp_first_list_adap(this@SupplierListFirstMAin,idsArray, dissupArray, nameArray, nameArray1, sunbnmArray, primgArray)
         val supplist = findViewById<View>(R.id.supp_list_ven) as ListView
         supplist.adapter = whatever
         whatever.notifyDataSetChanged()
         supplist.getItemIdAtPosition(0)


         supplist.setOnItemClickListener { parent, view, position, d ->
             println("dfhidd  "+a)
             val b = Intent(applicationContext, SupplierAddMain::class.java)
             b.putExtra("id", a[position])
             startActivity(b)



         }*/


                }
        /*imageButtonvert.setOnClickListener({


            val popup = PopupMenu(this@SupplierListFirstMAin, imageButtonvert)

            popup.menuInflater.inflate(R.menu.menu_suppliers, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@SupplierListFirstMAin, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()
                true
            }

            popup.show()

        })*/
    }
    private fun onStarClicked1() {
        data class Count(var number: Int)


    }



    ///get the csv file from storage to import suppliers.

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
try {
    if (requestCode == REQUESTCODE_PICK_VIDEO && resultCode == Activity.RESULT_OK) {
        val spid = ArrayList<String>()//
        val spnm = ArrayList<String>()
        val spmobcat1=ArrayList<String>()
        val spmobcat2=ArrayList<String>()
        val spmobcat3=ArrayList<String>()
        val spmobcat4=ArrayList<String>()
        val spmob1 = ArrayList<String>()
        val spmob2 = ArrayList<String>()
        val spmob3=ArrayList<String>()
        val spmob4=ArrayList<String>()
        val spstate = ArrayList<String>()
        val sppincode = ArrayList<String>()
        val sppgpsco_or=ArrayList<String>()
        val spcity = ArrayList<String>()
        val spaddress1 = ArrayList<String>()
        val spaddress2 = ArrayList<String>()
        val spaddress3 = ArrayList<String>()
        val spcontact_person = ArrayList<String>()
        val spemail = ArrayList<String>()
        val spgst = ArrayList<String>()

        val spimglink=ArrayList<String>()
        val prodkey = ArrayList<String>()
        val status = ArrayList<String>()
        val img1n=ArrayList<String>()
        val img2n=ArrayList<String>()
        val img3n=ArrayList<String>()
        val img4n=ArrayList<String>()
        val img5n=ArrayList<String>()
        val img1url=ArrayList<String>()
        val img2url=ArrayList<String>()
        val img3url=ArrayList<String>()
        val img4url=ArrayList<String>()
        val img5url=ArrayList<String>()
        val img1nhigh=ArrayList<String>()
        val img2nhigh=ArrayList<String>()
        val img3nhigh=ArrayList<String>()
        val img4nhigh=ArrayList<String>()
        val img5nhigh=ArrayList<String>()
        val img1urlhigh=ArrayList<String>()
        val img2urlhigh=ArrayList<String>()
        val img3urlhigh=ArrayList<String>()
        val img4urlhigh=ArrayList<String>()
        val img5urlhigh=ArrayList<String>()


        data class s(var spid: String, var spnm: String,var spmobcat1:String,var spmobcat2:String, var spmobcat3:String,
                     var spmobcat4:String, var spmob1: String, var spmob2: String, var spmob3:String,var spmob4:String,
                     var spstate: String, var sppincode: String,var sppgpsco_or:String, var spcity: String, var spaddress1:String,
                     var spaddress2: String,var spaddress3: String, var spcontact_person: String, var spemail: String, var spgst: String,
                     var spimglink:String, var prodkey: String, var status: String,var img1n:String,
                     var img2n:String, var img3n:String, var img4n:String, var img5n:String,var img1url:String, var img2url:String,
                     var img3url:String, var img4url:String,var img5url:String,var img1nhigh:String,var img2nhigh:String,var img3nhigh:String,
                     var img4nhigh:String,var img5nhigh:String,var img1urlhigh:String, var img2urlhigh:String, var img3urlhigh:String,
                     var img4urlhigh:String, var img5urlhigh:String)
























        if (data!!.data != null) {



            val pDialog = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Importing...")
            pDialog.setCancelable(false);
            pDialog.show();

            val fileUri = data.data
            Log.d("", "file URI= " + fileUri!! + "  " + fileUri.encodedPath + " " + data.data.lastPathSegment)
            val last = data.data.lastPathSegment
            val ed = last.replace("primary:", File.separator)
            val p = File(Environment.getExternalStorageDirectory()
                    .getAbsolutePath() + File.separator + ed.toString());
            val csvFile = p//Environment.getExternalStorageDirectory().absolutePath+File.separator+"servicelist.xlsx"
            println("csvFile  " + csvFile)
            var br: BufferedReader? = null
            val cvsSplitBy = ","


            try {
                br = BufferedReader(FileReader(csvFile))
                val li = br!!.readLine()
                println("line 0  " + li.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                while (br!!.readLine() != null) {
                    val line = br.readLine()
                    /*println("line 1  " + line.split(cvsSplitBy.toRegex()))//line 1  ["key", "service name", "category", "price"]
                            println("line 2  " + line.split(cvsSplitBy.toRegex()).drop(2))//line 2  ["price"]*/
                    //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })//line 3  ["key", "service name", "category", "price"]
                    //println("line 4  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray())//line 4  [Ljava.lang.String;@b731c54

                    try {

                        val pos = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                        //println("line 4  " + pos)
                        spid.add(pos[0])
                        val a = spid[0]
                        spnm.add(pos[1])
                        spmobcat1.add(pos[2])
                        spmobcat2.add(pos[3])
                        spmobcat3.add(pos[4])
                        spmobcat4.add(pos[5])
                        spmob1.add(pos[6])
                        spmob2.add(pos[7])
                        spmob3.add(pos[8])
                        spmob4.add(pos[9])


                        spstate.add(pos[10])
                        sppincode.add(pos[11])
                        sppgpsco_or.add(pos[12])
                        spcity.add(pos[13])
                        spaddress1.add(pos[14])
                        spaddress2.add(pos[15])
                        spaddress3.add(pos[16])
                        spcontact_person.add(pos[17])
                        spemail.add(pos[18])
                        spgst.add(pos[19])
                        spimglink.add(pos[20])
                        prodkey.add(pos[21])
                        status.add(pos[22])
                        img1n.add(pos[23])
                        img2n.add(pos[24])
                        img3n.add(pos[25])
                        img4n.add(pos[26])
                        img5n.add(pos[27])
                        img1url.add(pos[28])
                        img2url.add(pos[29])
                        img3url.add(pos[30])
                        img4url.add(pos[31])
                        img5url.add(pos[32])
                        img1nhigh.add(pos[33])
                        img2nhigh.add(pos[34])
                        img3nhigh.add(pos[35])
                        img4nhigh.add(pos[36])
                        img5nhigh.add(pos[37])
                        img1urlhigh.add(pos[38])
                        img2urlhigh.add(pos[39])
                        img3urlhigh.add(pos[40])
                        img4urlhigh.add(pos[41])
                        img5urlhigh.add(pos[42])


                        val database = FirebaseDatabase.getInstance()
                        val myRef = database.getReference("supplier_counter")
                        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                var p = mutableData.value


                                if (p == null) {
                                    p = 1
                                }

                                if (p == 0) {
                                    // Unstar the post and remove self from stars
                                    p = 1

                                } else {
                                    // Star the post and add self to stars
                                    p = Integer.parseInt(p.toString()) + 1
                                }

                                // Set value and report transaction success
                                mutableData.value = p
                                //mutableData.setValue(p.number)
                                return com.google.firebase.database.Transaction.success(mutableData)
                            }

                            override fun onComplete(
                                    databaseError: DatabaseError?,
                                    b: Boolean,
                                    dataSnapshot: DataSnapshot
                            ) {

                                println(dataSnapshot)
                                println(dataSnapshot.value)
                                val id = dataSnapshot.value

                                var k=pos[1].toString()
                                var kcaps=k
                                val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)

                                val datum = s(spid = id.toString(), spnm = upperString,spmobcat1=pos[2],spmobcat2=pos[3],spmobcat3=pos[4],
                                        spmobcat4=pos[5],spmob1 = pos[6], spmob2 = pos[7],spmob3 = pos[8],spmob4 = pos[9], spstate = pos[10], sppincode = pos[11],
                                        sppgpsco_or=pos[12],spcity = pos[13], spaddress1 = pos[14], spaddress2 = pos[15], spaddress3 = pos[16],
                                        spcontact_person = pos[17], spemail = pos[18], spgst = pos[19],spimglink=pos[20],prodkey = pos[21],status = pos[22],
                                        img1n=pos[23],img2n=pos[24],img3n=pos[25],img4n=pos[26],img5n=pos[27],img1url=pos[28],img2url=pos[29],img3url=pos[30],
                                        img4url=pos[31],img5url=pos[32],img1nhigh=pos[33],img2nhigh=pos[34], img3nhigh=pos[35],img4nhigh=pos[36],img5nhigh=pos[37],
                                        img1urlhigh=pos[38],img2urlhigh=pos[39],img3urlhigh=pos[40],img4urlhigh=pos[41],img5urlhigh=pos[42])















                                println(datum)

                                db.collection("suppliers")
                                        .add(datum)
                                        .addOnSuccessListener {
                                            get()
                                        }

                                // Transaction completed
                                // Log.d("", "postTransaction:onComplete:" + databaseError)
                            }
                        })








                    } catch (e: Exception) {

                    }
                }

            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } finally {
                if (br != null) {
                    try {
                        br!!.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }

                }
            }


/*
                        var linenumber = 0;

                        while (br.readLine() != null) {
                            linenumber++;
                            ff.add(linenumber.toString())
                            println("TOTAL COUNT:"+ff)
                            val line = br!!.readLine()
                            println("LINEEE"+line)

                            val pos = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                            poss=pos


                            spid.add(poss[0])
                            val a=spid[0]
                            spnm.add(poss[1])
                            spmob1.add(poss[2])
                            spmob2.add(poss[3])
                            spstate.add(poss[4])
                            sppincode.add(poss[5])
                            spcity.add(poss[6])
                            spaddress1.add(poss[7])
                            spaddress2.add(poss[8])
                            spaddress3.add(poss[9])
                            spcontact_person.add(poss[10])
                            spemail.add(poss[11])
                            spgst.add(poss[12])
                            spgpscoordinates.add(poss[13])
                            prodkey.add(poss[14])
                            status.add(poss[15])


                            val datum = s(spid = poss[0], spnm = poss[1], spmob1 = poss[2], spmob2 = poss[3], spstate = poss[4], sppincode = poss[5],
                                    spcity = poss[6], spaddress1 = poss[7], spaddress2 = poss[8], spaddress3 = poss[9],
                                    spcontact_person = poss[10], spemail = poss[11], spgst = poss[12], spgpscoordinates = poss[13], prodkey = poss[14],
                                    status = poss[15])
                            println(datum)
                            db.collection("suppliers")
                                    .add(datum)
                                    .addOnSuccessListener {refid ->
                                        var doc=refid.id
                                        importstring.add(doc)


                                    }*/


/*for(i in 0 until ff.size){

}*/


            /*try {

                        val li = br!!.readLine()
                        println("line 0  " + li.split(cvsSplitBy.toRegex()).dropLastWhile {it.isEmpty()})
                        while (br!!.readLine() != null) {
                            val line = br!!.readLine()
                            println("LINE"+line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                            *//*println("line 1  " + line.split(cvsSplitBy.toRegex()))//line 1  ["key", "service name", "category", "price"]
                        println("line 2  " + line.split(cvsSplitBy.toRegex()).drop(2))//line 2  ["price"]*//*
                            //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })//line 3  ["key", "service name", "category", "price"]
                            //println("line 4  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray())//line 4  [Ljava.lang.String;@b731c54


                            try {
                                val pos = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }

                                //println("line 4  " + pos)
                                spid.add(pos[0])
                                val a=spid[0]
                                spnm.add(pos[1])
                                spmob1.add(pos[2])
                                spmob2.add(pos[3])
                                spstate.add(pos[4])
                                sppincode.add(pos[5])
                                spcity.add(pos[6])
                                spaddress1.add(pos[7])
                                spaddress2.add(pos[8])
                                spaddress3.add(pos[9])
                                spcontact_person.add(pos[10])
                                spemail.add(pos[11])
                                spgst.add(pos[12])
                                spgpscoordinates.add(pos[13])
                                prodkey.add(pos[14])
                                status.add(pos[15])


                                val datum = s(spid = pos[0], spnm = pos[1], spmob1 = pos[2], spmob2 = pos[3], spstate = pos[4], sppincode = pos[5],
                                        spcity = pos[6], spaddress1 = pos[7], spaddress2 = pos[8], spaddress3 = pos[9],
                                        spcontact_person = pos[10], spemail = pos[11], spgst = pos[12], spgpscoordinates = pos[13], prodkey = pos[14],
                                        status = pos[15])
                                println(datum)
                                db.collection("suppliers")
                                        .add(datum)
                                        .addOnSuccessListener {refid ->
                                            var doc=refid.id
                                            importstring.add(doc)


                                        }

                            } catch (e: Exception) {


                                Toast.makeText(applicationContext,"ODD NUMBER CSV",Toast.LENGTH_SHORT).show()

                                val reader = BufferedReader(FileReader(csvFile))
                                reader.readLine()
                                val lin = reader.readLine()
                                while (reader!!.readLine() != null) {
                                    val line = reader.readLine()
                                    if (line != null) {
                                        val po = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                                        //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                                        spid.add(po[0])

                                         val a=spid[0]
                                        spnm.add(po[1])
                                        spmob1.add(po[2])
                                        spmob2.add(po[3])
                                        spstate.add(po[4])
                                        sppincode.add(po[5])
                                        spcity.add(po[6])
                                        spaddress1.add(po[7])
                                        spaddress2.add(po[8])
                                        spaddress3.add(po[9])
                                        spcontact_person.add(po[10])
                                        spemail.add(po[11])
                                        spgst.add(po[12])
                                        spgpscoordinates.add(po[13])
                                        //println("reader   " + line)
                                        //println("snm   " + snm)
                                        val datum = s(spid = po[0], spnm = po[1], spmob1 = po[2], spmob2 = po[3], spstate = po[4],
                                                sppincode = po[5], spcity = po[6], spaddress1 = po[7], spaddress2 = po[8], spaddress3 = po[9],
                                                spcontact_person = po[10], spemail = po[11], spgst = po[12], spgpscoordinates = po[13],
                                                prodkey = po[14], status = po[15])
                                        println(datum)
                                        db.collection("suppliers")
                                                .add(datum)
                                                .addOnSuccessListener {refid ->
                                                    var doc=refid.id
                                                    importstring.add(doc)


                                                }
                                    }
                                }


                            }




                        }


                    } catch (e:Exception) {



                    } catch (e: Exception) {

                    } finally {
                        if (br != null) {
                            try {
                                br!!.close()
                            } catch (e:Exception) {

                                println("FINALLY CATCh")

                            }

                        }*/
            /*                      val reader = BufferedReader(FileReader(csvFile))
                                reader.readLine()
                                val lin = reader.readLine()
                        while (reader!!.readLine() != null) {

                            if (lin != null) {
                                val line = reader.readLine()
                                println("vaeliye  " + line)
                                val po = lin.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                                val datum = s(spid = po[0], spnm = po[1], spmob1 = po[2], spmob2 = po[3],spstate = po[4], sppincode = po[5],
                                        spcity = po[6],spaddress1 = po[7], spaddress2 = po[8], spaddress3 = po[9], spcontact_person = po[10],spemail = po[11],spgst = po[12],
                                        spgpscoordinates = po[13],prodkey = po[14],
                                        status = po[15])


                                val llf = spid[0]
                                println(datum)
                                db.collection("suppliers")
                                        .add(datum)
                                        .addOnSuccessListener { refid ->
                                            var doc = refid.id
                                            importstring.add(doc)

                                        }
                            }
                        }*/

            /*val reader = BufferedReader (FileReader(csvFile))
                        reader.readLine()
                        val lin = reader.readLine()
                        while (reader!!.readLine() != null) {
                            val line = reader.readLine()
                            if (line != null) {
                                val po = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                                //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                                spid.add(po[0])
                                val llf=spid[0]
                                spnm.add(po[1])
                                spmob1.add(po[2])
                                spmob2.add(po[3])
                                spstate.add(po[4])
                                sppincode.add(po[5])
                                spcity.add(po[6])
                                spaddress1.add(po[7])
                                spaddress2.add(po[8])
                                spaddress3.add(po[9])
                                spcontact_person.add(po[10])
                                spemail.add(po[11])
                                spgst.add(po[12])
                                spgpscoordinates.add(po[13])
                                //println("reader   " + line)
                                //println("snm   " + snm)
                                val datum = s(spid = po[0], spnm = po[1], spmob1 = po[2], spmob2 = po[3], spstate = po[4],
                                        sppincode = po[5], spcity = po[6], spaddress1 = po[7], spaddress2 = po[8], spaddress3 = po[9],
                                        spcontact_person = po[10],spemail = po[11], spgst = po[12], spgpscoordinates = po[13], prodkey = po[14],
                                        status = po[15])
                                println(datum)
                                db.collection("suppliers")
                                        .add(datum)
                                        .addOnSuccessListener {refid ->
                                            var doc=refid.id
                                            importstring.add(doc)


                                        }
                            }
                        }
                        println("vaeliye  " + lin)
                        val po = lin.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                        val datum = s(spid = po[0], spnm = po[1], spmob1 = po[2], spmob2 = po[3], spstate = po[4], sppincode = po[5],
                                spcity = po[6], spaddress1 = po[7], spaddress2 = po[8], spaddress3 = po[9], spcontact_person = po[10], spemail = po[11], spgst = po[12],
                                spgpscoordinates = po[13], prodkey = po[14],
                                status = po[15])


                        val llf=spid[0]
                        println(datum)
                        db.collection("suppliers")
                                .add(datum)
                                .addOnSuccessListener {refid ->
                                    var doc=refid.id
                                    importstring.add(doc)



                                }*/


            val reader = BufferedReader(FileReader(csvFile))
            reader.readLine()
            val lin = reader.readLine()
            while (reader!!.readLine() != null) {
                val line = reader.readLine()
                if (line != null) {
                    val po = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                    //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })

                    //println("line 4  " + pos)
                    spid.add(po[0])
                    val a = spid[0]
                    spnm.add(po[1])
                    spmobcat1.add(po[2])
                    spmobcat2.add(po[3])
                    spmobcat3.add(po[4])
                    spmobcat4.add(po[5])
                    spmob1.add(po[6])
                    spmob2.add(po[7])
                    spmob3.add(po[8])
                    spmob4.add(po[9])


                    spstate.add(po[10])
                    sppincode.add(po[11])
                    sppgpsco_or.add(po[12])
                    spcity.add(po[13])
                    spaddress1.add(po[14])
                    spaddress2.add(po[15])
                    spaddress3.add(po[16])
                    spcontact_person.add(po[17])
                    spemail.add(po[18])
                    spgst.add(po[19])
                    spimglink.add(po[20])
                    prodkey.add(po[21])
                    status.add(po[22])
                    img1n.add(po[23])
                    img2n.add(po[24])
                    img3n.add(po[25])
                    img4n.add(po[26])
                    img5n.add(po[27])
                    img1url.add(po[28])
                    img2url.add(po[29])
                    img3url.add(po[30])
                    img4url.add(po[31])
                    img5url.add(po[32])
                    img1nhigh.add(po[33])
                    img2nhigh.add(po[34])
                    img3nhigh.add(po[35])
                    img4nhigh.add(po[36])
                    img5nhigh.add(po[37])
                    img1urlhigh.add(po[38])
                    img2urlhigh.add(po[39])
                    img3urlhigh.add(po[40])
                    img4urlhigh.add(po[41])
                    img5urlhigh.add(po[42])

                    val database = FirebaseDatabase.getInstance()
                    val myRef = database.getReference("supplier_counter")
                    myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                        override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                            var p = mutableData.value


                            if (p == null) {
                                p = 1
                            }

                            if (p == 0) {
                                // Unstar the post and remove self from stars
                                p = 1

                            } else {
                                // Star the post and add self to stars
                                p = Integer.parseInt(p.toString()) + 1
                            }

                            // Set value and report transaction success
                            mutableData.value = p
                            //mutableData.setValue(p.number)
                            return com.google.firebase.database.Transaction.success(mutableData)
                        }

                        override fun onComplete(
                                databaseError: DatabaseError?,
                                b: Boolean,
                                dataSnapshot: DataSnapshot
                        ) {

                            println(dataSnapshot)
                            println(dataSnapshot.value)
                            val id = dataSnapshot.value

                            var k=po[1].toString()
                            var kcaps=k
                            val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)

                            val datum = s(spid = id.toString(), spnm = upperString,spmobcat1=po[2],spmobcat2=po[3],spmobcat3=po[4],
                                    spmobcat4=po[5],spmob1 = po[6], spmob2 = po[7],spmob3 = po[8],spmob4 = po[9], spstate = po[10], sppincode = po[11],
                                    sppgpsco_or=po[12],spcity = po[13], spaddress1 = po[14], spaddress2 = po[15], spaddress3 = po[16],
                                    spcontact_person = po[17], spemail = po[18], spgst = po[19],spimglink=po[20],prodkey = po[21],status = po[22],
                                    img1n=po[23],img2n=po[24],img3n=po[25],img4n=po[26],img5n=po[27],img1url=po[28],img2url=po[29],img3url=po[30],
                                    img4url=po[31],img5url=po[32],img1nhigh=po[33],img2nhigh=po[34], img3nhigh=po[35],img4nhigh=po[36],img5nhigh=po[37],
                                    img1urlhigh=po[38],img2urlhigh=po[39],img3urlhigh=po[40],img4urlhigh=po[41],img5urlhigh=po[42])
                            println(datum)
                            db.collection("suppliers")
                                    .add(datum)
                                    .addOnSuccessListener { refid ->
                                        var doc = refid.id
                                        importstring.add(doc)
                                        get()
                                    }

                            // Transaction completed
                            // Log.d("", "postTransaction:onComplete:" + databaseError)
                        }
                    })

                    println("IDS ARRAYS"+Arrays.toString(spids))


                }
            }
            println("vaeliye  " + lin)
            val po = lin.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
       /*     val datum = s(spid = id.toString(), spnm = upperString,spmobcat1=po[2],spmobcat2=po[3],spmobcat3=po[4],
                    spmobcat4=po[5],spmob1 = po[6], spmob2 = po[7],spmob3 = po[8],spmob4 = po[9], spstate = po[10], sppincode = po[11],
                    sppgpsco_or=po[12],spcity = po[13], spaddress1 = po[14], spaddress2 = po[15], spaddress3 = po[16],
                    spcontact_person = po[17], spemail = po[18], spgst = po[19],spimglink=po[20],prodkey = po[21],status = po[22],
                    img1n=po[23],img2n=po[24],img3n=po[25],img4n=po[26],img5n=po[27],img1url=po[28],img2url=po[29],img3url=po[30],
                    img4url=po[31],img5url=po[32],img1nhigh=po[33],img2nhigh=po[34], img3nhigh=po[35],img4nhigh=po[36],img5nhigh=po[37],
                    img1urlhigh=po[38],img2urlhigh=po[39],img3urlhigh=po[40],img4urlhigh=po[41],img5urlhigh=po[42])*/


            println("IDS ARRAYS"+Arrays.toString(spids))
            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("supplier_counter")
            myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                    var p = mutableData.value


                    if (p == null) {
                        p = 1
                    }

                    if (p == 0) {
                        // Unstar the post and remove self from stars
                        p = 1

                    } else {
                        // Star the post and add self to stars
                        p = Integer.parseInt(p.toString()) + 1
                    }

                    // Set value and report transaction success
                    mutableData.value = p
                    //mutableData.setValue(p.number)
                    return com.google.firebase.database.Transaction.success(mutableData)
                }

                override fun onComplete(
                        databaseError: DatabaseError?,
                        b: Boolean,
                        dataSnapshot: DataSnapshot
                ) {

                    println(dataSnapshot)
                    println(dataSnapshot.value)
                    val id = dataSnapshot.value
                    var k=po[1].toString()
                    var kcaps=k
                    val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)
                    val datum = s(spid = id.toString(), spnm = upperString,spmobcat1=po[2],spmobcat2=po[3],spmobcat3=po[4],
                            spmobcat4=po[5],spmob1 = po[6], spmob2 = po[7],spmob3 = po[8],spmob4 = po[9], spstate = po[10], sppincode = po[11],
                            sppgpsco_or=po[12],spcity = po[13], spaddress1 = po[14], spaddress2 = po[15], spaddress3 = po[16],
                            spcontact_person = po[17], spemail = po[18], spgst = po[19],spimglink=po[20],prodkey = po[21],status = po[22],
                            img1n=po[23],img2n=po[24],img3n=po[25],img4n=po[26],img5n=po[27],img1url=po[28],img2url=po[29],img3url=po[30],
                            img4url=po[31],img5url=po[32],img1nhigh=po[33],img2nhigh=po[34], img3nhigh=po[35],img4nhigh=po[36],img5nhigh=po[37],
                            img1urlhigh=po[38],img2urlhigh=po[39],img3urlhigh=po[40],img4urlhigh=po[41],img5urlhigh=po[42])
                    println(datum)
                    db.collection("suppliers")
                            .add(datum)
                            .addOnSuccessListener { refid ->
                                var doc = refid.id
                                importstring.add(doc)
                                get()
                            }

                    // Transaction completed
                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                }
            })


              val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                    pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                    Toast.makeText(this, "Imported successfully", Toast.LENGTH_LONG).show()
                    pDialog1.titleText = "Imported!"

                    pDialog1.setConfirmText("OK")
                    pDialog1.show()
                    pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                    pDialog1.setConfirmClickListener {
                        pDialog1.hide()
                        pDialog.dismiss()
                    }
        }
    }
}
catch (e:Exception){
    Toast.makeText(applicationContext,"Invalid file",Toast.LENGTH_LONG).show()

}
    }








    /////////////--------------------------Get supplier details and list out from local sql db-----------------------------//
    fun get() {



                            var idsArray = arrayOf<String>()
                            var nameArray = arrayOf<String>()
                            var nameArray1 = arrayOf<String>()
                            var spidArray=arrayOf<String>()
                            var nm = arrayOf<String>()
                            var mob = arrayOf<String>()
                            var citysupplier = arrayOf<String>()
                            var sunbnmArray = arrayOf<String>()
                            var dissupArray = arrayOf<String>()
                            var primgArray = arrayOf<String>()
                            var icohighArray = arrayOf<String>()
                            var icohighnmArray = arrayOf<String>()

                            val dd = myDb.getAllData()

                            while (dd.moveToNext()) {
                                imageView10.visibility=View.GONE
                                idsArray = idsArray.plusElement(dd.getString(0))
                                a = idsArray
                                var name = dd.getString(1)
                                nm = nm.plusElement(name)
                                var spidd=dd.getString(2)
                                spidArray=spidArray.plusElement(spidd)
                                var city = dd.getString(13)
                                var dissup = dd.getString(22)
                                citysupplier = citysupplier.plusElement(city)

                                val high = dd.getString(38)
                                val highnm = dd.getString(33)

                                icohighnmArray=icohighnmArray.plusElement(highnm)
                                icohighArray=icohighArray.plusElement(high)
                                var mobile = dd.getString(6)
                                mob = mob.plusElement(mobile)
                                nameArray = nameArray.plusElement(name)
                                if(city.isNotEmpty()) {
                                    nameArray1 = nameArray1.plusElement(city + " " + mobile)
                                }
                                else if(city.isEmpty()){
                                    nameArray1 = nameArray1.plusElement(mobile)
                                }
                                sunbnmArray = sunbnmArray.plusElement(mobile)
                                dissupArray = dissupArray.plusElement(dissup)

                                a = idsArray
                                try {
                                    val ur = dd.getString(28) //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                    if (ur.isNotEmpty()) {

                                        primgArray = primgArray.plusElement(ur)
                                    } else {
                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                    }
                                } catch (e: Exception) {

                                }

                                for(i in 0 until idsArray.size){

                                    var kk=spidArray[i]
                                    idoflist=idoflist.plusElement(kk)


                                }
                                //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                /* if (ur.isNotEmpty()) {

                                     icoArray = icoArray.plusElement(ur)
                                 }else{
                                     icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                 }*/
                            }

                            val whatever = supp_first_list_adap(this@SupplierListFirstMAin, idsArray, dissupArray, nameArray, nameArray1, sunbnmArray, primgArray,icohighnmArray,icohighArray)
                            val supplist = findViewById<View>(R.id.supp_list_ven) as ListView
                            supplist.adapter = whatever



                            whatever.notifyDataSetChanged()
                            supplist.getItemIdAtPosition(0)





        supp_list_ven.setOnItemClickListener { parent, view, position, d ->
            println("dfhidd  " + a)
            val b = Intent(applicationContext, SupplierAddMain::class.java)
            b.putExtra("supppro", "fromsuplist")

            b.putExtra("id", a[position])

            b.putExtra("addsupp",addsupp)
            b.putExtra("editsupp",editsupp)
            b.putExtra("deletesupp",deletesupp)
            b.putExtra("viewsupp",viewsupp)
            b.putExtra("importsupp",importsupp)
            b.putExtra("exportsupp",exportsupp)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()
        }
    }







    fun popup(st:String){  //Access Denied
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    companion object {
  //Listens inetrnet status whether net is on/off. .


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively:RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                  /// if connection is off then all views becomes disable


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                  /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

    override fun onBackPressed() {

        if(containersd.visibility == View.VISIBLE){
            containersd.visibility=View.INVISIBLE
            relative.visibility=View.GONE
            constr.setBackgroundColor(Color.parseColor("#32ffffff"))
            supp_list_ven.isClickable=true
            supp_list_ven.isEnabled=true
            d_fab.isEnabled=true
            d_fab.isClickable=true
        }
        else if(card.visibility==View.VISIBLE)
        {
            card.visibility=View.GONE
            get()
        }
        else{
        /*   val i=Intent(this@SupplierListFirstMAin,MainActivity::class.java)
            i.putExtra("addsupp",addsupp)
            i.putExtra("editsupp",editsupp)
            i.putExtra("deletesupp",deletesupp)
            i.putExtra("viewsupp",viewsupp)
            i.putExtra("importsupp",importsupp)
            i.putExtra("exportsupp",exportsupp)
            startActivity(i)*/
            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        }
    }

    fun net_status():Boolean{   // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}



    /*   fun onBackPressed() {
       val e=Intent(context,Mainpage::class.java)
        startActivity(e)

    }*/







/* imageButtonvert.setOnClickListener({


     val popup = PopupMenu(this@SupplierSecondFragment, imageButtonvert)

     popup.menuInflater.inflate(R.menu.menu, popup.menu)

     popup.setOnMenuItemClickListener { item ->
         Toast.makeText(this@SupplierSecondFragment, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()

         true

     }

     popup.show()

 })
*/
/* d_fab.setOnClickListener {
     val intent=Intent(this@SupplierSecondFragment,MainActivityScroll::class.java)
     startActivity(intent)
*/

