package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView

/**
 * Created by vinitas stock on 03-01-2018.
 */
class allbranchesAdapter(
        private val context: Activity,
        private val icoArray: Array<Int>,
        private val pronm: Array<String>,
        private val text: Array<String>,
        private val ml: Array<String>,
        private val itemnm: Array<String>,
        private val bc: Array<String>,
        private val mrp: Array<String>,
        private val qty: Array<String>) : ArrayAdapter<Any>(context, R.layout.allbranches_list, pronm) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.allbranches_list, null, true)

        //this code gets references to objects in the listview_row.xml file
        val bc1 = rowView.findViewById<TextView>(R.id.order_bc) as TextView
        val pronm1 = rowView.findViewById<TextView>(R.id.pronm) as TextView
        val ml1 = rowView.findViewById<TextView>(R.id.ml) as TextView
        val itemnm1 = rowView.findViewById<TextView>(R.id.itemname) as TextView
        val text1 = rowView.findViewById<TextView>(R.id.textView2) as TextView
        val mrp1 = rowView.findViewById<TextView>(R.id.mrp) as TextView
        val qty1 = rowView.findViewById<TextView>(R.id.qty) as TextView
        val ico1 = rowView.findViewById<CircleImageView>(R.id.proimg) as CircleImageView

        //this code sets the values of the objects to values from the arrays
        pronm1.text = pronm[position]
        itemnm1.text = itemnm[position]
        bc1.text = bc[position]
        mrp1.text = mrp[position]
        qty1.text = qty[position]
        text1.text = text[position]
        ml1.text = ml[position]
        ico1.setImageResource(icoArray[position])
        //infoTextField.text = infoArray[position]
        //imageView.setImageResource(imageIDarray[position])

        return rowView

    }
}