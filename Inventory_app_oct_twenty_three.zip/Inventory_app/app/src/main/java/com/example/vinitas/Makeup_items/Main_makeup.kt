package com.example.vinitas.Makeup_items

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.support.constraint.ConstraintLayout
import android.support.design.widget.FloatingActionButton
import android.support.v7.widget.CardView
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.widget.AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.inventory_app.*
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.*
import kotlinx.android.synthetic.main.activity_main_makeup.*



import kotlinx.android.synthetic.main.product_list_activity.*

class Main_makeup : AppCompatActivity() {
    private var view=String()
    private var add=String()
    private var delete=String()
    private var edit=String()
    private var import=String()
    private var export =String()
    val REQUESTCODE_PICK_VIDEO:Int = 0
    private val REQUEST_CODE_EXAMPLE2 = 21
    private val REQUEST_CODE_EXAMPLE1 = 23
    private val REQUEST_CODE_EXAMPLE = 2



    var insertedloc=""
    var frmscrollact=String()

    private var viewpro = String()
    private var addpro = String()
    private var deletepro = String()
    private var editpro = String()
    private var importpro = String()
    private var exportpro = String()
    private var  stockin_hand= String()

    var makeupitem=String()

    var usArrayoriempty=arrayOf<String>()
    var tyArrayoriempty=arrayOf<String>()
    var brArrayoriempty=arrayOf<String>()
    var idoriempty=arrayOf<String>()
    var makeupitemempty= arrayOf<String>()
    var statusoriempty=arrayOf<String>()
    var icoArrayoriempty=arrayOf<String>()
    var icohighArrayoriempty=arrayOf<String>()
    var icohighnmArrayoriempty=arrayOf<String>()
    var iddoriempty=arrayOf<String>()
    var cateoriempty=arrayOf<String>()


    var ret=String()
    var bkbr=String()

    var serb=""

    var stockonhand=String()

    var usArrayori=arrayOf<String>()
    var tyArrayori=arrayOf<String>()
    var brArrayori=arrayOf<String>()
    var idori=arrayOf<String>()
    var statusori=arrayOf<String>()
    var icoArrayori=arrayOf<String>()
    var icohighArrayori=arrayOf<String>()
    var icohighnmArrayori=arrayOf<String>()
    var iddori=arrayOf<String>()
    var cateori=arrayOf<String>()
    var makeupitemori=arrayOf<String>()
    private var firstTimeprod: Boolean? = null


    var brkey = String()

    var openll=String()

    var brnm=String()

    var ddstr=String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    internal lateinit var myDb: Databasehelper_service
    internal lateinit var myDb1: Databasehelper
    internal lateinit var session: SessionManagement_service
    internal lateinit var sessions: SessionManagement
    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
    var a=arrayOf<String>()
    var ids= String()

    var frstvar=""


    private fun isFirstTimeProdmakeup(): Boolean {
        if (firstTimeprod == null) {
            val mPreferences = this.getSharedPreferences("first_times", Context.MODE_PRIVATE)
            firstTimeprod = mPreferences.getBoolean("firstTimes", true)
            if (firstTimeprod!!) {
                val editor = mPreferences.edit()
                editor.putBoolean("firstTimes", false)
                editor.commit()

                frstvar="inside"


            }
        }
        return firstTimeprod!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_makeup)

        net_status()//Check net status


//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Main_makeup) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off.
       log_network = findViewById(R.id.view7)
       log_networktext = findViewById(R.id.textView36)
       relatively =findViewById(R.id.relativeslayout)
       cont =findViewById<ConstraintLayout>(R.id.containers)
        payment_tk_PGdis=findViewById(R.id.payment_tk_PG)
        cardviewdis=findViewById(R.id.card)
        makeuplistdis=findViewById(R.id.makeup_list)
        imageButtonsrchdis=findViewById(R.id.imageButtonsrch)
        userbackdis=findViewById(R.id.back)
        imageButtonvertdis=findViewById(R.id.imageButtonvert)
        dfabdis=findViewById(R.id.d_fab)


        imageButtonsrch.setOnClickListener {   //Image button search  action
            println("clicked")
            card.visibility = View.VISIBLE
            card.startAnimation(AnimationUtils.loadAnimation(this@Main_makeup, R.anim.slide_to_right))
            editText.requestFocus()
            editText.setText("")
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            makeupitemori=makeupitemempty
            statusori=statusoriempty
            icoArrayori=icoArrayoriempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty
        }
        searchback.setOnClickListener {   //Image button search back action
            card.visibility = View.GONE
            card.startAnimation(AnimationUtils.loadAnimation(this@Main_makeup, R.anim.slide_to_left))
            noresfo.visibility=View.GONE
            makeup_list.visibility = View.VISIBLE
            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            makeupitemori=makeupitemempty
            serb="in"
            statusori=statusoriempty
            icoArrayori=icoArrayoriempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty

            gets()
            getattach()

        }

        isFirstTimeProdmakeup()


        addLogText(NetworkUtil.getConnectivityStatusString(this@Main_makeup))

        myDb = Databasehelper_service(this)
        myDb1 = Databasehelper(this)

        val service_access = SessionManagement(this)
        view = service_access.userDetails[SessionManagement.sview].toString()
        add = service_access.userDetails[SessionManagement.sadd].toString()
        delete = service_access.userDetails[SessionManagement.sdelete].toString()
        edit = service_access.userDetails[SessionManagement.sedit].toString()
        import = service_access.userDetails[SessionManagement.simport].toString()
        export = service_access.userDetails[SessionManagement.s_export].toString()

        val user = service_access.userDetails

        // name
        val name = user[SessionManagement.KEY_NAME]
        val namebr = user[SessionManagement.KEY_brnm]
        brkey = name.toString()
        brnm=namebr.toString()

        myDb = Databasehelper_service(this)

        myDb.givedata(brkey)

        session = SessionManagement_service(applicationContext)
        sessions = SessionManagement(applicationContext)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        val i = intent.extras

        try {
            val p = intent.getStringExtra("skey")
            ids = p
        } catch (e: Exception) {

        }



        //CLICK FAB BUTTON TO SELECT SERVICE AND ACCESSORIES OF MAKEUP's

        d_fab.setOnClickListener {
            if (add == "true") {
                val mShowButton = AnimationUtils.loadAnimation(this, R.anim.show_button)
                val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)
                if (payment_tk_PG.visibility == View.VISIBLE) {
                    openll="close"
                    payment_tk_PG.visibility = View.GONE
                    d_fab.startAnimation(mHideButton)
                    imageButtonsrch.isEnabled=false

                    makeup_list.isEnabled=false

                } else if (payment_tk_PG.visibility == View.GONE) {
                    openll="open"

                    payment_tk_PG.visibility = View.VISIBLE
                    d_fab.startAnimation(mShowButton)
                    imageButtonsrch.isEnabled=true

                    makeup_list.isEnabled=true

                }
                onResume()
            }

            else{

                popup("add")

            }
        }







        makeup_list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {

                val btn_initPosY=d_fab.getScrollY();
                if (scrollState == SCROLL_STATE_TOUCH_SCROLL) {
                    d_fab.animate().cancel();
                    d_fab.animate().translationYBy(150F);
                } else {
                    d_fab.animate().cancel();
                    d_fab.animate().translationY(btn_initPosY.toFloat());
                }

            }

            override fun onScroll(view: AbsListView, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {

            }
        })


        back.setOnClickListener {
            onBackPressed()
        }


        //ADD MAKEUP SERVICE,HERE WHEN WE CLICK MAKEUP SERVICE IT WILL NAVIGATE TO SERVICE ADD PAGE

        selectpro4.setOnClickListener {

            payment_tk_PG.visibility = View.GONE


            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            d_fab.startAnimation(mHideButton)

            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            statusori=statusoriempty
            makeupitemori=makeupitemempty
            icoArrayori=icoArrayoriempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty

            var frmser="makeup"
            myDb = Databasehelper_service(this)
            val service_access = SessionManagement(this)
            view = service_access.userDetails[SessionManagement.sview].toString()
            add = service_access.userDetails[SessionManagement.sadd].toString()
            delete = service_access.userDetails[SessionManagement.sdelete].toString()
            edit = service_access.userDetails[SessionManagement.sedit].toString()
            import = service_access.userDetails[SessionManagement.simport].toString()
            export = service_access.userDetails[SessionManagement.s_export].toString()

            val user = service_access.userDetails



            if (add == "true") {
                val b = Intent(applicationContext,ScrollActivity::class.java)
                b.putExtra("newid", db.collection("${brkey}_service").document().id)
                b.putExtra("add",add)
                b.putExtra("edit",edit)
                b.putExtra("delete",delete)
                b.putExtra("keybr", brkey)
                b.putExtra("makeup",frmser)
                startActivityForResult(b, REQUEST_CODE_EXAMPLE2);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                d_fab.isEnabled = true
            } else {
                popup("add")
                d_fab.isEnabled = true
            }












        }



        //Navigate to Attachments_Activity

        selectpro3.setOnClickListener {

            payment_tk_PG.visibility = View.GONE


            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            d_fab.startAnimation(mHideButton)

            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            statusori=statusoriempty
            icoArrayori=icoArrayoriempty
            makeupitemori=makeupitemempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty


            val pro_access =SessionManagement(this)
            viewpro=pro_access.userDetails[SessionManagement.pview].toString()
            addpro=pro_access.userDetails[SessionManagement.padd].toString()
            deletepro=pro_access.userDetails[SessionManagement.pdelete].toString()
            editpro=pro_access.userDetails[SessionManagement.pedit].toString()
            importpro=pro_access.userDetails[SessionManagement.pimport].toString()
            exportpro=pro_access.userDetails[SessionManagement.pexport].toString()
            stockin_hand=pro_access.userDetails[SessionManagement.pstockin_hand].toString()


            var frmser="makeup"
            myDb = Databasehelper_service(this)
            val service_access = SessionManagement(this)
            view = service_access.userDetails[SessionManagement.sview].toString()
            add = service_access.userDetails[SessionManagement.sadd].toString()
            delete = service_access.userDetails[SessionManagement.sdelete].toString()
            edit = service_access.userDetails[SessionManagement.sedit].toString()
            import = service_access.userDetails[SessionManagement.simport].toString()
            export = service_access.userDetails[SessionManagement.s_export].toString()

            val user = service_access.userDetails





            var pronew=db.collection("product").document().id
            var sernew=db.collection("${brkey}_service").document(pronew).toString()
            val a = Intent(this@Main_makeup, Attachments_Activity::class.java)




            a.putExtra("from","add")
            a.putExtra("newidpro",pronew)
            a.putExtra("newidser",sernew.toString())
            a.putExtra("add",add)
                a.putExtra("edit",edit)
                a.putExtra("delete",delete)
                a.putExtra("keybr", brkey)
                a.putExtra("makeup",frmser)
            a.putExtra("addpro", addpro)
            a.putExtra("editpro", editpro)
            a.putExtra("deletepro", deletepro)
            a.putExtra("viewpro", viewpro)
            a.putExtra("importpro", importpro)
            a.putExtra("changestock", stockin_hand)
            a.putExtra("exportpro", exportpro)
            a.putExtra("keybr",name)
            a.putExtra("itemname",textView3f.text.toString())

            startActivity(a);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

            finish()








        }


        //Navigate to Attachments_Activity


        addnewpro.setOnClickListener {

            payment_tk_PG.visibility = View.GONE


            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            d_fab.startAnimation(mHideButton)

            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            statusori=statusoriempty
            icoArrayori=icoArrayoriempty
            makeupitemori=makeupitemempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty


            val pro_access =SessionManagement(this)
            viewpro=pro_access.userDetails[SessionManagement.pview].toString()
            addpro=pro_access.userDetails[SessionManagement.padd].toString()
            deletepro=pro_access.userDetails[SessionManagement.pdelete].toString()
            editpro=pro_access.userDetails[SessionManagement.pedit].toString()
            importpro=pro_access.userDetails[SessionManagement.pimport].toString()
            exportpro=pro_access.userDetails[SessionManagement.pexport].toString()
            stockin_hand=pro_access.userDetails[SessionManagement.pstockin_hand].toString()


            var frmser="makeup"
            myDb = Databasehelper_service(this)
            val service_access = SessionManagement(this)
            view = service_access.userDetails[SessionManagement.sview].toString()
            add = service_access.userDetails[SessionManagement.sadd].toString()
            delete = service_access.userDetails[SessionManagement.sdelete].toString()
            edit = service_access.userDetails[SessionManagement.sedit].toString()
            import = service_access.userDetails[SessionManagement.simport].toString()
            export = service_access.userDetails[SessionManagement.s_export].toString()

            val user = service_access.userDetails





            var pronew=db.collection("product").document().id
            var sernew=db.collection("${brkey}_service").document(pronew).toString()
            val a = Intent(this@Main_makeup, Attachments_Activity::class.java)




            a.putExtra("from","add")
            a.putExtra("newidpro",pronew)
            a.putExtra("newidser",sernew.toString())
            a.putExtra("add",add)
            a.putExtra("edit",edit)
            a.putExtra("delete",delete)
            a.putExtra("keybr", brkey)
            a.putExtra("makeup",frmser)
            a.putExtra("addpro", addpro)
            a.putExtra("editpro", editpro)
            a.putExtra("deletepro", deletepro)
            a.putExtra("viewpro", viewpro)
            a.putExtra("importpro", importpro)
            a.putExtra("changestock", stockin_hand)
            a.putExtra("exportpro", exportpro)
            a.putExtra("keybr",name)
            a.putExtra("itemname",textView3.text.toString())




            startActivity(a);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

            finish()










        }


        //Navigate to Attachments_Activity

        selectpro.setOnClickListener {

            payment_tk_PG.visibility = View.GONE


            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            d_fab.startAnimation(mHideButton)

            usArrayori=usArrayoriempty
            tyArrayori=tyArrayoriempty
            brArrayori=brArrayoriempty
            idori=idoriempty
            statusori=statusoriempty
            icoArrayori=icoArrayoriempty
            makeupitemori=makeupitemempty
            icohighArrayori=icohighArrayoriempty
            icohighnmArrayori=icohighnmArrayoriempty
            iddori=iddoriempty
            cateori=cateoriempty


            val pro_access =SessionManagement(this)
            viewpro=pro_access.userDetails[SessionManagement.pview].toString()
            addpro=pro_access.userDetails[SessionManagement.padd].toString()
            deletepro=pro_access.userDetails[SessionManagement.pdelete].toString()
            editpro=pro_access.userDetails[SessionManagement.pedit].toString()
            importpro=pro_access.userDetails[SessionManagement.pimport].toString()
            exportpro=pro_access.userDetails[SessionManagement.pexport].toString()
            stockin_hand=pro_access.userDetails[SessionManagement.pstockin_hand].toString()


            var frmser="makeup"
            myDb = Databasehelper_service(this)
            val service_access = SessionManagement(this)
            view = service_access.userDetails[SessionManagement.sview].toString()
            add = service_access.userDetails[SessionManagement.sadd].toString()
            delete = service_access.userDetails[SessionManagement.sdelete].toString()
            edit = service_access.userDetails[SessionManagement.sedit].toString()
            import = service_access.userDetails[SessionManagement.simport].toString()
            export = service_access.userDetails[SessionManagement.s_export].toString()

            val user = service_access.userDetails





            var pronew=db.collection("product").document().id
            var sernew=db.collection("${brkey}_service").document(pronew).toString()
            val a = Intent(this@Main_makeup, Attachments_Activity::class.java)




            a.putExtra("from","add")
            a.putExtra("newidpro",pronew)
            a.putExtra("newidser",sernew.toString())
            a.putExtra("add",add)
            a.putExtra("edit",edit)
            a.putExtra("delete",delete)
            a.putExtra("keybr", brkey)
            a.putExtra("makeup",frmser)
            a.putExtra("addpro", addpro)
            a.putExtra("editpro", editpro)
            a.putExtra("deletepro", deletepro)
            a.putExtra("viewpro", viewpro)
            a.putExtra("importpro", importpro)
            a.putExtra("changestock", stockin_hand)
            a.putExtra("exportpro", exportpro)
            a.putExtra("keybr",name)
            a.putExtra("itemname",textView1f.text.toString())




            startActivity(a);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

            finish()










        }


        myDb = Databasehelper_service(this)
        println("myDb.getNotesCount() : "+myDb.getNotesCount())

        //Check if sql db service not exists, below code is going to insert a service to local sql table

        db.collection("${brkey}_service")
                .addSnapshotListener(EventListener<QuerySnapshot>{task,e->
                    println("e : "+e)
                    if (e==null) {
                        println("task.docchange : "+task.documentChanges)
                        for (change in task.getDocumentChanges()) {
                            when (change.getType()) {
                                DocumentChange.Type.ADDED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type added " + groupId)
                                    println("myDb.isin(groupId).moveToNext() " + myDb.checkIfRecordExist(groupId))
                                    val d=myDb.checkIfRecordExist(groupId)
                                    if (d==false) {

                                        imageView10.visibility=View.GONE
                                        val dd = change.document
                                        val id = dd.id;//0
                                        val snm = dd["snm"].toString();//1
                                        val sid = dd["sid"].toString();//2
                                        val dur = dd["dur"].toString();//3
                                        val sac = dd["sac"].toString();//4
                                        val sacdesc = dd["sacdesc"].toString();//5
                                        val pr = dd["pr"].toString();//6
                                        val tx = dd["tx"].toString();//7
                                        val igst = dd["igst"].toString();//8
                                        val cess = dd["cess"].toString();//9
                                        val cgst = dd["cgst"].toString();//10
                                        val sgst = dd["sgst"].toString();//11
                                        val ttot = dd["ttot"].toString();//12
                                        val ctot = dd["ctot"].toString();//13
                                        val gtot = dd["gtot"].toString();//14
                                        val ecomm = dd["ecomm"].toString();//15
                                        val ebns = dd["ebns"].toString();//16
                                        val cry = dd["cry"].toString();//17
                                        val ptg = dd["ptg"].toString();//18
                                        val bval = dd["bval"].toString();//19
                                        val gdr = dd["gdr"].toString();//20
                                        val mctg = dd["mctg"].toString();//21
                                        val sctg = dd["sctg"].toString();//22
                                        val mctgky = dd["mctgkey"].toString();//21
                                        val sctgky = dd["sctgkey"].toString();//22
                                        val desc = dd["desc"].toString();//23
                                        val fp = dd["fp"].toString();//24
                                        val fpr = dd["fpr"].toString();//25
                                        val tpr = dd["tpr"].toString();//26
                                        val status = dd["status"].toString();//27
                                        val img1n = dd["img1n"].toString();//28
                                        val img2n = dd["img2n"].toString();//29
                                        val img3n = dd["img3n"].toString();//30
                                        val img4n = dd["img4n"].toString();//31
                                        val img5n = dd["img5n"].toString();//32
                                        val img1url = dd["img1url"].toString();//33
                                        val img2url = dd["img2url"].toString();//34
                                        val img3url = dd["img3url"].toString();//35
                                        val img4url = dd["img4url"].toString();//36
                                        val img5url = dd["img5url"].toString();//37
                                        val img1nhigh = dd["img1nhigh"].toString();//28
                                        val img2nhigh = dd["img2nhigh"].toString();//29
                                        val img3nhigh = dd["img3nhigh"].toString();//30
                                        val img4nhigh = dd["img4nhigh"].toString();//31
                                        val img5nhigh = dd["img5nhigh"].toString();//32
                                        val img1urlhigh = dd["img1urlhigh"].toString();//33
                                        val img2urlhigh = dd["img2urlhigh"].toString();//34
                                        val img3urlhigh = dd["img3urlhigh"].toString();//35
                                        val img4urlhigh = dd["img4urlhigh"].toString();//36
                                        val img5urlhigh = dd["img5urlhigh"].toString();//37
                                        val retadates = dd["retdate"].toString();//37

                                        try {
                                            makeupitem = dd["makeupitem"].toString()
                                        }
                                        catch (e:Exception){

                                        }

                                        val isUpdated = myDb.insertData(id, snm, sid, dur, sac, sacdesc, pr, tx, igst, cess, cgst, sgst, ttot,
                                                ctot, gtot, ecomm, ebns, cry, ptg, bval, gdr, mctg, sctg, desc, fp, fpr, tpr, status, img1n,
                                                img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh,
                                                img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh,
                                                img4urlhigh, img5urlhigh,mctgky,sctgky,retadates,makeupitem)

                                        if (isUpdated==true) {

                                        }


                                    }
                                }
                                DocumentChange.Type.MODIFIED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type modified " + groupId)
                                    imageView10.visibility=View.GONE
                                    val dd = change.document
                                    val id = dd.id;//0
                                    val snm = dd["snm"].toString();//1
                                    val sid = dd["sid"].toString();//2
                                    val dur = dd["dur"].toString();//3
                                    val sac = dd["sac"].toString();//4
                                    val sacdesc = dd["sacdesc"].toString();//5
                                    val pr = dd["pr"].toString();//6
                                    val tx = dd["tx"].toString();//7
                                    val igst = dd["igst"].toString();//8
                                    val cess = dd["cess"].toString();//9
                                    val cgst = dd["cgst"].toString();//10
                                    val sgst = dd["sgst"].toString();//11
                                    val ttot = dd["ttot"].toString();//12
                                    val ctot = dd["ctot"].toString();//13
                                    val gtot = dd["gtot"].toString();//14
                                    val ecomm = dd["ecomm"].toString();//15
                                    val ebns = dd["ebns"].toString();//16
                                    val cry = dd["cry"].toString();//17
                                    val ptg = dd["ptg"].toString();//18
                                    val bval = dd["bval"].toString();//19
                                    val gdr = dd["gdr"].toString();//20
                                    val mctg = dd["mctg"].toString();//21
                                    val sctg = dd["sctg"].toString();//22
                                    val mctgky=dd["mctgkey"].toString();//21
                                    val sctgky=dd["sctgkey"].toString();//22
                                    val desc = dd["desc"].toString();//23
                                    val fp = dd["fp"].toString();//24
                                    val fpr = dd["fpr"].toString();//25
                                    val tpr = dd["tpr"].toString();//26
                                    val status = dd["status"].toString();//27
                                    val img1n = dd["img1n"].toString();//28
                                    val img2n = dd["img2n"].toString();//29
                                    val img3n = dd["img3n"].toString();//30
                                    val img4n = dd["img4n"].toString();//31
                                    val img5n = dd["img5n"].toString();//32
                                    val img1url = dd["img1url"].toString();//33
                                    val img2url = dd["img2url"].toString();//34
                                    val img3url = dd["img3url"].toString();//35
                                    val img4url = dd["img4url"].toString();//36
                                    val img5url = dd["img5url"].toString();//37

                                    val img1nhigh = dd["img1nhigh"].toString();//28
                                    val img2nhigh = dd["img2nhigh"].toString();//29
                                    val img3nhigh = dd["img3nhigh"].toString();//30
                                    val img4nhigh = dd["img4nhigh"].toString();//31
                                    val img5nhigh = dd["img5nhigh"].toString();//32
                                    val img1urlhigh = dd["img1urlhigh"].toString();//33
                                    val img2urlhigh = dd["img2urlhigh"].toString();//34
                                    val img3urlhigh = dd["img3urlhigh"].toString();//35
                                    val img4urlhigh = dd["img4urlhigh"].toString();//36
                                    val img5urlhigh = dd["img5urlhigh"].toString();//37
                                    val retadates = dd["retdate"].toString();//37
                                    try {
                                        makeupitem = dd["makeupitem"].toString()
                                    }
                                    catch (e:Exception){

                                    }

                                    val isUpdated = myDb.updateData(id, snm, sid, dur, sac, sacdesc, pr, tx, igst, cess,
                                            cgst, sgst, ttot, ctot, gtot, ecomm, ebns, cry, ptg, bval, gdr, mctg, sctg, desc, fp,
                                            fpr, tpr, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url,
                                            img5url,img1nhigh,img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh,
                                            img3urlhigh, img4urlhigh, img5urlhigh,mctgky,sctgky,retadates,makeupitem)

                                    if(isUpdated==true){

                                    }


                                }
                                DocumentChange.Type.REMOVED ->{
                                    val groupId = change.getDocument().getId()
                                    println("type removed " + groupId)
                                    myDb.deleteData(groupId)

                                }
                            }
                        }
                    }

                })



        myDb1 = Databasehelper(this)
        println("myDb.getNotesCount() : "+myDb1.getNotesCount())
        textView2.setText("${usArrayori.size} Items")

        //Check if sql db product not exists, below code is going to insert a product to local sql table

        db.collection("product")
                .addSnapshotListener(EventListener<QuerySnapshot>{task,e->
                    println("e : "+e)
                    if (e==null) {
                        println("task.docchange : "+task.documentChanges)
                        for (change in task.getDocumentChanges()) {
                            when (change.getType()) {
                                DocumentChange.Type.ADDED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type added " + groupId)


                                    println("myDb.isin(groupId).moveToNext() " +myDb1.checkIfRecordExist(groupId))
                                    val d=myDb1.checkIfRecordExist(groupId)
                                    if (d==false){
                                        imageView10.visibility=View.GONE
                                        val dd = change.document
                                        val id = dd.id;//0
                                        val pid = dd["p_id"].toString();//1
                                        val pname = dd["p_nm"].toString();//2
                                        val bcode = dd["bc"].toString();//3
                                        val pdes = dd["desc"].toString();//4
                                        val weight = dd["wg_vol"].toString();//5
                                        val psac = dd["hsn"].toString();//6
                                        try {
                                            stockonhand = dd["$brkey"].toString();//7
                                        }
                                        catch (e:Exception){

                                        }
                                        println("STHAND"+stockonhand)

                                        val minstock = dd["min_stk"].toString();//8
                                        val maxstock = dd["mx_stk"].toString();//9
                                        val price = dd["price"].toString();//10
                                        val taxable = dd["taxchk"].toString();//11
                                        val igst = dd["igst"].toString();//12
                                        val cgst = dd["cgst"].toString();//13
                                        val sgst = dd["sgst"].toString();//14

                                        val cess = dd["cess"].toString();//15

                                        val taxtotal = dd["taxtot"].toString();//16
                                        val cessval = dd["cesstot"].toString();//17
                                        val currency = dd["curency"].toString();//18
                                        val percentage = dd["percentage"].toString();//19
                                        try{
                                            ret=dd["retail"].toString()
                                        }
                                        catch (e:Exception){

                                        }
                                        try{

                                            bkbr=dd["backbar"].toString()
                                        }
                                        catch (e:Exception){

                                        }

                                        val percentagevalue = dd["percentageval"].toString();//20
                                        val product_dec = dd["product_desc"].toString();//21
                                        val mrP = dd["mrp"].toString();//22
                                        val cate = dd["ctgy"].toString();//23
                                        val manufacture = dd["mfr"].toString();//24
                                        val ut = dd["ut"].toString();//25
                                        val consold = dd["cn_sold"].toString();//26
                                        val comm = dd["emp_com"].toString();//27
                                        val status = dd["status"].toString();//27
                                        val img1n = dd["img1n"].toString();//28
                                        val img2n = dd["img2n"].toString();//29
                                        val img3n = dd["img3n"].toString();//30
                                        val img4n = dd["img4n"].toString();//31
                                        val img5n = dd["img5n"].toString();//32
                                        val img1url = dd["img1url"].toString();//33
                                        val img2url = dd["img2url"].toString();//34
                                        val img3url = dd["img3url"].toString();//35
                                        val img4url = dd["img4url"].toString();//36
                                        val img5url = dd["img5url"].toString();//37
                                        val img1nhigh = dd["img1nhigh"].toString();//28
                                        val img2nhigh = dd["img2nhigh"].toString();//29
                                        val img3nhigh = dd["img3nhigh"].toString();//30
                                        val img4nhigh = dd["img4nhigh"].toString();//31
                                        val img5nhigh = dd["img5nhigh"].toString();//32
                                        val img1urlhigh = dd["img1urlhigh"].toString();//33
                                        val img2urlhigh = dd["img2urlhigh"].toString();//34
                                        val img3urlhigh = dd["img3urlhigh"].toString();//35
                                        val img4urlhigh = dd["img4urlhigh"].toString();//36
                                        val img5urlhigh = dd["img5urlhigh"].toString();//37
                                        val orikys=dd["orikys"].toString()
                                        val protype=dd["protype"].toString()
                                        val retdate=dd["returnableday"].toString()

                                        val retn=dd["returnable"].toString()
                                        try {
                                            makeupitem = dd["makeupitem"].toString()
                                        }
                                        catch (e:Exception){

                                        }





                                        val isInserted = myDb1.insertData(id, pid, pname, bcode, pdes, weight, psac, cate, manufacture, ut, minstock, price,
                                                maxstock, consold,comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP, currency, status, percentage,
                                                percentagevalue, product_dec, stockonhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url,
                                                img5url,img1nhigh,img2nhigh,img3nhigh,img4nhigh,img5nhigh,img1urlhigh,img2urlhigh,img3urlhigh,img4urlhigh,
                                                img5urlhigh,orikys,ret,bkbr,protype,retn,retdate,makeupitem)
                                        textView2.setText("${usArrayori.size} Items")


                                        if(isInserted==true){
                                            println("ELSE CC MAIN MAKEUp")

                                            insertedloc="insert"
                                            gets()
                                            getattach()


                                        }


                                    }
                                }
                                DocumentChange.Type.MODIFIED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type modified " + groupId)
                                    imageView10.visibility=View.GONE
                                    val dd = change.document
                                    val id = dd.id;//0
                                    val pid = dd["p_id"].toString();//1
                                    val pname = dd["p_nm"].toString();//2
                                    val bcode = dd["bc"].toString();//3
                                    val pdes = dd["desc"].toString();//4
                                    val weight = dd["wg_vol"].toString();//5
                                    val psac = dd["hsn"].toString();//6
                                    try {


                                        stockonhand = dd["$brkey"].toString();//7
                                    }
                                    catch (e:Exception){

                                    }

                                    try{
                                        ret=dd["retail"].toString()
                                    }
                                    catch (e:Exception){

                                    }
                                    try{

                                        bkbr=dd["backbar"].toString()
                                    }
                                    catch (e:Exception){

                                    }

                                    println("STHAND Up"+stockonhand)

                                    val minstock = dd["min_stk"].toString();//8
                                    val maxstock = dd["mx_stk"].toString();//9
                                    val price = dd["price"].toString();//10
                                    val taxable = dd["taxchk"].toString();//11
                                    val igst = dd["igst"].toString();//12
                                    val cgst = dd["cgst"].toString();//13
                                    val sgst = dd["sgst"].toString();//14
                                    val cess = dd["cess"].toString();//15

                                    val taxtotal = dd["taxtot"].toString();//16
                                    val cessval = dd["cesstot"].toString();//17
                                    val currency = dd["curency"].toString();//18
                                    val percentage = dd["percentage"].toString();//19
                                    val percentagevalue = dd["percentageval"].toString();//20
                                    val product_dec = dd["product_desc"].toString();//21
                                    val mrP = dd["mrp"].toString();//22
                                    val cate = dd["ctgy"].toString();//23
                                    val manufacture = dd["mfr"].toString();//24
                                    val ut = dd["ut"].toString();//25
                                    val consold = dd["cn_sold"].toString();//26
                                    val comm = dd["emp_com"].toString();//27
                                    val status = dd["status"].toString();//27
                                    val img1n = dd["img1n"].toString();//28
                                    val img2n = dd["img2n"].toString();//29
                                    val img3n = dd["img3n"].toString();//30
                                    val img4n = dd["img4n"].toString();//31
                                    val img5n = dd["img5n"].toString();//32
                                    val img1url = dd["img1url"].toString();//33
                                    val img2url = dd["img2url"].toString();//34
                                    val img3url = dd["img3url"].toString();//35
                                    val img4url = dd["img4url"].toString();//36
                                    val img5url = dd["img5url"].toString();//37
                                    val img1nhigh = dd["img1nhigh"].toString();//28
                                    val img2nhigh = dd["img2nhigh"].toString();//29
                                    val img3nhigh = dd["img3nhigh"].toString();//30
                                    val img4nhigh = dd["img4nhigh"].toString();//31
                                    val img5nhigh = dd["img5nhigh"].toString();//32
                                    val img1urlhigh = dd["img1urlhigh"].toString();//33
                                    val img2urlhigh = dd["img2urlhigh"].toString();//34
                                    val img3urlhigh = dd["img3urlhigh"].toString();//35
                                    val img4urlhigh = dd["img4urlhigh"].toString();//36
                                    val img5urlhigh = dd["img5urlhigh"].toString();//37
                                    val orikys=dd["orikys"].toString()
                                    val protype=dd["protype"].toString()
                                    val retn=dd["returnable"].toString()
                                    val retdate=dd["returnableday"].toString()
                                    try {
                                        makeupitem = dd["makeupitem"].toString()
                                    }
                                    catch (e:Exception){

                                    }





                                    val isInserted = myDb1.updatedata(id, pid, pname, bcode, pdes, weight, psac, cate, manufacture, ut, minstock, price,
                                            maxstock, consold, comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP, currency, status, percentage,
                                            percentagevalue, product_dec, stockonhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url,
                                            img5url,img1nhigh,img2nhigh,img3nhigh, img4nhigh,img5nhigh,img1urlhigh,img2urlhigh,img3urlhigh,img4urlhigh,img5urlhigh,orikys,ret,bkbr,protype,retn,retdate,makeupitem)

                                    if(isInserted==true){

                                    }
                                }
                                DocumentChange.Type.REMOVED ->{
                                    val groupId = change.getDocument().getId()
                                    println("type removed " + groupId)
                                    myDb1.deleteData(groupId)
                                    textView2.setText("${usArrayori.size} Items")

                                }
                            }
                        }

                    }

                })



        //-----------------------Search----------------------------------------------//

        editText.addTextChangedListener(object : TextWatcher {


            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                progressBar12.visibility = View.VISIBLE
                makeup_list.visibility = View.GONE
                noresfo.visibility = View.GONE
                println("des : " + des)
                //progresslist.visibility=View.VISIBLE
                //Slist.visibility=View.GONE
                var usArray = arrayOf<String>()//("HD Makeup")
                var tyArray = arrayOf<String>()//("Skin Services, 120min")
                var brArray = arrayOf<String>()//("12,000.00")
                var id = arrayOf<String>()
                var status = arrayOf<String>()
                var icoArray = arrayOf<String>()
                var icohighArray = arrayOf<String>()
                var icohighnmArray = arrayOf<String>()

                var idd = arrayOf<String>()
                var cate = arrayOf<String>()
                val dd = myDb.retrieve(des.toString())

                if (dd.moveToNext()){

                        noresfo.visibility = View.GONE
                        println("dd : " + dd.getString(0))
                        idd = idd.plusElement(dd.getString(0))
                        val sname = dd.getString(1)
                        val maincat = dd.getString(21)
                        val subcat = dd.getString(22)
                        var sdur = dd.getString(51)
                        val price = dd.getString(14)
                        val state = dd.getString(27)
                        val highnm = dd.getString(38)

                        val high = dd.getString(43)

                        if (maincat == "Wedding") {

                            cate = cate.plusElement(maincat)
                            cateori=cateori.plusElement(maincat)
                            usArray = usArray.plusElement(sname+" - For rent")
                            usArrayori = usArrayori.plusElement(sname+" - For rent")

                            icohighnmArray = icohighnmArray.plusElement(highnm)
                            icohighnmArrayori = icohighnmArrayori.plusElement(highnm)


                            if ((maincat.isNotEmpty()) && (subcat.isNotEmpty()) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty()) && (sdur.isEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(subcat)
                                tyArrayori = tyArrayori.plusElement(subcat)

                            } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement(maincat)
                                tyArrayori = tyArrayori.plusElement(maincat)

                            } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement("")
                                tyArrayori = tyArrayori.plusElement("")

                            }

                            brArray = brArray.plusElement(price)
                            brArrayori = brArrayori.plusElement(price)
                            var makeupserv=dd.getString(51)

                            makeupitemori=makeupitemori.plusElement(makeupserv)

                            id = id.plusElement(dd.getString(0))
                            idori = idori.plusElement(dd.getString(0))

                            icohighArray = icohighArray.plusElement(high)
                            icohighArrayori = icohighArrayori.plusElement(high)

                            status = status.plusElement(state)
                            statusori = statusori.plusElement(state)

                            val ur = dd.getString(33)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                            val ur1 = dd.getString(34)
                            val ur2 = dd.getString(35)
                            val ur3 = dd.getString(36)
                            val ur4 = dd.getString(37)
                            if (ur.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur)
                                icoArrayori = icoArrayori.plusElement(ur)

                            } else if (ur1.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur1)
                                icoArrayori = icoArrayori.plusElement(ur1)

                            } else if (ur2.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur2)
                                icoArrayori = icoArrayori.plusElement(ur2)

                            } else if (ur3.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur3)
                                icoArrayori = icoArrayori.plusElement(ur3)

                            } else if (ur4.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur4)
                                icoArrayori = icoArrayori.plusElement(ur4)

                            } else {
                                icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                icoArrayori = icoArrayori.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                            }
                        }


                        //Slist.visibility=View.VISIBLE
                    }
                else{
                    val dd = myDb1.retrieve(des.toString())


                    if (dd.moveToNext()) {
                        idd = idd.plusElement(dd.getString(0))
                        val sname = dd.getString(2)
                        val maincat = dd.getString(52)
                        val subcat = dd.getString(53)
                        var sdur = dd.getString(55)
                        val price = dd.getString(22)
                        val state = dd.getString(24)
                        val high = dd.getString(44)
                        val highnm = dd.getString(39)

                        if (maincat == "Wedding") {
                            icohighnmArray = icohighnmArray.plusElement(highnm)
                            cate = cate.plusElement(maincat)
                            usArray = usArray.plusElement(sname+" - For sale")
                            icohighArray = icohighArray.plusElement(high)

                            icohighnmArrayori = icohighnmArrayori.plusElement(highnm)
                            cateori = cateori.plusElement(maincat)
                            usArrayori = usArrayori.plusElement(sname+" - For sale")
                            icohighArrayori = icohighArrayori.plusElement(high)

                            if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "true")) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "true")) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement(maincat + ", " + "Returnable")
                                tyArrayori = tyArrayori.plusElement(maincat + ", " + "Returnable")

                            } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "false")) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }

                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "false")) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement(maincat + ", " + "Not Returnable")
                                tyArrayori = tyArrayori.plusElement(maincat + ", " + "Not Returnable")

                            } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement(maincat)
                                tyArrayori = tyArrayori.plusElement(maincat)

                            } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                                if (sdur == "makeup service") {
                                    sdur = "Makeup service"
                                }
                                else if(sdur == "DECORATION JEWELLERY"){
                                    sdur = "Decoration jewellery"
                                }
                                else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                                    sdur = "Accessories / Attachments"
                                }
                                else if(sdur=="FLOWERS"){
                                    sdur = "Flowers"
                                }
                                tyArray = tyArray.plusElement(sdur)
                                tyArrayori = tyArrayori.plusElement(sdur)

                            } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                                tyArray = tyArray.plusElement("")
                                tyArrayori = tyArrayori.plusElement("")

                            }

                            brArray = brArray.plusElement(price)
                            brArrayori = brArrayori.plusElement(price)
                            var makeupserv=dd.getString(55)

                            makeupitemori=makeupitemori.plusElement(makeupserv)

                            id = id.plusElement(dd.getString(0))
                            idori = idori.plusElement(dd.getString(0))

                            status = status.plusElement(state)
                            statusori = statusori.plusElement(state)

                            val ur = dd.getString(44)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                            val ur1 = dd.getString(45)
                            val ur2 = dd.getString(46)
                            val ur3 = dd.getString(47)
                            val ur4 = dd.getString(48)
                            if (ur.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur)
                                icoArrayori = icoArrayori.plusElement(ur)

                            } else if (ur1.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur1)
                                icoArrayori = icoArrayori.plusElement(ur1)

                            } else if (ur2.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur2)
                                icoArrayori = icoArrayori.plusElement(ur2)

                            } else if (ur3.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur3)
                                icoArrayori = icoArrayori.plusElement(ur3)

                            } else if (ur4.isNotEmpty()) {
                                icoArray = icoArray.plusElement(ur4)
                                icoArrayori = icoArrayori.plusElement(ur4)

                            } else {
                                icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                icoArrayori = icoArrayori.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                            }
                        }
                    }
                }


                    makeup_list.visibility = View.VISIBLE
                    progressBar12.visibility = View.GONE
                    noresfo.visibility = View.GONE





                    //progresslist.visibility=View.GONE



                        if (usArray.isEmpty()) {

                            noresfo.visibility = View.VISIBLE
                        }

                        val whatever = SlistAdaptermakeup(this@Main_makeup, usArray, tyArray, brArray, id, status, icoArray, icohighnmArray, icohighArray)
                        val slist = findViewById<View>(R.id.makeup_list) as ListView
                        slist.adapter = whatever
                        whatever.notifyDataSetChanged()
                        slist.getItemIdAtPosition(0)




                //Click list item and navigate to  'Attachments_Activity' not as makeup service

                makeup_list.setOnItemClickListener { parent, views, position, d ->
                    if (makeupitemori[position] != "makeup service") {
                        val mHideButton = AnimationUtils.loadAnimation(this@Main_makeup, R.anim.hide_button)

                        d_fab.startAnimation(mHideButton)

                        myDb = Databasehelper_service(this@Main_makeup)
                        val service_access = SessionManagement(this@Main_makeup)
                        view = service_access.userDetails[SessionManagement.sview].toString()
                        add = service_access.userDetails[SessionManagement.sadd].toString()
                        delete = service_access.userDetails[SessionManagement.sdelete].toString()
                        edit = service_access.userDetails[SessionManagement.sedit].toString()
                        import = service_access.userDetails[SessionManagement.simport].toString()
                        export = service_access.userDetails[SessionManagement.s_export].toString()

                        var frmser = "makeup"
                        val pro_access = SessionManagement(this@Main_makeup)
                        viewpro = pro_access.userDetails[SessionManagement.pview].toString()
                        addpro = pro_access.userDetails[SessionManagement.padd].toString()
                        deletepro = pro_access.userDetails[SessionManagement.pdelete].toString()
                        editpro = pro_access.userDetails[SessionManagement.pedit].toString()
                        importpro = pro_access.userDetails[SessionManagement.pimport].toString()
                        exportpro = pro_access.userDetails[SessionManagement.pexport].toString()
                        stockin_hand = pro_access.userDetails[SessionManagement.pstockin_hand].toString()


                        val a = Intent(this@Main_makeup, Attachments_Activity::class.java)
                        a.putExtra("id", idori[position])
                        a.putExtra("from", "list")
                        a.putExtra("add", add)
                        a.putExtra("edit", edit)
                        a.putExtra("delete", delete)
                        a.putExtra("keybr", brkey)
                        a.putExtra("makeup", frmser)
                        a.putExtra("addpro", addpro)
                        a.putExtra("editpro", editpro)
                        a.putExtra("deletepro", deletepro)
                        a.putExtra("viewpro", viewpro)
                        a.putExtra("importpro", importpro)
                        a.putExtra("changestock", stockin_hand)
                        a.putExtra("exportpro", exportpro)

                        usArrayori = usArrayoriempty
                        tyArrayori = tyArrayoriempty
                        brArrayori = brArrayoriempty

                        statusori = statusoriempty
                        icoArrayori = icoArrayoriempty
                        icohighArrayori = icohighArrayoriempty
                        icohighnmArrayori = icohighnmArrayoriempty
                        iddori = iddoriempty
                        cateori = cateoriempty
                        startActivity(a);
                        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

                        finish()

                    }



                    //Click list item and navigate to  'ScrollActivity'

                    else if(makeupitemori[position]=="makeup service") {
                        var frmser="makeup"
                        myDb = Databasehelper_service(this@Main_makeup)
                        val service_access = SessionManagement(this@Main_makeup)
                        view = service_access.userDetails[SessionManagement.sview].toString()
                        add = service_access.userDetails[SessionManagement.sadd].toString()
                        delete = service_access.userDetails[SessionManagement.sdelete].toString()
                        edit = service_access.userDetails[SessionManagement.sedit].toString()
                        import = service_access.userDetails[SessionManagement.simport].toString()
                        export = service_access.userDetails[SessionManagement.s_export].toString()

                        val user = service_access.userDetails



                        if (add == "true") {
                            val b = Intent(applicationContext, ScrollActivity::class.java)
                            b.putExtra("id",idori[position])
                            b.putExtra("add",add)
                            b.putExtra("edit",edit)
                            b.putExtra("delete",delete)
                            b.putExtra("keybr", brkey)
                            b.putExtra("makeup",frmser)
                            usArrayori=usArrayoriempty
                            tyArrayori=tyArrayoriempty
                            brArrayori=brArrayoriempty

                            statusori=statusoriempty
                            makeupitemori=makeupitemempty
                            icoArrayori=icoArrayoriempty
                            icohighArrayori=icohighArrayoriempty
                            icohighnmArrayori=icohighnmArrayoriempty
                            iddori=iddoriempty
                            cateori=cateoriempty
                            startActivityForResult(b, REQUEST_CODE_EXAMPLE2);
                            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                            d_fab.isEnabled = true
                        } else {
                            popup("add")
                            d_fab.isEnabled = true
                        }
                    }
                }
                    }


            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                if(editText.text.toString().isEmpty()){
                    usArrayori=usArrayoriempty
                    tyArrayori=tyArrayoriempty
                    brArrayori=brArrayoriempty
                    idori=idoriempty
                    makeupitemori=makeupitemempty

                    statusori=statusoriempty
                    icoArrayori=icoArrayoriempty
                    icohighArrayori=icohighArrayoriempty
                    icohighnmArrayori=icohighnmArrayoriempty
                    iddori=iddoriempty
                    cateori=cateoriempty
                    noresfo.visibility=View.GONE
                    gets()
                    getattach()
                    //get()
                }
            }
        })



        if ((myDb.notesCount == 0)||(myDb1.notesCount == 0)) {     //if local sql db's document count is 0 nothing to be executed.
            imageView10.visibility=View.VISIBLE
        } else {

            if(frstvar!="inside") {
                println("ELSE CC")
                gets()    //gets() is used to get all service from local sql db.
                 getattach()  //getattach() is used to get all products from local sql db.
                    }

        }


    }

    fun popup(st:String){
        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Access Denied!")
                .setContentText("You dont have access to $st")
                .setConfirmText("ok")
                .setConfirmClickListener(null)
                .show()
        /*val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()*/
    }





    fun gets() {
listprogress.visibility=View.VISIBLE
        db.collection("product").whereEqualTo("protype","Wedding").orderBy("status",Query.Direction.ASCENDING)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                    var usArray = arrayOf<String>()//("HD Makeup")
                    var tyArray = arrayOf<String>()//("Skin Services, 120min")
                    var brArray = arrayOf<String>()//("12,000.00")
                    var id = arrayOf<String>()
                    var status = arrayOf<String>()
                    var icoArray = arrayOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()

                    var idd = arrayOf<String>()
                    var cate = arrayOf<String>()
                    if (e != null) {

                        return@EventListener
                    }

                    if (value.isEmpty == false) {
                        frmscrollact="pro"
                    }
                })

/*
        db.collection("${brkey}_service").whereEqualTo("mctg","Wedding").orderBy("status",Query.Direction.DESCENDING)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->*/

                    var usArray = arrayOf<String>()//("HD Makeup")
                    var tyArray = arrayOf<String>()//("Skin Services, 120min")
                    var brArray = arrayOf<String>()//("12,000.00")
                    var id = arrayOf<String>()
                    var status = arrayOf<String>()
                    var icoArray = arrayOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()

                    var idd = arrayOf<String>()
                    var cate = arrayOf<String>()
                   /* if (e != null) {

                        return@EventListener
                    }*/



        //Get and list the makeup service from local sql db

                 /*   if (value.isEmpty == false) {
                        for (document in value) {*/

        val dd = myDb.getAllData()

        while (dd.moveToNext()) {

            imageView10.visibility=View.GONE
            val maincateg = dd.getString(21)
            if(maincateg=="Wedding") {

                var idsss = dd.getString(0)
                var makeupserv = dd.getString(51)
                idd = idd.plusElement(idsss)
                iddori = iddori.plusElement(idsss)

                val sname = dd.getString(1)
                val maincat = dd.getString(21)
                val subcat = dd.getString(22)
                var sdur = dd.getString(51)
                val price = dd.getString(14)
                val state = dd.getString(27)
                val high = dd.getString(43)
                val highnm = dd.getString(38)
                icohighnmArray = icohighnmArray.plusElement(highnm)
                cate = cate.plusElement(maincat)
                usArray = usArray.plusElement(sname)
                icohighArray = icohighArray.plusElement(high)

                icohighnmArrayori = icohighnmArrayori.plusElement(highnm)
                cateori = cateori.plusElement(maincat)
                usArrayori = usArrayori.plusElement(sname+" - For rent")
                icohighArrayori = icohighArrayori.plusElement(high)
                makeupitemori = makeupitemori.plusElement(makeupserv)

                if ((maincat.isNotEmpty()) && (subcat.isNotEmpty()) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)
                } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty()) && (sdur.isEmpty())) {

                    tyArray = tyArray.plusElement(maincat + ", " + subcat)
                    tyArrayori = tyArrayori.plusElement(maincat + ", " + subcat)

                } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement(maincat)
                    tyArrayori = tyArrayori.plusElement(maincat)

                } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement("")
                    tyArrayori = tyArrayori.plusElement("")

                }

                brArray = brArray.plusElement(price)
                brArrayori = brArrayori.plusElement(price)

                id = id.plusElement(idsss)
                idori = idori.plusElement(idsss)

                status = status.plusElement(state)
                statusori = statusori.plusElement(state)

                val ur = dd.getString(43)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                val ur1 = dd.getString(44)
                val ur2 =dd.getString(45)
                val ur3 = dd.getString(46)
                val ur4 = dd.getString(47)
                if (ur.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur)
                    icoArrayori = icoArrayori.plusElement(ur)

                } else if (ur1.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur1)
                    icoArrayori = icoArrayori.plusElement(ur1)

                } else if (ur2.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur2)
                    icoArrayori = icoArrayori.plusElement(ur2)

                } else if (ur3.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur3)
                    icoArrayori = icoArrayori.plusElement(ur3)

                } else if (ur4.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur4)
                    icoArrayori = icoArrayori.plusElement(ur4)

                } else {
                    icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                    icoArrayori = icoArrayori.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                }
            }


        }

                        if(frmscrollact.isEmpty()) {
                            listprogress.visibility=View.GONE
                            val whatever = SlistAdaptermakeup(this, usArrayori, tyArrayori, brArrayori, idori, statusori, icoArrayori, icohighnmArrayori, icohighArrayori)
                            val slist = findViewById<View>(R.id.makeup_list) as ListView
                            slist.adapter = whatever
                            makeup_list.setOnItemClickListener { parent, views, position, d ->


                                var frmser = "makeup"
                                myDb = Databasehelper_service(this)
                                val service_access = SessionManagement(this)
                                view = service_access.userDetails[SessionManagement.sview].toString()
                                add = service_access.userDetails[SessionManagement.sadd].toString()
                                delete = service_access.userDetails[SessionManagement.sdelete].toString()
                                edit = service_access.userDetails[SessionManagement.sedit].toString()
                                import = service_access.userDetails[SessionManagement.simport].toString()
                                export = service_access.userDetails[SessionManagement.s_export].toString()

                                val user = service_access.userDetails



                                if (add == "true") {
                                    val b = Intent(applicationContext, ScrollActivity::class.java)
                                    b.putExtra("id", idori[position])
                                    b.putExtra("add", add)
                                    b.putExtra("edit", edit)
                                    b.putExtra("delete", delete)
                                    b.putExtra("keybr", brkey)
                                    b.putExtra("makeup", frmser)

                                    usArrayori = usArrayoriempty
                                    tyArrayori = tyArrayoriempty
                                    brArrayori = brArrayoriempty

                                    statusori = statusoriempty
                                    makeupitemori = makeupitemempty
                                    icoArrayori = icoArrayoriempty
                                    icohighArrayori = icohighArrayoriempty
                                    icohighnmArrayori = icohighnmArrayoriempty
                                    iddori = iddoriempty
                                    cateori = cateoriempty
                                    startActivityForResult(b, REQUEST_CODE_EXAMPLE2);
                                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                                    d_fab.isEnabled = true
                                } else {
                                    popup("add")
                                    d_fab.isEnabled = true
                                }
                            }


                        }

                    }


               /* })*/



    //Get and list the makeup product from local sql db


    fun getattach() {
        /*   db.collection("product").whereEqualTo("protype","Wedding").orderBy("status",Query.Direction.ASCENDING)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->*/

        var usArray = arrayOf<String>()//("HD Makeup")
        var tyArray = arrayOf<String>()//("Skin Services, 120min")
        var brArray = arrayOf<String>()//("12,000.00")
        var id = arrayOf<String>()
        var status = arrayOf<String>()
        var icoArray = arrayOf<String>()
        var icohighArray = arrayOf<String>()
        var icohighnmArray = arrayOf<String>()

        var idd = arrayOf<String>()
        var cate = arrayOf<String>()
        /* if (e != null) {

                        return@EventListener
                    }*/
/*
                    if (value.isEmpty == false) {
                        for (document in value) {*/
        val dd = myDb1.getAllData()

        while (dd.moveToNext()) {
            imageView10.visibility=View.GONE
            val maincateg = dd.getString(52)

            if (maincateg == "Wedding") {
                var idsss = dd.getString(0)

                var makeupserv = dd.getString(55)
                idd = idd.plusElement(idsss)
                val sname = dd.getString(2)
                val maincat = dd.getString(52)
                val subcat = dd.getString(53)
                var sdur = dd.getString(55)
                val price = dd.getString(22)
                val state = dd.getString(24)
                val high = dd.getString(44)
                val highnm = dd.getString(39)
                icohighnmArray = icohighnmArray.plusElement(highnm)
                cate = cate.plusElement(maincat)
                usArray = usArray.plusElement(sname)
                icohighArray = icohighArray.plusElement(high)

                icohighnmArrayori = icohighnmArrayori.plusElement(highnm)
                cateori = cateori.plusElement(maincat)
                usArrayori = usArrayori.plusElement(sname+" - For sale")
                icohighArrayori = icohighArrayori.plusElement(high)
                makeupitemori = makeupitemori.plusElement(makeupserv)
                frmscrollact = "pro"

                if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "true")) && (sdur.isNotEmpty())) {

                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                       /* sdur=f.substring(0).toUpperCase()
                        println("sdur"+sdur)*/

                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "true")) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement(maincat + ", " + "Returnable")
                    tyArrayori = tyArrayori.plusElement(maincat + ", " + "Returnable")

                } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "false")) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    /* sdur=f.substring(0).toUpperCase()
                     println("sdur"+sdur)*/
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isNotEmpty()) && (subcat.isNotEmpty() && (subcat == "false")) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement(maincat + ", " + "Not Returnable")
                    tyArrayori = tyArrayori.plusElement(maincat + ", " + "Not Returnable")

                } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement(maincat)
                    tyArrayori = tyArrayori.plusElement(maincat)

                } else if ((maincat.isNotEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    /* sdur=f.substring(0).toUpperCase()
                     println("sdur"+sdur)*/
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isNotEmpty())) {
                    if (sdur == "makeup service") {
                        sdur = "Makeup service"
                    }
                    else if(sdur == "DECORATION JEWELLERY"){
                        sdur = "Decoration jewellery"
                    }
                    else if(sdur=="ACCESSORIES / ATTACHMENTS"){
                        sdur = "Accessories / Attachments"
                    }
                    else if(sdur=="FLOWERS"){
                        sdur = "Flowers"
                    }
                    /* sdur=f.substring(0).toUpperCase()
                     println("sdur"+sdur)*/
                    tyArray = tyArray.plusElement(sdur)
                    tyArrayori = tyArrayori.plusElement(sdur)

                } else if ((maincat.isEmpty()) && (subcat.isEmpty()) && (sdur.isEmpty())) {
                    tyArray = tyArray.plusElement("")
                    tyArrayori = tyArrayori.plusElement("")

                }

                brArray = brArray.plusElement(price)
                brArrayori = brArrayori.plusElement(price)

                id = id.plusElement(idsss)
                idori = idori.plusElement(idsss)

                status = status.plusElement(state)
                statusori = statusori.plusElement(state)

                val ur = dd.getString(44)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                val ur1 = dd.getString(45)
                val ur2 = dd.getString(46)
                val ur3 = dd.getString(47)
                val ur4 = dd.getString(48)
                if (ur.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur)
                    icoArrayori = icoArrayori.plusElement(ur)

                } else if (ur1.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur1)
                    icoArrayori = icoArrayori.plusElement(ur1)

                } else if (ur2.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur2)
                    icoArrayori = icoArrayori.plusElement(ur2)

                } else if (ur3.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur3)
                    icoArrayori = icoArrayori.plusElement(ur3)

                } else if (ur4.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur4)
                    icoArrayori = icoArrayori.plusElement(ur4)

                } else {
                    icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                    icoArrayori = icoArrayori.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                }
            }

        }

        listprogress.visibility = View.GONE
        textView2.setText("${usArrayori.size} Items")
        val whatever = SlistAdaptermakeup(this, usArrayori, tyArrayori, brArrayori, idori, statusori, icoArrayori, icohighnmArrayori, icohighArrayori)
        val slist = findViewById<View>(R.id.makeup_list) as ListView
        slist.adapter = whatever



        makeup_list.setOnItemClickListener { parent, views, position, d ->

                //Click list item and navigate to  'Attachments_Activity' not as makeup service

            if (makeupitemori[position] != "makeup service") {
                val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

                d_fab.startAnimation(mHideButton)

                myDb = Databasehelper_service(this)
                val service_access = SessionManagement(this)
                view = service_access.userDetails[SessionManagement.sview].toString()
                add = service_access.userDetails[SessionManagement.sadd].toString()
                delete = service_access.userDetails[SessionManagement.sdelete].toString()
                edit = service_access.userDetails[SessionManagement.sedit].toString()
                import = service_access.userDetails[SessionManagement.simport].toString()
                export = service_access.userDetails[SessionManagement.s_export].toString()

                var frmser = "makeup"
                val pro_access = SessionManagement(this)
                viewpro = pro_access.userDetails[SessionManagement.pview].toString()
                addpro = pro_access.userDetails[SessionManagement.padd].toString()
                deletepro = pro_access.userDetails[SessionManagement.pdelete].toString()
                editpro = pro_access.userDetails[SessionManagement.pedit].toString()
                importpro = pro_access.userDetails[SessionManagement.pimport].toString()
                exportpro = pro_access.userDetails[SessionManagement.pexport].toString()
                stockin_hand = pro_access.userDetails[SessionManagement.pstockin_hand].toString()


                val a = Intent(this@Main_makeup, Attachments_Activity::class.java)
                a.putExtra("id", idori[position])
                a.putExtra("from", "list")
                a.putExtra("add", add)
                a.putExtra("edit", edit)
                a.putExtra("delete", delete)
                a.putExtra("keybr", brkey)
                a.putExtra("makeup", frmser)
                a.putExtra("addpro", addpro)
                a.putExtra("editpro", editpro)
                a.putExtra("deletepro", deletepro)
                a.putExtra("viewpro", viewpro)
                a.putExtra("importpro", importpro)
                a.putExtra("changestock", stockin_hand)
                a.putExtra("exportpro", exportpro)

                usArrayori = usArrayoriempty
                tyArrayori = tyArrayoriempty
                brArrayori = brArrayoriempty
                makeupitemori = makeupitemempty

                statusori = statusoriempty
                icoArrayori = icoArrayoriempty
                icohighArrayori = icohighArrayoriempty
                icohighnmArrayori = icohighnmArrayoriempty
                iddori = iddoriempty
                cateori = cateoriempty

                startActivity(a);
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)

                finish()

            }

                                //Click list item and navigate to  'ScrollActivity'


            else if (makeupitemori[position] == "makeup service") {
                var frmser = "makeup"
                myDb = Databasehelper_service(this)
                val service_access = SessionManagement(this)
                view = service_access.userDetails[SessionManagement.sview].toString()
                add = service_access.userDetails[SessionManagement.sadd].toString()
                delete = service_access.userDetails[SessionManagement.sdelete].toString()
                edit = service_access.userDetails[SessionManagement.sedit].toString()
                import = service_access.userDetails[SessionManagement.simport].toString()
                export = service_access.userDetails[SessionManagement.s_export].toString()

                val user = service_access.userDetails



                if (add == "true") {
                    val b = Intent(applicationContext, ScrollActivity::class.java)
                    b.putExtra("id", idori[position])
                    b.putExtra("add", add)
                    b.putExtra("edit", edit)
                    b.putExtra("delete", delete)
                    b.putExtra("keybr", brkey)
                    b.putExtra("makeup", frmser)
                    usArrayori = usArrayoriempty
                    tyArrayori = tyArrayoriempty
                    brArrayori = brArrayoriempty

                    statusori = statusoriempty
                    makeupitemori = makeupitemempty
                    icoArrayori = icoArrayoriempty
                    icohighArrayori = icohighArrayoriempty
                    icohighnmArrayori = icohighnmArrayoriempty
                    iddori = iddoriempty
                    cateori = cateoriempty
                    startActivityForResult(b, REQUEST_CODE_EXAMPLE2);
                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                    d_fab.isEnabled = true
                } else {
                    popup("add")
                    d_fab.isEnabled = true
                }
            }

        }

    }
                   /* }


                })*/

    companion object {
        //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont:ConstraintLayout?=null
        private var payment_tk_PGdis:LinearLayout?=null
        private var makeuplistdis:ListView?=null
        private var imageButtonsrchdis:ImageButton?=null
        private var userbackdis:ImageView?=null
        private var  imageButtonvertdis:ImageButton?=null
        private var cardviewdis:CardView?=null
        private var dfabdis:FloatingActionButton?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                /// if connection is off then all views becomes disable


                log_network!!.visibility= View.VISIBLE
                log_networktext!!.visibility= View.VISIBLE
                relatively!!.visibility= View.VISIBLE

                cont!!.setBackgroundColor(Color.parseColor("#43161616"))
                payment_tk_PGdis!!.visibility=View.GONE
                cardviewdis!!.visibility=View.GONE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {



                log_network!!.visibility= View.GONE
                log_networktext!!.visibility= View.GONE
                relatively!!.visibility= View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))



                if(payment_tk_PGdis!!.visibility==View.VISIBLE){
                    imageButtonvertdis!!.isEnabled=false
                    imageButtonsrchdis!!.isEnabled=false
                    dfabdis!!.isEnabled=true
                    makeuplistdis!!.isEnabled=false
                    makeuplistdis!!.isClickable=false
                    userbackdis!!.isEnabled=false
                }
                else if(payment_tk_PGdis!!.visibility==View.GONE){
                    imageButtonvertdis!!.isEnabled=true
                    imageButtonsrchdis!!.isEnabled=true
                    makeuplistdis!!.isClickable=true
                    dfabdis!!.isEnabled=true
                    makeuplistdis!!.isEnabled=true
                    userbackdis!!.isEnabled=true
                }

            }
        }
    }

     override fun onBackPressed() {

         //Back action
         if (card.visibility == View.VISIBLE) {
             usArrayori=usArrayoriempty
             tyArrayori=tyArrayoriempty
             brArrayori=brArrayoriempty
             idori=idoriempty
             statusori=statusoriempty
             icoArrayori=icoArrayoriempty
             icohighArrayori=icohighArrayoriempty
             icohighnmArrayori=icohighnmArrayoriempty
             iddori=iddoriempty
             cateori=cateoriempty
            card.visibility = View.GONE
            noresfo.visibility=View.GONE



             gets()
             getattach()
        }
         else if(payment_tk_PG.visibility==View.VISIBLE) {

             val mShowButton = AnimationUtils.loadAnimation(this, R.anim.show_button)
             val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

             payment_tk_PG.visibility=View.GONE
             d_fab.startAnimation(mHideButton)
             onResume()
         }
         else if(containersdmakeup.visibility==View.VISIBLE){
             containersdmakeup.visibility=View.INVISIBLE
             relativemakeup.visibility=View.GONE

             containers.setBackgroundColor(Color.parseColor("#32ffffff"))
             makeup_list.isClickable=true
             makeup_list.isEnabled=true
             d_fab.isEnabled=true
             d_fab.isClickable=true

         }
             else{
                 finish()
                 overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

             }
         }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            2 -> {   //Comes from add product result
                if ((resultCode == Activity.RESULT_OK)) {

                    frmscrollact="pro"


                    if(usArrayori.isEmpty()) {
                        gets()
                        getattach()
                    }


                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")

                        frmscrollact="pro"

                        if(usArrayori.isEmpty()) {
                            gets()
                            getattach()
                        }

                    }
                }

            }
            21 -> {
                if ((resultCode == Activity.RESULT_OK)) {

                                //Comes from add service result
               /*     prokydivseladd()*/



                    if(usArrayori.isEmpty()) {
                        gets()
                        getattach()
                    }


                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")

                        if(usArrayori.isEmpty()) {
                            gets()
                            getattach()
                        }

                    }
                }

            }
            23 -> {    //Comes from add product result

                if ((resultCode == Activity.RESULT_OK)) {
                    frmscrollact="pro"

                    if(usArrayori.isEmpty()) {
                        gets()
                        getattach()
                    }



                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")

                        frmscrollact="pro"
                        if(usArrayori.isEmpty()) {
                            gets()
                            getattach()
                        }


                    }
                }

            }
        }
    }
    fun net_status():Boolean{  ///Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
