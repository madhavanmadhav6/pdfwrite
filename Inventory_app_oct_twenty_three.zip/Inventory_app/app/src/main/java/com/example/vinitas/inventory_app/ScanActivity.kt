package com.example.vinitas.inventory_app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Camera
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.google.android.gms.vision.CameraSource
import com.google.android.gms.vision.Detector
import com.google.android.gms.vision.barcode.Barcode
import com.google.android.gms.vision.barcode.BarcodeDetector
import kotlinx.android.synthetic.main.activity_scan.*
import java.io.IOException

class ScanActivity : AppCompatActivity() {
    // Session Manager Class
    internal lateinit var cameraView: SurfaceView
    internal lateinit var barcode: BarcodeDetector
    internal lateinit var cameraSource: CameraSource
    internal lateinit var holder: SurfaceHolder
    internal lateinit var session: SessionManagement


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)










        cameraView = findViewById<View>(R.id.cameraView) as SurfaceView   //Camera view
        cameraView.setZOrderMediaOverlay(true)
        holder = cameraView.holder
        barcode = BarcodeDetector.Builder(this)  //Define barcode detector

                .build()
        if (!barcode.isOperational) {
            Toast.makeText(applicationContext, "Sorry, Couldn't setup the detector", Toast.LENGTH_LONG).show()
            this.finish()
        }




        cameraSource = CameraSource.Builder(this, barcode)
                .setFacing(CameraSource.CAMERA_FACING_BACK)
                .setRequestedFps(15f)
                .setAutoFocusEnabled(true)
                .setRequestedPreviewSize(258, 258)
                .build()
        cameraView.holder.addCallback(object : SurfaceHolder.Callback {

            override fun surfaceCreated(holder: SurfaceHolder) {
                try {
                    if (ContextCompat.checkSelfPermission(this@ScanActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        try {
                            cameraSource.start(cameraView.holder)
                        }
                        catch (e:Exception){

                            Toast.makeText(applicationContext,"Failed to open camera",Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }

            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {

            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {

            }
        })
        barcode.setProcessor(object : Detector.Processor<Barcode> {
            override fun release() {

            }



            //If barcodes received then navigate to (yourbranchActivity)

            override fun receiveDetections(detections: Detector.Detections<Barcode>) {
                val barcodes = detections.detectedItems
               // Log.i("barcode",barcodes.valueAt(0).toString())
                if (barcodes.size() > 0) {
                    val intent = Intent(this@ScanActivity,yourbranchActivity::class.java)
                    intent.putExtra("frm_main","qr")
                    intent.putExtra("barcode", barcodes.valueAt(0).displayValue)
                    startActivity(intent)
                   // setResult(Activity.RESULT_OK, intent)
                    finish()
                }
            }
        })


        /*val window = this.getWindow()

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)

// finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.transparent))*/


        // Session Manager
        session = SessionManagement(applicationContext)

        Toast.makeText(applicationContext, "User Login Status: " + session.isLoggedIn, Toast.LENGTH_LONG).show()
        if (session.isLoggedIn==true){
            val b= Intent(this,PinActivity::class.java)
            startActivity(b)
            finish()
        }
    }
    override fun onPause() {
        super.onPause()
        cameraSource.release()
        barcode.release()
        this@ScanActivity.finish()
    }

}
