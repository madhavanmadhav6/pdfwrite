package com.example.vinitas.inventory_app

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.example.vinitas.inventory_app.R.id.textView1
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.android.gms.vision.barcode.Barcode
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestore.getInstance
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_supp_product_add.*
import java.io.File


import java.net.URL
import java.text.DecimalFormat

import java.util.*


class SuppProductAddActivity : AppCompatActivity(), BaseSliderView.OnSliderClickListener {





    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null






    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }



    var TAG = "some"
    var db = getInstance()
    var f1 = String()
    var s1 = String()
    var t1 = String()
    var fo1 = String()
    var fif1 = String()
    //image name's
    var fn1 = String()
    var sn1 = String()
    var tn1 = String()
    var fon1 = String()
    var fifn1 = String()


    var f1edit = String()
    var s1edit = String()
    var t1edit = String()
    var fo1edit = String()
    var fif1edit = String()
    //image name's
    var fn1edit = String()
    var sn1edit = String()
    var tn1edit = String()
    var fon1edit = String()
    var fifn1edit = String()


    var img1urlhigh:String=""
    var img2urlhigh:String=""
    var img3urlhigh:String=""
    var img4urlhigh:String=""
    var img5urlhigh:String=""
    //image name's
    var img1nhigh:String=""
    var img2nhigh:String=""
    var img3nhigh:String=""
    var img4nhigh:String=""
    var img5nhigh:String=""

    var f1edithigh:String=""
    var s1edithigh:String=""
    var t1edithigh:String=""
    var fo1edithigh:String=""
    var fif1edithigh:String=""
    //image name's
    var fn1edithigh:String=""
    var sn1edithigh:String=""
    var tn1edithigh:String=""
    var fon1edithigh:String=""
    var fifn1edithigh:String=""

    var dup= String()

    var f1sup = String()
    var s1sup = String()
    var t1sup = String()
    var fo1sup = String()
    var fif1sup = String()
    //image name's
    var fn1sup = String()
    var sn1sup = String()
    var tn1sup = String()
    var fon1sup = String()
    var fifn1sup = String()


    var img1urlsuphigh:String=""
    var img2urlsuphigh:String=""
    var img3urlsuphigh:String=""
    var img4urlsuphigh:String=""
    var img5urlsuphigh:String=""
    //image name's
    var img1nsuphigh:String=""
    var img2nsuphigh:String=""
    var img3nsuphigh:String=""
    var img4nsuphigh:String=""
    var img5nsuphigh:String=""

    //image url's
    var f1supedit:String=""
    var s1supedit:String=""
    var t1supedit:String=""
    var fo1supedit:String=""
    var fif1supedit:String=""
    //image name's
    var fn1supedit:String=""
    var sn1supedit:String=""
    var tn1supedit:String=""
    var fon1supedit:String=""
    var fifn1supedit:String=""


    var f1supedithigh:String=""
    var s1supedithigh:String=""
    var t1supedithigh:String=""
    var fo1supedithigh:String=""
    var fif1supedithigh:String=""
    //image name's
    var fn1supedithigh:String=""
    var sn1supedithigh:String=""
    var tn1supedithigh:String=""
    var fon1supedithigh:String=""
    var fifn1supedithigh:String=""


    var suppnamevalidate= String()
    var suppmobcat1validate= String()
    var suppmobcat2validate= String()
    var suppmobcat3validate= String()
    var suppaddress1validate= String()
    var suppmobilevalidate= String()
    var suppmobile21validate= String()
    var suppmobile31validate= String()
    var suppmobile41validate= String()
    var suppaddress2validate= String()
    var suppaddress3validate= String()
    var suppcityvalidate= String()
    var suppstatevalidate= String()
    var supppinvalidate= String()
    var contactprsvalidate= String()
    var prodkyvalidate= String()
    var gpsvalidate= String()
    var suppemailvalidate= String()
    var suppgstvalidate= String()
    var file_maps = arrayListOf<String>()
    var file_mapspro = arrayListOf<String>()
    var mresultsarr= arrayListOf<String>()


    var cntpri:Int=0
    var cntnm:Int=0
    var cntcess:Int=0
    var cntigst:Int=0
    var cntvol:Int=0
    var cnthsc:Int=0
    var cnthscdes:Int=0
    var cntsoh:Int=0
    var cntmx:Int=0
    var cntmin:Int=0

var editclipro=String()
    var editclisupp= String()
    //image url's
    var f1send: String = ""
    var s1send: String = ""
    var t1send: String = ""
    var fo1send: String = ""
    var fif1send: String = ""
    //image name's
    var fn1send: String = ""
    var sn1send: String = ""
    var tn1send: String = ""
    var fon1send: String = ""
    var fifn1send: String = ""



    var pnamevalidate=String()
    var pidvalidate=String()
    var volvalidate=String()
    var bcodeidvalidate=String()
    var hscvalidate=String()
    var hscdesvalidate=String()
    var maincatvalidate="Select"
    var subcatvalidate="Select"
    var listvalidate="Select"
    var pricevalidate=String()
    var taxcheckvalidate="false"
    var intgstvalidate=String()
    var centgstvalidate=String()
    var stategstvalidate=String()
    var taxtotvalidate=String()
    var cessvaluevalidate=String()
    var mrpvalidate=String()



    var maxstockvalidate=String()
    var minstockvalidate=String()

    var stockhandvalidate=String()


    var commlistener = String()
   var fieldlistenr= String()

    //Suppproduts access

    private var addsupppro: String = ""
    private var editesupppro: String = ""
    private var deletesupppro: String = ""
    private var viewsupppro: String = ""
    private var importsupppro: String = ""
    private var exportsupppro: String = ""


    var catetr= String()
    var uttr= String()
    var manutr= String()


    var catesnd= String()
    var uttrsnd= String()
    var manusnd= String()


    data class s(

            var sp_nm: String,
            var sp_id: Any,
            var spbc: Any,
            var spwg_vol: Any,
            var sput: String,
            var spctgy: String,
            var spmfr: String,
            var sphsn: Any,
            var spdesc: Any,
            var spprice: Any,
            var sptaxchk: Any,
            var spigst: Any,
            var spcgst: Any,
            var spsgst: Any,
            var spcess: Any,
            var sptaxtot: Any,
            var spcesstot: Any,
            var spmrp: Any,
            var spstock_hand: String,
            var spmin_stk: Any,
            var spmx_stk: Any,
            var status: String,
            var spsave_key: Any,
            var img1n: Any,
            var img2n: Any,
            var img3n: Any,
            var img4n: Any,
            var img5n: Any,
            var img1url: Any,
            var img2url: Any,
            var img3url: Any,
            var img4url: Any,
            var img5url: Any,


            var img1nhigh:String,     //image 1 name
            var img2nhigh:String,     //image 2 name
            var img3nhigh:String,     //image 3 name
            var img4nhigh:String,     //image 4 name
            var img5nhigh:String,     //image 5 name
            var img1urlhigh:String,     //image 1 url
            var img2urlhigh:String,     //image 2 url
            var img3urlhigh:String,     //image 3 url
            var img4urlhigh:String,     //image 4 url
            var img5urlhigh:String
    )

    var prosave_key = arrayOf<String>()
    override fun onSliderClick(slider: BaseSliderView?) {
        //Toast.makeText(this, slider!!.getBundle().get("extra") + "",Toast.LENGTH_SHORT).show();
    }

    var d = arrayListOf<String>()
var listnersave= String()
    var profab= String()

    var startlistprokey= String()
    var productprokey= String()

    var maincatId = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supp_product_add)



        userback.setOnClickListener {

            onBackPressed()
        }


net_status()




        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SuppProductAddActivity) > 0)
        {

        }
        else{

        }



        relativeslayoutdis=findViewById(R.id.relativeslayout)
        consermaindis=findViewById(R.id.container)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        scroll2_sliderdis=findViewById(R.id.scroll2_slider)
        scroll2_slider2dis=findViewById(R.id.scroll2_slider2)
        gallerydis=findViewById(R.id.gallery)
        editdis=findViewById(R.id.edit)

        addLogText(NetworkUtil.getConnectivityStatusString(this@SuppProductAddActivity))


        val come = intent.extras
        val i = come.getString("pro_supppro")


        val maincat=ArrayList<String>()
        val adp1 = ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, maincat)
        adp1.setDropDownViewResource(R.layout.spinner_view)

        val list=ArrayList<String>()
        val dataAdapter = ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, list)
        dataAdapter.setDropDownViewResource(R.layout.spinner_view)

        val subcat = ArrayList<String>()
        val adp2 = ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, subcat)
        adp2.setDropDownViewResource(R.layout.spinner_view)

        /*if(i=="scan") {


            val pids = intent.getStringExtra("pid")
            val profabs = intent.getStringExtra("profab")
            profab=profabs

            val pnames = intent.getStringExtra("pname")
            val bcodes = intent.getStringExtra("bcode")
            val pdess = intent.getStringExtra("pdes")
            val weights = intent.getStringExtra("weight")
            val psacs = intent.getStringExtra("psac")
            val stockonhands = intent.getStringExtra("stockonhand")
            val minstocks = intent.getStringExtra("minstock")
            val maxstocks = intent.getStringExtra("maxstock")
            val prices = intent.getStringExtra("price")
            val taxables = intent.getStringExtra("taxable").toBoolean()
            val igsts = intent.getStringExtra("igst")
            val cgsts = intent.getStringExtra("cgst")
            val sgsts = intent.getStringExtra("sgst")
            val cesss = intent.getStringExtra("cess")
            val taxtotals = intent.getStringExtra("taxtotal")
            val cessvals = intent.getStringExtra("cessval")
            val savekys = intent.getStringExtra("saveky")
            val mrPs = intent.getStringExtra("mrP")
            val cates = intent.getStringExtra("cate").toBoolean()
            val manufactures = intent.getStringExtra("manufacture").toBoolean()
            val uts = intent.getStringExtra("ut").toBoolean()
            val statuss = intent.getStringExtra("status")
            val img1nsups = intent.getStringExtra("img1nsup")
            val img2nsups = intent.getStringExtra("img2nsup")
            val img3nsups = intent.getStringExtra("img3nsup")
            val img4nsups = intent.getStringExtra("img4nsup")
            val img5nsups = intent.getStringExtra("img5nsup")
            val img1urlsups = intent.getStringExtra("img1urlsup")
            val img2urlsups = intent.getStringExtra("img2urlsup")
            val img3urlsups = intent.getStringExtra("img3urlsup")
            val img4urlsups = intent.getStringExtra("img4urlsup")
            val img5urlsups = intent.getStringExtra("img5urlsup")
            val img1ns = intent.getStringExtra("img1n")
            val img2ns = intent.getStringExtra("img2n")
            val img3ns = intent.getStringExtra("img3n")
            val img4ns = intent.getStringExtra("img4n")
            val img5ns = intent.getStringExtra("img5n")
            val img1urls = intent.getStringExtra("img1url")
            val img2urls = intent.getStringExtra("img2url")
            val img3urls = intent.getStringExtra("img3url")
            val img4urls = intent.getStringExtra("img4url")
            val img5urls = intent.getStringExtra("img5url")
            val snames = intent.getStringExtra("sname")
            val sids = intent.getStringExtra("sid")
            val scons = intent.getStringExtra("scon")
            val mobs = intent.getStringExtra("mob")
            val mob1s = intent.getStringExtra("mob1")
            val mob2s = intent.getStringExtra("mob2")
            val mobiles = intent.getStringExtra("mobile")
            val mobile1s = intent.getStringExtra("mobile1")
            val mobile2s = intent.getStringExtra("mobile2")
            val saddres = intent.getStringExtra("saddre")
            val saddre1s = intent.getStringExtra("saddre1")
            val saddre2s = intent.getStringExtra("saddre2")
            val scitys = intent.getStringExtra("scity")
            val sstates = intent.getStringExtra("sstate")
            val spins = intent.getStringExtra("spin")
            val sgpss = intent.getStringExtra("sgps")
            val smails = intent.getStringExtra("smail")
            val sgstcodes = intent.getStringExtra("sgstcode")
            val urlims = intent.getStringExtra("urlim")
            val sidss = intent.getStringExtra("sids")
            val statussups = intent.getStringExtra("statussup")
            val savekysups = intent.getStringExtra("savekysup")
            val prodkys = intent.getStringExtra("prodky")
            val comlisn=intent.getStringExtra("commlisteners")
            val listn=intent.getStringExtra("listnrsaves")
            editclisupp=intent.getStringExtra("editclsupp")
            editclipro=intent.getStringExtra("editclpro")
            listnersave=listn



            if((editclipro=="clicked")&&(sup_pid.text.toString()!="Auto-generated")){
                edit.visibility=View.INVISIBLE
            }
            else if((editclipro.isEmpty())&&(sup_pid.text.toString()!="Auto-generated")){
                edit.visibility=View.VISIBLE
            }


            val fieldlistn=intent.getStringExtra("fieldlistnrsaves")
            fieldlistenr=fieldlistn
            val bundle = intent.extras
            val prosv=bundle!!.get("prosvkys") as Array<String>

            prosave_key=prosv


             addsupppro=intent.getStringExtra("addspro")

             editesupppro=intent.getStringExtra("editspro")

             deletesupppro=intent.getStringExtra("viewspro")

             viewsupppro=intent.getStringExtra("deletespro")

             importsupppro=intent.getStringExtra("importspro")
             exportsupppro=intent.getStringExtra("exportspro")














            sup_pname.setText(pnames)
            sup_pid.setText(pids)
            sup_vol.setText(weights)

            sup_bcode.setText(bcodes)
            sup_hsc.setText(psacs)
            sup_hscdes.setText(pdess)
            sup_price.setText(prices)
            sup_intgst.setText(igsts)
            sup_cess.setText(cesss)
            sup_centgst.setText(cgsts)
            sup_stategst.setText(sgsts)
            sup_taxtot.setText(taxtotals)

            sup_cessvalue.setText(cessvals)
            sup_mrp.setText(mrPs)
            sup_stockhand.setText(stockonhands)
            sup_maxstock.setText(maxstocks)
            sup_minstock.setText(minstocks)
            sup_taxcheck.isChecked = taxables
            savekey.setText(savekys)
            sup_cate.isSelected = cates
            sup_manu.isSelected = manufactures
            sup_unit.isSelected = uts
            disable.setText(statuss)

            commlistener=comlisn


            fn1 = img1ns
            sn1 = img2ns
            tn1 = img3ns
            fon1 = img4ns
            fifn1sup = img5ns
            f1 = img1urls
            s1 = img2urls
            t1 = img3urls
            fo1 = img4urls
            fif1 = img5urls







            textView1.setText(snames)
            textView22.setText(sids)

            textView33.setText(scons)
            textView4.setText(mobs.toString())
            textView5.setText(mob1s.toString())
            textView6.setText(mob2s.toString())
            textView7.setText(mobiles)

            textView8.setText(mobile1s)
            textView9.setText(mobile2s)
            textView10.setText(saddres)
            textView11.setText(saddre1s)
            textView12.setText(saddre2s)
            textView13.setText(scitys)
            textView14.setText(sstates)
            textView15.setText(spins)

            textView16.setText(sgpss)
            textView17.setText(smails)

            textView18.setText(sgstcodes)
            textView19.setText(urlims)
            textView20.setText(sidss)
            saveky.setText(savekysups)
            prokey.setText(prodkys)
            textView21.setText(statussups)

            f1sup = img1urlsups
            s1sup = img2urlsups
            t1sup = img3urlsups
            fo1sup = img4urlsups
            fif1sup = img5urlsups
            fn1sup = img1nsups
            sn1sup = img2nsups
            tn1sup = img3nsups
            fon1sup = img4nsups
            fifn1sup = img5nsups

            *//*scroll2_slider2.visibility = View.GONE

            val bitmapArray = ArrayList<String>()
            bitmapArray.clear()

try {
    d.add(f1);bitmapArray.add(f1)
    println(bitmapArray[0])
}
catch(e:Exception){

}


try {
            d.add(s1);bitmapArray.add(s1)
            println(bitmapArray[1])
}
catch(e:Exception){

}

try {
            d.add(t1);bitmapArray.add(t1)
            println(bitmapArray[2])


}
catch(e:Exception){

}

            try {
            d.add(fo1);bitmapArray.add(fo1)
            println(bitmapArray[3])

           }
catch(e:Exception){

}


try {
            d.add(fif1);bitmapArray.add(fif1)
            println(bitmapArray[4])
}
catch(e:Exception){

}

            Log.d("tag", "  " + bitmapArray)
            if (bitmapArray.isNotEmpty()) {
                for (r in 0 until bitmapArray.size) {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("khd", "r  " + bitmapArray[r])
                    textSliderView
                            //.description(name)
                            .image(bitmapArray[r])
                            .setScaleType(BaseSliderView.ScaleType.Fit)
                            .setOnSliderClickListener(this@SuppProductAddActivity)

                    //add your extra information
                    *//**//*textSliderView.bundle(Bundle())
                textSliderView.bundle.clear()*//**//*
                    //.putString("extra", bitmapArray[r])

                    scroll2_slider.addSlider(textSliderView)
                }
                scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                scroll2_slider.setCustomAnimation(DescriptionAnimation())
                scroll2_slider.setDuration(5000)

                //scroll2_preview_service_image
                try {
                    val newurl = URL(bitmapArray[0]).openStream()
                    val img = BitmapFactory.decodeStream(newurl)
                }
                catch (e:Exception)
                {

                }*//*



        }*/
        Handler().postDelayed(Runnable { loadim() }, 1000)
        if (i == "product") { 



            db.collection("productcategory")
                    .get()
                    .addOnCompleteListener {task->
                        if (task.isSuccessful){
                            if (task.result != null){
                                maincat.clear()
                                maincatId.clear()
                                maincat.add("Select")
                                maincatId.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatId.add(document.id)
                                    val c = dd["cat"].toString()
                                    maincat.add(c)
                                    println(maincat)
                                    sup_cate.adapter=adp1
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }
                        }
                    }


            db.collection("unit")
                    .get()
                    .addOnCompleteListener {task->
                        if (task.isSuccessful){

                            if (task.result != null){
                                list.clear()
                                maincatId.clear()
                                list.add("Select")
                                maincatId.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatId.add(document.id)
                                    val c = dd["cat"].toString()
                                    list.add(c)
                                    println(maincat)
                                    sup_unit.adapter=dataAdapter
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }
                        }
                    }


            db.collection("manufacturer")
                    .get()
                    .addOnCompleteListener {task->
                        if (task.isSuccessful){
                            if (task.result != null){
                                subcat.clear()
                                maincatId.clear()
                                subcat.add("Select")
                                maincatId.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatId.add(document.id)
                                    val c = dd["cat"].toString()
                                    subcat.add(c)
                                    println(maincat)
                                    sup_manu.adapter=adp2
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }
                        }
                    }


            val image_view = findViewById<ImageView>(R.id.imageView41)
            val image_button = findViewById(R.id.imageButton2) as ImageView

            image_button.setOnClickListener {
                gallery.isEnabled = false
                val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)

                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)

                b.putExtra("listener",commlistener)

                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)

                b.putExtra("addpro",addsupppro)
                b.putExtra("editpro",editesupppro)
                b.putExtra("deletepro",deletesupppro)
                b.putExtra("viewpro",viewsupppro)
                b.putExtra("importpro",importsupppro)
                b.putExtra("exportpro",exportsupppro)

                b.putExtra("edtcli",editclipro)



                startActivityForResult(b, 0)
                gallery.isEnabled = true


            }
            image_view.setOnClickListener {

                val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)

                b.putExtra("listener",commlistener)

                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)

                b.putExtra("addpro",addsupppro)
                b.putExtra("editpro",editesupppro)
                b.putExtra("deletepro",deletesupppro)
                b.putExtra("viewpro",viewsupppro)
                b.putExtra("importpro",importsupppro)
                b.putExtra("exportpro",exportsupppro)

                b.putExtra("edtcli",editclipro)



                startActivityForResult(b, 0)
                gallery.isEnabled = true
            }

            val sup_name = intent.getStringExtra("pro_sname1")
            val sup_id = intent.getStringExtra("pro_sid1")
            val sup_cont = intent.getStringExtra("pro_scon1")
            val sup_mob = intent.getStringExtra("pro_mob")
            val sup_mob1 = intent.getStringExtra("pro_mob1")
            val sup_mob2 = intent.getStringExtra("pro_mob2")
            val sup_mobile = intent.getStringExtra("pro_mobile")
            val sup_mobile1 = intent.getStringExtra("pro_mobile1")
            val sup_mobile2 = intent.getStringExtra("pro_mobile2")
            val sup_addr = intent.getStringExtra("pro_saddress")
            val sup_addr1 = intent.getStringExtra("pro_saddress1")
            val sup_addr2 = intent.getStringExtra("pro_saddress2")
            val sup_city = intent.getStringExtra("pro_scity")
            val sup_state = intent.getStringExtra("pro_sstate")
            val sup_pin = intent.getStringExtra("pro_spin")
            val sup_gps = intent.getStringExtra("pro_sgps")
            val sup_mail = intent.getStringExtra("pro_smail")
            val sup_gstcd = intent.getStringExtra("pro_sgstcd")
            val sup_imgurl = intent.getStringExtra("pro_url")
            val sup_status = intent.getStringExtra("pro_status")
            val ids = intent.getStringExtra("pro_sids")
            val key = intent.getStringExtra("savekysnd")
            val img1 = intent.getStringExtra("img1")
            val img2 = intent.getStringExtra("img2")
            val img3 = intent.getStringExtra("img3")
            val img4 = intent.getStringExtra("img4")
            val img5 = intent.getStringExtra("img5")
            val imgurl6 = intent.getStringExtra("url1")
            val imgurl7 = intent.getStringExtra("url2")
            val imgurl8 = intent.getStringExtra("url3")
            val imgurl9 = intent.getStringExtra("url4")
            val imgurl10 = intent.getStringExtra("url5")
            val savelistnr=intent.getStringExtra("listenr")
            listnersave=savelistnr
try {
    startlistprokey = intent.getStringExtra("startlistprky")
    productprokey = intent.getStringExtra("profrmprky")
}
catch (e:Exception){

}


            try{

                img1urlsuphigh=intent.getStringExtra("img1urlhigh")
                img2urlsuphigh=intent.getStringExtra("img2urlhigh")
                img3urlsuphigh=intent.getStringExtra("img3urlhigh")
                img4urlsuphigh=intent.getStringExtra("img4urlhigh")
                img5urlsuphigh=intent.getStringExtra("img5urlhigh")
                //image name's
                img1nsuphigh=intent.getStringExtra("img1nhigh")
                img2nsuphigh=intent.getStringExtra("img2nhigh")
                img3nsuphigh=intent.getStringExtra("img3nhigh")
                img4nsuphigh=intent.getStringExtra("img4nhigh")
                img5nsuphigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1supedit=intent.getStringExtra("f1edit")
                s1supedit=intent.getStringExtra("s1edit")
                t1supedit=intent.getStringExtra("t1edit")
                fo1supedit=intent.getStringExtra("fo1edit")
                fif1supedit=intent.getStringExtra("fif1edit")
                //image name's
                fn1supedit=intent.getStringExtra("fn1edit")
                sn1supedit=intent.getStringExtra("sn1edit")
                tn1supedit=intent.getStringExtra("tn1edit")
                fon1supedit=intent.getStringExtra("fon1edit")
                fifn1supedit=intent.getStringExtra("fifn1edit")


                f1supedithigh=intent.getStringExtra("f1edithigh")
                s1supedithigh=intent.getStringExtra("s1edithigh")
                t1supedithigh=intent.getStringExtra("t1edithigh")
                fo1supedithigh=intent.getStringExtra("fo1edithigh")
                fif1supedithigh=intent.getStringExtra("fif1edithigh")
                //image name's
                fn1supedithigh=intent.getStringExtra("fn1edithigh")
                sn1supedithigh=intent.getStringExtra("sn1edithigh")
                tn1supedithigh=intent.getStringExtra("tn1edithigh")
                fon1supedithigh=intent.getStringExtra("fon1edithigh")
                fifn1supedithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                mresultsarr=intent.getStringArrayListExtra("mresultsarr")

            }
            catch (e:Exception){

            }





            val fieldsavelistnr=intent.getStringExtra("fieldlistenr")

            fieldlistenr=fieldsavelistnr
            val ad = intent.getStringExtra("addspro")
            val ed = intent.getStringExtra("editspro")
            val vie = intent.getStringExtra("viewspro")
            val dele = intent.getStringExtra("deletespro")
            val imp = intent.getStringExtra("importspro")
            val expo = intent.getStringExtra("exportspro")


            editclisupp=intent.getStringExtra("edtcli")
            profab="infab"

            if (ad != null) {
                addsupppro = ad
            }
            if (ed != null) {
                editesupppro = ed
            }
            if (dele != null) {
                deletesupppro = dele
            }
            if (vie != null) {
                viewsupppro = vie
            }
            if (imp != null) {
                importsupppro = imp
            }
            if (expo != null) {
                exportsupppro = expo
            }








            try {
                val prkey = intent.getStringExtra("prky")
                prosave_key = prosave_key.plusElement(prkey)
                prokey.setText(prkey.toString())

            } catch (e: Exception) {

            }


            println("PRODUCT KEYYYYYY" + Arrays.toString(prosave_key))
            println(sup_name)
            println(key)

            textView1.setText(sup_name)
            textView22.setText(sup_id)
            println(sup_id)
            textView33.setText(sup_cont)
            textView4.setText(sup_mob.toString())
            textView5.setText(sup_mob1.toString())
            textView6.setText(sup_mob2.toString())
            textView7.setText(sup_mobile)
            println(sup_mobile)
            textView8.setText(sup_mobile1)
            textView9.setText(sup_mobile2)
            textView10.setText(sup_addr)
            textView11.setText(sup_addr1)
            textView12.setText(sup_addr2)
            textView13.setText(sup_city)
            textView14.setText(sup_state)
            textView15.setText(sup_pin)
            println(sup_pin)
            textView16.setText(sup_gps)
            textView17.setText(sup_mail)
            println(sup_mail)
            textView18.setText(sup_gstcd)
            textView19.setText(sup_imgurl)
            textView20.setText(sup_status)
            saveky.setText(key)
            textView21.setText(ids)

            f1sup = imgurl6
            s1sup = imgurl7
            t1sup = imgurl8
            fo1sup = imgurl9
            fif1sup = imgurl10
            fn1sup= img1
            sn1sup = img2
            tn1sup = img3
            fon1sup = img4
            fifn1sup = img5


            if(sup_id!="Auto - generated") {


                suppnamevalidate = sup_name
                contactprsvalidate = sup_cont
                suppmobcat1validate = sup_mob.toString()
                suppmobcat2validate = sup_mob2.toString()
                suppmobcat3validate = sup_mob2.toString()
                suppmobilevalidate = sup_mobile.toString()
                suppmobile21validate = sup_mobile1
                suppmobile31validate = sup_mobile2
                suppaddress1validate = sup_addr
                suppaddress2validate = sup_addr1
                suppaddress3validate = sup_addr2
                suppcityvalidate = sup_city
                suppstatevalidate = sup_state
                supppinvalidate = sup_pin
                gpsvalidate = sup_gps
                suppemailvalidate = sup_mail
                suppgstvalidate = sup_gstcd

            }









            val k = intent.getStringExtra("svky")
            savekey.setText(k)
        }


        //LIST CLICK


        else if (i == "proliclick") {


            val pDialog = SweetAlertDialog(this@SuppProductAddActivity, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...");
            pDialog.setCancelable(false);
            pDialog.show();


            val maincat1=ArrayList<String>()
            val adp11= ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, maincat1)
            adp11.setDropDownViewResource(R.layout.spinner_view)

            val list1=ArrayList<String>()
            val dataAdapter1 = ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, list1)
            dataAdapter1.setDropDownViewResource(R.layout.spinner_view)

            val subcat1 = ArrayList<String>()
            val adp21 = ArrayAdapter(this@SuppProductAddActivity, R.layout.spinner_view, subcat1)
            adp21.setDropDownViewResource(R.layout.spinner_view)





            val b = intent.getStringExtra("id")
            val c = intent.getStringExtra("idsofpro")

            val ad = intent.getStringExtra("addspro")
            val ed = intent.getStringExtra("editspro")
            val vie = intent.getStringExtra("viewspro")
            val dele = intent.getStringExtra("deletespro")
            val imp = intent.getStringExtra("importspro")
            val expo = intent.getStringExtra("exportspro")
            editclisupp=intent.getStringExtra("edtcli")

            val fieldsavelistnr=intent.getStringExtra("fieldlistenr")

            fieldlistenr=fieldsavelistnr
            val sup_name = intent.getStringExtra("pro_sname1")
            val sup_id = intent.getStringExtra("pro_sid1")
            val sup_cont = intent.getStringExtra("pro_scon1")
            val sup_mob = intent.getStringExtra("pro_mob")
            val sup_mob1 = intent.getStringExtra("pro_mob1")
            val sup_mob2 = intent.getStringExtra("pro_mob2")
            val sup_mobile = intent.getStringExtra("pro_mobile")
            val sup_mobile1 = intent.getStringExtra("pro_mobile1")
            val sup_mobile2 = intent.getStringExtra("pro_mobile2")
            val sup_addr = intent.getStringExtra("pro_saddress")
            val sup_addr1 = intent.getStringExtra("pro_saddress1")
            val sup_addr2 = intent.getStringExtra("pro_saddress2")
            val sup_city = intent.getStringExtra("pro_scity")
            val sup_state = intent.getStringExtra("pro_sstate")
            val sup_pin = intent.getStringExtra("pro_spin")
            val sup_gps = intent.getStringExtra("pro_sgps")
            val sup_mail = intent.getStringExtra("pro_smail")
            val sup_gstcd = intent.getStringExtra("pro_sgstcd")
            val sup_imgurl = intent.getStringExtra("pro_url")
            val sup_status = intent.getStringExtra("pro_status")
            val ids = intent.getStringExtra("pro_sids")

            val img1 = intent.getStringExtra("img1")
            val img2 = intent.getStringExtra("img2")
            val img3 = intent.getStringExtra("img3")
            val img4 = intent.getStringExtra("img4")
            val img5 = intent.getStringExtra("img5")
            val imgurl6 = intent.getStringExtra("url1")
            val imgurl7 = intent.getStringExtra("url2")
            val imgurl8 = intent.getStringExtra("url3")
            val imgurl9 = intent.getStringExtra("url4")
            val imgurl10 = intent.getStringExtra("url5")

            val savelistnr=intent.getStringExtra("listenr")
            listnersave=savelistnr

            try {

                startlistprokey = intent.getStringExtra("startlistprky")
                productprokey = intent.getStringExtra("profrmprky")
            }
            catch (e:Exception){

            }

            try{

                img1urlsuphigh=intent.getStringExtra("img1urlhigh")
                img2urlsuphigh=intent.getStringExtra("img2urlhigh")
                img3urlsuphigh=intent.getStringExtra("img3urlhigh")
                img4urlsuphigh=intent.getStringExtra("img4urlhigh")
                img5urlsuphigh=intent.getStringExtra("img5urlhigh")
                //image name's
                img1nsuphigh=intent.getStringExtra("img1nhigh")
                img2nsuphigh=intent.getStringExtra("img2nhigh")
                img3nsuphigh=intent.getStringExtra("img3nhigh")
                img4nsuphigh=intent.getStringExtra("img4nhigh")
                img5nsuphigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1supedit=intent.getStringExtra("f1edit")
                s1supedit=intent.getStringExtra("s1edit")
                t1supedit=intent.getStringExtra("t1edit")
                fo1supedit=intent.getStringExtra("fo1edit")
                fif1supedit=intent.getStringExtra("fif1edit")
                //image name's
                fn1supedit=intent.getStringExtra("fn1edit")
                sn1supedit=intent.getStringExtra("sn1edit")
                tn1supedit=intent.getStringExtra("tn1edit")
                fon1supedit=intent.getStringExtra("fon1edit")
                fifn1supedit=intent.getStringExtra("fifn1edit")


                f1supedithigh=intent.getStringExtra("f1edithigh")
                s1supedithigh=intent.getStringExtra("s1edithigh")
                t1supedithigh=intent.getStringExtra("t1edithigh")
                fo1supedithigh=intent.getStringExtra("fo1edithigh")
                fif1supedithigh=intent.getStringExtra("fif1edithigh")
                //image name's
                fn1supedithigh=intent.getStringExtra("fn1edithigh")
                sn1supedithigh=intent.getStringExtra("sn1edithigh")
                tn1supedithigh=intent.getStringExtra("tn1edithigh")
                fon1supedithigh=intent.getStringExtra("fon1edithigh")
                fifn1supedithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                mresultsarr=intent.getStringArrayListExtra("mresultsarr")

            }
            catch (e:Exception){

            }

            textView1.setText(sup_name)
            textView22.setText(sup_id)
            println(sup_id)
            textView33.setText(sup_cont)
            textView4.setText(sup_mob.toString())
            textView5.setText(sup_mob1.toString())
            textView6.setText(sup_mob2.toString())
            textView7.setText(sup_mobile)
            println(sup_mobile)
            textView8.setText(sup_mobile1)
            textView9.setText(sup_mobile2)
            textView10.setText(sup_addr)
            textView11.setText(sup_addr1)
            textView12.setText(sup_addr2)
            textView13.setText(sup_city)
            textView14.setText(sup_state)
            textView15.setText(sup_pin)
            println(sup_pin)
            textView16.setText(sup_gps)
            textView17.setText(sup_mail)
            println(sup_mail)
            textView18.setText(sup_gstcd)
            textView19.setText(sup_imgurl)
            textView20.setText(sup_status)

            textView21.setText(ids)

            if(sup_id!="Auto - generated") {


                suppnamevalidate = sup_name
                contactprsvalidate = sup_cont
                suppmobcat1validate = sup_mob.toString()
                suppmobcat2validate = sup_mob2.toString()
                suppmobcat3validate = sup_mob2.toString()
                suppmobilevalidate = sup_mobile.toString()
                suppmobile21validate = sup_mobile1
                suppmobile31validate = sup_mobile2
                suppaddress1validate = sup_addr
                suppaddress2validate = sup_addr1
                suppaddress3validate = sup_addr2
                suppcityvalidate = sup_city
                suppstatevalidate = sup_state
                supppinvalidate = sup_pin
                gpsvalidate = sup_gps
                suppemailvalidate = sup_mail
                suppgstvalidate = sup_gstcd

            }

            f1sup = imgurl6
            s1sup = imgurl7
            t1sup = imgurl8
            fo1sup = imgurl9
            fif1sup = imgurl10
            fn1sup= img1
            sn1sup= img2
            tn1sup= img3
            fon1sup = img4
            fifn1sup = img5




            val k = intent.getStringExtra("svky")
            savekey.setText(k)

            if (ad != null) {
                addsupppro = ad
            }
            if (ed != null) {
                editesupppro = ed
            }
            if (dele != null) {
                deletesupppro = dele
            }
            if (vie != null) {
                viewsupppro = vie
            }
            if (imp != null) {
                importsupppro = imp
            }
            if (expo != null) {
                exportsupppro = expo
            }
            id.setText(b)
            prokey.setText(c)
            println("IDSS OF LIST CLICK IDDDDD" + id.text)
            println("CATEGORY"+maincat)

            profab="frmlist"

            if (id.text.isNotEmpty()) {
                supprosave.visibility = View.INVISIBLE
                edit.visibility = View.VISIBLE
                clear.visibility = View.INVISIBLE
                userback.visibility = View.VISIBLE

                db.collection("supplier_products").document(id.text.toString())
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                if (task.result != null) {
                                    Log.d("data", "is" + task.result.data)
                                    sup_pname.setText(task.result.get("sp_nm").toString())
                                    sup_pid.setText(task.result.get("sp_id").toString())
                                    sup_vol.setText(task.result.get("spwg_vol").toString())
                                   var k=task.result.get("sput").toString()
                                   var kmanu=task.result.get("spmfr").toString()
                                    var categ=task.result.get("spctgy").toString()
                                    sup_bcode.setText(task.result.get("spbc").toString())
                                    sup_hsc.setText(task.result.get("sphsn").toString())
                                    sup_hscdes.setText(task.result.get("spdesc").toString())
                                    sup_price.setText(task.result.get("spprice").toString())
                                    sup_taxcheck.setChecked(task.result.get("sptaxchk").toString().toBoolean())
                                    sup_intgst.setText(task.result.get("spigst").toString())
                                    sup_cess.setText(task.result.get("spcess").toString())
                                    sup_centgst.setText(task.result.get("spcgst").toString())
                                    sup_stategst.setText(task.result.get("spsgst").toString())
                                    sup_taxtot.setText(task.result.get("sptaxtot").toString())
                                    sup_cessvalue.setText(task.result.get("spcesstot").toString())
                                    sup_mrp.setText(task.result.get("spmrp").toString())

                                    sup_maxstock.setText(task.result.get("spmx_stk").toString())
                                    sup_minstock.setText(task.result.get("spmin_stk").toString())
                                    sup_stockhand.setText(task.result.get("spstock_hand").toString())



                                    disable.setText(task.result.get("status").toString())

                                  fn1 = task.result.get("img1n").toString()
                                    sn1 = task.result.get("img2n").toString()
                                 tn1 = task.result.get("img3n").toString()
                                   fon1 = task.result.get("img4n").toString()
                                    fifn1 = task.result.get("img5n").toString()

                                   f1 = task.result.get("img1url").toString()
                                    println("IMG names" + fn1)
                                    s1 = task.result.get("img2url").toString()
                                 t1 = task.result.get("img3url").toString()
                                 fo1 = task.result.get("img4url").toString()
                                    fif1 = task.result.get("img5url").toString()

                                    img1nhigh = task.result.get("img1nhigh").toString()
                                    img2nhigh = task.result.get("img2nhigh").toString()
                                    img3nhigh = task.result.get("img3nhigh").toString()
                                    img4nhigh = task.result.get("img4nhigh").toString()
                                    img5nhigh = task.result.get("img5nhigh").toString()

                                    img1urlhigh = task.result.get("img1urlhigh").toString()
                                    img2urlhigh = task.result.get("img2urlhigh").toString()
                                    img3urlhigh = task.result.get("img3urlhigh").toString()
                                    img4urlhigh = task.result.get("img4urlhigh").toString()
                                    img5urlhigh = task.result.get("img5urlhigh").toString()

                                    fn1edithigh= task.result.get("img1nhigh").toString()
                                    sn1edithigh= task.result.get("img2nhigh").toString()
                                    tn1edithigh= task.result.get("img3nhigh").toString()
                                    fon1edithigh= task.result.get("img4nhigh").toString()
                                    fifn1edithigh= task.result.get("img5nhigh").toString()

                                    f1edithigh = task.result.get("img1urlhigh").toString()
                                    s1edithigh = task.result.get("img2urlhigh").toString()
                                    t1edithigh = task.result.get("img3urlhigh").toString()
                                    fo1edithigh = task.result.get("img4urlhigh").toString()
                                    fif1edithigh = task.result.get("img5urlhigh").toString()

                                    f1 = task.result.get("img1url").toString()
                                    println("IMG names" + fn1)
                                    s1 = task.result.get("img2url").toString()
                                    t1 = task.result.get("img3url").toString()
                                    fo1 = task.result.get("img4url").toString()
                                    fif1 = task.result.get("img5url").toString()


                                    fn1edit = task.result.get("img1n").toString()
                                    sn1edit = task.result.get("img2n").toString()
                                    tn1edit = task.result.get("img3n").toString()
                                    fon1edit = task.result.get("img4n").toString()
                                    fifn1edit = task.result.get("img5n").toString()

                                    f1edit = task.result.get("img1url").toString()
                                    println("IMG names" + fn1)
                                    s1edit = task.result.get("img2url").toString()
                                    t1edit = task.result.get("img3url").toString()
                                    fo1edit = task.result.get("img4url").toString()
                                    fif1edit = task.result.get("img5url").toString()


                                    pnamevalidate=task.result.get("sp_nm").toString()
                                    volvalidate=task.result.get("spwg_vol").toString()
                                    bcodeidvalidate= (task.result.get("spbc").toString())
                                    hscvalidate=(task.result.get("sphsn").toString())
                                    hscdesvalidate= (task.result.get("spdesc").toString())
                                    maincatvalidate= task.result.get("spctgy").toString()
                                    subcatvalidate=task.result.get("spmfr").toString()
                                    listvalidate=task.result.get("sput").toString()
                                    pricevalidate=(task.result.get("spprice").toString())
                                    taxcheckvalidate=task.result.get("sptaxchk").toString()
                                    intgstvalidate=(task.result.get("spigst").toString())
                                    cessvaluevalidate=(task.result.get("spcess").toString())
                                    maxstockvalidate=task.result.get("spmx_stk").toString()
                                    minstockvalidate=task.result.get("spmin_stk").toString()
                                    stockhandvalidate=task.result.get("spstock_hand").toString()






                                    if (f1.isNullOrEmpty() == false || s1.isNullOrEmpty() == false || t1.isNullOrEmpty() == false || fo1.isNullOrEmpty() == false || fif1.isNullOrEmpty() == false) {


                                        scrollpro.visibility = View.VISIBLE


                                        scroll2_slider2.visibility = View.VISIBLE
                                        imageView41.visibility = View.GONE
                                        imageButton2.visibility = View.GONE
                                        gallery.visibility = View.VISIBLE
                                        if (f1.isNullOrEmpty() == false) {
                                            f1 = f1.toString()




                                        }
                                        if (s1.isNullOrEmpty() == false) {
                                            s1 = s1.toString()

                                        }
                                        if (t1.isNullOrEmpty() == false) {
                                            t1 = t1.toString()

                                        }
                                        if (fo1.isNullOrEmpty() == false) {
                                            fo1 = fo1.toString()

                                        }
                                        if (fif1.isNullOrEmpty() == false) {
                                            fif1 = fif1.toString()

                                        }
                                        if (fn1.isNullOrEmpty() == false) {
                                            fn1 = fn1.toString()


                                            img1nhigh=img1nhigh.toString()



                                            try {

                                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                                val dir = File(path);
                                                if (!dir.exists())
                                                    dir.mkdirs()

                                                val k = img1nhigh
                                                val recacnm = k.removeSuffix(".jpg")

                                                var y = recacnm + ".png"

                                                val file = File(dir, y)
                                                println("CONTENT URI" + file)
                                                if (file.exists()) {
                                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                                    file_mapspro.add(contentUri.toString())
                                                }
                                                else{
                                                    file_mapspro.add(f1)
                                                }
                                            }
                                            catch (e:Exception){
                                                file_mapspro.add(f1)
                                            }
                                        }
                                        if (sn1.isNullOrEmpty() == false) {
                                            sn1 = sn1.toString()

                                            img2nhigh=img2nhigh.toString()



                                            try {

                                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                                val dir = File(path);
                                                if (!dir.exists())
                                                    dir.mkdirs()

                                                val k = img2nhigh
                                                val recacnm = k.removeSuffix(".jpg")

                                                var y = recacnm + ".png"

                                                val file = File(dir, y)
                                                println("CONTENT URI" + file)
                                                if (file.exists()) {
                                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                                    file_mapspro.add(contentUri.toString())
                                                }
                                                else{
                                                    file_mapspro.add(s1)
                                                }
                                            }
                                            catch (e:Exception){
                                                file_mapspro.add(s1)
                                            }
                                        }
                                        if (tn1.isNullOrEmpty() == false) {
                                            tn1 = tn1.toString()

                                            img3nhigh=img3nhigh.toString()



                                            try {

                                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                                val dir = File(path);
                                                if (!dir.exists())
                                                    dir.mkdirs()

                                                val k = img3nhigh
                                                val recacnm = k.removeSuffix(".jpg")

                                                var y = recacnm + ".png"

                                                val file = File(dir, y)
                                                println("CONTENT URI" + file)
                                                if (file.exists()) {
                                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                                    file_mapspro.add(contentUri.toString())
                                                }
                                                else{
                                                    file_mapspro.add(t1)
                                                }
                                            }
                                            catch (e:Exception){
                                                file_mapspro.add(t1)
                                            }
                                        }
                                        if (fon1.isNullOrEmpty() == false) {
                                            fon1 = fon1.toString()

                                            img4nhigh=img4nhigh.toString()



                                            try {

                                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                                val dir = File(path);
                                                if (!dir.exists())
                                                    dir.mkdirs()

                                                val k = img4nhigh
                                                val recacnm = k.removeSuffix(".jpg")

                                                var y = recacnm + ".png"

                                                val file = File(dir, y)
                                                println("CONTENT URI" + file)
                                                if (file.exists()) {
                                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                                    file_mapspro.add(contentUri.toString())
                                                }
                                                else{
                                                    file_mapspro.add(fo1)
                                                }
                                            }
                                            catch (e:Exception){
                                                file_mapspro.add(fo1)
                                            }
                                        }
                                        if (fifn1.isNullOrEmpty() == false) {
                                            fifn1 = fifn1.toString()

                                            img5nhigh=img5nhigh.toString()



                                            try {

                                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                                val dir = File(path);
                                                if (!dir.exists())
                                                    dir.mkdirs()

                                                val k = img5nhigh
                                                val recacnm = k.removeSuffix(".jpg")

                                                var y = recacnm + ".png"

                                                val file = File(dir, y)
                                                println("CONTENT URI" + file)
                                                if (file.exists()) {
                                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                                    file_mapspro.add(contentUri.toString())
                                                }
                                                else{
                                                    file_mapspro.add(fif1)
                                                }
                                            }
                                            catch (e:Exception){
                                                file_mapspro.add(fif1)
                                            }

                                        }
                                    } else {
                                        scroll2_slider2.visibility = View.GONE

                                        scroll2_slider.visibility = View.VISIBLE

                                        imageView41.visibility = View.VISIBLE
                                        imageButton2.visibility = View.VISIBLE
                                        gallery.visibility = View.GONE
                                    }



                                    val image_view = findViewById<ImageView>(R.id.imageView41)
                                    val image_button = findViewById(R.id.imageButton2) as ImageView

                                    image_button.setOnClickListener {

                                        val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                                        b.putExtra("id", id.text.toString())
                                        b.putExtra("f1", f1)
                                        b.putExtra("fn1", fn1)
                                        b.putExtra("s1", s1)
                                        b.putExtra("sn1", sn1)
                                        b.putExtra("t1", t1)
                                        b.putExtra("tn1", tn1)
                                        b.putExtra("fo1", fo1)
                                        b.putExtra("fon1", fon1)
                                        b.putExtra("fif1", fif1)
                                        b.putExtra("fifn1", fifn1)
                                        b.putExtra("f1high", img1urlhigh)
                                        b.putExtra("fn1high", img1nhigh)
                                        b.putExtra("s1high", img2urlhigh)
                                        b.putExtra("sn1high", img2nhigh)
                                        b.putExtra("t1high", img3urlhigh)
                                        b.putExtra("tn1high",img3nhigh)
                                        b.putExtra("fo1high", img4urlhigh)
                                        b.putExtra("fon1high", img4nhigh)
                                        b.putExtra("fif1high", img5urlhigh)
                                        b.putExtra("fifn1high",img5nhigh)
                                        b.putExtra("mresult", mresultsarr)

                                        b.putExtra("listener",commlistener)

                                        b.putExtra("f1edithigh", f1edithigh)
                                        b.putExtra("fn1edithigh", fn1edithigh)
                                        b.putExtra("s1edithigh", s1edithigh)
                                        b.putExtra("sn1edithigh", sn1edithigh)
                                        b.putExtra("t1edithigh", t1edithigh)
                                        b.putExtra("tn1edithigh", tn1edithigh)
                                        b.putExtra("fo1edithigh", fo1edithigh)
                                        b.putExtra("fon1edithigh", fon1edithigh)
                                        b.putExtra("fif1edithigh", fif1edithigh)
                                        b.putExtra("fifn1edithigh", fifn1edithigh)
                                        b.putExtra("f1high", img1urlhigh)
                                        b.putExtra("fn1high", img1nhigh)
                                        b.putExtra("s1high", img2urlhigh)
                                        b.putExtra("sn1high", img2nhigh)
                                        b.putExtra("t1high", img3urlhigh)
                                        b.putExtra("tn1high",img3nhigh)
                                        b.putExtra("fo1high", img4urlhigh)
                                        b.putExtra("fon1high", img4nhigh)
                                        b.putExtra("fif1high", img5urlhigh)
                                        b.putExtra("fifn1high",img5nhigh)

                                        b.putExtra("f1edit", f1edit)
                                        b.putExtra("fn1edit", fn1edit)
                                        b.putExtra("s1edit", s1edit)
                                        b.putExtra("sn1edit", sn1edit)
                                        b.putExtra("t1edit", t1edit)
                                        b.putExtra("tn1edit", tn1edit)
                                        b.putExtra("fo1edit", fo1edit)
                                        b.putExtra("fon1edit", fon1edit)
                                        b.putExtra("fif1edit", fif1edit)
                                        b.putExtra("fifn1edit", fifn1edit)

                                        b.putExtra("addpro",addsupppro)
                                        b.putExtra("editpro",editesupppro)
                                        b.putExtra("deletepro",deletesupppro)
                                        b.putExtra("viewpro",viewsupppro)
                                        b.putExtra("importpro",importsupppro)
                                        b.putExtra("exportpro",exportsupppro)

                                        b.putExtra("edtcli",editclipro)




                                        startActivityForResult(b, 0)
                                        gallery.isEnabled = true
                                    }
                                    image_view.setOnClickListener {
                                        val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                                        b.putExtra("id", id.text.toString())
                                        b.putExtra("f1", f1)
                                        b.putExtra("fn1", fn1)
                                        b.putExtra("s1", s1)
                                        b.putExtra("sn1", sn1)
                                        b.putExtra("t1", t1)
                                        b.putExtra("tn1", tn1)
                                        b.putExtra("fo1", fo1)
                                        b.putExtra("fon1", fon1)
                                        b.putExtra("fif1", fif1)
                                        b.putExtra("fifn1", fifn1)

                                        b.putExtra("f1high", img1urlhigh)
                                        b.putExtra("fn1high", img1nhigh)
                                        b.putExtra("s1high", img2urlhigh)
                                        b.putExtra("sn1high", img2nhigh)
                                        b.putExtra("t1high", img3urlhigh)
                                        b.putExtra("tn1high",img3nhigh)
                                        b.putExtra("fo1high", img4urlhigh)
                                        b.putExtra("fon1high", img4nhigh)
                                        b.putExtra("fif1high", img5urlhigh)
                                        b.putExtra("fifn1high",img5nhigh)
                                        b.putExtra("mresult", mresultsarr)


                                        b.putExtra("listener",commlistener)
                                        b.putExtra("f1edithigh", f1edithigh)
                                        b.putExtra("fn1edithigh", fn1edithigh)
                                        b.putExtra("s1edithigh", s1edithigh)
                                        b.putExtra("sn1edithigh", sn1edithigh)
                                        b.putExtra("t1edithigh", t1edithigh)
                                        b.putExtra("tn1edithigh", tn1edithigh)
                                        b.putExtra("fo1edithigh", fo1edithigh)
                                        b.putExtra("fon1edithigh", fon1edithigh)
                                        b.putExtra("fif1edithigh", fif1edithigh)
                                        b.putExtra("fifn1edithigh", fifn1edithigh)
                                        b.putExtra("f1high", img1urlhigh)
                                        b.putExtra("fn1high", img1nhigh)
                                        b.putExtra("s1high", img2urlhigh)
                                        b.putExtra("sn1high", img2nhigh)
                                        b.putExtra("t1high", img3urlhigh)
                                        b.putExtra("tn1high",img3nhigh)
                                        b.putExtra("fo1high", img4urlhigh)
                                        b.putExtra("fon1high", img4nhigh)
                                        b.putExtra("fif1high", img5urlhigh)
                                        b.putExtra("fifn1high",img5nhigh)

                                        b.putExtra("f1edit", f1edit)
                                        b.putExtra("fn1edit", fn1edit)
                                        b.putExtra("s1edit", s1edit)
                                        b.putExtra("sn1edit", sn1edit)
                                        b.putExtra("t1edit", t1edit)
                                        b.putExtra("tn1edit", tn1edit)
                                        b.putExtra("fo1edit", fo1edit)
                                        b.putExtra("fon1edit", fon1edit)
                                        b.putExtra("fif1edit", fif1edit)
                                        b.putExtra("fifn1edit", fifn1edit)

                                        b.putExtra("addpro",addsupppro)
                                        b.putExtra("editpro",editesupppro)
                                        b.putExtra("deletepro",deletesupppro)
                                        b.putExtra("viewpro",viewsupppro)
                                        b.putExtra("importpro",importsupppro)
                                        b.putExtra("exportpro",exportsupppro)

                                        b.putExtra("edtcli",editclipro)


                                        startActivityForResult(b, 0)
                                        gallery.isEnabled = true
                                    }




                                    sup_pname.isEnabled = false
                                    sup_pid.isEnabled = false
                                    sup_vol.isEnabled = false
                                    imageButton2.isEnabled=false
                                    imageView41.isEnabled=false
                                    sup_unit.isEnabled = false
                                    sup_manu.isEnabled = false
                                    sup_cate.isEnabled = false
                                    sup_bcode.isEnabled = false
                                    sup_hsc.isEnabled = false
                                    sup_hscdes.isEnabled = false
                                    sup_price.isEnabled = false
                                    sup_taxcheck.isEnabled = false
                                    sup_intgst.isEnabled = false
                                    sup_cess.isEnabled = false
                                    sup_centgst.isEnabled = false
                                    sup_stategst.isEnabled = false
                                    sup_taxtot.isEnabled = false
                                    sup_cessvalue.isEnabled = false
                                    sup_mrp.isEnabled = false

                                    sup_maxstock.isEnabled = false
                                    sup_minstock.isEnabled = false
                                    sup_stockhand.isEnabled = false



                                    maincat1.add(categ)
                                    println("CATEG"+maincat)
                                    db.collection("productcategory")
                                            .get()
                                            .addOnCompleteListener {task->
                                                if (task.isSuccessful){
                                                    if (task.result != null){

                                                        maincatId.clear()

                                                        maincatId.add("")
                                                        for (document in task.result){

                                                            println("document id : "+document.id)
                                                            println("document data : "+document.data)
                                                            val dd=document.data
                                                            maincatId.add(document.id)
                                                            val c = dd["cat"].toString()



                                                            if(c==categ){
                                                                dup=c
                                                            }
                                                            else{
                                                                maincat1.add(c)
                                                            }



                                                            println(maincat)
                                                            println("CATEG"+maincat1)
                                                            sup_cate.adapter=adp11
                                                            /*  if (main.isNullOrEmpty()!=true){
                                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                                  cate.setSelection(spinnerPosition)
                                                              }*/
                                                        }
                                                    }
                                                }
                                            }



                                    val categories1 = ArrayList<String>()
                                    subcat1.add(kmanu)
                                    println("MANU SPIN"+subcat)

                                    db.collection("manufacturer")
                                            .get()
                                            .addOnCompleteListener {task->
                                                if (task.isSuccessful){
                                                    if (task.result != null){

                                                        maincatId.clear()

                                                        maincatId.add("")
                                                        for (document in task.result){
                                                            println("document id : "+document.id)
                                                            println("document data : "+document.data)
                                                            val dd=document.data
                                                            maincatId.add(document.id)
                                                            val c = dd["cat"].toString()



                                                            if(c==kmanu){
                                                                dup=c
                                                            }
                                                            else{
                                                                subcat1.add(c)
                                                            }
                                                            println(maincat)
                                                            println("MANU SPIN"+subcat1)
                                                            sup_manu.adapter=adp21
                                                            /*  if (main.isNullOrEmpty()!=true){
                                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                                  cate.setSelection(spinnerPosition)
                                                              }*/
                                                        }
                                                    }
                                                }
                                            }



                                    val categories2 = ArrayList<String>()
                                    list1.add(k)

                                    println("UNIT SPIN"+list)

                                    db.collection("unit")
                                            .get()
                                            .addOnCompleteListener {task->
                                                if (task.isSuccessful){

                                                    if (task.result != null){

                                                        maincatId.clear()

                                                        maincatId.add("")
                                                        for (document in task.result){
                                                            println("document id : "+document.id)
                                                            println("document data : "+document.data)
                                                            val dd=document.data
                                                            maincatId.add(document.id)
                                                            val c = dd["cat"].toString()




                                                            if(c==k){
                                                                dup=c
                                                            }
                                                            else{
                                                                list1.add(c)
                                                            }
                                                            println(maincat)
                                                            println("UNIT SPIN"+list1)
                                                            sup_unit.adapter=dataAdapter1
                                                            /*  if (main.isNullOrEmpty()!=true){
                                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                                  cate.setSelection(spinnerPosition)
                                                              }*/
                                                        }
                                                    }
                                                }
                                            }

                                } else {
                                    Log.d("data", "is not here")
                                }
                            } else {
                                Log.d("task is not success", "full" + task.exception)
                            }

                        }
            } else {
                supprosave.setText("SAVE")
            }






            pDialog.dismiss()


            edit.setOnClickListener {
                if (editesupppro == "true" || editesupppro.isNullOrEmpty()) {
                    edit.visibility = View.GONE
                    clear.visibility = View.INVISIBLE
                    userback.visibility = View.VISIBLE
                    supprosave.visibility = View.VISIBLE


                    editclipro="clicked"
                    supprosave.setText("SAVE")
                    sup_pname.isEnabled = true
                    sup_pid.isEnabled = false
                    sup_vol.isEnabled = true
                    sup_unit.isEnabled = true
                    sup_manu.isEnabled = true
                    sup_cate.isEnabled = true
                    sup_bcode.isEnabled = true
                    sup_hsc.isEnabled = true
                    sup_hscdes.isEnabled = true
                    sup_price.isEnabled = true
                    sup_taxcheck.isEnabled = true
                    sup_intgst.isEnabled = true
                    sup_cess.isEnabled = true
                    sup_centgst.isEnabled = true
                    sup_stategst.isEnabled = true
                    sup_taxtot.isEnabled = true
                    sup_cessvalue.isEnabled = true
                    sup_mrp.isEnabled = true
                    imageButton2.isEnabled=true
                    imageView41.isEnabled=true

                    sup_maxstock.isEnabled = true
                    sup_minstock.isEnabled = true
                    sup_stockhand.isEnabled = true
                } else if (editesupppro == "false") {
                    popup("edit")
                }


            }
        }



        /*  val mDemoSlider = findViewById<SliderLayout>(R.id.slider) as SliderLayout

        val file_maps = HashMap<String, Int>()
        file_maps.put("jkhdflh", R.drawable.loreal_bottl)
        file_maps.put("Big Bang Theory", R.drawable.loreal_bottl)
        file_maps.put("House of Cards", R.drawable.loreal_bottl)
        file_maps.put("Game of Thrones", R.drawable.loreal_bottl)
        for (name in file_maps.keys) {
            val textSliderView = TextSliderView(this)
            // initialize a SliderLayout
            textSliderView
                    //.description(name)
                    .image(file_maps.get(name)!!)
                    //.setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this)

            //add your extra information
            textSliderView.bundle(Bundle())
            textSliderView.bundle
                    .putString("extra", name)

            mDemoSlider.addSlider(textSliderView)
        }
        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default)
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
        mDemoSlider.setCustomAnimation(DescriptionAnimation())
        *//* mDemoSlider.setDuration(4000)*/

    /*    val categories = ArrayList<String>()
        categories.add("Hair")
        var db = FirebaseFirestore.getInstance()
        val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sup_cate.adapter = dataAdapter*/



        vert.setOnClickListener({


            val popup = PopupMenu(this@SuppProductAddActivity, vert)

            popup.menuInflater.inflate(R.menu.menu_main, popup.menu)
            val m1 = popup.menu.getItem(1)
            if (deletesupppro=="true"||deletesupppro.isNullOrEmpty()) {
                if (disable.text == "Disable") {
                    m1.title = "Enable product"


                    popup.setOnMenuItemClickListener { item ->
                        if (item.itemId == R.id.ex) {

                            val builder = android.app.AlertDialog.Builder(this@SuppProductAddActivity)
                            with(builder) {
                                setTitle("Enable")
                                setMessage("Please enable the product before you change stock")
                                setPositiveButton("ok") { dialog, whichButton ->

                                }


                                val dialog = builder.create()

                                dialog.show()
                            }


                        }

                        if (item.itemId == R.id.im) {


                            val builder = android.app.AlertDialog.Builder(this@SuppProductAddActivity)
                            with(builder) {
                                setTitle("Confirm?")
                                setMessage("Are you sure want to enable?")
                                setPositiveButton("Yes") { dialog, whichButton ->
                                    val pDialog = SweetAlertDialog(this@SuppProductAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialog.setTitleText("Enabling...");
                                    pDialog.setCancelable(false);
                                    pDialog.show();
                                    disable.setText("Active")
                                    var status = (disable.text).toString()

                                    val map = mutableMapOf<String, Any?>()
                                    map.put("status", status)
                                    db.collection("supplier_products").document(id.text.toString())
                                            .update(map)
                                            .addOnSuccessListener {


                                                pDialog.dismiss()
                                                Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()


                                                val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)

                                                i.putExtra("sndproky", "eventlist")

                                                val sname = (textView1.text).toString()
                                                val sid = textView22.text.toString()
                                                val scon = textView33.text.toString()
                                                val mob = textView4.text.toString()
                                                val mob1 = textView5.text.toString()
                                                val mob2 = textView6.text.toString()
                                                val mobile = textView7.text.toString()
                                                val mobile1 = textView8.text.toString()
                                                val mobile2 = textView9.text.toString()
                                                val saddre = textView10.text.toString()
                                                val saddre1 = textView11.text.toString()
                                                val saddre2 = textView12.text.toString()
                                                val scity = textView13.text.toString()
                                                val sstate = textView14.text.toString()
                                                val spin = textView15.text.toString()
                                                val sgps = textView16.text.toString()
                                                val smail = textView17.text.toString()
                                                val sgstcode = textView18.text.toString()
                                                val urlim = textView19.text.toString()
                                                val sids = textView20.text.toString()
                                                val status = textView21.text.toString()

                                                i.putExtra("addspro", addsupppro)
                                                i.putExtra("editspro", editesupppro)
                                                i.putExtra("viewspro", viewsupppro)
                                                i.putExtra("deletespro", deletesupppro)
                                                i.putExtra("importspro", importsupppro)
                                                i.putExtra("exportspro", exportsupppro)
                                                i.putExtra("keys", prokey.text.toString())
                                                i.putExtra("editclipro",editclipro)
                                                i.putExtra("editclisupp",editclisupp)

                                                i.putExtra("prret_sname1", sname)

                                                i.putExtra("proret_sid1", sid)
                                                i.putExtra("proret_scon1", scon)
                                                i.putExtra("proret_mob", mob)
                                                i.putExtra("proret_mob1", mob1)
                                                i.putExtra("proret_mob2", mob2)
                                                i.putExtra("proret_mobile", mobile)
                                                i.putExtra("proret_mobile1", mobile1)
                                                i.putExtra("proret_mobile2", mobile2)
                                                i.putExtra("proret_saddress", saddre)
                                                i.putExtra("proret_saddress1", saddre1)

                                                i.putExtra("proret_saddress2", saddre2)
                                                i.putExtra("listener",commlistener)
                                                i.putExtra("listenersave",listnersave)
                                                i.putExtra("fieldlistenersave",fieldlistenr)


                                                i.putExtra("proret_scity", scity)
                                                i.putExtra("proret_sstate", sstate)
                                                i.putExtra("proret_spin", spin)
                                                i.putExtra("proret_sgps", sgps)
                                                i.putExtra("proret_smail", smail)
                                                i.putExtra("proret_sgstcd", sgstcode)
                                                i.putExtra("proret_status", status)
                                                i.putExtra("proret_url", urlim)
                                                i.putExtra("proret_sids", sids)
                                                i.putExtra("retimg1", fn1sup)
                                                i.putExtra("retimg2", sn1sup)
                                                i.putExtra("retimg3", tn1sup)
                                                i.putExtra("retimg4", fon1sup)
                                                i.putExtra("retimg5", fifn1sup)
                                                i.putExtra("returl1", f1sup)
                                                i.putExtra("returl2", s1sup)
                                                i.putExtra("returl3", t1sup)
                                                i.putExtra("returl4", fo1sup)
                                                i.putExtra("returl5", fif1sup)


                                                i.putExtra("img1urlhigh",img1urlsuphigh)
                                                i.putExtra("img2urlhigh",img2urlsuphigh)
                                                i.putExtra("img3urlhigh",img3urlsuphigh)
                                                i.putExtra("img4urlhigh",img4urlsuphigh)
                                                i.putExtra("img5urlhigh",img5urlsuphigh)
                                                i.putExtra("img1nhigh",img1nsuphigh)
                                                i.putExtra("img2nhigh",img2nsuphigh)
                                                i.putExtra("img3nhigh",img3nsuphigh)
                                                i.putExtra("img4nhigh",img4nsuphigh)
                                                i.putExtra("img5nhigh",img5nsuphigh)


                                                i.putExtra("f1edit",f1supedit)
                                                i.putExtra("s1edit",s1supedit)
                                                i.putExtra("t1edit",t1supedit)
                                                i.putExtra("fo1edit",fo1supedit)
                                                i.putExtra("fif1edit",fif1supedit)
                                                i.putExtra("fn1edit",fn1supedit)
                                                i.putExtra("sn1edit",sn1supedit)
                                                i.putExtra("tn1edit",tn1supedit)
                                                i.putExtra("fon1edit",fon1supedit)
                                                i.putExtra("fifn1edit",fifn1supedit)
                                                i.putExtra("f1edithigh",f1supedithigh)
                                                i.putExtra("s1edithigh",s1supedithigh)
                                                i.putExtra("t1edithigh",t1supedithigh)
                                                i.putExtra("fo1edithigh",fo1supedithigh)
                                                i.putExtra("fif1edithigh",fif1supedithigh)
                                                i.putExtra("fn1edithigh",fn1supedithigh)
                                                i.putExtra("sn1edithigh",sn1supedithigh)
                                                i.putExtra("tn1edithigh",tn1supedithigh)
                                                i.putExtra("fon1edithigh",fon1supedithigh)
                                                i.putExtra("fifn1edithigh",fifn1supedithigh)

                                                i.putExtra("file_maps",file_maps)
                                                i.putExtra("mresultsarr",mresultsarr)

                                                i.putExtra("startlistprky",startlistprokey)
                                                i.putExtra("profrmprky",productprokey)

                                                startActivity(i)
                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                finish()


                                            }
                                }
                                setNegativeButton("No") { dialog, whichButton ->
                                    dialog.dismiss()
                                }

                                val dialog = builder.create()

                                dialog.show()
                            }

                        }




                        true
                    }



                    popup.show()
                } else if (disable.text == "Active") {


                    m1.title = "Disable product"
                    popup.setOnMenuItemClickListener { item ->

                        if (item.itemId == R.id.ex) {


                            if(editesupppro=="true") {
                                val alert = AlertDialog.Builder(this@SuppProductAddActivity)
                                val inflater = this.layoutInflater
                                /*with(alert) {
            setTitle("Select Branch")
            }*/
                                val dialog = alert.create()
                                dialog.setView(inflater.inflate(R.layout.stock_popup, null))
                                dialog.show()
                                val stkedt = dialog.findViewById<EditText>(R.id.stkhand) as EditText

                                stkedt.text=sup_stockhand.text

                                val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                                val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                                okact.setOnClickListener {

                                    val h = stkedt.text
                                    sup_stockhand.setText(h)
                                    dialog.hide()


                                }
                                cancelact.setOnClickListener {
                                    dialog.hide()
                                }
                            }
                            else if(editesupppro=="false"){
                                popup("change stock")
                            }

                        }


                        if (item.itemId == R.id.im) {


                            val builder = android.app.AlertDialog.Builder(this@SuppProductAddActivity)
                            with(builder) {
                                setTitle("Confirm?")
                                setMessage("Are you sure want to disable?")
                                setPositiveButton("Yes") { dialog, whichButton ->
                                    val pDialog = SweetAlertDialog(this@SuppProductAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialog.setTitleText("Disabling...");
                                    pDialog.setCancelable(false);
                                    pDialog.show();
                                    disable.setText("Disable")
                                    var status = (disable.text).toString()

                                    val map = mutableMapOf<String, Any?>()
                                    map.put("status", status)
                                    db.collection("supplier_products").document(id.text.toString())
                                            .update(map)
                                            .addOnSuccessListener {


                                                pDialog.dismiss()
                                                Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                                val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)

                                                i.putExtra("sndproky", "eventlist")

                                                val sname = (textView1.text).toString()
                                                val sid = textView22.text.toString()
                                                val scon = textView33.text.toString()
                                                val mob = textView4.text.toString()
                                                val mob1 = textView5.text.toString()
                                                val mob2 = textView6.text.toString()
                                                val mobile = textView7.text.toString()
                                                val mobile1 = textView8.text.toString()
                                                val mobile2 = textView9.text.toString()
                                                val saddre = textView10.text.toString()
                                                val saddre1 = textView11.text.toString()
                                                val saddre2 = textView12.text.toString()
                                                val scity = textView13.text.toString()
                                                val sstate = textView14.text.toString()
                                                val spin = textView15.text.toString()
                                                val sgps = textView16.text.toString()
                                                val smail = textView17.text.toString()
                                                val sgstcode = textView18.text.toString()
                                                val urlim = textView19.text.toString()
                                                val sids = textView20.text.toString()
                                                val status = textView21.text.toString()

                                                i.putExtra("addspro", addsupppro)
                                                i.putExtra("editspro", editesupppro)
                                                i.putExtra("viewspro", viewsupppro)
                                                i.putExtra("deletespro", deletesupppro)
                                                i.putExtra("importspro", importsupppro)
                                                i.putExtra("exportspro", exportsupppro)
                                                i.putExtra("keys", prokey.text.toString())
                                                i.putExtra("editclipro",editclipro)
                                                i.putExtra("editclisupp",editclisupp)

                                                i.putExtra("prret_sname1", sname)

                                                i.putExtra("proret_sid1", sid)
                                                i.putExtra("proret_scon1", scon)
                                                i.putExtra("proret_mob", mob)
                                                i.putExtra("proret_mob1", mob1)
                                                i.putExtra("proret_mob2", mob2)
                                                i.putExtra("proret_mobile", mobile)
                                                i.putExtra("proret_mobile1", mobile1)
                                                i.putExtra("proret_mobile2", mobile2)
                                                i.putExtra("proret_saddress", saddre)
                                                i.putExtra("proret_saddress1", saddre1)

                                                i.putExtra("proret_saddress2", saddre2)
                                                i.putExtra("listener",commlistener)
                                                i.putExtra("listenersave",listnersave)
                                                i.putExtra("fieldlistenersave",fieldlistenr)

                                                try {
                                                    i.putExtra("startlistprky", startlistprokey)

                                                    i.putExtra("profrmprky", productprokey)
                                                }
                                                catch (e:Exception){

                                                }



                                                i.putExtra("proret_scity", scity)
                                                i.putExtra("proret_sstate", sstate)
                                                i.putExtra("proret_spin", spin)
                                                i.putExtra("proret_sgps", sgps)
                                                i.putExtra("proret_smail", smail)
                                                i.putExtra("proret_sgstcd", sgstcode)
                                                i.putExtra("proret_status", status)
                                                i.putExtra("proret_url", urlim)
                                                i.putExtra("proret_sids", sids)
                                                i.putExtra("retimg1", fn1sup)
                                                i.putExtra("retimg2", sn1sup)
                                                i.putExtra("retimg3", tn1sup)
                                                i.putExtra("retimg4", fon1sup)
                                                i.putExtra("retimg5", fifn1sup)
                                                i.putExtra("returl1", f1sup)
                                                i.putExtra("returl2", s1sup)
                                                i.putExtra("returl3", t1sup)
                                                i.putExtra("returl4", fo1sup)
                                                i.putExtra("returl5", fif1sup)

                                                i.putExtra("img1urlhigh",img1urlsuphigh)
                                                i.putExtra("img2urlhigh",img2urlsuphigh)
                                                i.putExtra("img3urlhigh",img3urlsuphigh)
                                                i.putExtra("img4urlhigh",img4urlsuphigh)
                                                i.putExtra("img5urlhigh",img5urlsuphigh)
                                                i.putExtra("img1nhigh",img1nsuphigh)
                                                i.putExtra("img2nhigh",img2nsuphigh)
                                                i.putExtra("img3nhigh",img3nsuphigh)
                                                i.putExtra("img4nhigh",img4nsuphigh)
                                                i.putExtra("img5nhigh",img5nsuphigh)


                                                i.putExtra("f1edit",f1supedit)
                                                i.putExtra("s1edit",s1supedit)
                                                i.putExtra("t1edit",t1supedit)
                                                i.putExtra("fo1edit",fo1supedit)
                                                i.putExtra("fif1edit",fif1supedit)
                                                i.putExtra("fn1edit",fn1supedit)
                                                i.putExtra("sn1edit",sn1supedit)
                                                i.putExtra("tn1edit",tn1supedit)
                                                i.putExtra("fon1edit",fon1supedit)
                                                i.putExtra("fifn1edit",fifn1supedit)
                                                i.putExtra("f1edithigh",f1supedithigh)
                                                i.putExtra("s1edithigh",s1supedithigh)
                                                i.putExtra("t1edithigh",t1supedithigh)
                                                i.putExtra("fo1edithigh",fo1supedithigh)
                                                i.putExtra("fif1edithigh",fif1supedithigh)
                                                i.putExtra("fn1edithigh",fn1supedithigh)
                                                i.putExtra("sn1edithigh",sn1supedithigh)
                                                i.putExtra("tn1edithigh",tn1supedithigh)
                                                i.putExtra("fon1edithigh",fon1supedithigh)
                                                i.putExtra("fifn1edithigh",fifn1supedithigh)

                                                i.putExtra("file_maps",file_maps)
                                                i.putExtra("mresultsarr",mresultsarr)

                                                startActivity(i)
                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                finish()


                                            }
                                }
                                setNegativeButton("No") { dialog, whichButton ->
                                    dialog.dismiss()
                                }

                                val dialog = builder.create()

                                dialog.show()
                            }
                        }
                        true
                    }
                    popup.show()

                }
            }



            else if (deletesupppro=="false"){
                popup("Disable or Enable")
            }

        })


        db.collection("productcategory")
                .get()
                .addOnCompleteListener {task->
                    if (task.isSuccessful){
                        if (task.result != null){
                            maincat.clear()
                            maincatId.clear()
                            maincat.add("Select")
                            maincatId.add("")
                            for (document in task.result){
                                println("document id : "+document.id)
                                println("document data : "+document.data)
                                val dd=document.data
                                maincatId.add(document.id)
                                val c = dd["cat"].toString()
                                maincat.add(c)
                                println(maincat)
                                sup_cate.adapter=adp1
                                /*  if (main.isNullOrEmpty()!=true){
                                      val spinnerPosition = adp1.getPosition(main.toString())
                                      cate.setSelection(spinnerPosition)
                                  }*/
                            }
                        }
                    }
                }


        db.collection("unit")
                .get()
                .addOnCompleteListener {task->
                    if (task.isSuccessful){

                        if (task.result != null){
                            list.clear()
                            maincatId.clear()
                            list.add("Select")
                            maincatId.add("")
                            for (document in task.result){
                                println("document id : "+document.id)
                                println("document data : "+document.data)
                                val dd=document.data
                                maincatId.add(document.id)
                                val c = dd["cat"].toString()
                                list.add(c)
                                println(maincat)
                                sup_unit.adapter=dataAdapter
                                /*  if (main.isNullOrEmpty()!=true){
                                      val spinnerPosition = adp1.getPosition(main.toString())
                                      cate.setSelection(spinnerPosition)
                                  }*/
                            }
                        }
                    }
                }


        db.collection("manufacturer")
                .get()
                .addOnCompleteListener {task->
                    if (task.isSuccessful){
                        if (task.result != null){
                            subcat.clear()
                            maincatId.clear()
                            subcat.add("Select")
                            maincatId.add("")
                            for (document in task.result){
                                println("document id : "+document.id)
                                println("document data : "+document.data)
                                val dd=document.data
                                maincatId.add(document.id)
                                val c = dd["cat"].toString()
                                subcat.add(c)
                                println(maincat)
                                sup_manu.adapter=adp2
                                /*  if (main.isNullOrEmpty()!=true){
                                      val spinnerPosition = adp1.getPosition(main.toString())
                                      cate.setSelection(spinnerPosition)
                                  }*/
                            }
                        }
                    }
                }

     /*   val categories2 = ArrayList<String>()
        categories2.add("Loreal Professional")
        val dataAdapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_item,categories2)
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sup_manu.adapter = dataAdapter2

        val categories3 = ArrayList<String>()
        categories3.add("ml")
        val dataAdapter3 = ArrayAdapter(this, android.R.layout.simple_spinner_item,categories3)
        dataAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sup_unit.adapter = dataAdapter3*/


        //Tax Checkbox
        //Tax Checkbox
        sup_taxcheck.setOnCheckedChangeListener { compoundButton, b ->

            if (sup_taxcheck.isChecked == true) {
                sup_intgst.isEnabled = true
                sup_cess.isEnabled = true
                sup_centgst.isEnabled = false
                sup_stategst.isEnabled = false
            } else {
                sup_intgst.isEnabled = false
                sup_intgst.setText("")
                sup_cess.isEnabled = false
                sup_cess.setText("")
                sup_centgst.isEnabled = false
                sup_centgst.setText("")
                sup_stategst.isEnabled = false
                sup_stategst.setText("")
                sup_mrp.setText(DecimalFormat("#.00").format(sup_price.text.toString()))

            }
        }








//Price
        sup_price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (pr.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (sup_intgst.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = sup_intgst.text.toString().replace("%", "").toFloat()
                }
                if (sup_cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = sup_cess.text.toString().replace("%", "").toFloat()
                }
                errorprice.visibility = View.INVISIBLE
                //cgst & sgst
                val ans = igst / 2
                sup_centgst.setText("$ans" + "%")
                sup_stategst.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                sup_taxtot.setText(DecimalFormat("##.##").format(ttot))

                //cess total
                val cesstot = (pri * ces) / 100
                sup_cessvalue.setText(DecimalFormat("##.##").format(cesstot))

                //gross total
                val g = ttot + pri + cesstot
                sup_mrp.setText(DecimalFormat("#.00").format(g))

                          }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if(sup_price.text.toString()==""){
                    commlistener = ""
                }

            }
        })

//Intagrated Tax
        sup_intgst.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (sup_price.text.isEmpty()){
                    pri = 0.0F
                } else {
                    pri = sup_price.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (sup_cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = sup_cess.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                sup_centgst.setText("$ans" + "%")
                sup_stategst.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                sup_taxtot.setText(DecimalFormat("##.##").format(ttot))

                //cess total
                val cesstot = (pri * ces) / 100
                sup_cessvalue.setText(DecimalFormat("##.##").format(cesstot))

                //gross total
                val g = ttot + pri + cesstot
                sup_mrp.setText(DecimalFormat("#.00").format(g))

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if(sup_intgst.text.toString()==""){
                    commlistener = ""
                }
            }
        })
//cess
        sup_cess.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (sup_price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = sup_price.text.toString().toFloat()
                }
                if (sup_intgst.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = sup_intgst.text.toString().replace("%", "").toFloat()
                }
                if (cess.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.toString().replace("%", "").toFloat()
                }


                //cgst & sgst
                val ans = igst / 2
                sup_centgst.setText("$ans" + "%")
                sup_stategst.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                sup_taxtot.setText(DecimalFormat("##.##").format(ttot))

                //cess total
                val cesstot = (pri * ces) / 100
                sup_cessvalue.setText(DecimalFormat("##.##").format(cesstot))

                //gross total
                val g = ttot + pri + cesstot
                sup_mrp.setText(DecimalFormat("#.00").format(g))

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if(sup_cess.text.toString()==""){
                    commlistener = ""
                }
            }
        })


        sup_pname.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                errorpnm.visibility = View.INVISIBLE

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if(sup_pname.text.toString()==""){
                    commlistener = ""
                }
            }
        })

        gallery.setOnClickListener {
            scroll2_slider.removeAllSliders()
            gallery.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_product::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("mresult", mresultsarr)

            b.putExtra("listener",commlistener)

            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)

            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)

            b.putExtra("addpro",addsupppro)
            b.putExtra("editpro",editesupppro)
            b.putExtra("deletepro",deletesupppro)
            b.putExtra("viewpro",viewsupppro)
            b.putExtra("importpro",importsupppro)
            b.putExtra("exportpro",exportsupppro)

            b.putExtra("edtcli",editclipro)


            startActivityForResult(b, 0)
            gallery.isEnabled = true
        }

        scroll2_slider.setOnClickListener {
            scroll2_slider.removeAllSliders()
            scroll2_slider.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_product::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)

            b.putExtra("addpro",addsupppro)
            b.putExtra("editpro",editesupppro)
            b.putExtra("deletepro",deletesupppro)
            b.putExtra("viewpro",viewsupppro)
            b.putExtra("importpro",importsupppro)
            b.putExtra("exportpro",exportsupppro)

            b.putExtra("edtcli",editclipro)

            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("mresult", mresultsarr)

            b.putExtra("listener",commlistener)

            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)


            startActivityForResult(b, 0)
            scroll2_slider.isEnabled = true
        }



        clear.setOnClickListener {
            clear.visibility = View.INVISIBLE
            userback.visibility = View.VISIBLE


            sup_pname.setText("")
            sup_vol.setText("")

            sup_bcode.setText("")
            sup_hsc.setText("")
            sup_hscdes.setText("")
            sup_price.setText("")
            sup_intgst.setText("")
            sup_cess.setText("")
            sup_centgst.setText("")
            sup_stategst.setText("")
            sup_taxtot.setText("")

            sup_cessvalue.setText("")
            sup_mrp.setText("")
            sup_stockhand.setText("")
            sup_maxstock.setText("")
            sup_minstock.setText("")
        }

        supprosave.setOnClickListener { view ->
            if(net_status()==true) {
                if (sup_pname.length() == 0) {
                    errorpnm.visibility = View.VISIBLE
                    Toast.makeText(applicationContext, "Product name required", Toast.LENGTH_SHORT).show()
                    errorpnm.setError("Field cannot be empty")
                    errorpnm.setText("Field cannot be empty")
                }
                if (sup_price.length() == 0) {
                    errorprice.visibility = View.VISIBLE
                    Toast.makeText(applicationContext, "Product price required", Toast.LENGTH_SHORT).show()
                    errorprice.setError("Field cannot be empty")
                    errorprice.setText("Field cannot be empty")
                }
                if ((id.text == "") && (errorpnm.visibility == View.INVISIBLE) && (errorprice.visibility == View.INVISIBLE)) {
                    Toast.makeText(applicationContext, "Saving...", Toast.LENGTH_LONG).show()
                    onStarClicked1()
                    println("IN TIMEEEE")
                }


                if(id.text.toString().isNotEmpty()) {
                    if ((pnamevalidate != sup_pname.text.toString()) || (volvalidate != sup_vol.text.toString()) || (bcodeidvalidate != sup_bcode.text.toString()) ||
                            (hscvalidate != sup_hsc.text.toString()) || (hscdesvalidate != sup_hscdes.text.toString()) || (maincatvalidate != sup_cate.selectedItem.toString()) ||
                            (subcatvalidate != sup_manu.selectedItem.toString()) || (listvalidate != sup_unit.selectedItem.toString()) || (pricevalidate != sup_price.text.toString())
                            || (taxcheckvalidate != sup_taxcheck.isChecked.toString()) || (intgstvalidate != sup_intgst.text.toString()) || (cessvaluevalidate != sup_cess.text.toString())
                            || (maxstockvalidate != sup_maxstock.text.toString()) || (minstockvalidate != sup_minstock.text.toString()) || (stockhandvalidate != sup_stockhand.text.toString())) {

                        commlistener = "change"
                        println("ONBACK URL1 NOT EQUAL" + f1)

                    } else if (((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))) {
                        println("ONBACK URL1 EDIT NOT EQUAl" + f1)
                        commlistener = "change"
                    }

                    var pid = (sup_pid.text).toString()
                    var pname = (sup_pname.text).toString()
                    var bcode = (sup_bcode.text).toString()
                    var pdes = (sup_hscdes.text).toString()

                    var weight = (sup_vol.text).toString()
                    var psac = (sup_hsc.text).toString()
                    var stockonhand = (sup_stockhand.text).toString()

                    var minstock = (sup_minstock.text).toString()
                    var maxstock = (sup_maxstock.text).toString()
                    var price = (sup_price.text).toString()
                    var taxable = (sup_taxcheck.isChecked).toString()
                    var igst = (sup_intgst.text).toString()
                    var cgst = (sup_centgst.text).toString()
                    var sgst = (sup_stategst.text).toString()
                    var cess = (sup_cess.text).toString()
                    var taxtotal = (sup_taxtot.text).toString()
                    var cessval = (sup_cessvalue.text).toString()
                    var saveky = (savekey.text).toString()

                    var mrP = (sup_mrp.text).toString()
                    try {
                        var cate = sup_cate.selectedItem.toString()
                        var manufacture = sup_manu.selectedItem.toString()
                        var ut = sup_unit.selectedItem.toString()

                        catetr = cate
                        uttr = ut
                        manutr = manufacture
                    } catch (e: Exception) {

                    }

                    var status = (disable.text).toString()


                    if (f1.isEmpty()) {

                    }

                    val img1n = fn1
                    val img2n = sn1
                    val img3n = tn1
                    val img4n = fon1
                    val img5n = fifn1
                    val img1url = f1
                    val img2url = s1
                    val img3url = t1
                    val img4url = fo1
                    val img5url = fif1


                    val data = s(sp_id = pid, sp_nm = pname, spbc = bcode, spdesc = pdes, spwg_vol = weight, sphsn = psac, spctgy = catetr,
                            spmfr = manutr, sput = uttr, spmin_stk = minstock, spprice = price, spmx_stk = maxstock,
                            sptaxchk = taxable, spigst = igst, spcgst = cgst, spsgst = sgst, spcess = cess, sptaxtot = taxtotal,
                            spcesstot = cessval, spmrp = mrP, status = status, spstock_hand = stockonhand,
                            spsave_key = saveky, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n,
                            img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url,
                            img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh,
                            img5nhigh = img5nhigh, img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)



                    if ((id.text != "") && (errorpnm.visibility == View.INVISIBLE) && (errorprice.visibility == View.INVISIBLE)&&(commlistener == "change")) {

                        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                        pDialog.setTitleText("Saving...");
                        pDialog.setCancelable(false);
                        pDialog.show();
                        val db = FirebaseFirestore.getInstance()

                        db.collection("supplier_products").document(id.text.toString())

                                .set(data)
                                .addOnSuccessListener {

                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                    pDialog.dismiss()
                                    val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                                    i.putExtra("sndproky", "eventlist")

                                    val sname = (textView1.text).toString()
                                    val sid = textView22.text.toString()
                                    val scon = textView33.text.toString()
                                    val mob = textView4.text.toString()
                                    val mob1 = textView5.text.toString()
                                    val mob2 = textView6.text.toString()
                                    val mobile = textView7.text.toString()
                                    val mobile1 = textView8.text.toString()
                                    val mobile2 = textView9.text.toString()
                                    val saddre = textView10.text.toString()
                                    val saddre1 = textView11.text.toString()
                                    val saddre2 = textView12.text.toString()
                                    val scity = textView13.text.toString()
                                    val sstate = textView14.text.toString()
                                    val spin = textView15.text.toString()
                                    val sgps = textView16.text.toString()
                                    val smail = textView17.text.toString()
                                    val sgstcode = textView18.text.toString()
                                    val urlim = textView19.text.toString()
                                    val sids = textView20.text.toString()
                                    val status = textView21.text.toString()

                                    i.putExtra("addspro", addsupppro)
                                    i.putExtra("editspro", editesupppro)
                                    i.putExtra("viewspro", viewsupppro)
                                    i.putExtra("deletespro", deletesupppro)
                                    i.putExtra("importspro", importsupppro)
                                    i.putExtra("exportspro", exportsupppro)
                                    i.putExtra("keys", prokey.text.toString())
                                    i.putExtra("editclipro", editclipro)
                                    i.putExtra("editclisupp", editclisupp)

                                    i.putExtra("prret_sname1", sname)

                                    i.putExtra("proret_sid1", sid)
                                    i.putExtra("proret_scon1", scon)
                                    i.putExtra("proret_mob", mob)
                                    i.putExtra("proret_mob1", mob1)
                                    i.putExtra("proret_mob2", mob2)
                                    i.putExtra("proret_mobile", mobile)
                                    i.putExtra("proret_mobile1", mobile1)
                                    i.putExtra("proret_mobile2", mobile2)
                                    i.putExtra("proret_saddress", saddre)
                                    i.putExtra("proret_saddress1", saddre1)

                                    i.putExtra("proret_saddress2", saddre2)
                                    i.putExtra("listener", commlistener)
                                    i.putExtra("listenersave", listnersave)
                                    i.putExtra("fieldlistenersave", fieldlistenr)


                                    i.putExtra("proret_scity", scity)
                                    i.putExtra("proret_sstate", sstate)
                                    i.putExtra("proret_spin", spin)
                                    i.putExtra("proret_sgps", sgps)
                                    i.putExtra("proret_smail", smail)
                                    i.putExtra("proret_sgstcd", sgstcode)
                                    i.putExtra("proret_status", status)
                                    i.putExtra("proret_url", urlim)
                                    i.putExtra("proret_sids", sids)
                                    i.putExtra("retimg1", fn1sup)
                                    i.putExtra("retimg2", sn1sup)
                                    i.putExtra("retimg3", tn1sup)
                                    i.putExtra("retimg4", fon1sup)
                                    i.putExtra("retimg5", fifn1sup)
                                    i.putExtra("returl1", f1sup)
                                    i.putExtra("returl2", s1sup)
                                    i.putExtra("returl3", t1sup)
                                    i.putExtra("returl4", fo1sup)
                                    i.putExtra("returl5", fif1sup)

                                    i.putExtra("img1urlhigh", img1urlsuphigh)
                                    i.putExtra("img2urlhigh", img2urlsuphigh)
                                    i.putExtra("img3urlhigh", img3urlsuphigh)
                                    i.putExtra("img4urlhigh", img4urlsuphigh)
                                    i.putExtra("img5urlhigh", img5urlsuphigh)
                                    i.putExtra("img1nhigh", img1nsuphigh)
                                    i.putExtra("img2nhigh", img2nsuphigh)
                                    i.putExtra("img3nhigh", img3nsuphigh)
                                    i.putExtra("img4nhigh", img4nsuphigh)
                                    i.putExtra("img5nhigh", img5nsuphigh)


                                    i.putExtra("f1edit", f1supedit)
                                    i.putExtra("s1edit", s1supedit)
                                    i.putExtra("t1edit", t1supedit)
                                    i.putExtra("fo1edit", fo1supedit)
                                    i.putExtra("fif1edit", fif1supedit)
                                    i.putExtra("fn1edit", fn1supedit)
                                    i.putExtra("sn1edit", sn1supedit)
                                    i.putExtra("tn1edit", tn1supedit)
                                    i.putExtra("fon1edit", fon1supedit)
                                    i.putExtra("fifn1edit", fifn1supedit)
                                    i.putExtra("f1edithigh", f1supedithigh)
                                    i.putExtra("s1edithigh", s1supedithigh)
                                    i.putExtra("t1edithigh", t1supedithigh)
                                    i.putExtra("fo1edithigh", fo1supedithigh)
                                    i.putExtra("fif1edithigh", fif1supedithigh)
                                    i.putExtra("fn1edithigh", fn1supedithigh)
                                    i.putExtra("sn1edithigh", sn1supedithigh)
                                    i.putExtra("tn1edithigh", tn1supedithigh)
                                    i.putExtra("fon1edithigh", fon1supedithigh)
                                    i.putExtra("fifn1edithigh", fifn1supedithigh)

                                    i.putExtra("file_maps", file_maps)
                                    i.putExtra("mresultsarr", mresultsarr)


                                    i.putExtra("startlistprky", startlistprokey)

                                    i.putExtra("profrmprky", productprokey)


                                    startActivity(i)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                    finish()


                                }

                                .addOnFailureListener {
                                    Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                                    save_progress.visibility = android.view.View.GONE
                                }


                    }
                    else if((id.text.toString().isNotEmpty())&&(commlistener.isEmpty())){
                        Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()

                    }
                }

            }
            else{
                Toast.makeText(applicationContext,"Please turn on your connection",Toast.LENGTH_SHORT).show()
            }

        }


        ///VALIDATION FOR SAV LISTENERS




        sup_vol.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {

                if (sup_vol.text.toString().equals("")) {
                    commlistener = ""
                }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {


            }
        })


        sup_hsc.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {

                if (sup_hsc.text.toString().equals("")) {
                    commlistener = ""
                }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {


            }
        })

        sup_hscdes.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {


                if (sup_hscdes.text.toString().equals("")) {
                    commlistener = ""
                }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {



            }
        })





        sup_stockhand.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {

                if (sup_stockhand.text.toString().equals("")) {
                    commlistener = ""
                }


            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {




            }
        })

        sup_maxstock.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {


                if (sup_maxstock.text.toString().equals("")) {
                    commlistener = ""
                }

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {


            }
        })

        sup_minstock.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {

                if (sup_minstock.text.toString().equals("")) {
                    commlistener = ""
                }


            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {


            }
        })












        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERMISSION_REQUEST)
        }
        sup_bcode.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->

            if ((sup_bcode.length() == 0) && (sup_bcode.isFocused == true)) {


                var pid = (sup_pid.text).toString()
                var pname = (sup_pname.text).toString()
                var bcode = (sup_bcode.text).toString()
                var pdes = (sup_hscdes.text).toString()

                var weight = (sup_vol.text).toString()
                var psac = (sup_hsc.text).toString()
                var stockonhand = (sup_stockhand.text).toString()

                var minstock = (sup_minstock.text).toString()
                var maxstock = (sup_maxstock.text).toString()
                var price = (sup_price.text).toString()
                var taxable = (sup_taxcheck.text).toString()
                var igst = (sup_intgst.text).toString()
                var cgst = (sup_centgst.text).toString()
                var sgst = (sup_stategst.text).toString()
                var cess = (sup_cess.text).toString()
                var taxtotal = (sup_taxtot.text).toString()
                var cessval = (sup_cessvalue.text).toString()
                var saveky = (savekey.text).toString()

                var mrP = (sup_mrp.text).toString()
                try {
                    var cate = sup_cate.selectedItem.toString()
                    var manufacture = sup_manu.selectedItem.toString()
                    var ut = sup_unit.selectedItem.toString()

                    catesnd= cate
                    uttrsnd=ut
                    manusnd=manufacture

                }
                catch (e:Exception){

                }

                var status = (disable.text).toString()
                val img1nsup = fn1sup
                val img2nsup = sn1sup
                val img3nsup = tn1sup
                val img4nsup = fon1sup
                val img5nsup = fifn1sup
                val img1urlsup = f1sup
                val img2urlsup = s1sup
                val img3urlsup = t1sup
                val img4urlsup = fo1sup
                val img5urlsup= fif1sup

                val img1n= fn1
                val img2n= sn1
                val img3n= tn1
                val img4n= fon1
                val img5n= fifn1sup
                val img1url = f1
                val img2url = s1
                val img3url = t1
                val img4url = fo1
                val img5url= fif1



                val sname = (textView1.text).toString()
                val sid = textView22.text.toString()
                val scon = textView33.text.toString()
                val mob = textView4.text.toString()
                val mob1 = textView5.text.toString()
                val mob2 = textView6.text.toString()
                val mobile = textView7.text.toString()
                val mobile1 = textView8.text.toString()
                val mobile2 = textView9.text.toString()
                val saddre = textView10.text.toString()
                val saddre1 = textView11.text.toString()
                val saddre2 = textView12.text.toString()
                val scity = textView13.text.toString()
                val sstate = textView14.text.toString()
                val spin = textView15.text.toString()
                val sgps = textView16.text.toString()
                val smail = textView17.text.toString()
                val sgstcode = textView18.text.toString()
                val urlim = textView19.text.toString()
                val sids = textView20.text.toString()
                val statussup = textView21.text.toString()
                val savekysup=savekey.text.toString()
                val prodky = prokey.text.toString()

                val b = Intent(this@SuppProductAddActivity, ScanSupplierActivity::class.java)
                    b.putExtra("pid",pid)
                    b.putExtra("pname",pname)
                    b.putExtra("bcode",bcode)
                    b.putExtra("pdes",pdes)
                    b.putExtra("weight",weight)
                    b.putExtra("psac",psac)
                    b.putExtra("stockonhand",stockonhand)
                    b.putExtra("minstock",minstock)
                    b.putExtra("maxstock",maxstock)
                    b.putExtra("price",price)
                    b.putExtra("taxable",taxable)
                    b.putExtra("igst",igst)
                    b.putExtra("cgst",cgst)
                    b.putExtra("sgst",sgst)
                    b.putExtra("cess",cess)
                    b.putExtra("taxtotal",taxtotal)
                    b.putExtra("cessval",cessval)
                    b.putExtra("saveky",saveky)
                    b.putExtra("mrP",mrP)

                    b.putExtra("cate",catesnd)
                    b.putExtra("manufacture",uttrsnd)
                    b.putExtra("ut",manusnd)
                    b.putExtra("status",status)
                    b.putExtra("img1nsup",img1nsup)
                    b.putExtra("img2nsup",img2nsup)
                    b.putExtra("img3nsup",img3nsup)
                    b.putExtra("img4nsup",img4nsup)
                    b.putExtra("img5nsup",img5nsup)
                    b.putExtra("img1urlsup",img1urlsup)
                    b.putExtra("img2urlsup",img2urlsup)
                    b.putExtra("img3urlsup",img3urlsup)
                    b.putExtra("img4urlsup",img4urlsup)
                    b.putExtra("img5urlsup",img5urlsup)
                    b.putExtra("profab",profab)
                    b.putExtra("prosvkys",prosave_key)
                    b.putExtra("editclpro",editclipro)
                    b.putExtra("editclsupp",editclisupp)

                    b.putExtra("img1n",img1n)
                    b.putExtra("img2n",img2n)
                    b.putExtra("img3n",img3n)
                    b.putExtra("img4n",img4n)
                    b.putExtra("img5n",img5n)
                    b.putExtra("img1url",img1url)
                    b.putExtra("img2url",img2url)
                    b.putExtra("img3url",img3url)
                    b.putExtra("img4url",img4url)
                    b.putExtra("img5url",img5url)
                    b.putExtra("sname",sname)
                    b.putExtra("sid",sid)
                    b.putExtra("scon",scon)
                    b.putExtra("mob",mob)
                    b.putExtra("mob1",mob1)
                    b.putExtra("mob2",mob2)
                    b.putExtra("mobile",mobile)
                    b.putExtra("mobile1",mobile1)
                    b.putExtra("mobile2",mobile2)
                    b.putExtra("saddre",saddre)
                    b.putExtra("saddre1",saddre1)
                    b.putExtra("saddre2",saddre2)
                    b.putExtra("scity",scity)
                    b.putExtra("sstate",sstate)
                    b.putExtra("spin",spin)
                    b.putExtra("sgps",sgps)
                    b.putExtra("smail",smail)
                    b.putExtra("sgstcode",sgstcode)
                    b.putExtra("urlim",urlim)
                    b.putExtra("sids",sids)
                    b.putExtra("statussup",statussup)
                    b.putExtra("savekysup",savekysup)
                    b.putExtra("prodky",prodky)
                b.putExtra("commlisteners",commlistener)
                b.putExtra("fieldlistenersave",fieldlistenr)

                b.putExtra("listenersave",listnersave)
                b.putExtra("addspro", addsupppro)
                b.putExtra("editspro", editesupppro)
                b.putExtra("viewspro", viewsupppro)
                b.putExtra("deletespro", deletesupppro)
                b.putExtra("importspro", importsupppro)
                b.putExtra("exportspro", exportsupppro)
                b.putExtra("startlistprky",startlistprokey)

                b.putExtra("profrmprky",productprokey)


                startActivityForResult(b, 1)
            } else {
                Toast.makeText(this@SuppProductAddActivity, "Already Scanned",
                        Toast.LENGTH_LONG).show();

            }

        })
        sup_bcode.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                if ((sup_bcode.length() == 0) && (sup_bcode.isFocused == true)) {


                    var pid = (sup_pid.text).toString()
                    var pname = (sup_pname.text).toString()
                    var bcode = (sup_bcode.text).toString()
                    var pdes = (sup_hscdes.text).toString()

                    var weight = (sup_vol.text).toString()
                    var psac = (sup_hsc.text).toString()
                    var stockonhand = (sup_stockhand.text).toString()

                    var minstock = (sup_minstock.text).toString()
                    var maxstock = (sup_maxstock.text).toString()
                    var price = (sup_price.text).toString()
                    var taxable = (sup_taxcheck.text).toString()
                    var igst = (sup_intgst.text).toString()
                    var cgst = (sup_centgst.text).toString()
                    var sgst = (sup_stategst.text).toString()
                    var cess = (sup_cess.text).toString()
                    var taxtotal = (sup_taxtot.text).toString()
                    var cessval = (sup_cessvalue.text).toString()
                    var saveky = (savekey.text).toString()

                    var mrP = (sup_mrp.text).toString()
                    try {
                        var cate = sup_cate.selectedItem.toString()
                        var manufacture = sup_manu.selectedItem.toString()
                        var ut = sup_unit.selectedItem.toString()
                        catesnd=cate
                        uttrsnd=manufacture
                        manusnd=ut
                    }
                    catch (e:Exception){

                    }

                    var status = (disable.text).toString()
                    val img1nsup = fn1sup
                    val img2nsup = sn1sup
                    val img3nsup = tn1sup
                    val img4nsup = fon1sup
                    val img5nsup = fifn1sup
                    val img1urlsup = f1sup
                    val img2urlsup = s1sup
                    val img3urlsup = t1sup
                    val img4urlsup = fo1sup
                    val img5urlsup= fif1sup

                    val img1n= fn1
                    val img2n= sn1
                    val img3n= tn1
                    val img4n= fon1
                    val img5n= fifn1sup
                    val img1url = f1
                    val img2url = s1
                    val img3url = t1
                    val img4url = fo1
                    val img5url= fif1



                    val sname = (textView1.text).toString()
                    val sid = textView22.text.toString()
                    val scon = textView33.text.toString()
                    val mob = textView4.text.toString()
                    val mob1 = textView5.text.toString()
                    val mob2 = textView6.text.toString()
                    val mobile = textView7.text.toString()
                    val mobile1 = textView8.text.toString()
                    val mobile2 = textView9.text.toString()
                    val saddre = textView10.text.toString()
                    val saddre1 = textView11.text.toString()
                    val saddre2 = textView12.text.toString()
                    val scity = textView13.text.toString()
                    val sstate = textView14.text.toString()
                    val spin = textView15.text.toString()
                    val sgps = textView16.text.toString()
                    val smail = textView17.text.toString()
                    val sgstcode = textView18.text.toString()
                    val urlim = textView19.text.toString()
                    val sids = textView20.text.toString()
                    val statussup = textView21.text.toString()
                    val savekysup=savekey.text.toString()
                    val prodky = prokey.text.toString()

                    val b = Intent(this@SuppProductAddActivity, ScanSupplierActivity::class.java)
                    b.putExtra("pid",pid)
                    b.putExtra("pname",pname)
                    b.putExtra("bcode",bcode)
                    b.putExtra("pdes",pdes)
                    b.putExtra("weight",weight)
                    b.putExtra("psac",psac)
                    b.putExtra("stockonhand",stockonhand)
                    b.putExtra("minstock",minstock)
                    b.putExtra("maxstock",maxstock)
                    b.putExtra("price",price)
                    b.putExtra("taxable",taxable)
                    b.putExtra("igst",igst)
                    b.putExtra("cgst",cgst)
                    b.putExtra("sgst",sgst)
                    b.putExtra("cess",cess)
                    b.putExtra("taxtotal",taxtotal)
                    b.putExtra("cessval",cessval)
                    b.putExtra("saveky",saveky)
                    b.putExtra("mrP",mrP)
                    b.putExtra("cate",catesnd)
                    b.putExtra("manufacture",manusnd)
                    b.putExtra("ut",uttrsnd)
                    b.putExtra("status",status)
                    b.putExtra("img1nsup",img1nsup)
                    b.putExtra("img2nsup",img2nsup)
                    b.putExtra("img3nsup",img3nsup)
                    b.putExtra("img4nsup",img4nsup)
                    b.putExtra("img5nsup",img5nsup)
                    b.putExtra("img1urlsup",img1urlsup)
                    b.putExtra("img2urlsup",img2urlsup)
                    b.putExtra("img3urlsup",img3urlsup)
                    b.putExtra("img4urlsup",img4urlsup)
                    b.putExtra("img5urlsup",img5urlsup)
                    b.putExtra("profab",profab)
                    b.putExtra("prosvkys",prosave_key)

                    b.putExtra("editclpro",editclipro)
                    b.putExtra("editclsupp",editclisupp)

                    b.putExtra("img1n",img1n)
                    b.putExtra("img2n",img2n)
                    b.putExtra("img3n",img3n)
                    b.putExtra("img4n",img4n)
                    b.putExtra("img5n",img5n)
                    b.putExtra("img1url",img1url)
                    b.putExtra("img2url",img2url)
                    b.putExtra("img3url",img3url)
                    b.putExtra("img4url",img4url)
                    b.putExtra("img5url",img5url)
                    b.putExtra("sname",sname)
                    b.putExtra("sid",sid)
                    b.putExtra("scon",scon)
                    b.putExtra("mob",mob)
                    b.putExtra("mob1",mob1)
                    b.putExtra("mob2",mob2)
                    b.putExtra("mobile",mobile)
                    b.putExtra("mobile1",mobile1)
                    b.putExtra("mobile2",mobile2)
                    b.putExtra("saddre",saddre)
                    b.putExtra("saddre1",saddre1)
                    b.putExtra("saddre2",saddre2)
                    b.putExtra("scity",scity)
                    b.putExtra("sstate",sstate)
                    b.putExtra("spin",spin)
                    b.putExtra("sgps",sgps)
                    b.putExtra("smail",smail)
                    b.putExtra("sgstcode",sgstcode)
                    b.putExtra("urlim",urlim)
                    b.putExtra("sids",sids)
                    b.putExtra("statussup",statussup)
                    b.putExtra("savekysup",savekysup)
                    b.putExtra("prodky",prodky)
                    b.putExtra("commlisteners",commlistener)
                    b.putExtra("fieldlistenersave",fieldlistenr)
                    b.putExtra("startlistprky",startlistprokey)

                    b.putExtra("profrmprky",productprokey)


                    b.putExtra("listenersave",listnersave)
                    b.putExtra("addspro", addsupppro)
                    b.putExtra("editspro", editesupppro)
                    b.putExtra("viewspro", viewsupppro)
                    b.putExtra("deletespro", deletesupppro)
                    b.putExtra("importspro", importsupppro)
                    b.putExtra("exportspro", exportsupppro)

                    startActivityForResult(b, 1)
                }
                if(sup_bcode.text.toString().isEmpty()){

                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {



            }
        })


    }


    private fun onStarClicked1() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Saving...");
        pDialog.setCancelable(false);
        pDialog.show();
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("supplier_product_counter")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val ids = dataSnapshot.value
                suppprod_insert(ids.toString())


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }


    //ID GENERARION FUNCTION


    fun suppprod_insert(supid1: String) {
        if (sup_pname.length() == 0) {
            errorpnm.visibility = View.VISIBLE
            errorpnm.setError("Field cannot be empty")
            errorpnm.setText("Field cannot be empty")
            Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

        }
        if (sup_price.length() == 0) {
            errorprice.visibility = View.VISIBLE
            errorprice.setError("Field cannot be empty")
            errorprice.setText("Field cannot be empty")
            Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

        }

        var pid = "PRD" + supid1
        var pname = (sup_pname.text).toString()
        var bcode = (sup_bcode.text).toString()
        var pdes = (sup_hscdes.text).toString()

        var weight = (sup_vol.text).toString()
        var psac = (sup_hsc.text).toString()
        var stockonhand = (sup_stockhand.text).toString()

        var minstock = (sup_minstock.text).toString()
        var maxstock = (sup_maxstock.text).toString()
        var price = (sup_price.text).toString()
        var taxable = (sup_taxcheck.isChecked).toString()
        var igst = (sup_intgst.text).toString()
        var cgst = (sup_centgst.text).toString()
        var sgst = (sup_stategst.text).toString()
        var cess = (sup_cess.text).toString()
        var taxtotal = (sup_taxtot.text).toString()
        var cessval = (sup_cessvalue.text).toString()
        var saveky = (savekey.text).toString()

        var mrP = (sup_mrp.text).toString()
        try {
            var cate = sup_cate.selectedItem.toString()
            var manufacture = sup_manu.selectedItem.toString()
            var ut = sup_unit.selectedItem.toString()

            catetr=cate
            uttr=ut
            manutr= manufacture
        }
        catch (e:Exception){

        }

        var status = (disable.text).toString()


        if(f1.isEmpty()){

        }



        val img1n = fn1
        val img2n = sn1
        val img3n = tn1
        val img4n = fon1
        val img5n = fifn1
        val img1url = f1
        val img2url = s1
        val img3url = t1
        val img4url = fo1
        val img5url = fif1




        val data = s(sp_id = pid, sp_nm = pname, spbc = bcode, spdesc = pdes, spwg_vol = weight, sphsn = psac, spctgy = catetr,
                spmfr = manutr, sput = uttr, spmin_stk = minstock, spprice = price, spmx_stk = maxstock,
                sptaxchk = taxable, spigst = igst, spcgst = cgst, spsgst = sgst, spcess = cess, sptaxtot = taxtotal,
                spcesstot = cessval, spmrp = mrP, status = status, spstock_hand = stockonhand, spsave_key = saveky,
                img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url,
                img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh,
                img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,img1urlhigh = img1urlhigh,
                img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)
        val TAG = "some"
        /*    save_progress.visibility = android.view.View.VISIBLE*/


        supprosave.isEnabled = false



        var send = arrayOf<String>()
        var db = FirebaseFirestore.getInstance()
        db.collection("supplier_products")
                .add(data)
                .addOnSuccessListener { documentReference ->

                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var kk = documentReference.id
                    prosave_key = prosave_key.plusElement(kk)

                    println("AT THE PLACE KEY VALUEEEEEE" + Arrays.toString(prosave_key))


                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                    pDialog.dismiss()

                    Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()

                    val ib = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)
                    ib.putExtra("proky", Arrays.toString(prosave_key))

                    ib.putExtra("sndproky", "prod_key_snd")
                    ib.putExtra("svky", savekey.text.toString())

                    val sname = (textView1.text).toString()
                    val sid = textView22.text.toString()
                    val scon = textView33.text.toString()
                    val mob = textView4.text.toString()
                    val mob1 = textView5.text.toString()
                    val mob2 = textView6.text.toString()
                    val mobile = textView7.text.toString()
                    val mobile1 = textView8.text.toString()
                    val mobile2 = textView9.text.toString()
                    val saddre = textView10.text.toString()
                    val saddre1 = textView11.text.toString()
                    val saddre2 = textView12.text.toString()
                    val scity = textView13.text.toString()
                    val sstate = textView14.text.toString()
                    val spin = textView15.text.toString()
                    val sgps = textView16.text.toString()
                    val smail = textView17.text.toString()
                    val sgstcode = textView18.text.toString()
                    val urlim = textView19.text.toString()
                    val sids = textView20.text.toString()
                    val status = textView21.text.toString()
                    val prodky = prokey.text.toString()

                    ib.putExtra("prret_sname1", sname)

                    ib.putExtra("proret_sid1", sid)
                    ib.putExtra("proret_scon1", scon)
                    ib.putExtra("proret_mob", mob)
                    ib.putExtra("proret_mob1", mob1)
                    ib.putExtra("proret_mob2", mob2)
                    ib.putExtra("proret_mobile", mobile)
                    ib.putExtra("proret_mobile1", mobile1)
                    ib.putExtra("proret_mobile2", mobile2)
                    ib.putExtra("proret_saddress", saddre)
                    ib.putExtra("proret_saddress1", saddre1)
                    ib.putExtra("listener",commlistener)
                    ib.putExtra("listenersave",listnersave)

                    ib.putExtra("editclipro",editclipro)
                    ib.putExtra("editclisupp",editclisupp)
                    ib.putExtra("proret_saddress2", saddre2)
                    ib.putExtra("proret_scity", scity)
                    ib.putExtra("proret_sstate", sstate)
                    ib.putExtra("proret_spin", spin)
                    ib.putExtra("proret_sgps", sgps)
                    ib.putExtra("proret_smail", smail)
                    ib.putExtra("proret_sgstcd", sgstcode)
                    ib.putExtra("proret_status", status)
                    ib.putExtra("proret_url", urlim)
                    ib.putExtra("proret_sids", sids)
                    ib.putExtra("fieldlistenersave",fieldlistenr)
                    ib.putExtra("startlistprky",startlistprokey)

                    ib.putExtra("profrmprky",productprokey)

                    ib.putExtra("retimg1", fn1sup)
                    ib.putExtra("retimg2", sn1sup)
                    ib.putExtra("retimg3", tn1sup)
                    ib.putExtra("retimg4", fon1sup)
                    ib.putExtra("retimg5", fifn1sup)
                    ib.putExtra("returl1", f1sup)
                    ib.putExtra("returl2", s1sup)
                    ib.putExtra("returl3", t1sup)
                    ib.putExtra("returl4", fo1sup)
                    ib.putExtra("returl5", fif1sup)

                    ib.putExtra("img1urlhigh",img1urlsuphigh)
                    ib.putExtra("img2urlhigh",img2urlsuphigh)
                    ib.putExtra("img3urlhigh",img3urlsuphigh)
                    ib.putExtra("img4urlhigh",img4urlsuphigh)
                    ib.putExtra("img5urlhigh",img5urlsuphigh)
                    ib.putExtra("img1nhigh",img1nsuphigh)
                    ib.putExtra("img2nhigh",img2nsuphigh)
                    ib.putExtra("img3nhigh",img3nsuphigh)
                    ib.putExtra("img4nhigh",img4nsuphigh)
                    ib.putExtra("img5nhigh",img5nsuphigh)


                    ib.putExtra("f1edit",f1supedit)
                    ib.putExtra("s1edit",s1supedit)
                    ib.putExtra("t1edit",t1supedit)
                    ib.putExtra("fo1edit",fo1supedit)
                    ib.putExtra("fif1edit",fif1supedit)
                    ib.putExtra("fn1edit",fn1supedit)
                    ib.putExtra("sn1edit",sn1supedit)
                    ib.putExtra("tn1edit",tn1supedit)
                    ib.putExtra("fon1edit",fon1supedit)
                    ib.putExtra("fifn1edit",fifn1supedit)
                    ib.putExtra("f1edithigh",f1supedithigh)
                    ib.putExtra("s1edithigh",s1supedithigh)
                    ib.putExtra("t1edithigh",t1supedithigh)
                    ib.putExtra("fo1edithigh",fo1supedithigh)
                    ib.putExtra("fif1edithigh",fif1supedithigh)
                    ib.putExtra("fn1edithigh",fn1supedithigh)
                    ib.putExtra("sn1edithigh",sn1supedithigh)
                    ib.putExtra("tn1edithigh",tn1supedithigh)
                    ib.putExtra("fon1edithigh",fon1supedithigh)
                    ib.putExtra("fifn1edithigh",fifn1supedithigh)

                    ib.putExtra("file_maps",file_maps)
                    ib.putExtra("mresultsarr",mresultsarr)

                    ib.putExtra("retadd", addsupppro)
                    ib.putExtra("retview", viewsupppro)
                    ib.putExtra("retdelete", deletesupppro)
                    ib.putExtra("retedit", editesupppro)
                    ib.putExtra("retimport", importsupppro)
                    ib.putExtra("retexport", exportsupppro)



                    startActivity(ib)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                    finish()
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    /* save_progress.visibility = android.view.View.GONE*/
                }


    }

    fun loadim() {
        scrollpro.visibility = View.GONE
        scroll2_slider2.visibility=View.VISIBLE
        scroll2_slider.visibility=View.GONE
        if (file_mapspro.isNotEmpty()) {

        println("INSIDE LOADIM")
            println("INSIDE LOADIM"+file_mapspro)
            for (r in 0 until file_mapspro.size) {
                println("INSIDE LOADIM"+file_mapspro[r])
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout

                    println("INSIDE LOADIM"+file_mapspro[r])
                    textSliderView
                            //.description(name)
                            .image(file_mapspro[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {

                                if(net_status()==true) {

                                val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                                b.putExtra("id", id.text.toString())
                                b.putExtra("f1", f1)
                                b.putExtra("fn1", fn1)
                                b.putExtra("s1", s1)
                                b.putExtra("sn1", sn1)
                                b.putExtra("t1", t1)
                                b.putExtra("tn1", tn1)
                                b.putExtra("fo1", fo1)
                                b.putExtra("fon1", fon1)
                                b.putExtra("fif1", fif1)
                                b.putExtra("fifn1", fifn1)
                                b.putExtra("f1high", img1urlhigh)
                                b.putExtra("fn1high", img1nhigh)
                                b.putExtra("s1high", img2urlhigh)
                                b.putExtra("sn1high", img2nhigh)
                                b.putExtra("t1high", img3urlhigh)
                                b.putExtra("tn1high",img3nhigh)
                                b.putExtra("fo1high", img4urlhigh)
                                b.putExtra("fon1high", img4nhigh)
                                b.putExtra("fif1high", img5urlhigh)
                                b.putExtra("fifn1high",img5nhigh)
                                b.putExtra("mresult", mresultsarr)

                                b.putExtra("listener",commlistener)

                                b.putExtra("f1edithigh", f1edithigh)
                                b.putExtra("fn1edithigh", fn1edithigh)
                                b.putExtra("s1edithigh", s1edithigh)
                                b.putExtra("sn1edithigh", sn1edithigh)
                                b.putExtra("t1edithigh", t1edithigh)
                                b.putExtra("tn1edithigh", tn1edithigh)
                                b.putExtra("fo1edithigh", fo1edithigh)
                                b.putExtra("fon1edithigh", fon1edithigh)
                                b.putExtra("fif1edithigh", fif1edithigh)
                                b.putExtra("fifn1edithigh", fifn1edithigh)
                                b.putExtra("f1high", img1urlhigh)
                                b.putExtra("fn1high", img1nhigh)
                                b.putExtra("s1high", img2urlhigh)
                                b.putExtra("sn1high", img2nhigh)
                                b.putExtra("t1high", img3urlhigh)
                                b.putExtra("tn1high",img3nhigh)
                                b.putExtra("fo1high", img4urlhigh)
                                b.putExtra("fon1high", img4nhigh)
                                b.putExtra("fif1high", img5urlhigh)
                                b.putExtra("fifn1high",img5nhigh)

                                b.putExtra("f1edit", f1edit)
                                b.putExtra("fn1edit", fn1edit)
                                b.putExtra("s1edit", s1edit)
                                b.putExtra("sn1edit", sn1edit)
                                b.putExtra("t1edit", t1edit)
                                b.putExtra("tn1edit", tn1edit)
                                b.putExtra("fo1edit", fo1edit)
                                b.putExtra("fon1edit", fon1edit)
                                b.putExtra("fif1edit", fif1edit)
                                b.putExtra("fifn1edit", fifn1edit)

                                b.putExtra("addpro",addsupppro)
                                b.putExtra("editpro",editesupppro)
                                b.putExtra("deletepro",deletesupppro)
                                b.putExtra("viewpro",viewsupppro)
                                b.putExtra("importpro",importsupppro)
                                b.putExtra("exportpro",exportsupppro)

                                b.putExtra("edtcli",editclipro)
                                scroll2_slider.isEnabled = true

                                startActivityForResult(b, 0)
                                }
                                else{
                                    Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                }
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_service_image2
            try {
                val newurl = URL(file_mapspro[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)

            } catch (e: Exception) {

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            0 // For Images
            -> {
                if (resultCode == Activity.RESULT_OK) {




                    scroll2_slider.removeAllSliders()
                    scroll2_slider2.removeAllSliders()

                    scroll2_slider2.visibility = View.GONE
                    scroll2_slider.visibility = View.VISIBLE
                    val f = data!!.getStringExtra("f");
                    val fn = data!!.getStringExtra("fn");
                    val s = data!!.getStringExtra("s");
                    val sn = data!!.getStringExtra("sn");
                    val t = data!!.getStringExtra("t");
                    val tn = data!!.getStringExtra("tn");
                    val fo = data!!.getStringExtra("fo");
                    val fon = data!!.getStringExtra("fon");
                    val fif = data!!.getStringExtra("fif");
                    val fifn = data!!.getStringExtra("fifn");



                    val fedit = data!!.getStringExtra("fedit")
                    val fnedit = data!!.getStringExtra("fnedit")
                    val sedit = data!!.getStringExtra("sedit")
                    val snedit = data!!.getStringExtra("snedit")
                    val tedit = data!!.getStringExtra("tedit")
                    val tnedit = data!!.getStringExtra("tnedit")
                    val foedit = data!!.getStringExtra("foedit")
                    val fonedit = data!!.getStringExtra("fonedit")
                    val fifedit = data!!.getStringExtra("fifedit")
                    val fifnedit = data!!.getStringExtra("fifnedit");



                    if (fedit.isNotEmpty()) {


                        f1edit = fedit
                        fn1edit = fnedit


                    } else {



                        f1edit = ""
                        fn1edit = ""
                    }
                    if (sedit.isNotEmpty()) {



                        s1edit = sedit
                        sn1edit = snedit

                    } else {





                        s1edit = ""
                        sn1edit = ""
                    }
                    if (tedit.isNotEmpty()) {

                        t1edit = tedit
                        tn1edit = tnedit

                    } else {

                        t1edit = ""
                        tn1edit = ""
                    }
                    if (foedit.isNotEmpty()) {
                        fo1edit = foedit
                        fon1edit = fonedit

                    } else {

                        fo1edit = ""
                        fon1edit = ""
                    }
                    if (fifedit.isNotEmpty()) {

                        fif1edit = fifedit
                        fifn1edit = fifnedit

                    } else {

                        fif1edit = ""
                        fifn1edit = ""
                    }



                    val fhigh = data!!.getStringExtra("fhigh");
                    val fnhigh = data!!.getStringExtra("fnhigh");
                    val shigh = data!!.getStringExtra("shigh");
                    val snhigh = data!!.getStringExtra("snhigh");
                    val thigh = data!!.getStringExtra("thigh");
                    val tnhigh = data!!.getStringExtra("tnhigh");
                    val fohigh = data!!.getStringExtra("fohigh");
                    val fonhigh = data!!.getStringExtra("fonhigh");
                    val fifhigh = data!!.getStringExtra("fifhigh");
                    val fifnhigh = data!!.getStringExtra("fifnhigh");


                    println("fhigh" + fhigh)
                    println("shigh" + shigh)
                    println("thigh" + thigh)
                    println("fohigh" + fohigh)
                    println("fifhigh" + fifhigh)


                    println("fnhigh" + fnhigh)
                    println("snhigh" + snhigh)
                    println("tnhigh" + tnhigh)
                    println("fonhigh" + fonhigh)
                    println("fifnhigh" + fifnhigh)
                    if (fhigh.isNotEmpty()) {


                        img1urlhigh = fhigh
                        img1nhigh = fnhigh
                    } else {
                        img1urlhigh = ""
                        img1nhigh = ""
                    }
                    if (shigh.isNotEmpty()) {


                        img2urlhigh = shigh
                        img2nhigh = snhigh
                    } else {
                        img2urlhigh = ""
                        img2nhigh = ""
                    }
                    if (thigh.isNotEmpty()) {


                        img3urlhigh = thigh
                        img3nhigh = tnhigh
                    } else {
                        img3urlhigh = ""
                        img3nhigh = ""
                    }
                    if (fohigh.isNotEmpty()) {


                        img4urlhigh = fohigh
                        img4nhigh = fonhigh
                    } else {
                        img4urlhigh = ""
                        img4nhigh = ""
                    }
                    if (fifhigh.isNotEmpty()) {


                        img5urlhigh = fifhigh
                        img5nhigh = fifnhigh
                    } else {

                        img5urlhigh = ""
                        img5nhigh = ""
                    }

                    try {
                        mresultsarr = data!!.getStringArrayListExtra("mResult")
                    } catch (e: Exception) {

                    }




                    try {
                        commlistener = data!!.getStringExtra("listenersave")
                    } catch (e: Exception) {

                    }

                    try {
                        editclipro = data!!.getStringExtra("edtcli")
                    } catch (e: Exception) {

                    }
                    scrollpro.visibility=View.VISIBLE

                    val bitmapArray = ArrayList<String>()
                    bitmapArray.clear()

                    if (f.isNotEmpty()) {





                       /* imageView10.visibility=View.GONE*/
                        d.add(f)

                        f1 = f
                        fn1 = fn
                        if(img1nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(f1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(f1)
                            }
                        }
                        else{
                            bitmapArray.add(f)
                        }


                    } else {




                        /* imageView10.visibility=View.VISIBLE*/
                        f1 = ""
                        fn1 = ""
                    }
                    if (s.isNotEmpty()) {



                        d.add(s)

                        s1 = s
                        sn1 = sn


                        if(img2nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(s1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(s1)
                            }
                        }
                        else{
                            bitmapArray.add(s)
                        }

                    } else {





                        s1 = ""
                        sn1 = ""
                    }
                    if (t.isNotEmpty()) {




                        d.add(t)

                        t1 = t
                        tn1 = tn
                        if(img3nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(t1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(t1)
                            }
                        }
                        else{
                            bitmapArray.add(t)
                        }

                    } else {







                        t1 = ""
                        tn1 = ""
                    }
                    if (fo.isNotEmpty()) {


                        d.add(fo)

                        fo1 = fo
                        fon1 = fon

                        if(img4nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(fo1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(fo1)
                            }
                        }
                        else{
                            bitmapArray.add(fo)
                        }


                    } else {





                        fo1 = ""
                        fon1 = ""
                    }
                    if (fif.isNotEmpty()) {




                        d.add(fif)

                        fif1 = fif
                        fifn1 = fifn

                        if(img5nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(fif1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(fif1)
                            }
                        }
                        else{
                            bitmapArray.add(fif)
                        }



                    } else {




                        fif1 = ""
                        fifn1 = ""
                    }

                    if(f1.isNotEmpty()||s1.isNotEmpty()||t1.isNotEmpty()||fo1.isNotEmpty()||fif1.isNotEmpty()){
                        gallery.visibility=View.VISIBLE
                        imageView41.visibility=View.GONE
                        imageButton2.visibility=View.GONE
                    }
                    Handler().postDelayed(Runnable {
                        Log.d("tag", "  " + bitmapArray)
                        if (bitmapArray.isNotEmpty()) {
                            for (r in 0 until bitmapArray.size) {
                                val textSliderView = TextSliderView(this)
                                // initialize a SliderLayout
                                Log.d("khd", "r  " + bitmapArray[r])
                                textSliderView
                                        //.description(name)
                                        .image(bitmapArray[r])
                                        .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                        .setOnSliderClickListener {
                                            val b = Intent(applicationContext, AddImagesActivity_product::class.java)
                                            b.putExtra("id", id.text.toString())
                                            b.putExtra("f1", f1)
                                            b.putExtra("fn1", fn1)
                                            b.putExtra("s1", s1)
                                            b.putExtra("sn1", sn1)
                                            b.putExtra("t1", t1)
                                            b.putExtra("tn1", tn1)
                                            b.putExtra("fo1", fo1)
                                            b.putExtra("fon1", fon1)
                                            b.putExtra("fif1", fif1)
                                            b.putExtra("fifn1", fifn1)
                                            b.putExtra("f1high", img1urlhigh)
                                            b.putExtra("fn1high", img1nhigh)
                                            b.putExtra("s1high", img2urlhigh)
                                            b.putExtra("sn1high", img2nhigh)
                                            b.putExtra("t1high", img3urlhigh)
                                            b.putExtra("tn1high", img3nhigh)
                                            b.putExtra("fo1high", img4urlhigh)
                                            b.putExtra("fon1high", img4nhigh)
                                            b.putExtra("fif1high", img5urlhigh)
                                            b.putExtra("fifn1high", img5nhigh)
                                            b.putExtra("mresult", mresultsarr)

                                            b.putExtra("listener", commlistener)

                                            b.putExtra("f1edithigh", f1edithigh)
                                            b.putExtra("fn1edithigh", fn1edithigh)
                                            b.putExtra("s1edithigh", s1edithigh)
                                            b.putExtra("sn1edithigh", sn1edithigh)
                                            b.putExtra("t1edithigh", t1edithigh)
                                            b.putExtra("tn1edithigh", tn1edithigh)
                                            b.putExtra("fo1edithigh", fo1edithigh)
                                            b.putExtra("fon1edithigh", fon1edithigh)
                                            b.putExtra("fif1edithigh", fif1edithigh)
                                            b.putExtra("fifn1edithigh", fifn1edithigh)
                                            b.putExtra("f1high", img1urlhigh)
                                            b.putExtra("fn1high", img1nhigh)
                                            b.putExtra("s1high", img2urlhigh)
                                            b.putExtra("sn1high", img2nhigh)
                                            b.putExtra("t1high", img3urlhigh)
                                            b.putExtra("tn1high", img3nhigh)
                                            b.putExtra("fo1high", img4urlhigh)
                                            b.putExtra("fon1high", img4nhigh)
                                            b.putExtra("fif1high", img5urlhigh)
                                            b.putExtra("fifn1high", img5nhigh)

                                            b.putExtra("f1edit", f1edit)
                                            b.putExtra("fn1edit", fn1edit)
                                            b.putExtra("s1edit", s1edit)
                                            b.putExtra("sn1edit", sn1edit)
                                            b.putExtra("t1edit", t1edit)
                                            b.putExtra("tn1edit", tn1edit)
                                            b.putExtra("fo1edit", fo1edit)
                                            b.putExtra("fon1edit", fon1edit)
                                            b.putExtra("fif1edit", fif1edit)
                                            b.putExtra("fifn1edit", fifn1edit)

                                            b.putExtra("addpro", addsupppro)
                                            b.putExtra("editpro", editesupppro)
                                            b.putExtra("deletepro", deletesupppro)
                                            b.putExtra("viewpro", viewsupppro)
                                            b.putExtra("importpro", importsupppro)
                                            b.putExtra("exportpro", exportsupppro)

                                            b.putExtra("edtcli", editclipro)
                                        }

                                //add your extra information
                                /*textSliderView.bundle(Bundle())
                        textSliderView.bundle.clear()*/
                                //.putString("extra", bitmapArray[r])
scrollpro.visibility=View.GONE
                                scroll2_slider.addSlider(textSliderView)
                            }
                            scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                            scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                            scroll2_slider.setCustomAnimation(DescriptionAnimation())
                            scroll2_slider.setDuration(5000)

                            //scroll2_preview_service_image
                            val newurl = URL(bitmapArray[0]).openStream()
                            val img = BitmapFactory.decodeStream(newurl)

                        }
                    },500)

                    //bitmapArray.addAll(data.get("bitmapArray"))
                    //println(bitmapArray)
                    Log.d(" ", "result " + f)
                    Log.d(" ", "result " + s)
                    Log.d(" ", "result " + t)
                    Log.d(" ", "result " + fo)
                    Log.d(" ", "result " + fif)
                    /* this.runOnUiThread(Runnable() {
                         file_maps.clear()
                         d.addAll(d)
                         Log.d("map","  "+d)
                     })*/
                }
            }
            1 // Barcode
            -> {
                if (resultCode == Activity.RESULT_OK) {
                    if (data != null) {
                        val barcode = data.getParcelableExtra<Barcode>("barcode")
                        sup_bcode.post { sup_bcode.setText(barcode.displayValue) }
                        Log.d("jkjvfdhjh", "barcode  " + barcode.displayValue)


                    }
                }
                if (resultCode == Activity.RESULT_CANCELED) {
                    return;
                }
            }
        /*etc -> {
        }*/
        }
    }

    fun popup(st: String) {
        val pop = android.support.v7.app.AlertDialog.Builder(this)
        pop.create()
        val title = TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50, 20, 20, 20)
        title.textSize = 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    companion object {
        val REQUEST_CODE = 100
        val PERMISSION_REQUEST = 200



            private var log_network: View? = null
            private var log_networktext: View? = null
        private var scroll2_sliderdis:SliderLayout?=null
        private var scroll2_slider2dis:SliderLayout?=null
        private var gallerydis:ImageButton?=null

        private var editdis:ImageButton?=null
            private val log_str: String? = null
            var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var consermaindis: ConstraintLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null

        fun addLogText(log: String?) {
                if(log=="NOT_CONNECT"){
                    relativeslayoutdis!!.visibility=View.VISIBLE
                    constraintLayout3dis!!.visibility=View.VISIBLE
                    scroll2_sliderdis!!.isEnabled=false
                    scroll2_slider2dis!!.isEnabled=false
                    gallerydis!!.isEnabled=false
                    for (i  in 0 until consermaindis!!.getChildCount()) {
                        val child = consermaindis!!.getChildAt(i);
                        child.setEnabled(false);
                    }
                    try {
                        pDialogs!!.dismiss()
                    }
                    catch (e:Exception){

                    }

                }
                else
                {
                    relativeslayoutdis!!.visibility=View.GONE
                    constraintLayout3dis!!.visibility=View.GONE
                    scroll2_sliderdis!!.isEnabled=true
                    scroll2_slider2dis!!.isEnabled=true
                    gallerydis!!.isEnabled=true
                    for (i  in 0 until consermaindis!!.getChildCount()) {
                        val child = consermaindis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                }
            }

    }


    override fun onBackPressed() {

        commlistener = ""
        println("LISTENER SAVE"+commlistener)

        println("CESS VALIDATE"+cessvaluevalidate)

        println("name VALIDATE"+pnamevalidate)
        println("vol VALIDATE"+volvalidate)
        println("bcode VALIDATE"+bcodeidvalidate)
        println("hsc VALIDATE"+hscvalidate)
        println("hscvalide VALIDATE"+hscdesvalidate)
        println("maincatvalidate VALIDATE"+maincatvalidate)
        println("subcatvalidate VALIDATE"+subcatvalidate)
        println("listvalidate VALIDATE"+listvalidate)
        println("pricevalidate VALIDATE"+pricevalidate)
        println("taxcheckvalidate VALIDATE"+taxcheckvalidate)
        println("intgstvalidate VALIDATE"+intgstvalidate)
        println("cessvaluevalidate VALIDATE"+cessvaluevalidate)

        println("maxstockvalidate VALIDATE"+maxstockvalidate)
        println("minstockvalidate VALIDATE"+minstockvalidate)

        println("stockhandvalidate VALIDATE"+stockhandvalidate)


        println("F1 VAL"+f1)
        println("s1 VAL"+s1)
        println("t1 VAL"+t1)
        println("Fo1 VAL"+fo1)
        println("Fif1 VAL"+fif1)
        println("Fn1 VAL"+fn1)
        println("sn1 VAL"+sn1)
        println("tn1 VAL"+tn1)
        println("Fon1 VAL"+fon1)
        println("Fif1 VAL"+fifn1)


        println("F1ed VAL"+f1edit)
        println("s1ed VAL"+s1edit)
        println("t1ed AL"+t1edit)
        println("Fof1ed VAL"+fo1edit)
        println("Fif1ed VAL"+fif1edit)

        println("Fn1ed VAL"+fn1edit)
        println("sn1ed VAL"+sn1edit)
        println("tn1ed AL"+tn1edit)
        println("Fnof1ed VAL"+fon1edit)
        println("Finf1ed VAL"+fifn1edit)


        if((pnamevalidate!=sup_pname.text.toString())||(volvalidate!=sup_vol.text.toString())||(bcodeidvalidate!=sup_bcode.text.toString()) ||
                (hscvalidate!=sup_hsc.text.toString())||(hscdesvalidate!=sup_hscdes.text.toString())||(maincatvalidate!=sup_cate.selectedItem.toString())||
                (subcatvalidate!=sup_manu.selectedItem.toString())|| (listvalidate!=sup_unit.selectedItem.toString())||(pricevalidate!=sup_price.text.toString())
                ||(taxcheckvalidate!=sup_taxcheck.isChecked.toString())||(intgstvalidate!=sup_intgst.text.toString())||(cessvaluevalidate!=sup_cess.text.toString())
                ||(maxstockvalidate!=sup_maxstock.text.toString())||(minstockvalidate!=sup_minstock.text.toString())||(stockhandvalidate!=sup_stockhand.text.toString())){

            commlistener = "change"
            println("ONBACK URL1 NOT EQUAL"+f1)

        }

        else if(((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))){
            println("ONBACK URL1 EDIT NOT EQUAl"+f1)
            commlistener = "change"
        }

        else{
            val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


            i.putExtra("sndproky", "eventlist")

            val sname = (textView1.text).toString()
            val sid = textView22.text.toString()
            val scon = textView33.text.toString()
            val mob = textView4.text.toString()
            val mob1 = textView5.text.toString()
            val mob2 = textView6.text.toString()
            val mobile = textView7.text.toString()
            val mobile1 = textView8.text.toString()
            val mobile2 = textView9.text.toString()
            val saddre = textView10.text.toString()
            val saddre1 = textView11.text.toString()
            val saddre2 = textView12.text.toString()
            val scity = textView13.text.toString()
            val sstate = textView14.text.toString()
            val spin = textView15.text.toString()
            val sgps = textView16.text.toString()
            val smail = textView17.text.toString()
            val sgstcode = textView18.text.toString()
            val urlim = textView19.text.toString()
            val sids = textView20.text.toString()
            val status = textView21.text.toString()

            i.putExtra("addspro", addsupppro)
            i.putExtra("editspro", editesupppro)
            i.putExtra("viewspro", viewsupppro)
            i.putExtra("deletespro", deletesupppro)
            i.putExtra("importspro", importsupppro)
            i.putExtra("exportspro", exportsupppro)
            i.putExtra("keys", prokey.text.toString())
            i.putExtra("startlistprky",startlistprokey)

            i.putExtra("profrmprky",productprokey)

            i.putExtra("prret_sname1", sname)

            i.putExtra("proret_sid1", sid)
            i.putExtra("proret_scon1", scon)
            i.putExtra("proret_mob", mob)
            i.putExtra("proret_mob1", mob1)
            i.putExtra("proret_mob2", mob2)
            i.putExtra("proret_mobile", mobile)
            i.putExtra("proret_mobile1", mobile1)
            i.putExtra("proret_mobile2", mobile2)
            i.putExtra("proret_saddress", saddre)
            i.putExtra("proret_saddress1", saddre1)
            i.putExtra("listener",commlistener)
            i.putExtra("fieldlistenersave",fieldlistenr)
            i.putExtra("editclipro",editclipro)
            i.putExtra("editclisupp",editclisupp)

            i.putExtra("proret_saddress2", saddre2)
            i.putExtra("proret_scity", scity)
            i.putExtra("proret_sstate", sstate)
            i.putExtra("proret_spin", spin)
            i.putExtra("proret_sgps", sgps)
            i.putExtra("proret_smail", smail)
            i.putExtra("proret_sgstcd", sgstcode)
            i.putExtra("proret_status", status)
            i.putExtra("proret_url", urlim)
            i.putExtra("proret_sids", sids)
            i.putExtra("retimg1", fn1sup)
            i.putExtra("retimg2", sn1sup)
            i.putExtra("retimg3", tn1sup)
            i.putExtra("retimg4", fon1sup)
            i.putExtra("retimg5", fifn1sup)
            i.putExtra("returl1", f1sup)
            i.putExtra("returl2", s1sup)
            i.putExtra("returl3", t1sup)
            i.putExtra("returl4", fo1sup)
            i.putExtra("returl5", fif1sup)

            i.putExtra("img1urlhigh",img1urlsuphigh)
            i.putExtra("img2urlhigh",img2urlsuphigh)
            i.putExtra("img3urlhigh",img3urlsuphigh)
            i.putExtra("img4urlhigh",img4urlsuphigh)
            i.putExtra("img5urlhigh",img5urlsuphigh)
            i.putExtra("img1nhigh",img1nsuphigh)
            i.putExtra("img2nhigh",img2nsuphigh)
            i.putExtra("img3nhigh",img3nsuphigh)
            i.putExtra("img4nhigh",img4nsuphigh)
            i.putExtra("img5nhigh",img5nsuphigh)


            i.putExtra("f1edit",f1supedit)
            i.putExtra("s1edit",s1supedit)
            i.putExtra("t1edit",t1supedit)
            i.putExtra("fo1edit",fo1supedit)
            i.putExtra("fif1edit",fif1supedit)
            i.putExtra("fn1edit",fn1supedit)
            i.putExtra("sn1edit",sn1supedit)
            i.putExtra("tn1edit",tn1supedit)
            i.putExtra("fon1edit",fon1supedit)
            i.putExtra("fifn1edit",fifn1supedit)
            i.putExtra("f1edithigh",f1supedithigh)
            i.putExtra("s1edithigh",s1supedithigh)
            i.putExtra("t1edithigh",t1supedithigh)
            i.putExtra("fo1edithigh",fo1supedithigh)
            i.putExtra("fif1edithigh",fif1supedithigh)
            i.putExtra("fn1edithigh",fn1supedithigh)
            i.putExtra("sn1edithigh",sn1supedithigh)
            i.putExtra("tn1edithigh",tn1supedithigh)
            i.putExtra("fon1edithigh",fon1supedithigh)
            i.putExtra("fifn1edithigh",fifn1supedithigh)

            i.putExtra("file_maps",file_maps)
            i.putExtra("mresultsarr",mresultsarr)


            i.putExtra("listenersave",listnersave)


            startActivity(i)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
        }






    if (((f1.isNotEmpty()) || (s1.isNotEmpty()) || (t1.isNotEmpty()) || (fo1.isNotEmpty()) || (fif1.isNotEmpty())||(commlistener == "change"))&&(sup_pid.text.toString()=="Auto-generated")) {


        val builder = android.app.AlertDialog.Builder(this@SuppProductAddActivity)
            with(builder) {
                setTitle("Save?")
                setMessage("Do you want to save?")
                setPositiveButton("Yes") { dialog, whichButton ->
                    if(net_status()==true) {

                        if (sup_pname.length() == 0) {
                            errorpnm.visibility = View.VISIBLE
                            Toast.makeText(applicationContext, "Product name required", Toast.LENGTH_SHORT).show()
                            errorpnm.setError("Field cannot be empty")
                            errorpnm.setText("Field cannot be empty")
                        }
                        if (sup_price.length() == 0) {
                            errorprice.visibility = View.VISIBLE
                            Toast.makeText(applicationContext, "Product price required", Toast.LENGTH_SHORT).show()

                            errorprice.setError("Field cannot be empty")
                            errorprice.setText("Field cannot be empty")
                        }
                        if ((id.text == "") && (errorpnm.visibility == View.INVISIBLE) && (errorprice.visibility == View.INVISIBLE)) {
                            Toast.makeText(applicationContext, "Saving...", Toast.LENGTH_LONG).show()
                            onStarClicked1()
                            println("IN TIMEEEE")
                        }


                    }
                    else{
                        dialog.dismiss()
                    }

                }
                setNegativeButton("No") { dialog, whichButton ->
                    if ((id.text.toString().isEmpty())&&((sup_pid.text.toString()=="Auto-generated"))) {

                        dialog.dismiss()

                        val progressDialog = ProgressDialog(this@SuppProductAddActivity);
                        progressDialog.setTitle("Please wait...");
                        progressDialog.setMessage("wait for a while...");
                        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                        progressDialog.show();
                        progressDialog.setCancelable(false);

                        val del = ArrayList<String>()
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        if (fn1.isEmpty() && sn1.isEmpty() && tn1.isEmpty() && fon1.isEmpty() && fifn1.isEmpty()) {
                            progressDialog.dismiss()
                            val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                            i.putExtra("sndproky", "eventlist")

                            val sname = (textView1.text).toString()
                            val sid = textView22.text.toString()
                            val scon = textView33.text.toString()
                            val mob = textView4.text.toString()
                            val mob1 = textView5.text.toString()
                            val mob2 = textView6.text.toString()
                            val mobile = textView7.text.toString()
                            val mobile1 = textView8.text.toString()
                            val mobile2 = textView9.text.toString()
                            val saddre = textView10.text.toString()
                            val saddre1 = textView11.text.toString()
                            val saddre2 = textView12.text.toString()
                            val scity = textView13.text.toString()
                            val sstate = textView14.text.toString()
                            val spin = textView15.text.toString()
                            val sgps = textView16.text.toString()
                            val smail = textView17.text.toString()
                            val sgstcode = textView18.text.toString()
                            val urlim = textView19.text.toString()
                            val sids = textView20.text.toString()
                            val status = textView21.text.toString()

                            i.putExtra("addspro", addsupppro)
                            i.putExtra("editspro", editesupppro)
                            i.putExtra("viewspro", viewsupppro)
                            i.putExtra("deletespro", deletesupppro)
                            i.putExtra("importspro", importsupppro)
                            i.putExtra("exportspro", exportsupppro)
                            i.putExtra("keys", prokey.text.toString())
                            i.putExtra("startlistprky",startlistprokey)

                            i.putExtra("profrmprky",productprokey)

                            i.putExtra("prret_sname1", sname)

                            i.putExtra("proret_sid1", sid)
                            i.putExtra("proret_scon1", scon)
                            i.putExtra("proret_mob", mob)
                            i.putExtra("proret_mob1", mob1)
                            i.putExtra("proret_mob2", mob2)
                            i.putExtra("proret_mobile", mobile)
                            i.putExtra("proret_mobile1", mobile1)
                            i.putExtra("proret_mobile2", mobile2)
                            i.putExtra("proret_saddress", saddre)
                            i.putExtra("proret_saddress1", saddre1)
                            i.putExtra("listener",commlistener)
                            i.putExtra("fieldlistenersave",fieldlistenr)
                            i.putExtra("editclipro",editclipro)
                            i.putExtra("editclisupp",editclisupp)

                            i.putExtra("proret_saddress2", saddre2)
                            i.putExtra("proret_scity", scity)
                            i.putExtra("proret_sstate", sstate)
                            i.putExtra("proret_spin", spin)
                            i.putExtra("proret_sgps", sgps)
                            i.putExtra("proret_smail", smail)
                            i.putExtra("proret_sgstcd", sgstcode)
                            i.putExtra("proret_status", status)
                            i.putExtra("proret_url", urlim)
                            i.putExtra("proret_sids", sids)
                            i.putExtra("retimg1", fn1sup)
                            i.putExtra("retimg2", sn1sup)
                            i.putExtra("retimg3", tn1sup)
                            i.putExtra("retimg4", fon1sup)
                            i.putExtra("retimg5", fifn1sup)
                            i.putExtra("returl1", f1sup)
                            i.putExtra("returl2", s1sup)
                            i.putExtra("returl3", t1sup)
                            i.putExtra("returl4", fo1sup)
                            i.putExtra("returl5", fif1sup)

                            i.putExtra("img1urlhigh",img1urlsuphigh)
                            i.putExtra("img2urlhigh",img2urlsuphigh)
                            i.putExtra("img3urlhigh",img3urlsuphigh)
                            i.putExtra("img4urlhigh",img4urlsuphigh)
                            i.putExtra("img5urlhigh",img5urlsuphigh)
                            i.putExtra("img1nhigh",img1nsuphigh)
                            i.putExtra("img2nhigh",img2nsuphigh)
                            i.putExtra("img3nhigh",img3nsuphigh)
                            i.putExtra("img4nhigh",img4nsuphigh)
                            i.putExtra("img5nhigh",img5nsuphigh)


                            i.putExtra("f1edit",f1supedit)
                            i.putExtra("s1edit",s1supedit)
                            i.putExtra("t1edit",t1supedit)
                            i.putExtra("fo1edit",fo1supedit)
                            i.putExtra("fif1edit",fif1supedit)
                            i.putExtra("fn1edit",fn1supedit)
                            i.putExtra("sn1edit",sn1supedit)
                            i.putExtra("tn1edit",tn1supedit)
                            i.putExtra("fon1edit",fon1supedit)
                            i.putExtra("fifn1edit",fifn1supedit)
                            i.putExtra("f1edithigh",f1supedithigh)
                            i.putExtra("s1edithigh",s1supedithigh)
                            i.putExtra("t1edithigh",t1supedithigh)
                            i.putExtra("fo1edithigh",fo1supedithigh)
                            i.putExtra("fif1edithigh",fif1supedithigh)
                            i.putExtra("fn1edithigh",fn1supedithigh)
                            i.putExtra("sn1edithigh",sn1supedithigh)
                            i.putExtra("tn1edithigh",tn1supedithigh)
                            i.putExtra("fon1edithigh",fon1supedithigh)
                            i.putExtra("fifn1edithigh",fifn1supedithigh)

                            i.putExtra("file_maps",file_maps)
                            i.putExtra("mresultsarr",mresultsarr)


                            i.putExtra("listenersave",listnersave)


                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            finish()
                        }
                        val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                        val dir = File(path);

                        if (fn1.isNotEmpty()) {
                            val k = img1nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }

                            del.add(fn1)
                            del.add(img1nhigh)
                        }
                        if (sn1.isNotEmpty()) {
                            val k = img2nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            del.add(sn1)
                            del.add(img2nhigh)
                        }
                        if (tn1.isNotEmpty()) {
                            val k = img3nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            del.add(tn1)
                            del.add(img3nhigh)
                        }
                        if (fon1.isNotEmpty()) {
                            val k = img4nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            del.add(fon1)
                            del.add(img4nhigh)
                        }
                        if (fifn1.isNotEmpty()) {
                            val k = img5nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            del.add(fifn1)
                            del.add(img5nhigh)
                        }
                        if ((del.size >= 0)&&(net_status()==true)) {
                            for (i in del) {
                                val imagesRef = storageRef.child("supp_products").child(i)
                                imagesRef.delete()
                                        .addOnSuccessListener {
                                            if (i == del.get(del.size - 1)) {
                                                progressDialog.dismiss()
                                                val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                                                i.putExtra("sndproky", "eventlist")

                                                val sname = (textView1.text).toString()
                                                val sid = textView22.text.toString()
                                                val scon = textView33.text.toString()
                                                val mob = textView4.text.toString()
                                                val mob1 = textView5.text.toString()
                                                val mob2 = textView6.text.toString()
                                                val mobile = textView7.text.toString()
                                                val mobile1 = textView8.text.toString()
                                                val mobile2 = textView9.text.toString()
                                                val saddre = textView10.text.toString()
                                                val saddre1 = textView11.text.toString()
                                                val saddre2 = textView12.text.toString()
                                                val scity = textView13.text.toString()
                                                val sstate = textView14.text.toString()
                                                val spin = textView15.text.toString()
                                                val sgps = textView16.text.toString()
                                                val smail = textView17.text.toString()
                                                val sgstcode = textView18.text.toString()
                                                val urlim = textView19.text.toString()
                                                val sids = textView20.text.toString()
                                                val status = textView21.text.toString()

                                                i.putExtra("addspro", addsupppro)
                                                i.putExtra("editspro", editesupppro)
                                                i.putExtra("viewspro", viewsupppro)
                                                i.putExtra("deletespro", deletesupppro)
                                                i.putExtra("importspro", importsupppro)
                                                i.putExtra("exportspro", exportsupppro)
                                                i.putExtra("keys", prokey.text.toString())
                                                i.putExtra("startlistprky",startlistprokey)

                                                i.putExtra("profrmprky",productprokey)

                                                i.putExtra("prret_sname1", sname)

                                                i.putExtra("proret_sid1", sid)
                                                i.putExtra("proret_scon1", scon)
                                                i.putExtra("proret_mob", mob)
                                                i.putExtra("proret_mob1", mob1)
                                                i.putExtra("proret_mob2", mob2)
                                                i.putExtra("proret_mobile", mobile)
                                                i.putExtra("proret_mobile1", mobile1)
                                                i.putExtra("proret_mobile2", mobile2)
                                                i.putExtra("proret_saddress", saddre)
                                                i.putExtra("proret_saddress1", saddre1)
                                                i.putExtra("listener",commlistener)
                                                i.putExtra("fieldlistenersave",fieldlistenr)
                                                i.putExtra("editclipro",editclipro)
                                                i.putExtra("editclisupp",editclisupp)

                                                i.putExtra("proret_saddress2", saddre2)
                                                i.putExtra("proret_scity", scity)
                                                i.putExtra("proret_sstate", sstate)
                                                i.putExtra("proret_spin", spin)
                                                i.putExtra("proret_sgps", sgps)
                                                i.putExtra("proret_smail", smail)
                                                i.putExtra("proret_sgstcd", sgstcode)
                                                i.putExtra("proret_status", status)
                                                i.putExtra("proret_url", urlim)
                                                i.putExtra("proret_sids", sids)
                                                i.putExtra("retimg1", fn1sup)
                                                i.putExtra("retimg2", sn1sup)
                                                i.putExtra("retimg3", tn1sup)
                                                i.putExtra("retimg4", fon1sup)
                                                i.putExtra("retimg5", fifn1sup)
                                                i.putExtra("returl1", f1sup)
                                                i.putExtra("returl2", s1sup)
                                                i.putExtra("returl3", t1sup)
                                                i.putExtra("returl4", fo1sup)
                                                i.putExtra("returl5", fif1sup)

                                                i.putExtra("img1urlhigh",img1urlsuphigh)
                                                i.putExtra("img2urlhigh",img2urlsuphigh)
                                                i.putExtra("img3urlhigh",img3urlsuphigh)
                                                i.putExtra("img4urlhigh",img4urlsuphigh)
                                                i.putExtra("img5urlhigh",img5urlsuphigh)
                                                i.putExtra("img1nhigh",img1nsuphigh)
                                                i.putExtra("img2nhigh",img2nsuphigh)
                                                i.putExtra("img3nhigh",img3nsuphigh)
                                                i.putExtra("img4nhigh",img4nsuphigh)
                                                i.putExtra("img5nhigh",img5nsuphigh)


                                                i.putExtra("f1edit",f1supedit)
                                                i.putExtra("s1edit",s1supedit)
                                                i.putExtra("t1edit",t1supedit)
                                                i.putExtra("fo1edit",fo1supedit)
                                                i.putExtra("fif1edit",fif1supedit)
                                                i.putExtra("fn1edit",fn1supedit)
                                                i.putExtra("sn1edit",sn1supedit)
                                                i.putExtra("tn1edit",tn1supedit)
                                                i.putExtra("fon1edit",fon1supedit)
                                                i.putExtra("fifn1edit",fifn1supedit)
                                                i.putExtra("f1edithigh",f1supedithigh)
                                                i.putExtra("s1edithigh",s1supedithigh)
                                                i.putExtra("t1edithigh",t1supedithigh)
                                                i.putExtra("fo1edithigh",fo1supedithigh)
                                                i.putExtra("fif1edithigh",fif1supedithigh)
                                                i.putExtra("fn1edithigh",fn1supedithigh)
                                                i.putExtra("sn1edithigh",sn1supedithigh)
                                                i.putExtra("tn1edithigh",tn1supedithigh)
                                                i.putExtra("fon1edithigh",fon1supedithigh)
                                                i.putExtra("fifn1edithigh",fifn1supedithigh)

                                                i.putExtra("file_maps",file_maps)
                                                i.putExtra("mresultsarr",mresultsarr)


                                                i.putExtra("listenersave",listnersave)


                                                startActivity(i)
                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                finish()
                                            }
                                        }
                                        .addOnCompleteListener {
                                        }
                            }
                        }
                        else{
                            progressDialog.dismiss()
                            val o=Intent(this@SuppProductAddActivity,MainProductlistActivity::class.java)

                            val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                            i.putExtra("sndproky", "eventlist")

                            val sname = (textView1.text).toString()
                            val sid = textView22.text.toString()
                            val scon = textView33.text.toString()
                            val mob = textView4.text.toString()
                            val mob1 = textView5.text.toString()
                            val mob2 = textView6.text.toString()
                            val mobile = textView7.text.toString()
                            val mobile1 = textView8.text.toString()
                            val mobile2 = textView9.text.toString()
                            val saddre = textView10.text.toString()
                            val saddre1 = textView11.text.toString()
                            val saddre2 = textView12.text.toString()
                            val scity = textView13.text.toString()
                            val sstate = textView14.text.toString()
                            val spin = textView15.text.toString()
                            val sgps = textView16.text.toString()
                            val smail = textView17.text.toString()
                            val sgstcode = textView18.text.toString()
                            val urlim = textView19.text.toString()
                            val sids = textView20.text.toString()
                            val status = textView21.text.toString()

                            i.putExtra("addspro", addsupppro)
                            i.putExtra("editspro", editesupppro)
                            i.putExtra("viewspro", viewsupppro)
                            i.putExtra("deletespro", deletesupppro)
                            i.putExtra("importspro", importsupppro)
                            i.putExtra("exportspro", exportsupppro)
                            i.putExtra("keys", prokey.text.toString())
                            i.putExtra("startlistprky",startlistprokey)

                            i.putExtra("profrmprky",productprokey)

                            i.putExtra("prret_sname1", sname)

                            i.putExtra("proret_sid1", sid)
                            i.putExtra("proret_scon1", scon)
                            i.putExtra("proret_mob", mob)
                            i.putExtra("proret_mob1", mob1)
                            i.putExtra("proret_mob2", mob2)
                            i.putExtra("proret_mobile", mobile)
                            i.putExtra("proret_mobile1", mobile1)
                            i.putExtra("proret_mobile2", mobile2)
                            i.putExtra("proret_saddress", saddre)
                            i.putExtra("proret_saddress1", saddre1)
                            i.putExtra("listener",commlistener)
                            i.putExtra("fieldlistenersave",fieldlistenr)
                            i.putExtra("editclipro",editclipro)
                            i.putExtra("editclisupp",editclisupp)

                            i.putExtra("proret_saddress2", saddre2)
                            i.putExtra("proret_scity", scity)
                            i.putExtra("proret_sstate", sstate)
                            i.putExtra("proret_spin", spin)
                            i.putExtra("proret_sgps", sgps)
                            i.putExtra("proret_smail", smail)
                            i.putExtra("proret_sgstcd", sgstcode)
                            i.putExtra("proret_status", status)
                            i.putExtra("proret_url", urlim)
                            i.putExtra("proret_sids", sids)
                            i.putExtra("retimg1", fn1sup)
                            i.putExtra("retimg2", sn1sup)
                            i.putExtra("retimg3", tn1sup)
                            i.putExtra("retimg4", fon1sup)
                            i.putExtra("retimg5", fifn1sup)
                            i.putExtra("returl1", f1sup)
                            i.putExtra("returl2", s1sup)
                            i.putExtra("returl3", t1sup)
                            i.putExtra("returl4", fo1sup)
                            i.putExtra("returl5", fif1sup)

                            i.putExtra("img1urlhigh",img1urlsuphigh)
                            i.putExtra("img2urlhigh",img2urlsuphigh)
                            i.putExtra("img3urlhigh",img3urlsuphigh)
                            i.putExtra("img4urlhigh",img4urlsuphigh)
                            i.putExtra("img5urlhigh",img5urlsuphigh)
                            i.putExtra("img1nhigh",img1nsuphigh)
                            i.putExtra("img2nhigh",img2nsuphigh)
                            i.putExtra("img3nhigh",img3nsuphigh)
                            i.putExtra("img4nhigh",img4nsuphigh)
                            i.putExtra("img5nhigh",img5nsuphigh)


                            i.putExtra("f1edit",f1supedit)
                            i.putExtra("s1edit",s1supedit)
                            i.putExtra("t1edit",t1supedit)
                            i.putExtra("fo1edit",fo1supedit)
                            i.putExtra("fif1edit",fif1supedit)
                            i.putExtra("fn1edit",fn1supedit)
                            i.putExtra("sn1edit",sn1supedit)
                            i.putExtra("tn1edit",tn1supedit)
                            i.putExtra("fon1edit",fon1supedit)
                            i.putExtra("fifn1edit",fifn1supedit)
                            i.putExtra("f1edithigh",f1supedithigh)
                            i.putExtra("s1edithigh",s1supedithigh)
                            i.putExtra("t1edithigh",t1supedithigh)
                            i.putExtra("fo1edithigh",fo1supedithigh)
                            i.putExtra("fif1edithigh",fif1supedithigh)
                            i.putExtra("fn1edithigh",fn1supedithigh)
                            i.putExtra("sn1edithigh",sn1supedithigh)
                            i.putExtra("tn1edithigh",tn1supedithigh)
                            i.putExtra("fon1edithigh",fon1supedithigh)
                            i.putExtra("fifn1edithigh",fifn1supedithigh)

                            i.putExtra("file_maps",file_maps)
                            i.putExtra("mresultsarr",mresultsarr)


                            i.putExtra("listenersave",listnersave)


                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            finish()
                        }
                    }
                    else{
                        Toast.makeText(applicationContext,"No internet Connection",Toast.LENGTH_SHORT).show()
                        val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                        i.putExtra("sndproky", "eventlist")

                        val sname = (textView1.text).toString()
                        val sid = textView22.text.toString()
                        val scon = textView33.text.toString()
                        val mob = textView4.text.toString()
                        val mob1 = textView5.text.toString()
                        val mob2 = textView6.text.toString()
                        val mobile = textView7.text.toString()
                        val mobile1 = textView8.text.toString()
                        val mobile2 = textView9.text.toString()
                        val saddre = textView10.text.toString()
                        val saddre1 = textView11.text.toString()
                        val saddre2 = textView12.text.toString()
                        val scity = textView13.text.toString()
                        val sstate = textView14.text.toString()
                        val spin = textView15.text.toString()
                        val sgps = textView16.text.toString()
                        val smail = textView17.text.toString()
                        val sgstcode = textView18.text.toString()
                        val urlim = textView19.text.toString()
                        val sids = textView20.text.toString()
                        val status = textView21.text.toString()

                        i.putExtra("addspro", addsupppro)
                        i.putExtra("editspro", editesupppro)
                        i.putExtra("viewspro", viewsupppro)
                        i.putExtra("deletespro", deletesupppro)
                        i.putExtra("importspro", importsupppro)
                        i.putExtra("exportspro", exportsupppro)
                        i.putExtra("keys", prokey.text.toString())
                        i.putExtra("startlistprky",startlistprokey)

                        i.putExtra("profrmprky",productprokey)

                        i.putExtra("prret_sname1", sname)

                        i.putExtra("proret_sid1", sid)
                        i.putExtra("proret_scon1", scon)
                        i.putExtra("proret_mob", mob)
                        i.putExtra("proret_mob1", mob1)
                        i.putExtra("proret_mob2", mob2)
                        i.putExtra("proret_mobile", mobile)
                        i.putExtra("proret_mobile1", mobile1)
                        i.putExtra("proret_mobile2", mobile2)
                        i.putExtra("proret_saddress", saddre)
                        i.putExtra("proret_saddress1", saddre1)
                        i.putExtra("listener",commlistener)
                        i.putExtra("fieldlistenersave",fieldlistenr)
                        i.putExtra("editclipro",editclipro)
                        i.putExtra("editclisupp",editclisupp)

                        i.putExtra("proret_saddress2", saddre2)
                        i.putExtra("proret_scity", scity)
                        i.putExtra("proret_sstate", sstate)
                        i.putExtra("proret_spin", spin)
                        i.putExtra("proret_sgps", sgps)
                        i.putExtra("proret_smail", smail)
                        i.putExtra("proret_sgstcd", sgstcode)
                        i.putExtra("proret_status", status)
                        i.putExtra("proret_url", urlim)
                        i.putExtra("proret_sids", sids)
                        i.putExtra("retimg1", fn1sup)
                        i.putExtra("retimg2", sn1sup)
                        i.putExtra("retimg3", tn1sup)
                        i.putExtra("retimg4", fon1sup)
                        i.putExtra("retimg5", fifn1sup)
                        i.putExtra("returl1", f1sup)
                        i.putExtra("returl2", s1sup)
                        i.putExtra("returl3", t1sup)
                        i.putExtra("returl4", fo1sup)
                        i.putExtra("returl5", fif1sup)

                        i.putExtra("img1urlhigh",img1urlsuphigh)
                        i.putExtra("img2urlhigh",img2urlsuphigh)
                        i.putExtra("img3urlhigh",img3urlsuphigh)
                        i.putExtra("img4urlhigh",img4urlsuphigh)
                        i.putExtra("img5urlhigh",img5urlsuphigh)
                        i.putExtra("img1nhigh",img1nsuphigh)
                        i.putExtra("img2nhigh",img2nsuphigh)
                        i.putExtra("img3nhigh",img3nsuphigh)
                        i.putExtra("img4nhigh",img4nsuphigh)
                        i.putExtra("img5nhigh",img5nsuphigh)


                        i.putExtra("f1edit",f1supedit)
                        i.putExtra("s1edit",s1supedit)
                        i.putExtra("t1edit",t1supedit)
                        i.putExtra("fo1edit",fo1supedit)
                        i.putExtra("fif1edit",fif1supedit)
                        i.putExtra("fn1edit",fn1supedit)
                        i.putExtra("sn1edit",sn1supedit)
                        i.putExtra("tn1edit",tn1supedit)
                        i.putExtra("fon1edit",fon1supedit)
                        i.putExtra("fifn1edit",fifn1supedit)
                        i.putExtra("f1edithigh",f1supedithigh)
                        i.putExtra("s1edithigh",s1supedithigh)
                        i.putExtra("t1edithigh",t1supedithigh)
                        i.putExtra("fo1edithigh",fo1supedithigh)
                        i.putExtra("fif1edithigh",fif1supedithigh)
                        i.putExtra("fn1edithigh",fn1supedithigh)
                        i.putExtra("sn1edithigh",sn1supedithigh)
                        i.putExtra("tn1edithigh",tn1supedithigh)
                        i.putExtra("fon1edithigh",fon1supedithigh)
                        i.putExtra("fifn1edithigh",fifn1supedithigh)

                        i.putExtra("file_maps",file_maps)
                        i.putExtra("mresultsarr",mresultsarr)


                        i.putExtra("listenersave",listnersave)


                        startActivity(i)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                        finish()
                    }








                }
                val dialog = builder.create()
                dialog.show()
            }
        }  else if ((commlistener == "change")&&(id.text.toString().isNotEmpty())) {
            println("LISTENER"+commlistener)
            val builder = android.app.AlertDialog.Builder(this@SuppProductAddActivity)
            with(builder) {
                setTitle("Save Changes?")
                setMessage("Do you want to save?")
                setPositiveButton("Yes") { dialog, whichButton ->
                    if(net_status()==true) {

                        var pid = (sup_pid.text).toString()
                        var pname = (sup_pname.text).toString()
                        var bcode = (sup_bcode.text).toString()
                        var pdes = (sup_hscdes.text).toString()

                        var weight = (sup_vol.text).toString()
                        var psac = (sup_hsc.text).toString()
                        var stockonhand = (sup_stockhand.text).toString()

                        var minstock = (sup_minstock.text).toString()
                        var maxstock = (sup_maxstock.text).toString()
                        var price = (sup_price.text).toString()
                        var taxable = (sup_taxcheck.isChecked).toString()
                        var igst = (sup_intgst.text).toString()
                        var cgst = (sup_centgst.text).toString()
                        var sgst = (sup_stategst.text).toString()
                        var cess = (sup_cess.text).toString()
                        var taxtotal = (sup_taxtot.text).toString()
                        var cessval = (sup_cessvalue.text).toString()
                        var saveky = (savekey.text).toString()

                        var mrP = (sup_mrp.text).toString()
                        var cate = sup_cate.selectedItem.toString()
                        var manufacture = sup_manu.selectedItem.toString()
                        var ut = sup_unit.selectedItem.toString()

                        var status = (disable.text).toString()
                        val img1n = fn1
                        val img2n = sn1
                        val img3n = tn1
                        val img4n = fon1
                        val img5n = fifn1
                        val img1url = f1
                        val img2url = s1
                        val img3url = t1
                        val img4url = fo1
                        val img5url = fif1


                        val data = s(sp_id = pid, sp_nm = pname, spbc = bcode, spdesc = pdes, spwg_vol = weight, sphsn = psac, spctgy = cate,
                                spmfr = manufacture, sput = ut, spmin_stk = minstock, spprice = price, spmx_stk = maxstock,
                                sptaxchk = taxable, spigst = igst, spcgst = cgst, spsgst = sgst, spcess = cess, sptaxtot = taxtotal,
                                spcesstot = cessval, spmrp = mrP, status = status, spstock_hand = stockonhand, spsave_key = saveky, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n,
                                img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh,
                                img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,img1urlhigh = img1urlhigh,
                                img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)



                        if ((id.text != "") && (errorpnm.visibility == View.INVISIBLE) && (errorprice.visibility == View.INVISIBLE)) {

                            val pDialog = SweetAlertDialog(this@SuppProductAddActivity, SweetAlertDialog.PROGRESS_TYPE);
                            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialog.setTitleText("Saving...");
                            pDialog.setCancelable(false);
                            pDialog.show();
                            val db = FirebaseFirestore.getInstance()

                            db.collection("supplier_products").document(id.text.toString())

                                    .set(data)
                                    .addOnSuccessListener {

                                        Toast.makeText(this@SuppProductAddActivity, "data is updated", Toast.LENGTH_LONG).show()
                                        pDialog.dismiss()
                                        val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                                        i.putExtra("sndproky", "eventlist")

                                        val sname = (textView1.text).toString()
                                        val sid = textView22.text.toString()
                                        val scon = textView33.text.toString()
                                        val mob = textView4.text.toString()
                                        val mob1 = textView5.text.toString()
                                        val mob2 = textView6.text.toString()
                                        val mobile = textView7.text.toString()
                                        val mobile1 = textView8.text.toString()
                                        val mobile2 = textView9.text.toString()
                                        val saddre = textView10.text.toString()
                                        val saddre1 = textView11.text.toString()
                                        val saddre2 = textView12.text.toString()
                                        val scity = textView13.text.toString()
                                        val sstate = textView14.text.toString()
                                        val spin = textView15.text.toString()
                                        val sgps = textView16.text.toString()
                                        val smail = textView17.text.toString()
                                        val sgstcode = textView18.text.toString()
                                        val urlim = textView19.text.toString()
                                        val sids = textView20.text.toString()
                                        val status = textView21.text.toString()

                                        i.putExtra("addspro", addsupppro)
                                        i.putExtra("editspro", editesupppro)
                                        i.putExtra("viewspro", viewsupppro)
                                        i.putExtra("deletespro", deletesupppro)
                                        i.putExtra("importspro", importsupppro)
                                        i.putExtra("exportspro", exportsupppro)
                                        i.putExtra("keys", prokey.text.toString())
                                        i.putExtra("listenersave", listnersave)
                                        i.putExtra("fieldlistenersave", fieldlistenr)
                                        i.putExtra("editclipro", editclipro)
                                        i.putExtra("editclisupp", editclisupp)

                                        i.putExtra("prret_sname1", sname)

                                        i.putExtra("proret_sid1", sid)
                                        i.putExtra("proret_scon1", scon)
                                        i.putExtra("proret_mob", mob)
                                        i.putExtra("proret_mob1", mob1)
                                        i.putExtra("proret_mob2", mob2)
                                        i.putExtra("proret_mobile", mobile)
                                        i.putExtra("proret_mobile1", mobile1)
                                        i.putExtra("proret_mobile2", mobile2)
                                        i.putExtra("proret_saddress", saddre)
                                        i.putExtra("proret_saddress1", saddre1)

                                        i.putExtra("proret_saddress2", saddre2)
                                        i.putExtra("proret_scity", scity)
                                        i.putExtra("proret_sstate", sstate)
                                        i.putExtra("proret_spin", spin)
                                        i.putExtra("proret_sgps", sgps)
                                        i.putExtra("proret_smail", smail)
                                        i.putExtra("proret_sgstcd", sgstcode)
                                        i.putExtra("proret_status", status)
                                        i.putExtra("proret_url", urlim)
                                        i.putExtra("proret_sids", sids)
                                        i.putExtra("retimg1", fn1sup)
                                        i.putExtra("retimg2", sn1sup)
                                        i.putExtra("retimg3", tn1sup)
                                        i.putExtra("retimg4", fon1sup)
                                        i.putExtra("retimg5", fifn1sup)
                                        i.putExtra("returl1", f1sup)
                                        i.putExtra("returl2", s1sup)
                                        i.putExtra("returl3", t1sup)
                                        i.putExtra("returl4", fo1sup)
                                        i.putExtra("returl5", fif1sup)


                                        i.putExtra("img1urlhigh",img1urlsuphigh)
                                        i.putExtra("img2urlhigh",img2urlsuphigh)
                                        i.putExtra("img3urlhigh",img3urlsuphigh)
                                        i.putExtra("img4urlhigh",img4urlsuphigh)
                                        i.putExtra("img5urlhigh",img5urlsuphigh)
                                        i.putExtra("img1nhigh",img1nsuphigh)
                                        i.putExtra("img2nhigh",img2nsuphigh)
                                        i.putExtra("img3nhigh",img3nsuphigh)
                                        i.putExtra("img4nhigh",img4nsuphigh)
                                        i.putExtra("img5nhigh",img5nsuphigh)


                                        i.putExtra("f1edit",f1supedit)
                                        i.putExtra("s1edit",s1supedit)
                                        i.putExtra("t1edit",t1supedit)
                                        i.putExtra("fo1edit",fo1supedit)
                                        i.putExtra("fif1edit",fif1supedit)
                                        i.putExtra("fn1edit",fn1supedit)
                                        i.putExtra("sn1edit",sn1supedit)
                                        i.putExtra("tn1edit",tn1supedit)
                                        i.putExtra("fon1edit",fon1supedit)
                                        i.putExtra("fifn1edit",fifn1supedit)
                                        i.putExtra("f1edithigh",f1supedithigh)
                                        i.putExtra("s1edithigh",s1supedithigh)
                                        i.putExtra("t1edithigh",t1supedithigh)
                                        i.putExtra("fo1edithigh",fo1supedithigh)
                                        i.putExtra("fif1edithigh",fif1supedithigh)
                                        i.putExtra("fn1edithigh",fn1supedithigh)
                                        i.putExtra("sn1edithigh",sn1supedithigh)
                                        i.putExtra("tn1edithigh",tn1supedithigh)
                                        i.putExtra("fon1edithigh",fon1supedithigh)
                                        i.putExtra("fifn1edithigh",fifn1supedithigh)

                                        i.putExtra("file_maps",file_maps)
                                        i.putExtra("mresultsarr",mresultsarr)
                                        i.putExtra("startlistprky",startlistprokey)

                                        i.putExtra("profrmprky",productprokey)


                                        startActivity(i)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()


                                    }

                                    .addOnFailureListener {
                                        Toast.makeText(this@SuppProductAddActivity, "not updated", Toast.LENGTH_LONG).show()
                                        save_progress.visibility = android.view.View.GONE
                                    }


                        }
                    }
                    else{
                        dialog.dismiss()
                    }
                }
                setNegativeButton("No") { dialog, whichButton ->

                     if ((id.text.isNotEmpty())&&(net_status()==true)) {
                    val delname = ArrayList<String>()
                    val delnameedit = ArrayList<String>()
                    val delnamehigh = ArrayList<String>()
                    val delnameedithigh = ArrayList<String>()
                    val delurl = ArrayList<String>()
                    val delurledit = ArrayList<String>()
                    val delurledithigh = ArrayList<String>()
                    val deldbnm = ArrayList<String>()

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

                    val dir = File(path);

                    val progressDialog = ProgressDialog(this@SuppProductAddActivity);
                    progressDialog.setTitle("Please wait...");
                    progressDialog.setMessage("wait for a while...");
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    progressDialog.show();
                    progressDialog.setCancelable(false);

                    if (fn1 != fn1edit) {
                        val k = img1nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(path);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        delname.add(fn1)
                        delnamehigh.add(img1nhigh)
                    }
                    if (sn1 != sn1edit) {
                        val k = img2nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(path);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        delname.add(sn1)
                        delnamehigh.add(img2nhigh)
                    }
                    if (tn1 != tn1edit) {
                        val k = img3nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(path);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        delname.add(tn1)
                        delnamehigh.add(img3nhigh)
                    }
                    if (fon1 != fon1edit) {
                        val k = img4nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(path);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        delname.add(fon1)
                        delnamehigh.add(img4nhigh)
                    }
                    if (fifn1 != fifn1edit) {
                        val k = img5nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(path);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        delname.add(fifn1)
                        delnamehigh.add(img5nhigh)
                    }


                    println("DELE NAME" + delname)
                    println("DELE NAME HIGH" + delnamehigh)


                    delurl.add(f1edit)
                    delnameedit.add(fn1edit)

                    delurledithigh.add(f1edithigh)
                    delnameedithigh.add(fn1edithigh)

                    dialog.dismiss()


                    deletedb()
                    if ((delname.size >= 0)&&(net_status()==true)) {
                        for (i in delname) {
                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()

                            val imagesRef = storageRef.child("supp_products").child(i)
                            imagesRef.delete()
                                    .addOnSuccessListener {

                                        if (i == delname.get(delname.size - 1)) {
                                            for (i in delnamehigh) {
                                                val imagesRef = storageRef.child("supp_products").child(i)
                                                imagesRef.delete()
                                                        .addOnSuccessListener {
                                                            if (i == delnamehigh.get(delnamehigh.size - 1)) {

                                                                progressDialog.dismiss()
                                                                val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                                                                i.putExtra("sndproky", "eventlist")

                                                                val sname = (textView1.text).toString()
                                                                val sid = textView22.text.toString()
                                                                val scon = textView33.text.toString()
                                                                val mob = textView4.text.toString()
                                                                val mob1 = textView5.text.toString()
                                                                val mob2 = textView6.text.toString()
                                                                val mobile = textView7.text.toString()
                                                                val mobile1 = textView8.text.toString()
                                                                val mobile2 = textView9.text.toString()
                                                                val saddre = textView10.text.toString()
                                                                val saddre1 = textView11.text.toString()
                                                                val saddre2 = textView12.text.toString()
                                                                val scity = textView13.text.toString()
                                                                val sstate = textView14.text.toString()
                                                                val spin = textView15.text.toString()
                                                                val sgps = textView16.text.toString()
                                                                val smail = textView17.text.toString()
                                                                val sgstcode = textView18.text.toString()
                                                                val urlim = textView19.text.toString()
                                                                val sids = textView20.text.toString()
                                                                val status = textView21.text.toString()

                                                                i.putExtra("addspro", addsupppro)
                                                                i.putExtra("editspro", editesupppro)
                                                                i.putExtra("viewspro", viewsupppro)
                                                                i.putExtra("deletespro", deletesupppro)
                                                                i.putExtra("importspro", importsupppro)
                                                                i.putExtra("exportspro", exportsupppro)
                                                                i.putExtra("keys", prokey.text.toString())
                                                                i.putExtra("startlistprky",startlistprokey)

                                                                i.putExtra("profrmprky",productprokey)

                                                                i.putExtra("prret_sname1", sname)

                                                                i.putExtra("proret_sid1", sid)
                                                                i.putExtra("proret_scon1", scon)
                                                                i.putExtra("proret_mob", mob)
                                                                i.putExtra("proret_mob1", mob1)
                                                                i.putExtra("proret_mob2", mob2)
                                                                i.putExtra("proret_mobile", mobile)
                                                                i.putExtra("proret_mobile1", mobile1)
                                                                i.putExtra("proret_mobile2", mobile2)
                                                                i.putExtra("proret_saddress", saddre)
                                                                i.putExtra("proret_saddress1", saddre1)
                                                                i.putExtra("listener",commlistener)
                                                                i.putExtra("fieldlistenersave",fieldlistenr)
                                                                i.putExtra("editclipro",editclipro)
                                                                i.putExtra("editclisupp",editclisupp)

                                                                i.putExtra("proret_saddress2", saddre2)
                                                                i.putExtra("proret_scity", scity)
                                                                i.putExtra("proret_sstate", sstate)
                                                                i.putExtra("proret_spin", spin)
                                                                i.putExtra("proret_sgps", sgps)
                                                                i.putExtra("proret_smail", smail)
                                                                i.putExtra("proret_sgstcd", sgstcode)
                                                                i.putExtra("proret_status", status)
                                                                i.putExtra("proret_url", urlim)
                                                                i.putExtra("proret_sids", sids)
                                                                i.putExtra("retimg1", fn1sup)
                                                                i.putExtra("retimg2", sn1sup)
                                                                i.putExtra("retimg3", tn1sup)
                                                                i.putExtra("retimg4", fon1sup)
                                                                i.putExtra("retimg5", fifn1sup)
                                                                i.putExtra("returl1", f1sup)
                                                                i.putExtra("returl2", s1sup)
                                                                i.putExtra("returl3", t1sup)
                                                                i.putExtra("returl4", fo1sup)
                                                                i.putExtra("returl5", fif1sup)

                                                                i.putExtra("img1urlhigh",img1urlsuphigh)
                                                                i.putExtra("img2urlhigh",img2urlsuphigh)
                                                                i.putExtra("img3urlhigh",img3urlsuphigh)
                                                                i.putExtra("img4urlhigh",img4urlsuphigh)
                                                                i.putExtra("img5urlhigh",img5urlsuphigh)
                                                                i.putExtra("img1nhigh",img1nsuphigh)
                                                                i.putExtra("img2nhigh",img2nsuphigh)
                                                                i.putExtra("img3nhigh",img3nsuphigh)
                                                                i.putExtra("img4nhigh",img4nsuphigh)
                                                                i.putExtra("img5nhigh",img5nsuphigh)


                                                                i.putExtra("f1edit",f1supedit)
                                                                i.putExtra("s1edit",s1supedit)
                                                                i.putExtra("t1edit",t1supedit)
                                                                i.putExtra("fo1edit",fo1supedit)
                                                                i.putExtra("fif1edit",fif1supedit)
                                                                i.putExtra("fn1edit",fn1supedit)
                                                                i.putExtra("sn1edit",sn1supedit)
                                                                i.putExtra("tn1edit",tn1supedit)
                                                                i.putExtra("fon1edit",fon1supedit)
                                                                i.putExtra("fifn1edit",fifn1supedit)
                                                                i.putExtra("f1edithigh",f1supedithigh)
                                                                i.putExtra("s1edithigh",s1supedithigh)
                                                                i.putExtra("t1edithigh",t1supedithigh)
                                                                i.putExtra("fo1edithigh",fo1supedithigh)
                                                                i.putExtra("fif1edithigh",fif1supedithigh)
                                                                i.putExtra("fn1edithigh",fn1supedithigh)
                                                                i.putExtra("sn1edithigh",sn1supedithigh)
                                                                i.putExtra("tn1edithigh",tn1supedithigh)
                                                                i.putExtra("fon1edithigh",fon1supedithigh)
                                                                i.putExtra("fifn1edithigh",fifn1supedithigh)

                                                                i.putExtra("file_maps",file_maps)
                                                                i.putExtra("mresultsarr",mresultsarr)


                                                                i.putExtra("listenersave",listnersave)


                                                                startActivity(i)
                                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                                finish()

                                                            }

                                                        }
                                            }
                                        }

                                    }
                        }


                    }
                    else{
                        progressDialog.dismiss()
                        val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                        i.putExtra("sndproky", "eventlist")

                        val sname = (textView1.text).toString()
                        val sid = textView22.text.toString()
                        val scon = textView33.text.toString()
                        val mob = textView4.text.toString()
                        val mob1 = textView5.text.toString()
                        val mob2 = textView6.text.toString()
                        val mobile = textView7.text.toString()
                        val mobile1 = textView8.text.toString()
                        val mobile2 = textView9.text.toString()
                        val saddre = textView10.text.toString()
                        val saddre1 = textView11.text.toString()
                        val saddre2 = textView12.text.toString()
                        val scity = textView13.text.toString()
                        val sstate = textView14.text.toString()
                        val spin = textView15.text.toString()
                        val sgps = textView16.text.toString()
                        val smail = textView17.text.toString()
                        val sgstcode = textView18.text.toString()
                        val urlim = textView19.text.toString()
                        val sids = textView20.text.toString()
                        val status = textView21.text.toString()

                        i.putExtra("addspro", addsupppro)
                        i.putExtra("editspro", editesupppro)
                        i.putExtra("viewspro", viewsupppro)
                        i.putExtra("deletespro", deletesupppro)
                        i.putExtra("importspro", importsupppro)
                        i.putExtra("exportspro", exportsupppro)
                        i.putExtra("keys", prokey.text.toString())
                        i.putExtra("startlistprky",startlistprokey)

                        i.putExtra("profrmprky",productprokey)

                        i.putExtra("prret_sname1", sname)

                        i.putExtra("proret_sid1", sid)
                        i.putExtra("proret_scon1", scon)
                        i.putExtra("proret_mob", mob)
                        i.putExtra("proret_mob1", mob1)
                        i.putExtra("proret_mob2", mob2)
                        i.putExtra("proret_mobile", mobile)
                        i.putExtra("proret_mobile1", mobile1)
                        i.putExtra("proret_mobile2", mobile2)
                        i.putExtra("proret_saddress", saddre)
                        i.putExtra("proret_saddress1", saddre1)
                        i.putExtra("listener",commlistener)
                        i.putExtra("fieldlistenersave",fieldlistenr)
                        i.putExtra("editclipro",editclipro)
                        i.putExtra("editclisupp",editclisupp)

                        i.putExtra("proret_saddress2", saddre2)
                        i.putExtra("proret_scity", scity)
                        i.putExtra("proret_sstate", sstate)
                        i.putExtra("proret_spin", spin)
                        i.putExtra("proret_sgps", sgps)
                        i.putExtra("proret_smail", smail)
                        i.putExtra("proret_sgstcd", sgstcode)
                        i.putExtra("proret_status", status)
                        i.putExtra("proret_url", urlim)
                        i.putExtra("proret_sids", sids)
                        i.putExtra("retimg1", fn1sup)
                        i.putExtra("retimg2", sn1sup)
                        i.putExtra("retimg3", tn1sup)
                        i.putExtra("retimg4", fon1sup)
                        i.putExtra("retimg5", fifn1sup)
                        i.putExtra("returl1", f1sup)
                        i.putExtra("returl2", s1sup)
                        i.putExtra("returl3", t1sup)
                        i.putExtra("returl4", fo1sup)
                        i.putExtra("returl5", fif1sup)

                        i.putExtra("img1urlhigh",img1urlsuphigh)
                        i.putExtra("img2urlhigh",img2urlsuphigh)
                        i.putExtra("img3urlhigh",img3urlsuphigh)
                        i.putExtra("img4urlhigh",img4urlsuphigh)
                        i.putExtra("img5urlhigh",img5urlsuphigh)
                        i.putExtra("img1nhigh",img1nsuphigh)
                        i.putExtra("img2nhigh",img2nsuphigh)
                        i.putExtra("img3nhigh",img3nsuphigh)
                        i.putExtra("img4nhigh",img4nsuphigh)
                        i.putExtra("img5nhigh",img5nsuphigh)


                        i.putExtra("f1edit",f1supedit)
                        i.putExtra("s1edit",s1supedit)
                        i.putExtra("t1edit",t1supedit)
                        i.putExtra("fo1edit",fo1supedit)
                        i.putExtra("fif1edit",fif1supedit)
                        i.putExtra("fn1edit",fn1supedit)
                        i.putExtra("sn1edit",sn1supedit)
                        i.putExtra("tn1edit",tn1supedit)
                        i.putExtra("fon1edit",fon1supedit)
                        i.putExtra("fifn1edit",fifn1supedit)
                        i.putExtra("f1edithigh",f1supedithigh)
                        i.putExtra("s1edithigh",s1supedithigh)
                        i.putExtra("t1edithigh",t1supedithigh)
                        i.putExtra("fo1edithigh",fo1supedithigh)
                        i.putExtra("fif1edithigh",fif1supedithigh)
                        i.putExtra("fn1edithigh",fn1supedithigh)
                        i.putExtra("sn1edithigh",sn1supedithigh)
                        i.putExtra("tn1edithigh",tn1supedithigh)
                        i.putExtra("fon1edithigh",fon1supedithigh)
                        i.putExtra("fifn1edithigh",fifn1supedithigh)

                        i.putExtra("file_maps",file_maps)
                        i.putExtra("mresultsarr",mresultsarr)


                        i.putExtra("listenersave",listnersave)


                        startActivity(i)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                        finish()
                    }
                }
                     else{
                         Toast.makeText(applicationContext,"No internet Connection",Toast.LENGTH_SHORT).show()
                         val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


                         i.putExtra("sndproky", "eventlist")

                         val sname = (textView1.text).toString()
                         val sid = textView22.text.toString()
                         val scon = textView33.text.toString()
                         val mob = textView4.text.toString()
                         val mob1 = textView5.text.toString()
                         val mob2 = textView6.text.toString()
                         val mobile = textView7.text.toString()
                         val mobile1 = textView8.text.toString()
                         val mobile2 = textView9.text.toString()
                         val saddre = textView10.text.toString()
                         val saddre1 = textView11.text.toString()
                         val saddre2 = textView12.text.toString()
                         val scity = textView13.text.toString()
                         val sstate = textView14.text.toString()
                         val spin = textView15.text.toString()
                         val sgps = textView16.text.toString()
                         val smail = textView17.text.toString()
                         val sgstcode = textView18.text.toString()
                         val urlim = textView19.text.toString()
                         val sids = textView20.text.toString()
                         val status = textView21.text.toString()

                         i.putExtra("addspro", addsupppro)
                         i.putExtra("editspro", editesupppro)
                         i.putExtra("viewspro", viewsupppro)
                         i.putExtra("deletespro", deletesupppro)
                         i.putExtra("importspro", importsupppro)
                         i.putExtra("exportspro", exportsupppro)
                         i.putExtra("keys", prokey.text.toString())
                         i.putExtra("startlistprky",startlistprokey)

                         i.putExtra("profrmprky",productprokey)

                         i.putExtra("prret_sname1", sname)

                         i.putExtra("proret_sid1", sid)
                         i.putExtra("proret_scon1", scon)
                         i.putExtra("proret_mob", mob)
                         i.putExtra("proret_mob1", mob1)
                         i.putExtra("proret_mob2", mob2)
                         i.putExtra("proret_mobile", mobile)
                         i.putExtra("proret_mobile1", mobile1)
                         i.putExtra("proret_mobile2", mobile2)
                         i.putExtra("proret_saddress", saddre)
                         i.putExtra("proret_saddress1", saddre1)
                         i.putExtra("listener",commlistener)
                         i.putExtra("fieldlistenersave",fieldlistenr)
                         i.putExtra("editclipro",editclipro)
                         i.putExtra("editclisupp",editclisupp)

                         i.putExtra("proret_saddress2", saddre2)
                         i.putExtra("proret_scity", scity)
                         i.putExtra("proret_sstate", sstate)
                         i.putExtra("proret_spin", spin)
                         i.putExtra("proret_sgps", sgps)
                         i.putExtra("proret_smail", smail)
                         i.putExtra("proret_sgstcd", sgstcode)
                         i.putExtra("proret_status", status)
                         i.putExtra("proret_url", urlim)
                         i.putExtra("proret_sids", sids)
                         i.putExtra("retimg1", fn1sup)
                         i.putExtra("retimg2", sn1sup)
                         i.putExtra("retimg3", tn1sup)
                         i.putExtra("retimg4", fon1sup)
                         i.putExtra("retimg5", fifn1sup)
                         i.putExtra("returl1", f1sup)
                         i.putExtra("returl2", s1sup)
                         i.putExtra("returl3", t1sup)
                         i.putExtra("returl4", fo1sup)
                         i.putExtra("returl5", fif1sup)

                         i.putExtra("img1urlhigh",img1urlsuphigh)
                         i.putExtra("img2urlhigh",img2urlsuphigh)
                         i.putExtra("img3urlhigh",img3urlsuphigh)
                         i.putExtra("img4urlhigh",img4urlsuphigh)
                         i.putExtra("img5urlhigh",img5urlsuphigh)
                         i.putExtra("img1nhigh",img1nsuphigh)
                         i.putExtra("img2nhigh",img2nsuphigh)
                         i.putExtra("img3nhigh",img3nsuphigh)
                         i.putExtra("img4nhigh",img4nsuphigh)
                         i.putExtra("img5nhigh",img5nsuphigh)


                         i.putExtra("f1edit",f1supedit)
                         i.putExtra("s1edit",s1supedit)
                         i.putExtra("t1edit",t1supedit)
                         i.putExtra("fo1edit",fo1supedit)
                         i.putExtra("fif1edit",fif1supedit)
                         i.putExtra("fn1edit",fn1supedit)
                         i.putExtra("sn1edit",sn1supedit)
                         i.putExtra("tn1edit",tn1supedit)
                         i.putExtra("fon1edit",fon1supedit)
                         i.putExtra("fifn1edit",fifn1supedit)
                         i.putExtra("f1edithigh",f1supedithigh)
                         i.putExtra("s1edithigh",s1supedithigh)
                         i.putExtra("t1edithigh",t1supedithigh)
                         i.putExtra("fo1edithigh",fo1supedithigh)
                         i.putExtra("fif1edithigh",fif1supedithigh)
                         i.putExtra("fn1edithigh",fn1supedithigh)
                         i.putExtra("sn1edithigh",sn1supedithigh)
                         i.putExtra("tn1edithigh",tn1supedithigh)
                         i.putExtra("fon1edithigh",fon1supedithigh)
                         i.putExtra("fifn1edithigh",fifn1supedithigh)

                         i.putExtra("file_maps",file_maps)
                         i.putExtra("mresultsarr",mresultsarr)


                         i.putExtra("listenersave",listnersave)


                         startActivity(i)
                         overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                         finish()
                     }


                }
                val dialog = builder.create()
                dialog.show()
            }


        }
      /*  else{
            val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


            i.putExtra("sndproky", "eventlist")

            val sname = (textView1.text).toString()
            val sid = textView22.text.toString()
            val scon = textView33.text.toString()
            val mob = textView4.text.toString()
            val mob1 = textView5.text.toString()
            val mob2 = textView6.text.toString()
            val mobile = textView7.text.toString()
            val mobile1 = textView8.text.toString()
            val mobile2 = textView9.text.toString()
            val saddre = textView10.text.toString()
            val saddre1 = textView11.text.toString()
            val saddre2 = textView12.text.toString()
            val scity = textView13.text.toString()
            val sstate = textView14.text.toString()
            val spin = textView15.text.toString()
            val sgps = textView16.text.toString()
            val smail = textView17.text.toString()
            val sgstcode = textView18.text.toString()
            val urlim = textView19.text.toString()
            val sids = textView20.text.toString()
            val status = textView21.text.toString()

            i.putExtra("addspro", addsupppro)
            i.putExtra("editspro", editesupppro)
            i.putExtra("viewspro", viewsupppro)
            i.putExtra("deletespro", deletesupppro)
            i.putExtra("importspro", importsupppro)
            i.putExtra("exportspro", exportsupppro)
            i.putExtra("keys", prokey.text.toString())
            i.putExtra("fieldlistenersave",fieldlistenr)
            i.putExtra("editclipro",editclipro)
            i.putExtra("editclisupp",editclisupp)
            i.putExtra("prret_sname1", sname)
            i.putExtra("listenersave",listnersave)
            i.putExtra("startlistprky",startlistprokey)

            i.putExtra("profrmprky",productprokey)


            i.putExtra("proret_sid1", sid)
            i.putExtra("proret_scon1", scon)
            i.putExtra("proret_mob", mob)
            i.putExtra("proret_mob1", mob1)
            i.putExtra("proret_mob2", mob2)
            i.putExtra("proret_mobile", mobile)
            i.putExtra("proret_mobile1", mobile1)
            i.putExtra("proret_mobile2", mobile2)
            i.putExtra("proret_saddress", saddre)
            i.putExtra("proret_saddress1", saddre1)
            i.putExtra("listener",commlistener)
            i.putExtra("proret_saddress2", saddre2)
            i.putExtra("proret_scity", scity)
            i.putExtra("proret_sstate", sstate)
            i.putExtra("proret_spin", spin)
            i.putExtra("proret_sgps", sgps)
            i.putExtra("proret_smail", smail)
            i.putExtra("proret_sgstcd", sgstcode)
            i.putExtra("proret_status", status)
            i.putExtra("proret_url", urlim)
            i.putExtra("proret_sids", sids)
            i.putExtra("retimg1", fn1sup)
            i.putExtra("retimg2", sn1sup)
            i.putExtra("retimg3", tn1sup)
            i.putExtra("retimg4", fon1sup)
            i.putExtra("retimg5", fifn1sup)
            i.putExtra("returl1", f1sup)
            i.putExtra("returl2", s1sup)
            i.putExtra("returl3", t1sup)
            i.putExtra("returl4", fo1sup)
            i.putExtra("returl5", fif1sup)


            i.putExtra("img1urlhigh",img1urlsuphigh)
            i.putExtra("img2urlhigh",img2urlsuphigh)
            i.putExtra("img3urlhigh",img3urlsuphigh)
            i.putExtra("img4urlhigh",img4urlsuphigh)
            i.putExtra("img5urlhigh",img5urlsuphigh)
            i.putExtra("img1nhigh",img1nsuphigh)
            i.putExtra("img2nhigh",img2nsuphigh)
            i.putExtra("img3nhigh",img3nsuphigh)
            i.putExtra("img4nhigh",img4nsuphigh)
            i.putExtra("img5nhigh",img5nsuphigh)


            i.putExtra("f1edit",f1supedit)
            i.putExtra("s1edit",s1supedit)
            i.putExtra("t1edit",t1supedit)
            i.putExtra("fo1edit",fo1supedit)
            i.putExtra("fif1edit",fif1supedit)
            i.putExtra("fn1edit",fn1supedit)
            i.putExtra("sn1edit",sn1supedit)
            i.putExtra("tn1edit",tn1supedit)
            i.putExtra("fon1edit",fon1supedit)
            i.putExtra("fifn1edit",fifn1supedit)
            i.putExtra("f1edithigh",f1supedithigh)
            i.putExtra("s1edithigh",s1supedithigh)
            i.putExtra("t1edithigh",t1supedithigh)
            i.putExtra("fo1edithigh",fo1supedithigh)
            i.putExtra("fif1edithigh",fif1supedithigh)
            i.putExtra("fn1edithigh",fn1supedithigh)
            i.putExtra("sn1edithigh",sn1supedithigh)
            i.putExtra("tn1edithigh",tn1supedithigh)
            i.putExtra("fon1edithigh",fon1supedithigh)
            i.putExtra("fifn1edithigh",fifn1supedithigh)

            i.putExtra("file_maps",file_maps)
            i.putExtra("mresultsarr",mresultsarr)

            startActivity(i)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
        }*/
    }
    fun deletedb() {
        if(((fn1 != fn1edit)||(sn1 != sn1edit)||(tn1 != tn1edit)|| (fon1 != fon1edit)||(fifn1 != fifn1edit))&&(net_status()==true)) {
            if ((id.text.isNotEmpty()) && (fn1 != fn1edit)) {
                db.collection("supplier_products").document(id.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                            db.collection("supplier_products").document(id.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                        db.collection("supplier_products").document(id.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").document(id.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (sn1 != sn1edit)) {

                db.collection("supplier_products").document(id.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                            db.collection("supplier_products").document(id.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                        db.collection("supplier_products").document(id.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").document(id.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (tn1 != tn1edit)) {
                db.collection("supplier_products").document(id.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                            db.collection("supplier_products").document(id.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                        db.collection("supplier_products").document(id.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").document(id.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fon1 != fon1edit)) {
                db.collection("supplier_products").document(id.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                            db.collection("supplier_products").document(id.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                        db.collection("supplier_products").document(id.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").document(id.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fifn1 != fifn1edit)) {
                db.collection("supplier_products").document(id.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                            db.collection("supplier_products").document(id.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                        db.collection("supplier_products").document(id.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("supplier_products").document(id.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }
        else{

            val i = Intent(this@SuppProductAddActivity, SupplierSecondmain::class.java)


            i.putExtra("sndproky", "eventlist")

            val sname = (textView1.text).toString()
            val sid = textView22.text.toString()
            val scon = textView33.text.toString()
            val mob = textView4.text.toString()
            val mob1 = textView5.text.toString()
            val mob2 = textView6.text.toString()
            val mobile = textView7.text.toString()
            val mobile1 = textView8.text.toString()
            val mobile2 = textView9.text.toString()
            val saddre = textView10.text.toString()
            val saddre1 = textView11.text.toString()
            val saddre2 = textView12.text.toString()
            val scity = textView13.text.toString()
            val sstate = textView14.text.toString()
            val spin = textView15.text.toString()
            val sgps = textView16.text.toString()
            val smail = textView17.text.toString()
            val sgstcode = textView18.text.toString()
            val urlim = textView19.text.toString()
            val sids = textView20.text.toString()
            val status = textView21.text.toString()

            i.putExtra("addspro", addsupppro)
            i.putExtra("editspro", editesupppro)
            i.putExtra("viewspro", viewsupppro)
            i.putExtra("deletespro", deletesupppro)
            i.putExtra("importspro", importsupppro)
            i.putExtra("exportspro", exportsupppro)
            i.putExtra("keys", prokey.text.toString())
            i.putExtra("fieldlistenersave",fieldlistenr)
            i.putExtra("editclipro",editclipro)
            i.putExtra("editclisupp",editclisupp)
            i.putExtra("prret_sname1", sname)
            i.putExtra("listenersave",listnersave)
            i.putExtra("startlistprky",startlistprokey)

            i.putExtra("profrmprky",productprokey)


            i.putExtra("proret_sid1", sid)
            i.putExtra("proret_scon1", scon)
            i.putExtra("proret_mob", mob)
            i.putExtra("proret_mob1", mob1)
            i.putExtra("proret_mob2", mob2)
            i.putExtra("proret_mobile", mobile)
            i.putExtra("proret_mobile1", mobile1)
            i.putExtra("proret_mobile2", mobile2)
            i.putExtra("proret_saddress", saddre)
            i.putExtra("proret_saddress1", saddre1)
            i.putExtra("listener",commlistener)
            i.putExtra("proret_saddress2", saddre2)
            i.putExtra("proret_scity", scity)
            i.putExtra("proret_sstate", sstate)
            i.putExtra("proret_spin", spin)
            i.putExtra("proret_sgps", sgps)
            i.putExtra("proret_smail", smail)
            i.putExtra("proret_sgstcd", sgstcode)
            i.putExtra("proret_status", status)
            i.putExtra("proret_url", urlim)
            i.putExtra("proret_sids", sids)
            i.putExtra("retimg1", fn1sup)
            i.putExtra("retimg2", sn1sup)
            i.putExtra("retimg3", tn1sup)
            i.putExtra("retimg4", fon1sup)
            i.putExtra("retimg5", fifn1sup)
            i.putExtra("returl1", f1sup)
            i.putExtra("returl2", s1sup)
            i.putExtra("returl3", t1sup)
            i.putExtra("returl4", fo1sup)
            i.putExtra("returl5", fif1sup)


            i.putExtra("img1urlhigh",img1urlsuphigh)
            i.putExtra("img2urlhigh",img2urlsuphigh)
            i.putExtra("img3urlhigh",img3urlsuphigh)
            i.putExtra("img4urlhigh",img4urlsuphigh)
            i.putExtra("img5urlhigh",img5urlsuphigh)
            i.putExtra("img1nhigh",img1nsuphigh)
            i.putExtra("img2nhigh",img2nsuphigh)
            i.putExtra("img3nhigh",img3nsuphigh)
            i.putExtra("img4nhigh",img4nsuphigh)
            i.putExtra("img5nhigh",img5nsuphigh)


            i.putExtra("f1edit",f1supedit)
            i.putExtra("s1edit",s1supedit)
            i.putExtra("t1edit",t1supedit)
            i.putExtra("fo1edit",fo1supedit)
            i.putExtra("fif1edit",fif1supedit)
            i.putExtra("fn1edit",fn1supedit)
            i.putExtra("sn1edit",sn1supedit)
            i.putExtra("tn1edit",tn1supedit)
            i.putExtra("fon1edit",fon1supedit)
            i.putExtra("fifn1edit",fifn1supedit)
            i.putExtra("f1edithigh",f1supedithigh)
            i.putExtra("s1edithigh",s1supedithigh)
            i.putExtra("t1edithigh",t1supedithigh)
            i.putExtra("fo1edithigh",fo1supedithigh)
            i.putExtra("fif1edithigh",fif1supedithigh)
            i.putExtra("fn1edithigh",fn1supedithigh)
            i.putExtra("sn1edithigh",sn1supedithigh)
            i.putExtra("tn1edithigh",tn1supedithigh)
            i.putExtra("fon1edithigh",fon1supedithigh)
            i.putExtra("fifn1edithigh",fifn1supedithigh)

            i.putExtra("file_maps",file_maps)
            i.putExtra("mresultsarr",mresultsarr)

            startActivity(i)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
        }
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
