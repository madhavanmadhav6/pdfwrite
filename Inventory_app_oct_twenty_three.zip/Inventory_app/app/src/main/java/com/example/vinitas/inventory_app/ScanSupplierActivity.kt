package com.example.vinitas.inventory_app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Toast
import com.google.android.gms.vision.CameraSource
import com.google.android.gms.vision.Detector
import com.google.android.gms.vision.Detector.*
import com.google.android.gms.vision.barcode.Barcode
import com.google.android.gms.vision.barcode.BarcodeDetector
import kotlinx.android.synthetic.main.activity_supplier_scan.*
import java.io.IOException
import android.content.Intent
import android.util.Log
import java.nio.file.Files.size
import android.util.SparseArray
import android.view.View


class ScanSupplierActivity : AppCompatActivity() {
    internal lateinit var cameraView: SurfaceView
    internal lateinit var barcode: BarcodeDetector
    internal lateinit var cameraSource: CameraSource
    internal lateinit var holder: SurfaceHolder


   var pid= String()
   var pname= String()
   var bcode= String()
   var pdes= String()
   var weight= String()
   var psac= String()
   var stockonhand= String()
   var minstock= String()
   var maxstock= String()
   var price= String()
   var taxable= String()
   var igst= String()
   var cgst= String()
   var sgst= String()
   var cess= String()
   var taxtotal= String()
   var cessval= String()
   var saveky= String()
   var mrP= String()
   var cate= String()
   var manufacture= String()
   var ut= String()
   var status= String()
   var img1nsup= String()
   var img2nsup= String()
   var img3nsup= String()
   var img4nsup= String()
   var img5nsup= String()
   var img1urlsup= String()
   var img2urlsup= String()
    var img3urlsup= String()
    var img4urlsup= String()
    var img5urlsup= String()
    var img1n= String()
    var img2n= String()
    var img3n= String()
    var img4n= String()
    var img5n= String()
    var img1url= String()
    var img2url= String()
    var img3url= String()
    var img4url= String()
    var img5url= String()
    var sname= String()
    var sid= String()
    var scon= String()
    var mob= String()
    var mob1= String()
    var mob2= String()
    var mobile= String()
    var mobile1= String()
    var mobile2= String()
    var saddre= String()
    var saddre1= String()
    var saddre2= String()
    var scity= String()
    var sstate= String()
    var spin= String()
    var sgps= String()
    var smail= String()
    var sgstcode= String()
    var urlim= String()
    var sids= String()
    var statussup= String()
    var savekysup= String()
    var prodky= String()
var comlisn= String()
    var profab= String()
    var editclpro= String()
    var editclsupp= String()


    var prosvkys= arrayOf<String>()
    private var addsupppro: String=""
    private var editesupppro:String=""
    private var deletesupppro:String=""
    private var viewsupppro:String=""
    private var importsupppro:String=""
    private var exportsupppro:String=""


    var savelistnr= String()

    var fieldlistenersave= String()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supplier_scan)



        pid=intent.getStringExtra("pid")
        pname=intent.getStringExtra("pname")
        bcode=intent.getStringExtra("bcode")
        pdes=intent.getStringExtra("pdes")
        weight=intent.getStringExtra("weight")
        psac=intent.getStringExtra("psac")
        stockonhand=intent.getStringExtra("stockonhand")
        minstock=intent.getStringExtra("minstock")
        maxstock=intent.getStringExtra("maxstock")
        price=intent.getStringExtra("price")
        taxable=intent.getStringExtra("taxable")
        igst=intent.getStringExtra("igst")
        cgst=intent.getStringExtra("cgst")
        sgst=intent.getStringExtra("sgst")
        cess=intent.getStringExtra("cess")
        taxtotal=intent.getStringExtra("taxtotal")
        cessval=intent.getStringExtra("cessval")
        saveky=intent.getStringExtra("saveky")
        mrP=intent.getStringExtra("mrP")
        cate=intent.getStringExtra("cate")
        manufacture=intent.getStringExtra("manufacture")
        ut=intent.getStringExtra("ut")
        status=intent.getStringExtra("status")
        img1nsup=intent.getStringExtra("img1nsup")
        img2nsup=intent.getStringExtra("img2nsup")
        img3nsup=intent.getStringExtra("img3nsup")
        img4nsup=intent.getStringExtra("img4nsup")
        img5nsup=intent.getStringExtra("img5nsup")
        img1urlsup=intent.getStringExtra("img1urlsup")
        img2urlsup=intent.getStringExtra("img2urlsup")
        img3urlsup=intent.getStringExtra("img3urlsup")
        img4urlsup=intent.getStringExtra("img4urlsup")
        img5urlsup=intent.getStringExtra("img5urlsup")
        img1n=intent.getStringExtra("img1n")
        img2n=intent.getStringExtra("img2n")
        img3n=intent.getStringExtra("img3n")
        img4n=intent.getStringExtra("img4n")
        img5n=intent.getStringExtra("img5n")
        img1url=intent.getStringExtra("img1url")
        img2url=intent.getStringExtra("img2url")
        img3url=intent.getStringExtra("img3url")
        img4url=intent.getStringExtra("img4url")
        img5url=intent.getStringExtra("img5url")
        sname=intent.getStringExtra("sname")
        sid=intent.getStringExtra("sid")
        scon=intent.getStringExtra("scon")
        mob=intent.getStringExtra("mob")
        mob1=intent.getStringExtra("mob1")
        mob2=intent.getStringExtra("mob2")
        mobile=intent.getStringExtra("mobile")
        mobile1=intent.getStringExtra("mobile1")
        mobile2=intent.getStringExtra("mobile2")
        saddre=intent.getStringExtra("saddre")
        saddre1=intent.getStringExtra("saddre1")
        saddre2=intent.getStringExtra("saddre2")
        scity=intent.getStringExtra("scity")
        sstate=intent.getStringExtra("sstate")
        spin=intent.getStringExtra("spin")
        sgps=intent.getStringExtra("sgps")
        smail=intent.getStringExtra("smail")
        sgstcode=intent.getStringExtra("sgstcode")
        urlim=intent.getStringExtra("urlim")
        sids=intent.getStringExtra("sids")
        statussup=intent.getStringExtra("statussup")
        savekysup=intent.getStringExtra("savekysup")
        prodky=intent.getStringExtra("prodky")
        profab=intent.getStringExtra("profab")
        val bundle = intent.extras
        prosvkys=bundle.get("prosvkys") as Array<String>
        comlisn=intent.getStringExtra("commlisteners")
        fieldlistenersave=intent.getStringExtra("fieldlistenersave")
        val ad = intent.getStringExtra("addspro")
        val ed = intent.getStringExtra("editspro")
        val vie= intent.getStringExtra("viewspro")
        val dele = intent.getStringExtra("deletespro")
        val imp = intent.getStringExtra("importspro")
        val expo = intent.getStringExtra("exportspro")


        editclpro=intent.getStringExtra("editclpro")
        editclsupp=intent.getStringExtra("editclsupp")



        val liiss=intent.getStringExtra("listenersave")
        savelistnr=liiss

        if (ad != null) {
            addsupppro = ad

            println("ADD PERMISSION"+addsupppro)
        }
        if (ed != null) {
            editesupppro = ed
        }
        if (dele != null) {
            deletesupppro = dele
        }
        if (vie != null) {
            viewsupppro = vie
        }
        if (imp != null) {
            importsupppro = imp
        }
        if (expo != null) {
            exportsupppro = expo
        }







        cameraView = findViewById<View>(R.id.cameraView) as SurfaceView
        cameraView.setZOrderMediaOverlay(true)
        holder = cameraView.holder
        barcode = BarcodeDetector.Builder(this)
        .build()
        if (!barcode.isOperational) {
            Toast.makeText(applicationContext, "Sorry, Couldn't setup the detector", Toast.LENGTH_LONG).show()
            this.finish()
        }
        cameraSource = CameraSource.Builder(this, barcode)
                .setFacing(CameraSource.CAMERA_FACING_BACK)
                .setRequestedFps(24f)
                .setAutoFocusEnabled(true)
                .setRequestedPreviewSize(1920, 1024)
                .build()
        cameraView.holder.addCallback(object: SurfaceHolder.Callback {

            override fun surfaceCreated(holder: SurfaceHolder) {
                try {
                    if (ContextCompat.checkSelfPermission(this@ScanSupplierActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        cameraSource.start(cameraView.holder)
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }

            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {

            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {

            }
        })
        barcode.setProcessor(object : Detector.Processor<Barcode> {
            override fun release() {

            }

            //If barcodes received then navigate to result activity

            override fun receiveDetections(detections: Detector.Detections<Barcode>) {
                val barcodes = detections.detectedItems
                Log.i("barcode",barcodes.valueAt(0).toString())
                if (barcodes.size() > 0) {
                    val intent = Intent()
                    intent.putExtra("barcode", barcodes.valueAt(0))
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }

            }
        })
    }
    override fun onPause() {
        super.onPause()
        cameraSource.release()
        barcode.release()
        this@ScanSupplierActivity.finish()
    }

    override fun onBackPressed() {


        val intent = Intent()
        setResult(RESULT_CANCELED, intent);
        finish();


        /*val i=Intent(this@ScanSupplierActivity,SuppProductAddActivity::class.java)

      i.putExtra("pid",pid)
      i.putExtra("pname",pname)
        i.putExtra("pro_supppro","scan")
      i.putExtra("bcode",bcode)
      i.putExtra("pdes",pdes)
      i.putExtra("weight",weight)
      i.putExtra("psac",psac)
      i.putExtra("stockonhand",stockonhand)
      i.putExtra("minstock",minstock)
      i.putExtra("maxstock",maxstock)
      i.putExtra("price",price)
      i.putExtra("taxable",taxable)
      i.putExtra("igst",igst)
      i.putExtra("cgst",cgst)
      i.putExtra("sgst",sgst)
      i.putExtra("cess",cess)
      i.putExtra("taxtotal",taxtotal)
      i.putExtra("cessval",cessval)
      i.putExtra("saveky",saveky)
      i.putExtra("mrP",mrP)
      i.putExtra("cate",cate)
      i.putExtra("manufacture",manufacture)
      i.putExtra("ut",ut)
      i.putExtra("status",status)
      i.putExtra("img1nsup",img1nsup)
      i.putExtra("img2nsup",img2nsup)
      i.putExtra("img3nsup",img3nsup)
      i.putExtra("img4nsup",img4nsup)
      i.putExtra("img5nsup",img5nsup)
      i.putExtra("img1urlsup",img1urlsup)
      i.putExtra("img2urlsup",img2urlsup)
      i.putExtra("img3urlsup",img3urlsup)
      i.putExtra("img4urlsup",img4urlsup)
      i.putExtra("img5urlsup",img5urlsup)
      i.putExtra("img1n",img1n)
      i.putExtra("img2n",img2n)
      i.putExtra("img3n",img3n)
      i.putExtra("img4n",img4n)
      i.putExtra("img5n",img5n)
      i.putExtra("img1url",img1url)
      i.putExtra("img2url",img2url)
      i.putExtra("img3url",img3url)
      i.putExtra("img4url",img4url)
      i.putExtra("img5url",img5url)
      i.putExtra("sname",sname)
      i.putExtra("sid",sid)
      i.putExtra("scon",scon)
      i.putExtra("mob",mob)
      i.putExtra("mob1",mob1)
      i.putExtra("mob2",mob2)
      i.putExtra("mobile",mobile)
      i.putExtra("mobile1",mobile1)
      i.putExtra("mobile2",mobile2)
      i.putExtra("saddre",saddre)
      i.putExtra("saddre1",saddre1)
      i.putExtra("saddre2",saddre2)
      i.putExtra("scity",scity)
      i.putExtra("sstate",sstate)
      i.putExtra("spin",spin)
      i.putExtra("sgps",sgps)
      i.putExtra("smail",smail)
      i.putExtra("sgstcode",sgstcode)
      i.putExtra("urlim",urlim)
      i.putExtra("sids",sids)
      i.putExtra("statussup",statussup)
      i.putExtra("savekysup",savekysup)
      i.putExtra("prodky",prodky)
        i.putExtra("commlisteners",comlisn)
         i.putExtra("listnrsaves", savelistnr)
        i.putExtra("fieldlistnrsaves", fieldlistenersave)
        i.putExtra("prosvkys", prosvkys)

        i.putExtra("profab", profab)
        i.putExtra("editclpro",editclpro)
        i.putExtra("editclsupp",editclsupp)


        i.putExtra("addspro", addsupppro)
         i.putExtra("editspro", editesupppro)
         i.putExtra("viewspro", viewsupppro)
         i.putExtra("deletespro", deletesupppro)
         i.putExtra("importspro", importsupppro)
         i.putExtra("exportspro", exportsupppro)

        startActivity(i)
        finish()*/
    }
}