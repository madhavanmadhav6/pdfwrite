package com.example.vinitas.inventory_app

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.support.annotation.RequiresApi
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.*
import android.support.constraint.ConstraintLayout
import android.util.Log

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_scroll.*
import java.util.*
import android.support.v7.app.AlertDialog
import android.view.View
import android.text.Editable
import android.text.Selection
import android.text.TextWatcher
import android.view.ContextMenu
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.example.vinitas.Makeup_items.Main_makeup
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.*

import java.io.File
import java.net.URL
import java.text.DecimalFormat
import kotlin.collections.ArrayList


class ScrollActivity : AppCompatActivity(), BaseSliderView.OnSliderClickListener {



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }




    internal lateinit var myDb: Databasehelper_service
    //var ur : String ="https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/ourimages-13.jpg?alt=media&token=e9641bdf-30a0-4517-8d44-d7e1987ae2a8"
    //image url's
    var img1url: String = ""
    var img2url: String = ""
    var img3url: String = ""
    var img4url: String = ""
    var img5url: String = ""
    //image name's
    var img1n: String = ""
    var img2n: String = ""
    var img3n: String = ""
    var img4n: String = ""
    var img5n: String = ""

    var img1urlhigh: String = ""
    var img2urlhigh: String = ""
    var img3urlhigh: String = ""
    var img4urlhigh: String = ""
    var img5urlhigh: String = ""
    //image name's
    var img1nhigh: String = ""
    var img2nhigh: String = ""
    var img3nhigh: String = ""
    var img4nhigh: String = ""
    var img5nhigh: String = ""


    var gender: String = ""
    var maincat: String = ""
    var subcat: String = ""
    var des: String = ""
    var fix: String = ""
    var from: String = ""
    var to: String = ""
    var listcome = String()
    var branchky=String()
    var brnm=String()
    var retdatedup=String()
    var imcome = String()

    var cntpri: Int = 0
    var cntnm: Int = 0
    var cntcess: Int = 0
    var cntigst: Int = 0
    var cntvol: Int = 0
    var cnthsc: Int = 0
    var cnthscdes: Int = 0
    var cntsoh: Int = 0
    var cntmx: Int = 0
    var cntmin: Int = 0

    //image url's
    var f1edit: String = ""
    var s1edit: String = ""
    var t1edit: String = ""
    var fo1edit: String = ""
    var fif1edit: String = ""
    //image name's
    var fn1edit: String = ""
    var sn1edit: String = ""
    var tn1edit: String = ""
    var fon1edit: String = ""
    var fifn1edit: String = ""


    var snamevalidate = String()
    var sdurvalidate = String()
    var hsnTvalidate = String()
    var hsndesvalidate = String()
    var pricevalidate = String()
    var intaxvalidate = String()
    var cessvalidate = String()
    var pervalidate = String()

    var subcatvaldup=String()

    var frmmakeup=String()

    var makeupitemstr=String()

    var subcategID=ArrayList<String>()

    var payempvalidate = "false"
    var paybonusvalidate = "false"
    var currencyvalidate = String()
    var percentagevalidate = String()
    var scroll2_fixed_pricevalidate = String()
    var scroll2_price_fromvalidate = String()
    var scroll2_price_tovalidate = String()

    var gendervalidate="Select"
    var maincatvalidate="Select"
    var subcatvalidate=""
    var descvalidate=""
    //image url's
    var f1edithigh: String = ""
    var s1edithigh: String = ""
    var t1edithigh: String = ""
    var fo1edithigh: String = ""
    var fif1edithigh: String = ""
    //image name's
    var fn1edithigh: String = ""
    var sn1edithigh: String = ""
    var tn1edithigh: String = ""
    var fon1edithigh: String = ""
    var fifn1edithigh: String = ""

    var mctgkeys=String()
    var sctgkeys=String()
    var fixed_error: String = ""
    var from_error: String = ""
    var to_error: String = ""
    var gen_error: String = ""
    var main_error: String = ""
    var sub_error: String = ""
    var fix_check: String = "true"
    var from_check: String = "false"

    var maincatId = ArrayList<String>()
    private var add: String = ""
    private var edite: String = ""
    private var delete: String = ""




    var d = arrayListOf<String>()
    var file_maps = arrayListOf<String>()
    var editclick = String()
    var mc = String()
    var frmscrtwo = String()
    override fun onSliderClick(slider: BaseSliderView?) {
        return
    }

    var db = FirebaseFirestore.getInstance()

    data class s(
            var snm: String,            //service Name
            var sid: String,            //service Id	(Auto Id)
            var dur: String,            //Duration
            var sac: String,            //HSN / SAC Code
            var sacdesc: String,        //HSN / SAC Code
            var pr: String,             //Price
            var tx: String,             //Taxable checkbox
            var igst: String,          //Integrated Tax
            var cess: String,           //Cess
            var cgst: String,          //Central Tax
            var sgst: String,          //State Tax
            var ttot: String,          //Tax total
            var ctot: String,          //Cess total
            var gtot: String,          //Gross total
            var ecomm: String,         //Pay employee commission on this service checkbox
            var ebns: String,          //Pay bonus to employee when this service sold checkbox
            var cry: String,           //Currency	radiobutton
            var ptg: String,           //Percentage	radiobutton
            var bval: String,          //Bonus Value
            var gdr: String,           //Gender
            var mctg: String,          //Main category
            var sctg: String,
            var mctgkey: String,
            var retdate:String,
            var sctgkey: String, //Sub Category
            var desc: String,
            var makeupitem:String,//Description
            var fp: String,     //Fixed price
            var fpr: String,        //Range of Price	From
            var tpr: String,     //	To
            var status: String,    //status of service
            var img1n: String,     //image 1 name
            var img2n: String,     //image 2 name
            var img3n: String,     //image 3 name
            var img4n: String,     //image 4 name
            var img5n: String,     //image 5 name
            var img1url: String,     //image 1 url
            var img2url: String,     //image 2 url
            var img3url: String,     //image 3 url
            var img4url: String,     //image 4 url
            var img5url: String,     //image 5 url

            var img1nhigh: String,     //image 1 name
            var img2nhigh: String,     //image 2 name
            var img3nhigh: String,     //image 3 name
            var img4nhigh: String,     //image 4 name
            var img5nhigh: String,     //image 5 name
            var img1urlhigh: String,     //image 1 url
            var img2urlhigh: String,     //image 2 url
            var img3urlhigh: String,     //image 3 url
            var img4urlhigh: String,     //image 4 url
            var img5urlhigh: String     //image 5 url

    )

    var listenersave = String()

    var mresultsarr = arrayListOf<String>()
    var cacnm1 = String()
    val TAG = "some"

    var addedSuffix = false
    var SUFFIX = " my suffix"

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scroll)


        net_status()        //Check net status



        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@ScrollActivity) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off and other views.


        relativeslayoutdis=findViewById(R.id.relativeslayout)
        consermaindis=findViewById(R.id.consermain)
        firstreldis=findViewById(R.id.firstrel)
        secreldis=findViewById(R.id.secrel)
        texreldis=findViewById(R.id.texrel)
        inreldis=findViewById(R.id.inrel)
        catreldis=findViewById(R.id.catrel)
        desreldis=findViewById(R.id.desrel)
        pricereldis=findViewById(R.id.pricerel)
        lastreldis=findViewById(R.id.lastrel)
        scrollView2dis=findViewById(R.id.scrollView2)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        editdis=findViewById(R.id.edit)
        scroll2_gallerydis=findViewById(R.id.scroll2_gallery)
      /*  relativeLayout2dis=findViewById(R.id.relativeLayout2)

        lineardis=findViewById(R.id.linear)
        cambackdis=findViewById(R.id.camback)*/
        addLogText(NetworkUtil.getConnectivityStatusString(this@ScrollActivity))

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val ad = intent.getStringExtra("add")
        val ed = intent.getStringExtra("edit")
        val del = intent.getStringExtra("delete")
        if (ad != null) {
            add = ad
        }
        if (ed != null) {
            edite = ed
        }
        if (del != null) {
            delete = del
        }

        try {
            val keyss = intent.getStringExtra("keybr")
             branchky=keyss
        }
        catch (e:Exception){

        }

        try{
            frmmakeup=intent.getStringExtra("makeup")
        }
        catch (e:Exception){

        }


        myDb = Databasehelper_service(this)

            val service_access = SessionManagement(this)
            val user = service_access.userDetails
            val name = user[SessionManagement.KEY_NAME]
            branchky = name.toString()

        val namebr = user[SessionManagement.KEY_brnm]
        brnm=namebr.toString()
        myDb.givedata(branchky)

        val maincateg = ArrayList<String>()
        val adp1 = ArrayAdapter(this@ScrollActivity, R.layout.spinner_view, maincateg)
        adp1.setDropDownViewResource(R.layout.spinner_view)

        val lists = ArrayList<String>()
        val dataAdapter = ArrayAdapter(this@ScrollActivity, R.layout.spinner_view, lists)
        dataAdapter.setDropDownViewResource(R.layout.spinner_view)

        val subcateg = ArrayList<String>()
        val adp2 = ArrayAdapter(this@ScrollActivity, R.layout.spinner_view, subcateg)
        adp2.setDropDownViewResource(R.layout.spinner_view)



        try {
            listenersave = intent.getStringExtra("listenersave")
        } catch (e: Exception) {
        }

        try {
            mresultsarr = intent.getStringArrayListExtra("mresult")
        } catch (e: Exception) {

        }
        try {
            cacnm1 = intent.getStringExtra("cacnm1")
        } catch (e: Exception) {

        }





        // vert menu contains Popup with the title of Enable/Disable

        disable.setOnClickListener {
            val popup = PopupMenu(this@ScrollActivity, disable)
            popup.menuInflater.inflate(R.menu.disable, popup.menu)
            val m1 = popup.menu.getItem(0)
            if (delete == "true" || delete.isNullOrEmpty()) {
                if (save.visibility == View.VISIBLE) {
                    if (state.text == "Disabled") {
                        m1.title = "Enable service"
                        popup.setOnMenuItemClickListener { item ->  //Click disable title and change the status of the product as 'DISABLED'

                            if(net_status()==true) {
                                val upid = id.text.toString()
                                val sname = (textInputLayout.editText!!.text).toString()
                                val sid = (textInputLayout2.editText!!.text).toString()
                                val sdur = (textInputLayout3.editText!!.text).toString()
                                val hsnT = (hsnT.text).toString()
                                val hsndes = (hsndes.text).toString()
                                val pr = (price.text).toString()
                                val Tax = (Tax.isChecked.toString())
                                val intax = (intax.text).toString()
                                val cess = (cess.text).toString()
                                val Ctax = (Ctax.text).toString()
                                val Stax = (Stax.text).toString()
                                val taxtot = (taxtot.text).toString()
                                val css = (css.text).toString()
                                val Gtot = (grosstot.text).toString()
                                val payemp = (payemp.isChecked.toString())
                                val paybonus = (paybonus.isChecked.toString())
                                val currency = (currency.isChecked.toString())
                                val percentage = (percentage.isChecked.toString())
                                val per = (per.text).toString()
                                val retdates=""
                                if(frmmakeup=="makeup"){
                                   makeupitemstr="makeup service"
                                }
                                else if(frmmakeup.isEmpty()){
                                    makeupitemstr=""

                                }


                                //val desc = (descrip.text).toString()

                                val builder = android.app.AlertDialog.Builder(this@ScrollActivity)
                                with(builder) {
                                    setTitle("Confirm?")
                                    setMessage("Are you sure want to enable?")
                                    setPositiveButton("Yes") { dialog, whichButton ->
                                        pDialogs = SweetAlertDialog(this@ScrollActivity, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialogs!!.setTitleText("Enabling...");
                                        pDialogs!!.setCancelable(false);
                                        pDialogs!!.show();
                                        state.setText("Active")
                                        val status = (state.text.toString())
                                        val map = mutableMapOf<String, Any?>()
                                        map.put("status", status)
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess, Ctax,
                                                            Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage, per, gender, maincat, subcat,
                                                            des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                            img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                            img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys,retdates,makeupitemstr)


                                                    pDialogs!!.dismiss()
                                                    Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()
                                                    val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                                    startActivity(t)
                                                    finish()
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                                }
                                    }
                                            .setNegativeButton("No") { dialog, whichButton ->
                                                dialog.dismiss()
                                            }

                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }
                            else if(net_status()==false){
                                Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()

                            }


                            true
                        }
                        popup.show()
                    } else if (state.text == "Active") {
                        m1.title = "Disable service"
                        popup.setOnMenuItemClickListener { item ->  //Click enable title and change the status of the product as 'Active'
                            if(net_status()==true) {
                                val upid = id.text.toString()
                                val sname = (textInputLayout.editText!!.text).toString()
                                val sid = (textInputLayout2.editText!!.text).toString()
                                val sdur = (textInputLayout3.editText!!.text).toString()
                                val hsnT = (hsnT.text).toString()
                                val hsndes = (hsndes.text).toString()
                                val pr = (price.text).toString()
                                val Tax = (Tax.isChecked.toString())
                                val intax = (intax.text).toString()
                                val cess = (cess.text).toString()
                                val Ctax = (Ctax.text).toString()
                                val Stax = (Stax.text).toString()
                                val taxtot = (taxtot.text).toString()
                                val css = (css.text).toString()
                                val Gtot = (grosstot.text).toString()
                                val payemp = (payemp.isChecked.toString())
                                val paybonus = (paybonus.isChecked.toString())
                                val currency = (currency.isChecked.toString())
                                val percentage = (percentage.isChecked.toString())
                                val per = (per.text).toString()
                                val retdates=""
                                if(frmmakeup=="makeup"){
                                    makeupitemstr="makeup service"
                                }
                                else if(frmmakeup.isEmpty()){
                                    makeupitemstr=""

                                }
                                //val desc = (descrip.text).toString()

                                val builder = android.app.AlertDialog.Builder(this@ScrollActivity)
                                with(builder) {
                                    setTitle("Confirm?")
                                    setMessage("Are you sure want to disable?")
                                    setPositiveButton("Yes") { dialog, whichButton ->
                                        pDialogs = SweetAlertDialog(this@ScrollActivity, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialogs!!.setTitleText("Disabling...");
                                        pDialogs!!.setCancelable(false);
                                        pDialogs!!.show();
                                        state.setText("Disabled")
                                        val status = (state.text.toString())
                                        val map = mutableMapOf<String, Any?>()
                                        map.put("status", status)
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess,
                                                            Ctax, Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage, per, gender, maincat,
                                                            subcat, des, fix, from, to, status, img1n, img2n, img3n,
                                                            img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                                            img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys,retdates,makeupitemstr)


                                                    pDialogs!!.dismiss()
                                                    Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                                    val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                                    startActivity(t)
                                                    finish()
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                                }
                                    }
                                            .setNegativeButton("No") { dialog, whichButton ->


                                                dialog.dismiss()
                                            }
                                    val dialog = builder.create()

                                    dialog.show()
                                }

                        }
                        else if(net_status()==false){
                            Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()

                        }



                            true
                        }
                        popup.show()
                    }
                }
            } else if (delete == "false") {
                popup("Disable or Enable")
            }
        }
        //get id's from list
        val b = intent.getStringExtra("id")
        val a = intent.getStringExtra("newid")
        newid.setText(a)//create new service
        if (b.isNullOrEmpty() == false) {
            id.setText(b)//updating list
            save.visibility = View.INVISIBLE
            edit.visibility = View.VISIBLE

            listcome = "yes"

            val edit = intent.getIntExtra("edit", View.VISIBLE)
            if (edit.equals(View.GONE)) {

            }
            if (state.text.toString().isNullOrEmpty() == false) {
                println("state is not empty")
                if (state.text.toString() == "Active")
                {
                    state.text = "Active"
                } else if (state.text.toString() == "Disabled")
                {
                    println("state disabled")
                    state.text = "Disabled"
                }
            }

        } else if (a.isNullOrEmpty() == false) {

            disable.visibility = View.GONE

        }

        println("id  " + id.text)
        println("new id  " + newid.text)






        if (fix_check.isNullOrEmpty() == false) {
            scroll2_fixed.isChecked = fix_check.toBoolean()
            scroll2_fixed_price.isEnabled = fix_check.toBoolean()
        }
        if (from_check.isNullOrEmpty() == false) {
            scroll2_from.isChecked = from_check.toBoolean()
            scroll2_price_from.isEnabled = from_check.toBoolean()
            scroll2_price_to.isEnabled = from_check.toBoolean()
        }
        if (fixed_error.isNullOrEmpty() == false) {

        }
        if (from_error.isNullOrEmpty() == false) {

        }
        if (to_error.isNullOrEmpty() == false) {

        }


        /* if (status.isNullOrEmpty()==false){
            if (status=="Enabled"){
                state.setText("Enabled")
                println("Enabled")
            }else if (status=="Disabled"){
                state.setText("Disabled")
                println("Disabled")
            }
        }
        if (lid.isNullOrEmpty()==false){
            id.setText(lid.toString())//updateting list
            save.visibility=View.GONE
            edit.visibility=View.VISIBLE
            val s_edit=intent.getIntExtra("s_edit",View.VISIBLE)
            if (s_edit.equals(View.GONE)) {
                println("s_edit  "+s_edit)
                save.visibility = View.VISIBLE
                edit.visibility = View.GONE
            }else{
                println("else s_edit  "+s_edit)
            }

        }*/

        //scroll2 page items
        /*var gen = intent.getStringExtra("gender")
        var main = intent.getStringExtra("maincat")
        var sub = intent.getStringExtra("subcat")
        val de = intent.getStringExtra("des")
        val fi = intent.getStringExtra("fix")
        val fro = intent.getStringExtra("from")
        val t = intent.getStringExtra("to")

        //image url's
        var f1=intent.getStringExtra("f")
        var s1=intent.getStringExtra("s")
        var t1=intent.getStringExtra("t")
        var fo1=intent.getStringExtra("fo")
        var fif1=intent.getStringExtra("fif")

        //image name's
        var fn1=intent.getStringExtra("fn")
        var sn1=intent.getStringExtra("sn")
        var tn1=intent.getStringExtra("tn")
        var fon1=intent.getStringExtra("fon")
        var fifn1=intent.getStringExtra("fifn")

        println(des)

        if (f1.isNullOrEmpty()==false&&fn1.isNullOrEmpty()==false){
            img1url=f1
            img1n=fn1
        }
        if (s1.isNullOrEmpty()==false&&sn1.isNullOrEmpty()==false){
            img2url=s1
            img2n=sn1
        }
        if (t1.isNullOrEmpty()==false&&tn1.isNullOrEmpty()==false){
            img3url=t1
            img3n=tn1
        }
        if (fo1.isNullOrEmpty()==false&&fon1.isNullOrEmpty()==false){
            img4url=fo1
            img4n=fon1
        }
        if (fif1.isNullOrEmpty()==false&&fifn1.isNullOrEmpty()==false){
            img5url=fif1
            img5n=fifn1
        }

        val f1edits = intent.getStringExtra("f1edit")
        val s1edits = intent.getStringExtra("s1edit")
        val t1edits = intent.getStringExtra("t1edit")
        val fo1edits = intent.getStringExtra("fo1edit")
        val fif1edits = intent.getStringExtra("fif1edit")

        val fn1edits = intent.getStringExtra("fn1edit")
        val sn1edits = intent.getStringExtra("sn1edit")
        val tn1edits = intent.getStringExtra("tn1edit")
        val fon1edits = intent.getStringExtra("fon1edit")
        val fifn1edits = intent.getStringExtra("fifn1edit")


        if (f1edits.isNullOrEmpty() != true) {
            f1edit=f1edits
            fn1edit=fn1edits
        }

        if (s1edits.isNullOrEmpty() != true) {
            s1edit=s1edits
            sn1edit=sn1edits
        }
        if (t1edits.isNullOrEmpty() != true) {
            t1edit=t1edits
            tn1edit=tn1edits
        }

        if (fo1edits.isNullOrEmpty() != true) {
            fo1edit=fo1edits
            fon1edit=fon1edits
        }

        if (fif1edits.isNullOrEmpty() != true) {
            fif1edit=fif1edits
            fifn1edit=fifn1edits
        }


        //image url's
        var f1high=intent.getStringExtra("fhigh")
        var s1high=intent.getStringExtra("shigh")
        var t1high=intent.getStringExtra("thigh")
        var fo1high=intent.getStringExtra("fohigh")
        var fif1high=intent.getStringExtra("fifhigh")

        //image name's
        var fn1high=intent.getStringExtra("fnhigh")
        var sn1high=intent.getStringExtra("snhigh")
        var tn1high=intent.getStringExtra("tnhigh")
        var fon1high=intent.getStringExtra("fonhigh")
        var fifn1high=intent.getStringExtra("fifnhigh")


        println("f1high"+f1high)
        println("s1high"+s1high)
        println("t1high"+t1high)
        println("f1ohigh"+fo1high)
        println("fif1high"+fif1high)


        println("fn1high"+fn1high)
        println("sn1high"+sn1high)
        println("tn1high"+tn1high)
        println("fon1high"+fon1high)
        println("fifn1high"+fifn1high)

        println(des)

        if (f1high.isNullOrEmpty()==false&&fn1high.isNullOrEmpty()==false){
            img1urlhigh=f1high
            img1nhigh=fn1high

            println("img1urlhigh"+img1urlhigh)
            println("img1nhigh"+img1nhigh)
        }
        if (s1high.isNullOrEmpty()==false&&sn1high.isNullOrEmpty()==false){
            img2urlhigh=s1high
            img2nhigh=sn1high
        }
        if (t1high.isNullOrEmpty()==false&&tn1high.isNullOrEmpty()==false){
            img3urlhigh=t1high
            img3nhigh=tn1high
        }
        if (fo1high.isNullOrEmpty()==false&&fon1high.isNullOrEmpty()==false){
            img4urlhigh=fo1high
            img4nhigh=fon1high
        }
        if (fif1high.isNullOrEmpty()==false&&fifn1high.isNullOrEmpty()==false){
            img5urlhigh=fif1high
            img5nhigh=fifn1high
        }



        val f1editshigh = intent.getStringExtra("f1edithigh")
        val s1editshigh = intent.getStringExtra("s1edithigh")
        val t1editshigh = intent.getStringExtra("t1edithigh")
        val fo1editshigh = intent.getStringExtra("fo1edithigh")
        val fif1editshigh = intent.getStringExtra("fif1edithigh")

        val fn1editshigh = intent.getStringExtra("fn1edithigh")
        val sn1editshigh = intent.getStringExtra("sn1edithigh")
        val tn1editshigh = intent.getStringExtra("tn1edithigh")
        val fon1editshigh = intent.getStringExtra("fon1edithigh")
        val fifn1editshigh = intent.getStringExtra("fifn1edithigh")


        if (f1editshigh.isNullOrEmpty() != true) {
            f1edithigh=f1editshigh
            fn1edithigh=fn1editshigh
        }

        if (s1editshigh.isNullOrEmpty() != true) {
            s1edithigh=s1editshigh
            sn1edithigh=sn1editshigh
        }
        if (t1editshigh.isNullOrEmpty() != true) {
            t1edithigh=t1editshigh
            tn1edithigh=tn1editshigh
        }

        if (fo1editshigh.isNullOrEmpty() != true) {
            fo1edithigh=fo1editshigh
            fon1edithigh=fon1editshigh
        }

        if (fif1editshigh.isNullOrEmpty() != true) {
            fif1edithigh=fif1editshigh
            fifn1edithigh=fifn1editshigh
        }*/


        /*if((f1!=f1edit)||(s1!=s1edit)||(t1!=t1edit)||(fo1!=fo1edit)||(fif1!=fif1edit)){
            listenersave="change"

        }
        else if(sid.text.toString()==""){
            listenersave="change"
        }*/

/*
        if (save.visibility==View.VISIBLE) {
            sname.setText(sname1)
            sid.setText(sid1)
            sdur.setText(sdur1)
            hsnT.setText(hsnT1)
            hsndes.setText(hsndes1)
            price.setText(price1)
            Tax.isChecked = Tax1
            intax.setText(intax1)
            cess.setText(cess1)
            Ctax.setText(Ctax1)
            Stax.setText(Stax1)
            taxtot.setText(taxtot1)
            css.setText(css1)
            grosstot.setText(grosstot1)
            payemp.isChecked = payemp1
            paybonus.isChecked = paybonus1
            currency.isChecked = currency1
            percentage.isChecked = percentage1
            per.setText(per1)

            scroll2_descrip.setText(des)
            scroll2_fixed_price.setText(fix)
            scroll2_price_from.setText(from)
            scroll2_price_to.setText(to)
            if (scroll2_fixed_price.text.isNotEmpty()) {
                scroll2_preview_price.setText("Rs " + scroll2_fixed_price.text.toString())
            }
            if (scroll2_price_from.text.isNotEmpty() && scroll2_price_to.text.isNotEmpty()) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + scroll2_price_to.text.toString())
            }
        }*/
        //descrip.setText(descrip1)
        /*id.setText(lid)
        println("else  "+id.text.toString())*/

        if (sid.text.isEmpty()) {
            sid.setText("Auto-genereted")
        }



        //If edit button is visible ,then all views are false

        if (edit.visibility == View.VISIBLE) {
            println("id  " + id.text.toString())
            println("new id  " + newid.text)
            save.visibility = View.INVISIBLE
            edit.visibility = View.VISIBLE
            disable.visibility = View.GONE


            sname.isEnabled = false
            sid.isEnabled = false
            sdur.isEnabled = false
            hsnT.isEnabled = false
            hsndes.isEnabled = false
            price.isEnabled = false
            Tax.isEnabled = false
            intax.isEnabled = false
            cess.isEnabled = false
            Ctax.isEnabled = false
            Stax.isEnabled = false
            taxtot.isEnabled = false
            css.isEnabled = false
            grosstot.isEnabled = false
            payemp.isEnabled = false
            paybonus.isEnabled = false
            currency.isEnabled = false
            percentage.isEnabled = false
            per.isEnabled = false

            scroll2_category.isEnabled = false
            scroll2_sub_category.isEnabled = false
            scroll2_gender.isEnabled = false
            scroll2_descrip.isEnabled = false
            scroll2_fixed.isEnabled = false
            scroll2_from.isEnabled = false
            scroll2_fixed_price.isEnabled = false
            scroll2_price_from.isEnabled = false
            scroll2_price_to.isEnabled = false
            val getone = myDb.getOne(id.text.toString())
            if (getone.moveToNext()) {
                mc = getone.getString(22).toString()
                if (getone.getString(23).toString() != "") {
                    scroll2_descrip.setText(getone.getString(23))
                }
                if (getone.getString(24).toString() != "") {
                    scroll2_fixed_price.setText(getone.getString(24).toString())
                    scroll2_preview_price.setText("RS ${getone.getString(24).toString()}")
                }
                if (getone.getString(25) != "" && getone.getString(26) != "") {
                    scroll2_price_from.setText(getone.getString(25).toString())
                    scroll2_preview_price.setText("From RS ${getone.getString(25).toString()} to ${getone.getString(26).toString()}")
                }
                if (getone.getString(26) != "") {
                    scroll2_price_to.setText(getone.getString(26).toString())
                }
            }

            if (paybonus.isEnabled == false) {
                currency.isEnabled = false
                currency.isEnabled = false
                percentage.isEnabled = false
                per.isEnabled = false
                currency.setTextColor(Color.parseColor("#85546e7a"))
                percentage.setTextColor(Color.parseColor("#d3d3d3"))
                per.setTextColor(Color.parseColor("#d3d3d3"))
            }


           // -----------edit button click and enable all views----------------//
            edit.setOnClickListener {

                if (edite == "true" || edite.isNullOrEmpty()) {
                    editclick = "clicked"
                    sname.isEnabled = true

                    sdur.isEnabled = true
                    hsnT.isEnabled = true
                    hsndes.isEnabled = true
                    price.isEnabled = true
                    Tax.isEnabled = true

                    if(Tax.isChecked==true){

                        intax.isEnabled = true
                        cess.isEnabled = true
                    }


                    taxtot.isEnabled = true
                    css.isEnabled = true
                    grosstot.isEnabled = true
                    payemp.isEnabled = true
                    paybonus.isEnabled = true
                    currency.isEnabled = true
                    percentage.isEnabled = true
                    per.isEnabled = true

                    edit.visibility = View.GONE
                    save.visibility = View.VISIBLE
                    disable.visibility = View.VISIBLE

                    scroll2_category.isEnabled = true
                    scroll2_sub_category.isEnabled = true
                    scroll2_descrip.isEnabled = true
                    scroll2_gender.isEnabled = true
                    if (from != "" || to != "") {
                        scroll2_from.isChecked = true
                        scroll2_from.isEnabled = true
                        scroll2_fixed_price.isEnabled=false
                        scroll2_fixed.isEnabled = true
                        scroll2_fixed.isChecked = false
                        scroll2_price_from.isEnabled=true
                        scroll2_price_to.isEnabled=true
                        scroll2_preview_price.setText("From Rs $from to $to")
                    } else if (fix != "") {
                        scroll2_from.isChecked = false
                        scroll2_from.isEnabled = true
                        scroll2_fixed.isChecked = true
                        scroll2_fixed.isEnabled = true
                        scroll2_price_from.isEnabled=false
                        scroll2_price_to.isEnabled=false
                        scroll2_preview_price.setText(fix)
                    }
                    else{
                        scroll2_from.isChecked = false
                        scroll2_from.isEnabled = true
                        scroll2_fixed_price.isEnabled=true
                        scroll2_fixed.isEnabled = true
                        scroll2_fixed.isChecked = true
                        scroll2_price_from.isEnabled=false
                        scroll2_price_to.isEnabled=false

                    }
                } else if (edite == "false") {
                    popup("edit")
                }
            }





            //------------------------Get all details from existing service from local sql db and fill in the corresponding fields---------//
            if (id.text.isNotEmpty()) {
                println(id.text.toString())
                val getone = myDb.getOne(id.text.toString())
                if (getone.moveToNext()) {
                    println("sfkuygon     " + getone.getString(0))
                    sname.setText(getone.getString(1))
                    snamevalidate = sname.text.toString()

                    sid.setText(getone.getString(2))
                    sdur.setText(getone.getString(3))
                    sdurvalidate = sdur.text.toString()
                    hsnT.setText(getone.getString(4))
                    hsnTvalidate = hsnT.text.toString()
                    hsndes.setText(getone.getString(5))
                    hsndesvalidate = hsndes.text.toString()

                    price.setText(getone.getString(6))
                    pricevalidate = price.text.toString()

                    Tax.setChecked((getone.getString(7).toBoolean()))



                    retdatedup=getone.getString(50)

                    intax.setText(getone.getString(8))
                    intaxvalidate = intax.text.toString()

                    cess.setText(getone.getString(9))
                    cessvalidate = cess.text.toString()

                    Ctax.setText(getone.getString(10))
                    Stax.setText(getone.getString(11))
                    taxtot.setText(getone.getString(12))
                    css.setText(getone.getString(13))
                    grosstot.setText(getone.getString(14))
                    payemp.setChecked(getone.getString(15).toBoolean())
                    payempvalidate = getone.getString(15)
                    paybonusvalidate = getone.getString(16)
                    currencyvalidate = getone.getString(17)
                    percentagevalidate = getone.getString(18)
                    paybonus.setChecked(getone.getString(16).toBoolean())
                    currency.setChecked(getone.getString(17).toBoolean())
                    percentage.setChecked(getone.getString(18).toBoolean())
                    per.setText(getone.getString(19))
                    pervalidate = per.text.toString()
                    gender = getone.getString(20).toString()
                    maincat = getone.getString(21).toString()
                    subcat = getone.getString(22).toString()

                    makeupitemstr=getone.getString(51).toString()
                    try{
                        mctgkeys=getone.getString(48).toString()
                    }
                    catch (e:Exception){

                    }
                    try{
                        sctgkeys=getone.getString(49).toString()
                    }
                    catch (e:Exception){

                    }

                    println("MC SUPER"+subcat)


                    gendervalidate=getone.getString(20).toString()
                    maincatvalidate= getone.getString(21).toString()
                    if(maincatvalidate==""){
                        maincatvalidate="Select"
                            }
                    subcatvalidate=getone.getString(22).toString()

                    des = getone.getString(23).toString()
                    descvalidate= getone.getString(23).toString()
                    fix = getone.getString(24).toString()
                    from = getone.getString(25).toString()
                    to = getone.getString(26).toString()
                    scroll2_fixed_price.setText(fix)

                    scroll2_fixed_pricevalidate = fix
                    scroll2_price_fromvalidate = from
                    scroll2_price_tovalidate = to

                    scroll2_price_from.setText(from)
                    scroll2_price_to.setText(to)
                    state.setText(getone.getString(27))

                    scroll2_preview_service_name.setText(getone.getString(1))

                    if (from != "" || to != "") {
                        scroll2_from.isChecked = true
                        scroll2_fixed_price.isEnabled=false
                        scroll2_price_from.isEnabled=true
                        scroll2_price_to.isEnabled=true
                        scroll2_fixed.isChecked = false
                        scroll2_preview_price.setText("From Rs $from to $to")
                    } else if (fix != "") {
                        scroll2_from.isChecked = false
                        scroll2_fixed.isChecked = true
                        scroll2_fixed_price.isEnabled=true
                        scroll2_price_from.isEnabled=false
                        scroll2_price_to.isEnabled=false
                        scroll2_preview_price.setText(fix)
                    }

                    if (frmscrtwo != "scrtwo") {
                        img1n = getone.getString(28).toString()
                        img2n = getone.getString(29).toString()
                        img3n = getone.getString(30).toString()
                        img4n = getone.getString(31).toString()
                        img5n = getone.getString(32).toString()
                        img1url = getone.getString(33).toString()
                        img2url = getone.getString(34).toString()
                        img3url = getone.getString(35).toString()
                        img4url = getone.getString(36).toString()
                        img5url = getone.getString(37).toString()

                        img1nhigh = getone.getString(38).toString()
                        img2nhigh = getone.getString(39).toString()
                        img3nhigh = getone.getString(40).toString()
                        img4nhigh = getone.getString(41).toString()
                        img5nhigh = getone.getString(42).toString()
                        img1urlhigh = getone.getString(43).toString()
                        img2urlhigh = getone.getString(44).toString()
                        img3urlhigh = getone.getString(45).toString()
                        img4urlhigh = getone.getString(46).toString()
                        img5urlhigh = getone.getString(47).toString()

                        f1edithigh = img1urlhigh
                        fn1edithigh = img1nhigh
                        s1edithigh = img2urlhigh
                        sn1edithigh = img2nhigh
                        t1edithigh = img3urlhigh
                        tn1edithigh = img3nhigh
                        fo1edithigh = img4urlhigh
                        fon1edithigh = img4nhigh
                        fif1edithigh = img5urlhigh
                        fifn1edithigh = img5nhigh



                        f1edit = img1url.toString()
                        fn1edit = img1n.toString()
                        s1edit = img2url.toString()
                        sn1edit = img2n.toString()
                        t1edit = img3url.toString()
                        tn1edit = img3n.toString()
                        fo1edit = img4url.toString()
                        fon1edit = img4n.toString()
                        fif1edit = img5url.toString()
                        fifn1edit = img5n.toString()
                    }
                }
            }

        } else {
            println(newid.text.toString())
        }



        //  Handler() func is used to display all images in slider view afetr 1000 millisecods of activity creation.

        Handler().postDelayed(Runnable { loadim() }, 1000)






        //-----------------GENDER spinner items adpter------------------------//

        lists.add("Select")
        lists.add("Men")
        lists.add("Women")
        lists.add("Unisex")
        scroll2_gender.adapter = dataAdapter
        if (gender.isNullOrEmpty() != true) {
            val spinnerPosition = dataAdapter.getPosition(gender)
            scroll2_gender.setSelection(spinnerPosition)
        }

        //scroll2_category spinner get main categories from db

        if(frmmakeup.isEmpty()) {
            db.collection("servicecategory")
                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                        if (task.isEmpty == false) {
                            if (task != null) {
                                maincateg.clear()
                                maincatId.clear()
                                maincateg.add("Select")
                                maincatId.add("")
                                for (document in task) {
                                    println("document id : " + document.id)
                                    println("document data : " + document.data)
                                    val dd = document.data
                                    maincatId.add(document.id)
                                    val c = dd["cat"].toString()
                                    maincateg.add(c)
                                    println(maincateg)
                                    scroll2_category.adapter = adp1
                                    if (maincat.isNullOrEmpty() != true) {
                                        val spinnerPosition = adp1.getPosition(maincat.toString())
                                        scroll2_category.setSelection(spinnerPosition)

                                    }
                                }
                            }
                        }
                    })


            //scroll2_gender spinner onItemSeletedListener
            scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                    if (p2 == 0) {
                        /*gen_error.visibility=View.VISIBLE
                    gen_error.setError(" ")*/
                    } else {
                        gen_errors.visibility = View.GONE
                    }
                }
            }

            //scroll2_category spinner onItemSeletedListener
            scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                    println(maincatId.get(position))
                    val key = maincatId.get(position)

                    mctgkeys = key
                    //scroll2_sub_category spinner
                    if (scroll2_category.selectedItemPosition == 0) {

                        /*main_error.visibility=View.VISIBLE
                    main_error.setError(" ")*/
                    } else {
                        main_errors.visibility = View.GONE
                        db.collection("subcategory")
                                .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                    subcateg.clear()
                                    subcategID.clear()
                                    subcateg.add("")
                                    subcategID.add("")



                                    if (task.isEmpty == false) {
                                        if (task != null) {
                                            for (document in task) {
                                                println("document id : " + document.id)
                                                println("document data : " + document.data)


                                                val dd = document.data
                                                val mainid = dd["main_id"].toString()
                                                scroll2_sub_category.adapter = adp2
                                                if (mainid == key) {
                                                    val c = dd["cat"].toString()
                                                    subcateg.add(c)
                                                    subcategID.add(document.id)
                                                    println("SUB CATEG" + subcateg)
                                                    scroll2_sub_category.adapter = adp2
                                                    scroll2_sub_category.setSelection(0)

                                                    /* if (mc.isNotEmpty()) {
                                                        println("mc  " + mc)
                                                        val spinnerPosition = adp2.getPosition(mc)
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }*/
                                                } else {
                                                    /* subcateg.clear()*/

                                                    adp2.notifyDataSetChanged()
                                                }
                                                if (subcat.isNullOrEmpty() != true) {
                                                    println("true subcat" + subcat)
                                                    val spinnerPosition = adp2.getPosition(subcat.toString())
                                                    scroll2_sub_category.setSelection(spinnerPosition)
                                                }
                                            }

                                        }
                                    } else {


                                    }

                                })
                    }
                }
            }
            scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {


                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                    println(subcategID.get(position))
                    val key = subcategID.get(position)

                    sctgkeys = key
                }
            }
        }
        else if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
            db.collection("servicecategory").whereEqualTo("cat","Wedding")
                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                        if (task.isEmpty == false) {
                            if (task != null) {
                                maincateg.clear()
                                maincatId.clear()
                                maincateg.add("Select")
                                maincatId.add("")
                                for (document in task) {
                                    println("document id : " + document.id)
                                    println("document data : " + document.data)
                                    val dd = document.data
                                    maincatId.add(document.id)
                                    val c = dd["cat"].toString()
                                    maincateg.add(c)
                                    println(maincateg)
                                    scroll2_category.adapter = adp1
                                    if (maincat.isNullOrEmpty() != true) {
                                        val spinnerPosition = adp1.getPosition(maincat.toString())
                                        scroll2_category.setSelection(spinnerPosition)

                                    }
                                    else if(maincat.isNullOrEmpty()==true){

                                        scroll2_category.setSelection(1)
                                        scroll2_category.isEnabled=false
                                    }
                                }
                            }
                        }
                    })


            //scroll2_gender spinner onItemSeletedListener
            scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                    if (p2 == 0) {
                        /*gen_error.visibility=View.VISIBLE
                    gen_error.setError(" ")*/
                    } else {
                        gen_errors.visibility = View.GONE
                    }
                }
            }

            //scroll2_category spinner onItemSeletedListener   get sub categories from db  depending upon what we selected in main category

            scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                    println(maincatId.get(position))
                    val key = maincatId.get(position)

                    mctgkeys = key
                    //scroll2_sub_category spinner
                    if (scroll2_category.selectedItemPosition == 0) {

                        /*main_error.visibility=View.VISIBLE
                    main_error.setError(" ")*/
                    } else {
                        main_errors.visibility = View.GONE
                        db.collection("subcategory").whereEqualTo("main_cat","Wedding")
                                .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                    subcateg.clear()
                                    subcategID.clear()
                                    subcateg.add("")
                                    subcategID.add("")



                                    if (task.isEmpty == false) {
                                        if (task != null) {
                                            for (document in task) {
                                                println("document id : " + document.id)
                                                println("document data : " + document.data)


                                                val dd = document.data
                                                val mainid = dd["main_id"].toString()
                                                scroll2_sub_category.adapter = adp2
                                                if (mainid == key) {
                                                    val c = dd["cat"].toString()
                                                    subcateg.add(c)
                                                    subcategID.add(document.id)
                                                    println("SUB CATEG" + subcateg)
                                                    scroll2_sub_category.adapter = adp2
                                                    scroll2_sub_category.setSelection(0)

                                                    /* if (mc.isNotEmpty()) {
                                                        println("mc  " + mc)
                                                        val spinnerPosition = adp2.getPosition(mc)
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }*/
                                                } else {
                                                    /* subcateg.clear()*/

                                                    adp2.notifyDataSetChanged()
                                                }
                                                if (subcat.isNullOrEmpty() != true) {
                                                    println("true subcat" + subcat)
                                                    val spinnerPosition = adp2.getPosition(subcat.toString())
                                                    scroll2_sub_category.setSelection(spinnerPosition)
                                                }
                                                else if(subcat.isNullOrEmpty() == true){
                                                    scroll2_sub_category.setSelection(2)
                                                    scroll2_sub_category.isEnabled=false

                                                }
                                            }

                                        }
                                    } else {


                                    }

                                })
                    }
                }
            }
            scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p0: AdapterView<*>?) {


                    return
                }

                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                    println(subcategID.get(position))
                    val key = subcategID.get(position)

                    sctgkeys = key
                }
            }
        }

        if (id.text.isNotEmpty()) {
            val getone = myDb.getOne(id.text.toString())
            if (getone.moveToNext()) {

            }
        }

        //scroll2_fixed setOnCheckedChangeListener
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.setText("")
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.setText(scroll2_descrip.text.toString())
            scroll2_preview_description.visibility = View.VISIBLE
        }
        if (scroll2_fixed.isChecked == true) {
            if (scroll2_fixed_price.text.isEmpty()) {
                /*fixed_error.visibility = View.VISIBLE
                fixed_error.setError(" ")*/
            }
        } else {
            fixed_errors.visibility = View.GONE
        }
        scroll2_fixed.setOnCheckedChangeListener { fixed, b ->
            if (fixed.isChecked == true) {
                println("fixed  " + b)
                fixed.isChecked = true
                scroll2_fixed_price.isEnabled = true
                scroll2_from.isChecked = false
                scroll2_price_from.isEnabled = false
                try {
                    scroll2_price_from.setText("")
                    scroll2_price_to.setText("")
                }
                catch (e:Exception){

                }

                if(id.text.toString().isNotEmpty()){

                    if(scroll2_fixed.isChecked==true){
                        scroll2_fixed_price.setText(fix)
                    }

                }
                else{

                }

                scroll2_price_to.isEnabled = false

                from_errors.visibility = View.GONE
                to_errors.visibility = View.GONE
                if (scroll2_fixed_price.text.isEmpty()) {
                    /*fixed_error.visibility=View.VISIBLE
                    fixed_error.setError(" ")*/
                }
            } else {
                fixed_errors.visibility = View.GONE
            }
        }
        //scroll2_from setOnCheckedChangeListener
        if (scroll2_from.isChecked == true) {
            if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                /*from_error.visibility=View.VISIBLE
                from_error.setError(" ")
                to_error.visibility=View.VISIBLE
                to_error.setError(" ")*/
            }
        } else {
            from_errors.visibility = View.GONE
            to_errors.visibility = View.GONE
        }
        scroll2_from.setOnCheckedChangeListener { fro, b ->
            if (fro.isChecked == true) {
                scroll2_fixed.isChecked = false
                scroll2_fixed_price.isEnabled = false
                scroll2_fixed_price.setText("")
                if(id.text.toString().isNotEmpty()) {
                    if (scroll2_from.isChecked == true) {
                        scroll2_price_from.setText(from)
                        scroll2_price_to.setText(to)
                    }
                }

                fro.isChecked = true
                scroll2_price_from.isEnabled = true
                scroll2_price_to.isEnabled = true
                fixed_errors.visibility = View.GONE
                if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                    /* from_error.visibility=View.VISIBLE
                    from_error.setError(" ")
                    to_error.visibility=View.VISIBLE
                    to_error.setError(" ")*/
                }
            } else {
                from_errors.visibility = View.GONE
                to_errors.visibility = View.GONE
            }
        }

        //description ontextchanged
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.visibility = View.VISIBLE
        }
        scroll2_descrip.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_description.setText(des)
                if (des.isEmpty()) {
                    scroll2_preview_description.visibility = View.GONE
                } else {
                    scroll2_preview_description.visibility = View.VISIBLE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //fixed price ontextchanged
        if (scroll2_fixed_price.text.isEmpty() && scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
            scroll2_preview_price.setText("Service price")
        }
        scroll2_fixed_price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(price: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("Rs " + price)
                if (price.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (scroll2_fixed_price.text.isEmpty()) {


                } else {
                    fixed_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })



        //from price ontextchanged




        scroll2_price_from.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(from: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + from + " to " + scroll2_price_to.text.toString())
                if (from.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (scroll2_price_to.text.isEmpty() && from.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (from.isEmpty()) {

                } else {
                    from_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

            }
        })


        //to price ontextchanged
        scroll2_price_to.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(to: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + to)
                if (to.isEmpty()) {
                    scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString())
                }
                if (scroll2_price_from.text.isEmpty() && to.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (to.isEmpty()) {

                } else {
                    to_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })





        println("id  " + id.text)
        println("new id  " + newid.text)



        //save action
        save.setOnClickListener {
            println("save clicked " + newid.text)
            if ((newid.text.isNotEmpty()) && (net_status() == true)) {
                if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                    if (scroll2_fixed.isChecked == true) {
                        if (scroll2_fixed_price.text.isEmpty()) {

                        }
                    }
                    if (scroll2_from.isChecked == true) {
                        if (scroll2_price_from.text.isEmpty()) {

                        }
                        if (scroll2_price_to.text.isEmpty()) {

                        }
                    }
                }
                if (sname.text.isEmpty() || price.text.isEmpty()) {
                    println("gender " + scroll2_gender.selectedItemPosition.toString())
                    if (scroll2_gender.selectedItemPosition == 0) {

                    }
                    if (scroll2_category.selectedItemPosition == 0) {

                    }
                    if (scroll2_sub_category.selectedItemPosition == 0) {

                    }
                    if (sname.text.isEmpty()) {
                        sname_error.visibility = View.VISIBLE


                    }
                    if (price.text.isEmpty()) {
                        price_error.visibility = View.VISIBLE

                    }
                    println("main " + scroll2_category.selectedItemPosition.toString())
                    println("sub " + scroll2_sub_category.selectedItemPosition.toString())
                    Toast.makeText(this, "please fill required fields!", Toast.LENGTH_LONG).show()
                } else if (sname.text.isNotEmpty() && price.text.isNotEmpty()) {

                    if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                        if (scroll2_fixed.isChecked == true) {
                            if (scroll2_fixed_price.text.isEmpty()) {

                            }
                        }
                        if (scroll2_from.isChecked == true) {
                            if (scroll2_price_from.text.isEmpty()) {

                            }
                            if (scroll2_price_to.text.isEmpty()) {

                            }
                        }
                    }



                    if ((newid.text.isNotEmpty() && id.text.isEmpty())&&(net_status()==true)) {


                        try {
                            if(scroll2_price_to.text.toString().isNotEmpty()&&scroll2_price_from.text.toString().isNotEmpty()) {
                                if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                                   poplow()
                                } else {
                                    save.isEnabled = false
                                    save_progress.visibility = android.view.View.VISIBLE

                                    onStarClicked1()    //New service insert
                                }
                            }
                            else{
                                save.isEnabled = false
                                save_progress.visibility = android.view.View.VISIBLE

                                onStarClicked1()  //New service insert
                            }
                        }
                        catch (e:Exception){

                        }




                    } else {
                        Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()

                        println("scroll2_price_to.text" + scroll2_price_to.text)
                    }


                } else {
                    Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("textView1.text.isNotEmpty()&&textView6.text.isNotEmpty()&&scroll2_gender.selectedItemPosition!=0&&scroll2_category.selectedItemPosition!=0&&scroll2_sub_category.selectedItemPosition!=0" + sname.text + "  " + price.text + "  " + scroll2_gender.selectedItemPosition + "  " + scroll2_category.selectedItemPosition + "  " + scroll2_sub_category.selectedItemPosition)
                }
            } else if ((id.text.isNotEmpty()) && (net_status() == true)) {

                try {
                    if (scroll2_category.selectedItemPosition==0) {
                        subcatvaldup = ""

                    } else if ((scroll2_category.selectedItemPosition!=0)&&(scroll2_sub_category.selectedItemPosition!=0)) {
                        subcatvaldup = scroll2_sub_category.selectedItem.toString()
                    }
                }
                catch (e:Exception){

                }

                if((snamevalidate!=sname.text.toString())||(sdurvalidate!=sdur.text.toString())||(hsnTvalidate!=hsnT.text.toString())
                        ||(hsndesvalidate!=hsndes.text.toString())||(pricevalidate!=price.text.toString())||(intaxvalidate!=intax.text.toString())||
                        (gendervalidate!=scroll2_gender.selectedItem.toString())||(maincatvalidate!=scroll2_category.selectedItem.toString())||
                        (subcatvalidate!=subcatvaldup)||(cessvalidate!=cess.text.toString())||(pervalidate!=per.text.toString())||(payempvalidate!=payemp.isChecked.toString())||(descvalidate!=scroll2_descrip.text.toString())||
                        (paybonusvalidate!=paybonus.isChecked.toString())||(scroll2_fixed_pricevalidate!=scroll2_fixed_price.text.toString())
                        ||(scroll2_price_fromvalidate!=scroll2_price_from.text.toString())||(scroll2_price_tovalidate!=scroll2_price_to.text.toString())){

                    listenersave = "change"
                    println("ONBACK URL1 NOT EQUAL"+img1url)
                    println("SAVE CLICK LISTENER SAVE"+listenersave)

                }

                else if(((img1url != f1edit) || (img2url != s1edit) || (img3url != t1edit) || (img4url != fo1edit) || (img5url != fif1edit))){
                    println("ONBACK URL1 EDIT NOT EQUAl"+img1url)
                    listenersave = "change"
                    println("SAVE CLICK LISTENER SAVE"+listenersave)
                }



                println("UPDATE")




                if((id.text.isNotEmpty())&&(net_status()==true)&&(listenersave=="change")){
                    println("SAVE CLICK LISTENER SAVE"+listenersave)
                    try {
                        if(scroll2_price_to.text.toString().isNotEmpty()&&scroll2_price_from.text.toString().isNotEmpty()) {
                            if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                                 poplow()
                            } else {
                                update()    //For existing service update
                            }
                        }
                        else{
                            update()           //For existing service update
                        }
                    }
                    catch (e:Exception){
                    }

                }
                else if((id.text.isNotEmpty())&&(listenersave.isEmpty())){

                    Toast.makeText(this@ScrollActivity, "Nothing happened for save", Toast.LENGTH_LONG).show()

                }


            } else {
                Toast.makeText(this@ScrollActivity, "No internet connection", Toast.LENGTH_LONG).show()

            }

        }



        //Navigate to multi images add activity - AddImagesActivity_services

        scroll2_gallery.setOnClickListener {
            scroll2_slider.removeAllSliders()
            scroll2_gallery.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listenersave", listenersave)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            startActivityForResult(b, 0)
            scroll2_gallery.isEnabled = true
        }







        //Navigate to multi images add activity - AddImagesActivity_services

        camback.setOnClickListener {
            camback.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("listenersave", listenersave)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)



            startActivityForResult(b, 0)
            camback.isEnabled = true
        }
        //Navigate to multi images add activity - AddImagesActivity_services

        cam.setOnClickListener {
            cam.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("listenersave", listenersave)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)


            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            startActivityForResult(b, 0)
            cam.isEnabled = true
        }


        //did.setText(b)
        //duration time picker
        /*sdur.setOnFocusChangeListener { view, b ->
            if(sdur.isFocused==true) {
                val mcurrentTime = Calendar.getInstance()
                val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
                val minute = mcurrentTime.get(Calendar.MINUTE)
                val mTimePicker: TimePickerDialog
                mTimePicker = TimePickerDialog(this@ScrollActivity, TimePickerDialog.OnTimeSetListener { timePicker, selectedHour, selectedMinute ->
                    sdur.setText(selectedHour.toString() + ":" + selectedMinute) }, hour, minute, true)//Yes 24 hour time
                mTimePicker.setTitle("Select Time")
                mTimePicker.show()
            }
        }*/

        /*disable.setOnClickListener {
            val popup = PopupMenu(this@ScrollActivity, disable)
            popup.menuInflater.inflate(R.menu.disable, popup.menu)
            val m1 = popup.menu.getItem(0)
            if (save.visibility==View.VISIBLE) {
                if (state.text == "Disabled") {
                    m1.title = "Enable service"
                    popup.setOnMenuItemClickListener { item ->
                        state.setText("Enabled")
                        Toast.makeText(this@ScrollActivity, "" + item, Toast.LENGTH_SHORT).show()
                        true
                    }
                    popup.show()
                } else if (state.text == "Enabled") {
                    m1.title = "Disable service"
                    popup.setOnMenuItemClickListener { item ->
                        state.setText("Disabled")
                        Toast.makeText(this@ScrollActivity, "" + item, Toast.LENGTH_SHORT).show()
                        true
                    }
                    popup.show()
                }
            }
        }*/

        if (id.text.isNotEmpty()) {
            val getone = myDb.getOne(id.text.toString())
            if (getone.moveToNext()) {
                sl_title.setText(getone.getString(1).toString())
            }
        }



        // If imagelinks are not empty then add image links to 'filemaps' array for slider view.
        //Image links from local storage or online db

        if (img1url.isNullOrEmpty() == false || img2url.isNullOrEmpty() == false || img3url.isNullOrEmpty() == false || img4url.isNullOrEmpty() == false || img5url.isNullOrEmpty() == false) {


            scrollpro.visibility = View.VISIBLE

            scroll2_preview_service_image2.visibility = View.VISIBLE
            scroll2_slider2.visibility = View.VISIBLE
            camback.visibility = View.GONE
            cam.visibility = View.GONE
            scroll2_gallery.visibility = View.VISIBLE
            if (img1url.isNullOrEmpty() == false) {
                img1url = img1url.toString()

            }
            if (img2url.isNullOrEmpty() == false) {
                img2url = img2url.toString()

            }
            if (img3url.isNullOrEmpty() == false) {
                img3url = img3url.toString()

            }
            if (img4url.isNullOrEmpty() == false) {
                img4url = img4url.toString()

            }
            if (img5url.isNullOrEmpty() == false) {
                img5url = img5url.toString()

            }
            if (img1n.isNullOrEmpty() == false) {
                img1n = img1n.toString()
                img1nhigh=img1nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img1nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img1url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img1url)
                }



            }
            if (img2n.isNullOrEmpty() == false) {
                img2n = img2n.toString()
                img2nhigh=img2nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img2nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img2url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img2url)
                }
            }
            if (img3n.isNullOrEmpty() == false) {
                img3n = img3n.toString()
                img3nhigh=img3nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img3nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img3url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img3url)
                }
            }
            if (img4n.isNullOrEmpty() == false) {
                img4n = img4n.toString()
                img4nhigh=img4nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img4nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img4url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img4url)
                }
            }
            if (img5n.isNullOrEmpty() == false) {
                img5n = img5n.toString()

                img5nhigh=img5nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img5nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img5url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img5url)
                }
            }
        } else {
            scroll2_slider2.visibility = View.GONE
            scroll2_preview_service_image2.visibility = View.GONE
            scroll2_slider.visibility = View.VISIBLE
            scroll2_preview_service_image.visibility = View.VISIBLE

            camback.visibility = View.VISIBLE
            cam.visibility = View.VISIBLE
            scroll2_gallery.visibility = View.GONE
        }

        if (paybonus.isEnabled == true) {
            if (paybonus.isChecked == true) {
                percentage.isEnabled = true
                currency.isEnabled = true
                per.isEnabled = true
                currency.setTextColor(Color.parseColor("#546e7a"))
                percentage.setTextColor(Color.parseColor("#546e7a"))
                per.setTextColor(Color.parseColor("#546e7a"))
            } else {
                percentage.isEnabled = false
                per.isEnabled = false
                currency.isEnabled = false
                currency.setTextColor(Color.parseColor("#85546e7a"))
                percentage.setTextColor(Color.parseColor("#85546e7a"))
                per.setTextColor(Color.parseColor("#85546e7a"))
            }
        }
        paybonus.setOnCheckedChangeListener { button, state ->
            if (paybonus.isEnabled == true) {
                if (state == true) {
                    percentage.isEnabled = true
                    currency.isEnabled = true
                    per.isEnabled = true
                    currency.setTextColor(Color.parseColor("#546e7a"))
                    percentage.setTextColor(Color.parseColor("#546e7a"))
                    per.setTextColor(Color.parseColor("#546e7a"))
                } else {
                    percentage.isEnabled = false
                    per.isEnabled = false
                    currency.isEnabled = false
                    currency.setTextColor(Color.parseColor("#85546e7a"))
                    percentage.setTextColor(Color.parseColor("#d3d3d3"))
                    per.setTextColor(Color.parseColor("#d3d3d3"))
                }
            }
        }
        currency.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                percentage.isChecked = false
                percentage.setTextColor(Color.parseColor("#d3d3d3"))
                per.setText("")
            } else if (state == false) {
                percentage.isChecked = true
                percentage.setTextColor(Color.parseColor("#546e7a"))
                per.setText("")
            }
        }
        percentage.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                currency.isChecked = false
                currency.setTextColor(Color.parseColor("#85546e7a"))
                per.setText("")
            } else if (state == false) {
                currency.isChecked = true
                currency.setTextColor(Color.parseColor("#546e7a"))
                per.setText("")
            }
        }

        per.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                var pri: Float
                if (currency.isChecked == true) {
                    if (s.isNotEmpty()) {
                        pri = s.toString().toFloat()
                        if (price.text.toString().isNotEmpty()) {
                            if ((pri > price.text.toString().toFloat())) {
                                per.isEnabled = false
                                val builder = AlertDialog.Builder(this@ScrollActivity)
                                with(builder) {
                                    setTitle("Exceed")
                                    setMessage("Given value is higher than price.")
                                    builder.setCancelable(false)

                                    setPositiveButton("Ok") { dialog, whichButton ->
                                        per.isEnabled = true
                                        per.setText("")
                                        dialog.dismiss()
                                    }
                                    val dialog = builder.create()
                                    dialog.show()
                                }
                            }
                        } else {
                            val builder = AlertDialog.Builder(this@ScrollActivity)
                            with(builder) {
                                setTitle("Alert")
                                setMessage("please fill price field before currency")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->
                                    per.isEnabled = true
                                    per.setText("")
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }
                    }
                } else if (percentage.isChecked == true) {
                    if (s.isNotEmpty()) {
                        pri = s.toString().toFloat()


                        if ((pri > 100)) {
                            per.isEnabled = false
                            val builder = AlertDialog.Builder(this@ScrollActivity)
                            with(builder) {
                                setTitle("Exceed")
                                setMessage("Given percentage value is greater than 100.")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->
                                    per.setText("")
                                    per.isEnabled = true
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }


                    }

                }

            }
        })

        //incentives
        /* currency.isEnabled = false
         percentage.isEnabled = false
         per.isEnabled = false
         currency.setTextColor(Color.parseColor("#d3d3d3"))
         percentage.setTextColor(Color.parseColor("#d3d3d3"))
         per.setTextColor(Color.parseColor("#d3d3d3"))
         paybonus.setOnCheckedChangeListener { button, b ->
             if (paybonus.isChecked == false ) {
                 currency.isChecked = true
                 percentage.isChecked = false
                 currency.isEnabled = false
                 percentage.isEnabled = false
                 per.isEnabled = false
                 currency.setTextColor(Color.parseColor("#d3d3d3"))
                 percentage.setTextColor(Color.parseColor("#d3d3d3"))
                 per.setTextColor(Color.parseColor("#d3d3d3"))
             } else if (paybonus.isChecked == true) {
                 currency.isEnabled = true
                 percentage.isEnabled = true
                 per.isEnabled = true
                 currency.setTextColor(Color.parseColor("#546e7a"))
                 percentage.setTextColor(Color.parseColor("#546e7a"))
                 per.setTextColor(Color.parseColor("#546e7a"))
             }
             if (currency.isChecked == true && percentage.isChecked == true) {
                 percentage.setTextColor(Color.parseColor("#546e7a"))
                 percentage.isChecked = true
                 currency.setTextColor(Color.parseColor("#d3d3d3"))
                 currency.isChecked = false
                 per.setTextColor(Color.parseColor("#546e7a"))
                 per.isEnabled = true
             }
         }
         percentage.setOnCheckedChangeListener { compoundButton, b ->
             if (currency.isChecked == true && percentage.isChecked == true) {
                 percentage.setTextColor(Color.parseColor("#546e7a"))
                 percentage.isChecked = true
                 currency.setTextColor(Color.parseColor("#d3d3d3"))
                 currency.isChecked = false
                 per.setTextColor(Color.parseColor("#546e7a"))
                 per.isEnabled = true
             }
         }
         currency.setOnCheckedChangeListener { compoundButton, b ->
             if (percentage.isChecked == true && currency.isChecked == true) {
                 currency.setTextColor(Color.parseColor("#546e7a"))
                 currency.isChecked = true
                 percentage.setTextColor(Color.parseColor("#d3d3d3"))
                 percentage.isChecked = false
                 per.setTextColor(Color.parseColor("#546e7a"))
                 per.isEnabled = true
             }
         }*/

        back.setOnClickListener {
            back.isEnabled = false
            onBackPressed()
            //finish()
        }
        //Tax Checkbox

        if (id.text.toString().isNotEmpty() && editclick == "clicked") {
            if (Tax.isChecked == true) {
                intax.isEnabled = true
                cess.isEnabled = true
                Ctax.isEnabled = false
                Stax.isEnabled = false
            } else {
                intax.isEnabled = false
                intax.setText("")
                cess.isEnabled = false
                cess.setText("")
                Ctax.isEnabled = false
                Ctax.setText("")
                Stax.isEnabled = false
                Stax.setText("")
                grosstot.setText(price.text.toString())

            }
        } else if (id.text.toString().isEmpty()) {
            if (Tax.isChecked == true) {
                intax.isEnabled = true
                cess.isEnabled = true
                Ctax.isEnabled = false
                Stax.isEnabled = false
            } else {
                intax.isEnabled = false
                intax.setText("")
                cess.isEnabled = false
                cess.setText("")
                Ctax.isEnabled = false
                Ctax.setText("")
                Stax.isEnabled = false
                Stax.setText("")


            }
        }

        Tax.setOnCheckedChangeListener { compoundButton, b ->
            if (id.text.toString().isNotEmpty() && editclick == "clicked") {

                if (Tax.isChecked == true) {
                    intax.isEnabled = true
                    cess.isEnabled = true
                    Ctax.isEnabled = false
                    Stax.isEnabled = false
                } else {
                    intax.isEnabled = false
                    intax.setText("")
                    cess.isEnabled = false
                    cess.setText("")
                    Ctax.isEnabled = false
                    Ctax.setText("")
                    Stax.isEnabled = false
                    Stax.setText("")
                    grosstot.setText(price.text.toString())
                }
            } else if (id.text.toString().isEmpty()) {
                if (Tax.isChecked == true) {
                    intax.isEnabled = true
                    cess.isEnabled = true
                    Ctax.isEnabled = false
                    Stax.isEnabled = false
                } else {
                    intax.isEnabled = false
                    intax.setText("")
                    cess.isEnabled = false
                    cess.setText("")
                    Ctax.isEnabled = false
                    Ctax.setText("")
                    Stax.isEnabled = false
                    Stax.setText("")
                    grosstot.setText(price.text.toString())
                }
            }
        }






        sname.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


                scroll2_preview_service_name.setText(pr)


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })


        sname.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->




        });


        sdur.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->


            if (sname.text.isNotEmpty()) {


                val dd = myDb.retrieves(sname.text.toString())
                try {
                    while (dd.moveToNext()) {
                        val snames = dd.getString(1)

                        if ((snames == sname.text.toString()) && (id.text.isEmpty())) {

                            val builder = AlertDialog.Builder(this@ScrollActivity)
                            with(builder) {
                                setTitle("Already exist")
                                setMessage("Service name already exist!")
                                // Dialog
                                setPositiveButton("Ok") { dialog, whichButton ->
                                    sname.setText("")
                                    dialog.dismiss()

                                }

                                val dialog = builder.create()
                                dialog.show()
                            }

                        }

                    }
                }
                catch (e:Exception){


                }

                if (sname.text.toString().isEmpty()) {

                }
            }


            if ((!hasFocus)&&(sdur.text.isNotEmpty())) {
                if ((!sdur.text.toString().endsWith("mins") && (sdur.text.toString().isNotEmpty()))) {
                    var jj = sdur.text.toString()
                    sdur.setText("$jj mins")
                }
                // code to execute when EditText loses focus
            }

        });


        /*sdur.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {




                if((sid.text.toString()=="Auto-genereted")){
                    listenersave="change"
                }




            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {


                if(sdur.text.toString().isEmpty()){
                    listenersave=""
                }
                else if(sdur.text.toString().isNotEmpty()){


                }
            }
        })*/
        /* hsnT.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {



                if((sid.text.toString()=="Auto-genereted")){
                    listenersave="change"
                }

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                if(hsnT.text.toString().isEmpty()){
                    listenersave=""
                }
            }
        })*/
        /* hsndes.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {

                if((sid.text.toString()=="Auto-genereted")){
                    listenersave="change"
                }
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                if(hsndes.text.toString().isEmpty()){
                    listenersave=""
                }
            }
        })*/


        //During price edittext changelitener which calculates the price with gst and cess values

        price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


                if (pr.isNullOrEmpty()) {
                    price_error.visibility = View.VISIBLE

                } else {
                    price_error.visibility = View.GONE
                }
                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (pr.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (intax.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = intax.text.toString().replace("%", "").toFloat()
                }
                if (cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if (price.text.toString().isEmpty()) {
                    listenersave = ""
                }
            }
        })

        //During Integrated tax edittext changelitener which calculates the price with gst and cess values

        intax.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = price.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if (intax.text.toString().isEmpty()) {
                    listenersave = ""
                }

            }
        })


        //During cess  edittext changelitener which calculates the price with gst and cess values

        cess.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {

                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = price.text.toString().toFloat()
                }
                if (intax.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = intax.text.toString().replace("%", "").toFloat()
                }
                if (cess.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (cess.text.toString().isEmpty()) {
                    listenersave = ""
                }
            }
        })
        //scroll2_page items
        if (gender.isNullOrEmpty() == false) gender = gender.toString()
        if (maincat.isNullOrEmpty() == false) maincat = maincat.toString()
        if (subcat.isNullOrEmpty() == false) subcat = subcat.toString()
        if (des.isNullOrEmpty() == false) des = des.toString()
        if (fix.isNullOrEmpty() == false) fix = fix.toString()
        if (from.isNullOrEmpty() == false) from = from.toString()
        if (to.isNullOrEmpty() == false) to = to.toString()


        //sname addTextChangedListener
        textInputLayout.editText!!.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {
                if (p0.isNullOrEmpty()) {
                    sname_error.visibility = View.VISIBLE

                } else {
                    sname_error.visibility = View.GONE
                }
                if (id.text.isNotEmpty()) {

                }
            }

            override fun afterTextChanged(p0: Editable?) {

            }

            override fun beforeTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {

            }
        })
        fix_check = intent.getBooleanExtra("fix_check", true).toString()
        from_check = intent.getBooleanExtra("from_check", false).toString()

      /*  save.setOnClickListener { view ->
            println("save clicked " + newid.text)
            if (newid.text.isNotEmpty()) {
                println("new id  " + newid.text)

                if (textInputLayout.editText!!.text.isEmpty() || price.text.isEmpty()) {
                    if (textInputLayout.editText!!.text.isEmpty()) {
                        sname_error.visibility = View.VISIBLE
                        sname_error.setError("")
                    }
                    if (price.text.isEmpty()) {
                        price_error.visibility = View.VISIBLE
                        price_error.setError("")
                    }
                    if (gender.isEmpty()) {
                        gen_error = "true"
                    }
                    if (maincat.isEmpty()) {
                        main_error = "true"
                    }
                    if (subcat.isEmpty()) {
                        sub_error = "true"
                    }
                    Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()

                } else if (textInputLayout.editText!!.text.isNotEmpty() && price.text.isNotEmpty()) {

                    if (newid.text.isNotEmpty() && id.text.isEmpty()) {
                        onStarClicked1()
                    } else {
                        Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()
                        println("to.isNotEmpty() " + to)
                    }


                } else {
                    Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("fix.isNotEmpty()fix.isEmpty()" + fix)
                }
            } else if (id.text.isNotEmpty()) {
                update()
            }
        }*/

        //var radioGroup1: RadioGroup? = null
        var deals: RadioButton? = null


        //radioGroup1 = (findViewById<View>(R.id.radioGroup1) as RadioGroup)

        // deals = findViewById(deals) as RadioButton

        /*  radioGroup1.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.service -> { }
                R.id.web -> {
                    //save_progress.visibility=View.VISIBLE
                    val arguments = Intent(this@ScrollActivity, Scroll2_page::class.java)
                    arguments.putExtra("sname",sname.text.toString())
                    arguments.putExtra("sid",sid.text.toString())
                    arguments.putExtra("sdur",sdur.text.toString())
                    arguments.putExtra("hsnT",hsnT.text.toString())
                    arguments.putExtra("hsndes",hsndes.text.toString())
                    arguments.putExtra("price",price.text.toString())
                    arguments.putExtra("Tax",Tax.isChecked)
                    arguments.putExtra("intax",intax.text.toString())
                    arguments.putExtra("cess",cess.text.toString())
                    arguments.putExtra("Ctax",Ctax.text.toString())
                    arguments.putExtra("Stax",Stax.text.toString())
                    arguments.putExtra("taxtot",taxtot.text.toString())
                    arguments.putExtra("css",css.text.toString())
                    arguments.putExtra("grosstot",grosstot.text.toString())
                    arguments.putExtra("payemp",payemp.isChecked)
                    arguments.putExtra("paybonus",paybonus.isChecked)
                    arguments.putExtra("currency",currency.isChecked)
                    arguments.putExtra("percentage",percentage.isChecked)
                    arguments.putExtra("per",per.text.toString())
                    arguments.putExtra("state",state.text.toString())
                    arguments.putExtra("mresult",mresultsarr)
                    arguments.putExtra("listenersave",listenersave)
                    arguments.putExtra("editclick",editclick)
                    arguments.putExtra("cacnm1",cacnm1)

                    println("state  "+state.text)
                    arguments.putExtra("edit",edit.visibility)
                    println("eidt  "+edit.visibility)
                    //arguments.putExtra("descrip",descrip.text.toString())
                    arguments.putExtra("lid",id.text.toString())
                    arguments.putExtra("newid",newid.text.toString())
                    //scroll2_page items
                    arguments.putExtra("gender",gender)
                    arguments.putExtra("maincat",maincat)
                    arguments.putExtra("subcat",subcat)
                    arguments.putExtra("des",des)
                    arguments.putExtra("fix",fix)
                    arguments.putExtra("from",from)
                    arguments.putExtra("to",to)
                    arguments.putExtra("fix_chk",fix_check)
                    arguments.putExtra("frm_chk",from_check)
                    if(fixed_error.isNotEmpty()){
                        arguments.putExtra("fix_err",fixed_error)
                    }
                    if (from_error.isNotEmpty()){
                        arguments.putExtra("frm_err",from_error)
                    }
                    if (to_error.isNotEmpty()){
                        arguments.putExtra("to_err",to_error)
                    }
                    if(gen_error.isNotEmpty()){
                        arguments.putExtra("gen_err",gen_error)
                    }
                    if (main_error.isNotEmpty()){
                        arguments.putExtra("main_err",main_error)
                    }
                    if (sub_error.isNotEmpty()){
                        arguments.putExtra("sub_err",sub_error)
                    }
                    //image url's
                    arguments.putExtra("f",f1)
                    arguments.putExtra("s",s1)
                    arguments.putExtra("t",t1)
                    arguments.putExtra("fo",fo1)
                    arguments.putExtra("fif",fif1)
                    //image name's
                    arguments.putExtra("fn",fn1)
                    arguments.putExtra("sn",sn1)
                    arguments.putExtra("tn",tn1)
                    arguments.putExtra("fon",fon1)
                    arguments.putExtra("fifn",fifn1)
                    arguments.putExtra("f1edit", f1edit)
                    arguments.putExtra("fn1edit", fn1edit)
                    arguments.putExtra("s1edit", s1edit)
                    arguments.putExtra("sn1edit", sn1edit)
                    arguments.putExtra("t1edit", t1edit)
                    arguments.putExtra("tn1edit", tn1edit)
                    arguments.putExtra("fo1edit", fo1edit)
                    arguments.putExtra("fon1edit", fon1edit)
                    arguments.putExtra("fif1edit", fif1edit)
                    arguments.putExtra("fifn1edit", fifn1edit)



                    println("f1high"+f1high)
                    println("s1high"+s1high)
                    println("t1high"+t1high)
                    println("f1ohigh"+fo1high)
                    println("fif1high"+fif1high)


                    println("fn1high"+fn1high)
                    println("sn1high"+sn1high)
                    println("tn1high"+tn1high)
                    println("fon1high"+fon1high)
                    println("fifn1high"+fifn1high)
                    //image url's
                    arguments.putExtra("fhigh",f1high)
                    arguments.putExtra("shigh",s1high)
                    arguments.putExtra("thigh",t1high)
                    arguments.putExtra("fohigh",fo1high)
                    arguments.putExtra("fifhigh",fif1high)
                    //image name's
                    arguments.putExtra("fnhigh",fn1high)
                    arguments.putExtra("snhigh",sn1high)
                    arguments.putExtra("tnhigh",tn1high)
                    arguments.putExtra("fon",fon1high)
                    arguments.putExtra("fifnhigh",fifn1high)

                    arguments.putExtra("f1edithigh", f1edithigh)
                    arguments.putExtra("fn1edithigh", fn1edithigh)
                    arguments.putExtra("s1edithigh", s1edithigh)
                    arguments.putExtra("sn1edithigh", sn1edithigh)
                    arguments.putExtra("t1edithigh", t1edithigh)
                    arguments.putExtra("tn1edithigh", tn1edithigh)
                    arguments.putExtra("fo1edithigh", fo1edithigh)
                    arguments.putExtra("fon1edithigh", fon1edithigh)
                    arguments.putExtra("fif1edithigh", fif1edithigh)
                    arguments.putExtra("fifn1edithigh", fifn1edithigh)

                    arguments.putExtra("add",add)
                    arguments.putExtra("edite",edite)
                    arguments.putExtra("delete",delete)
                    *//*if (id.text.isNotEmpty()&&newid.text.isEmpty()) {
                        arguments.putExtra("id", id.text.toString())
                    }else if(id.text.isEmpty()&&newid.text.isNotEmpty()){
                        arguments.putExtra("newid", newid.text.toString())
                    }*//*
                    if (sname.text.isNotEmpty()){
                        arguments.putExtra("name",sname.text.toString())
                    }

                    startActivity(arguments)
                   // save_progress.visibility=View.GONE
                    overridePendingTransition(0, 0)
                    finish()
                }
                else -> {
                }
            }
        })*/
    }




    //loadim() func is used to load all image links to slider view

    fun loadim() {
        scrollpro.visibility = View.GONE
        if (file_maps.isNotEmpty()) {


            for (r in 0 until file_maps.size) {
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("file_maps", "r  " + file_maps[r])
                    textSliderView
                            //.description(name)
                            .image(file_maps[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {

                                if(net_status()==true){


                                val b = Intent(applicationContext, AddImagesActivity_services::class.java)
                                b.putExtra("id", id.text.toString())
                                b.putExtra("add", add)
                                b.putExtra("edit", edite)
                                b.putExtra("delete", delete)
                                b.putExtra("keys",branchky)
                                b.putExtra("f1", img1url)
                                b.putExtra("fn1", img1n)
                                b.putExtra("s1", img2url)
                                b.putExtra("sn1", img2n)
                                b.putExtra("t1", img3url)
                                b.putExtra("tn1", img3n)
                                b.putExtra("fo1", img4url)
                                b.putExtra("fon1", img4n)
                                b.putExtra("fif1", img5url)
                                b.putExtra("fifn1", img5n)

                                b.putExtra("f1high", img1urlhigh)
                                b.putExtra("fn1high", img1nhigh)
                                b.putExtra("s1high", img2urlhigh)
                                b.putExtra("sn1high", img2nhigh)
                                b.putExtra("t1high", img3urlhigh)
                                b.putExtra("tn1high", img3nhigh)
                                b.putExtra("fo1high", img4urlhigh)
                                b.putExtra("fon1high", img4nhigh)
                                b.putExtra("fif1high", img5urlhigh)
                                b.putExtra("fifn1high", img5nhigh)
                                b.putExtra("f1edithigh", f1edithigh)
                                b.putExtra("fn1edithigh", fn1edithigh)
                                b.putExtra("s1edithigh", s1edithigh)
                                b.putExtra("sn1edithigh", sn1edithigh)
                                b.putExtra("t1edithigh", t1edithigh)
                                b.putExtra("tn1edithigh", tn1edithigh)
                                b.putExtra("fo1edithigh", fo1edithigh)
                                b.putExtra("fon1edithigh", fon1edithigh)
                                b.putExtra("fif1edithigh", fif1edithigh)
                                b.putExtra("fifn1edithigh", fifn1edithigh)
                                b.putExtra("f1edit", f1edit)
                                b.putExtra("fn1edit", fn1edit)
                                b.putExtra("s1edit", s1edit)
                                b.putExtra("sn1edit", sn1edit)
                                b.putExtra("t1edit", t1edit)
                                b.putExtra("tn1edit", tn1edit)
                                b.putExtra("fo1edit", fo1edit)
                                b.putExtra("fon1edit", fon1edit)
                                b.putExtra("fif1edit", fif1edit)
                                b.putExtra("fifn1edit", fifn1edit)
                                startActivityForResult(b, 0)
                                scroll2_slider.isEnabled = true
                                }
                                else{
                                    Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                }
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_service_image2
            try {
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)
                scroll2_preview_service_image2.setImageBitmap(img)
            } catch (e: Exception) {

            }
        }
    }


    //Receive image links from multi images activity and load into slider.


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0) {

            if (resultCode == Activity.RESULT_OK) {

                scroll2_slider.removeAllSliders()
                scroll2_slider2.removeAllSliders()

                imcome = "yes"

                scroll2_preview_service_image2.visibility = View.GONE
                scroll2_slider2.visibility = View.GONE
                scroll2_slider3.visibility = View.GONE
                scroll2_slider.visibility = View.VISIBLE
                scroll2_preview_service_image.visibility = View.VISIBLE
                val f = data!!.getStringExtra("f");
                val fn = data!!.getStringExtra("fn");
                val s = data!!.getStringExtra("s");
                val sn = data!!.getStringExtra("sn");
                val t = data!!.getStringExtra("t");
                val tn = data!!.getStringExtra("tn");
                val fo = data!!.getStringExtra("fo");
                val fon = data!!.getStringExtra("fon");
                val fif = data!!.getStringExtra("fif");
                val fifn = data!!.getStringExtra("fifn");


                val fedit = data!!.getStringExtra("fedit")
                val fnedit = data!!.getStringExtra("fnedit")
                val sedit = data!!.getStringExtra("sedit")
                val snedit = data!!.getStringExtra("snedit")
                val tedit = data!!.getStringExtra("tedit")
                val tnedit = data!!.getStringExtra("tnedit")
                val foedit = data!!.getStringExtra("foedit")
                val fonedit = data!!.getStringExtra("fonedit")
                val fifedit = data!!.getStringExtra("fifedit")
                val fifnedit = data!!.getStringExtra("fifnedit");

                try {
                    mresultsarr = data!!.getStringArrayListExtra("mResult")
                } catch (e: Exception) {

                }



                try {
                    cacnm1 = data!!.getStringExtra("cacnm1")
                } catch (e: Exception) {

                }
                try {
                    listenersave = data!!.getStringExtra("listenersave")
                } catch (e: Exception) {

                }

                val fhigh = data!!.getStringExtra("fhigh");
                val fnhigh = data!!.getStringExtra("fnhigh");
                val shigh = data!!.getStringExtra("shigh");
                val snhigh = data!!.getStringExtra("snhigh");
                val thigh = data!!.getStringExtra("thigh");
                val tnhigh = data!!.getStringExtra("tnhigh");
                val fohigh = data!!.getStringExtra("fohigh");
                val fonhigh = data!!.getStringExtra("fonhigh");
                val fifhigh = data!!.getStringExtra("fifhigh");
                val fifnhigh = data!!.getStringExtra("fifnhigh");


                println("fhigh" + fhigh)
                println("shigh" + shigh)
                println("thigh" + thigh)
                println("fohigh" + fohigh)
                println("fifhigh" + fifhigh)


                println("fnhigh" + fnhigh)
                println("snhigh" + snhigh)
                println("tnhigh" + tnhigh)
                println("fonhigh" + fonhigh)
                println("fifnhigh" + fifnhigh)
                if (fhigh.isNotEmpty()) {


                    img1urlhigh = fhigh
                    img1nhigh = fnhigh
                } else {
                    img1urlhigh = ""
                    img1nhigh = ""
                }
                if (shigh.isNotEmpty()) {


                    img2urlhigh = shigh
                    img2nhigh = snhigh
                } else {
                    img2urlhigh = ""
                    img2nhigh = ""
                }
                if (thigh.isNotEmpty()) {


                    img3urlhigh = thigh
                    img3nhigh = tnhigh
                } else {
                    img3urlhigh = ""
                    img3nhigh = ""
                }
                if (fohigh.isNotEmpty()) {


                    img4urlhigh = fohigh
                    img4nhigh = fonhigh
                } else {
                    img4urlhigh = ""
                    img4nhigh = ""
                }
                if (fifhigh.isNotEmpty()) {


                    img5urlhigh = fifhigh
                    img5nhigh = fifnhigh
                } else {

                    img5urlhigh = ""
                    img5nhigh = ""
                }


                val fedithigh = data!!.getStringExtra("fedithigh")
                val fnedithigh = data!!.getStringExtra("fnedithigh")
                val sedithigh = data!!.getStringExtra("sedithigh")
                val snedithigh = data!!.getStringExtra("snedithigh")
                val tedithigh = data!!.getStringExtra("tedithigh")
                val tnedithigh = data!!.getStringExtra("tnedithigh")
                val foedithigh = data!!.getStringExtra("foedithigh")
                val fonedithigh = data!!.getStringExtra("fonedithigh")
                val fifedithigh = data!!.getStringExtra("fifedithigh")
                val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                if (fedithigh.isNotEmpty()) {


                    f1edithigh = fedithigh
                    fn1edithigh = fnedithigh


                } else {


                    f1edithigh = ""
                    fn1edithigh = ""
                }
                if (sedithigh.isNotEmpty()) {


                    s1edithigh = sedithigh
                    sn1edithigh = snedithigh

                } else {


                    s1edithigh = ""
                    sn1edithigh = ""
                }
                if (tedithigh.isNotEmpty()) {

                    t1edithigh = tedithigh
                    tn1edithigh = tnedithigh

                } else {

                    t1edithigh = ""
                    tn1edithigh = ""
                }
                if (foedithigh.isNotEmpty()) {
                    fo1edithigh = foedithigh
                    fon1edithigh = fonedithigh

                } else {

                    fo1edithigh = ""
                    fon1edithigh = ""
                }
                if (fifedithigh.isNotEmpty()) {

                    fif1edithigh = fifedithigh
                    fifn1edithigh = fifnedithigh

                } else {

                    fif1edithigh = ""
                    fifn1edithigh = ""
                }





                if (fedit.isNotEmpty()) {


                    f1edit = fedit
                    fn1edit = fnedit


                } else {


                    f1edit = ""
                    fn1edit = ""
                }
                if (sedit.isNotEmpty()) {


                    s1edit = sedit
                    sn1edit = snedit

                } else {


                    s1edit = ""
                    sn1edit = ""
                }
                if (tedit.isNotEmpty()) {

                    t1edit = tedit
                    tn1edit = tnedit

                } else {

                    t1edit = ""
                    tn1edit = ""
                }
                if (foedit.isNotEmpty()) {
                    fo1edit = foedit
                    fon1edit = fonedit

                } else {

                    fo1edit = ""
                    fon1edit = ""
                }
                if (fifedit.isNotEmpty()) {

                    fif1edit = fifedit
                    fifn1edit = fifnedit

                } else {

                    fif1edit = ""
                    fifn1edit = ""
                }


                val bitmapArray = ArrayList<String>()
                bitmapArray.clear()
                scrollpro.visibility = View.VISIBLE
                if (f.isNotEmpty() || s.isNotEmpty() || t.isNotEmpty() || fo.isNotEmpty() || fif.isNotEmpty()) {
                    camback.visibility = View.GONE
                    cam.visibility = View.GONE
                    scroll2_gallery.visibility = View.VISIBLE
                } else {
                    camback.visibility = View.VISIBLE
                    cam.visibility = View.VISIBLE
                    scroll2_gallery.visibility = View.GONE
                }

                if (f.isNotEmpty()) {
                    img1url = f
                    img1n = fn
                    if(img1nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img1nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img1url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img1url)
                        }
                    }
                    else{
                        d.add(f);bitmapArray.add(f)
                    }






                } else {
                    img1url = ""
                    img1n = ""
                }
                if (s.isNotEmpty()) {
                    d.add(s);

                    img2url = s
                    img2n = sn


                    if(img2nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img2nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img2url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img2url)
                        }
                    }
                    else{
                        bitmapArray.add(s)
                    }






                } else {
                    img2url = ""
                    img2n = ""
                }
                if (t.isNotEmpty()) {
                    d.add(t);
                    img3url = t
                    img3n = tn
                    if(img3nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img3nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img3url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img3url)
                        }
                    }
                    else{
                        bitmapArray.add(t)
                    }




                } else {
                    img3url = ""
                    img3n = ""
                }
                if (fo.isNotEmpty()) {
                    d.add(fo);


                    img4url = fo
                    img4n = fon

                    if(img4nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img4nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img4url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img4url)
                        }
                    }
                    else{
                        bitmapArray.add(fo)
                    }







                } else {
                    img4url = ""
                    img4n = ""
                }
                if (fif.isNotEmpty()) {
                    d.add(fif);




                    img5url = fif
                    img5n = fifn



                    if(img5nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img5nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img5url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img5url)
                        }
                    }
                    else{
                        bitmapArray.add(fif)
                    }
                } else {
                    img5url = ""
                    img5n = ""
                }

                Handler().postDelayed(Runnable {     //Load images into slider


                    Log.d("tag", "  " + bitmapArray)
                    if (bitmapArray.isNotEmpty()) {
                        for (r in 0 until bitmapArray.size) {
                            scrollpro.visibility = View.GONE

                            val textSliderView = TextSliderView(this)
                            // initialize a SliderLayout
                            Log.d("khd", "r  " + bitmapArray[r])
                            textSliderView
                                    //.description(name)
                                    .image(bitmapArray[r])

                                    .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                    .setOnSliderClickListener {
                                        if(net_status()==true){

                                            // Navigate to multi images select activity

                                        val b = Intent(applicationContext, AddImagesActivity_services::class.java)
                                        b.putExtra("id", id.text.toString())
                                        b.putExtra("keys",branchky)
                                        b.putExtra("f1", img1url)
                                        b.putExtra("fn1", img1n)
                                        b.putExtra("s1", img2url)
                                        b.putExtra("sn1", img2n)
                                        b.putExtra("t1", img3url)
                                        b.putExtra("tn1", img3n)
                                        b.putExtra("fo1", img4url)
                                        b.putExtra("fon1", img4n)
                                        b.putExtra("fif1", img5url)
                                        b.putExtra("fifn1", img5n)
                                        b.putExtra("f1high", img1urlhigh)
                                        b.putExtra("fn1high", img1nhigh)
                                        b.putExtra("s1high", img2urlhigh)
                                        b.putExtra("sn1high", img2nhigh)
                                        b.putExtra("t1high", img3urlhigh)
                                        b.putExtra("tn1high", img3nhigh)
                                        b.putExtra("fo1high", img4urlhigh)
                                        b.putExtra("fon1high", img4nhigh)
                                        b.putExtra("fif1high", img5urlhigh)
                                        b.putExtra("fifn1high", img5nhigh)
                                        b.putExtra("mresult", mresultsarr)
                                        b.putExtra("listenersave", listenersave)
                                        b.putExtra("f1edithigh", f1edithigh)
                                        b.putExtra("fn1edithigh", fn1edithigh)
                                        b.putExtra("s1edithigh", s1edithigh)
                                        b.putExtra("sn1edithigh", sn1edithigh)
                                        b.putExtra("t1edithigh", t1edithigh)
                                        b.putExtra("tn1edithigh", tn1edithigh)
                                        b.putExtra("fo1edithigh", fo1edithigh)
                                        b.putExtra("fon1edithigh", fon1edithigh)
                                        b.putExtra("fif1edithigh", fif1edithigh)
                                        b.putExtra("fifn1edithigh", fifn1edithigh)

                                        b.putExtra("cacnm1", cacnm1)
                                        b.putExtra("f1edit", f1edit)
                                        b.putExtra("fn1edit", fn1edit)
                                        b.putExtra("s1edit", s1edit)
                                        b.putExtra("sn1edit", sn1edit)
                                        b.putExtra("t1edit", t1edit)
                                        b.putExtra("tn1edit", tn1edit)
                                        b.putExtra("fo1edit", fo1edit)
                                        b.putExtra("fon1edit", fon1edit)
                                        b.putExtra("fif1edit", fif1edit)
                                        b.putExtra("fifn1edit", fifn1edit)
                                        startActivityForResult(b, 0)
                                        scroll2_slider.isEnabled = true
                                        }
                                        else{
                                            Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                        }
                                    }

                            //add your extra information
                            /*textSliderView.bundle(Bundle())
                    textSliderView.bundle.clear()*/
                            //.putString("extra", bitmapArray[r])

                            scroll2_slider.addSlider(textSliderView)
                        }
                        scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                        scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                        scroll2_slider.setCustomAnimation(DescriptionAnimation())
                        scroll2_slider.setDuration(5000)

                        //scroll2_preview_service_image
                        val newurl = URL(bitmapArray[0]).openStream()
                        val img = BitmapFactory.decodeStream(newurl)
                        scroll2_preview_service_image.setImageBitmap(img)
                    }
                }, 1000)
                //bitmapArray.addAll(data.get("bitmapArray"))
                //println(bitmapArray)
                Log.d(" ", "result " + f)
                Log.d(" ", "result " + s)
                Log.d(" ", "result " + t)
                Log.d(" ", "result " + fo)
                Log.d(" ", "result " + fif)
                /* this.runOnUiThread(Runnable() {
                    file_maps.clear()
                    d.addAll(d)
                    Log.d("map","  "+d)
                })*/
            }

            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
                val f = data!!.getStringExtra("f");
                val fn = data!!.getStringExtra("fn");
                val s = data!!.getStringExtra("s");
                val sn = data!!.getStringExtra("sn");
                val t = data!!.getStringExtra("t");
                val tn = data!!.getStringExtra("tn");
                val fo = data!!.getStringExtra("fo");
                val fon = data!!.getStringExtra("fon");
                val fif = data!!.getStringExtra("fif");
                val fifn = data!!.getStringExtra("fifn");

                if (f.isNotEmpty()) {


                    img1url = f
                    img1n = fn
                } else {
                    img1url = ""
                    img1n = ""
                }
                if (s.isNotEmpty()) {


                    img2url = s
                    img2n = sn
                } else {
                    img2url = ""
                    img2n = ""
                }
                if (t.isNotEmpty()) {


                    img3url = t
                    img3n = tn
                } else {
                    img3url = ""
                    img3n = ""
                }
                if (fo.isNotEmpty()) {


                    img4url = fo
                    img4n = fon
                } else {
                    img4url = ""
                    img4n = ""
                }
                if (fif.isNotEmpty()) {


                    img5url = fif
                    img5n = fifn
                } else {
                    img5url = ""
                    img5n = ""
                }


                val fedit = data!!.getStringExtra("fedit")
                val fnedit = data!!.getStringExtra("fnedit")
                val sedit = data!!.getStringExtra("sedit")
                val snedit = data!!.getStringExtra("snedit")
                val tedit = data!!.getStringExtra("tedit")
                val tnedit = data!!.getStringExtra("tnedit")
                val foedit = data!!.getStringExtra("foedit")
                val fonedit = data!!.getStringExtra("fonedit")
                val fifedit = data!!.getStringExtra("fifedit")
                val fifnedit = data!!.getStringExtra("fifnedit");

                try {
                    mresultsarr = data!!.getStringArrayListExtra("mResult")
                } catch (e: Exception) {

                }



                try {
                    cacnm1 = data!!.getStringExtra("cacnm1")
                } catch (e: Exception) {

                }
                try {
                    listenersave = data!!.getStringExtra("listenersave")
                } catch (e: Exception) {

                }

                val fhigh = data!!.getStringExtra("fhigh");
                val fnhigh = data!!.getStringExtra("fnhigh");
                val shigh = data!!.getStringExtra("shigh");
                val snhigh = data!!.getStringExtra("snhigh");
                val thigh = data!!.getStringExtra("thigh");
                val tnhigh = data!!.getStringExtra("tnhigh");
                val fohigh = data!!.getStringExtra("fohigh");
                val fonhigh = data!!.getStringExtra("fonhigh");
                val fifhigh = data!!.getStringExtra("fifhigh");
                val fifnhigh = data!!.getStringExtra("fifnhigh");


                println("fhigh" + fhigh)
                println("shigh" + shigh)
                println("thigh" + thigh)
                println("fohigh" + fohigh)
                println("fifhigh" + fifhigh)


                println("fnhigh" + fnhigh)
                println("snhigh" + snhigh)
                println("tnhigh" + tnhigh)
                println("fonhigh" + fonhigh)
                println("fifnhigh" + fifnhigh)
                if (fhigh.isNotEmpty()) {


                    img1urlhigh = fhigh
                    img1nhigh = fnhigh
                } else {
                    img1urlhigh = ""
                    img1nhigh = ""
                }
                if (shigh.isNotEmpty()) {


                    img2urlhigh = shigh
                    img2nhigh = snhigh
                } else {
                    img2urlhigh = ""
                    img2nhigh = ""
                }
                if (thigh.isNotEmpty()) {


                    img3urlhigh = thigh
                    img3nhigh = tnhigh
                } else {
                    img3urlhigh = ""
                    img3nhigh = ""
                }
                if (fohigh.isNotEmpty()) {


                    img4urlhigh = fohigh
                    img4nhigh = fonhigh
                } else {
                    img4urlhigh = ""
                    img4nhigh = ""
                }
                if (fifhigh.isNotEmpty()) {


                    img5urlhigh = fifhigh
                    img5nhigh = fifnhigh
                } else {

                    img5urlhigh = ""
                    img5nhigh = ""
                }


                val fedithigh = data!!.getStringExtra("fedithigh")
                val fnedithigh = data!!.getStringExtra("fnedithigh")
                val sedithigh = data!!.getStringExtra("sedithigh")
                val snedithigh = data!!.getStringExtra("snedithigh")
                val tedithigh = data!!.getStringExtra("tedithigh")
                val tnedithigh = data!!.getStringExtra("tnedithigh")
                val foedithigh = data!!.getStringExtra("foedithigh")
                val fonedithigh = data!!.getStringExtra("fonedithigh")
                val fifedithigh = data!!.getStringExtra("fifedithigh")
                val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                if (fedithigh.isNotEmpty()) {


                    f1edithigh = fedithigh
                    fn1edithigh = fnedithigh


                } else {


                    f1edithigh = ""
                    fn1edithigh = ""
                }
                if (sedithigh.isNotEmpty()) {


                    s1edithigh = sedithigh
                    sn1edithigh = snedithigh

                } else {


                    s1edithigh = ""
                    sn1edithigh = ""
                }
                if (tedithigh.isNotEmpty()) {

                    t1edithigh = tedithigh
                    tn1edithigh = tnedithigh

                } else {

                    t1edithigh = ""
                    tn1edithigh = ""
                }
                if (foedithigh.isNotEmpty()) {
                    fo1edithigh = foedithigh
                    fon1edithigh = fonedithigh

                } else {

                    fo1edithigh = ""
                    fon1edithigh = ""
                }
                if (fifedithigh.isNotEmpty()) {

                    fif1edithigh = fifedithigh
                    fifn1edithigh = fifnedithigh

                } else {

                    fif1edithigh = ""
                    fifn1edithigh = ""
                }





                if (fedit.isNotEmpty()) {


                    f1edit = fedit
                    fn1edit = fnedit


                } else {


                    f1edit = ""
                    fn1edit = ""
                }
                if (sedit.isNotEmpty()) {


                    s1edit = sedit
                    sn1edit = snedit

                } else {


                    s1edit = ""
                    sn1edit = ""
                }
                if (tedit.isNotEmpty()) {

                    t1edit = tedit
                    tn1edit = tnedit

                } else {

                    t1edit = ""
                    tn1edit = ""
                }
                if (foedit.isNotEmpty()) {
                    fo1edit = foedit
                    fon1edit = fonedit

                } else {

                    fo1edit = ""
                    fon1edit = ""
                }
                if (fifedit.isNotEmpty()) {

                    fif1edit = fifedit
                    fifn1edit = fifnedit

                } else {

                    fif1edit = ""
                    fifn1edit = ""
                }

                Log.d("no ", "Result")



                imcome = "yes"
            }
        }
    }




    ///onStarClicked1() func is used to save and increase the service count

    private fun onStarClicked1() {

        if (net_status() == true) {

             pDialogs = SweetAlertDialog(this@ScrollActivity, SweetAlertDialog.PROGRESS_TYPE);
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialogs!!.setTitleText("Preparing...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();

            data class Count(var number: Int)

            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("service_id")
            myRef.runTransaction(object : Transaction.Handler {
                override fun doTransaction(mutableData: MutableData): Transaction.Result? {
                    var p = mutableData.value
                    if (p == null) {
                        p = 1
                    } else if (p == 0) {
                        // Unstar the post and remove self from stars
                        p = 1

                    } else {
                        // Star the post and add self to stars
                        p = Integer.parseInt(p.toString()) + 1
                    }
                    // Set value and report transaction success
                    mutableData.value = p
                    //mutableData.setValue(p.number)
                    return Transaction.success(mutableData)
                }

                override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {
                    println(dataSnapshot)
                    println(dataSnapshot.value)
                    val id = dataSnapshot.value
                    textInputLayout2.editText!!.setText(id.toString())
                    pDialogs!!.dismiss()
                    service_insert(id.toString())
                    // Transaction completed
                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                }
            })
        }
        else
        {
            Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
        }
        }



    fun service_insert(service_id: String) {


         pDialogs = SweetAlertDialog(this@ScrollActivity, SweetAlertDialog.PROGRESS_TYPE);
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialogs!!.setTitleText("Saving...")
        pDialogs!!.setCancelable(false)
        pDialogs!!.show();

        val nid= newid.text.toString()
        val sname = (textInputLayout.editText!!.text).toString()
        val sid = "SRV"+service_id
        val sdur = (textInputLayout3.editText!!.text).toString()
        val hsnT = (hsnT.text).toString()
        val hsndes = (hsndes.text).toString()
        val pr = (price.text).toString()
        val Tax = (Tax.isChecked.toString())
        val intax = (intax.text).toString()
        val cess = (cess.text).toString()
        val Ctax = (Ctax.text).toString()
        val Stax = (Stax.text).toString()
        val taxtot = (taxtot.text).toString()
        val css = (css.text).toString()
        val Gtot = (grosstot.text).toString()
        val payemp = (payemp.isChecked.toString())
        val paybonus = (paybonus.isChecked.toString())
        val currency = (currency.isChecked.toString())
        val percentage = (percentage.isChecked.toString())
        val per = (per.text).toString()
        val gender = (scroll2_gender.selectedItem.toString())

        val retdates=""
        if(frmmakeup=="makeup"){
            makeupitemstr="makeup service"
        }
        else if(frmmakeup.isEmpty()){
            makeupitemstr=""

        }


        try {
            if(scroll2_category.selectedItemPosition == 0) {

                maincat = ""
            } else {
                maincat = (scroll2_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }

        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcat = ""
            } else {
                subcat = (scroll2_sub_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }
        val des = (scroll2_descrip.text.toString())
        val fix = (scroll2_fixed_price.text.toString())
        val from = (scroll2_price_from.text.toString())
        val to = (scroll2_price_to.text.toString())

        //val desc = (descrip.text).toString()
        val status = (state.text.toString())
        val data = s(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess,
                cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp, ebns = paybonus, cry = currency,
                ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcat,mctgkey=mctgkeys,
                sctgkey=sctgkeys,desc = des, fp = fix, fpr = from, tpr = to,status = status, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url,
                img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,retdate = retdates,makeupitem = makeupitemstr)
        //if ((did.text.toString()).isEmpty()) {
        save.isEnabled = false

        val isInserted = myDb.insertData(nid, sname, sid, sdur, hsnT, hsndes,
                pr, Tax, intax, cess, Ctax, Stax, taxtot, css, Gtot, payemp, paybonus,
                currency, percentage, per, gender, maincat, subcat, des, fix, from, to,
                status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,mctgkeys,sctgkeys,retdates,makeupitemstr)
        if (isInserted == true){

           }
        else{
           }
        db = FirebaseFirestore.getInstance()
        db.collection("${branchky}_service").document(newid.text.toString())
                .set(data)
                .addOnSuccessListener {
                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()

                    pDialogs!!.dismiss()

                    if(frmmakeup.isEmpty()) {
                        val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                        startActivity(t)
                        finish()
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                    }
                    else if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                        val data = Intent(applicationContext,Main_makeup::class.java)

                        // Add the required data to be returned to the MainActivity


                        // Set the resultCode to Activity.RESULT_OK to
                        // indicate a success and attach the Intent
                        // which contains our result data
                        setResult(Activity.RESULT_OK, data)

                        // With finish() we close the AnotherActivity to
                        // return to MainActivity
                        finish()

                        Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()



                    }



                }
                .addOnFailureListener {Exception->

                    pDialogs!!.dismiss()
                    Toast.makeText(this, "not saved "+Exception.toString(), Toast.LENGTH_LONG).show()

                }
    }//ZfxlxjdmDFLImZppJa0f

    override fun onBackPressed() {

        listenersave = ""
        println("LISTENER SAVE"+listenersave)

        println("VALUE OF IMG2NAME"+img2n)
        println("VALUE OF IMG2NAME EDIT"+sn1edit)

        println("VALUE OF IMG1NAME"+img1n)
        println("VALUE OF IMG1NAME EDIT"+fn1edit)

        println("VALUE OF IMG3NAME"+img3n)
        println("VALUE OF IMG3NAME EDIT"+tn1edit)

        println("VALUE OF IMG4NAME"+img4n)
        println("VALUE OF IMG4NAME EDIT"+fon1edit)

        println("VALUE OF IMG5NAME"+img5n)
        println("VALUE OF IMG5NAME EDIT"+fifn1edit)

        println("VALUE OF BONUS STRING"+snamevalidate)
        println("VALUE OF BONUS EDITTEXT"+sname.text.toString())





        try {
            if (scroll2_category.selectedItemPosition==0) {
                subcatvaldup = ""

            } else if ((scroll2_category.selectedItemPosition!=0)&&(scroll2_sub_category.selectedItemPosition!=0)) {
                subcatvaldup = scroll2_sub_category.selectedItem.toString()
            }
        }
        catch (e:Exception){

        }
        if(frmmakeup=="makeup"||frmmakeup.isNotEmpty()){
            maincatvalidate=scroll2_category.selectedItem.toString()
            subcatvalidate=subcatvaldup
        }


        if((snamevalidate!=sname.text.toString())||(sdurvalidate!=sdur.text.toString())||(hsnTvalidate!=hsnT.text.toString())
        ||(hsndesvalidate!=hsndes.text.toString())||(pricevalidate!=price.text.toString())||(intaxvalidate!=intax.text.toString())||
                (gendervalidate!=scroll2_gender.selectedItem.toString())||(maincatvalidate!=scroll2_category.selectedItem.toString())||(subcatvalidate!=subcatvaldup)
            ||(cessvalidate!=cess.text.toString())||(pervalidate!=per.text.toString())||(payempvalidate!=payemp.isChecked.toString())||(descvalidate!=scroll2_descrip.text.toString())||
                        (paybonusvalidate!=paybonus.isChecked.toString())||(scroll2_fixed_pricevalidate!=scroll2_fixed_price.text.toString())
                        ||(scroll2_price_fromvalidate!=scroll2_price_from.text.toString())||(scroll2_price_tovalidate!=scroll2_price_to.text.toString())){

            listenersave = "change"
            println("ONBACK URL1 NOT EQUAL"+img1url)

        }

        else if(((img1url != f1edit) || (img2url != s1edit) || (img3url != t1edit) || (img4url != fo1edit) || (img5url != fif1edit))){
            println("ONBACK URL1 EDIT NOT EQUAl"+img1url)
            listenersave = "change"
        }

        if (((img1url.isNotEmpty()) || (img2url.isNotEmpty()) || (img3url.isNotEmpty()) || (img4url.isNotEmpty()) || (img5url.isNotEmpty())||(listenersave == "change"))&&(sid.text.toString()=="Auto-generated")) {
                println("ONBACK URL1 EDIT NOT SID"+img1url)
                alert()
            }

            else if ((listenersave == "change")&&(id.text.toString().isNotEmpty())) {
                println("ONBACK URL1 EDIT LIST ID"+img1url)
                alert()
            }
        else {
            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                val data = Intent(applicationContext,Main_makeup::class.java)
                setResult(Activity.RESULT_CANCELED, data)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()

            }
            else if(frmmakeup.isEmpty()) {
                val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                startActivity(t)
                finish()
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
            }
            }

        }

    fun alert() {
        val builder = AlertDialog.Builder(this@ScrollActivity)
        with(builder) {
            setTitle("Save?")
            setMessage("Do you want to save?")


            // Save Dialog

            setPositiveButton("Yes") { dialog, whichButton ->

                dialog.dismiss()

                try {
                    if(scroll2_price_to.text.toString().isNotEmpty()&&scroll2_price_from.text.toString().isNotEmpty()) {
                        if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                            poplow()  // Preview price value validation popup
                        } else {
                            save()   //Save action popup
                        }
                    }
                    else{
                        save()
                    }
                }
                catch (e:Exception){

                }

            }
                    .setNegativeButton("No") { dialog, whichButton ->

                        println("f1edit value" + f1edit)



                        if (newid.text.toString().isNotEmpty()) {

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@ScrollActivity);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);
                            println("true " + newid.text.toString())
                            val del = ArrayList<String>()
                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()



                            //Navigate to makeup list

                            if (img1n.isEmpty() && img2n.isEmpty() && img3n.isEmpty() && img4n.isEmpty() && img5n.isEmpty()) {
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }

                                //Navigate to service list

                                else if(frmmakeup.isEmpty()) {
                                    val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                    startActivity(t)
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                }
                            }
                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);

                            if (img1n.isNotEmpty()) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }

                                del.add(img1n)
                                del.add(img1nhigh)
                            }
                            if (img2n.isNotEmpty()) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img2n)
                                del.add(img2nhigh)
                            }
                            if (img3n.isNotEmpty()) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img3n)
                                del.add(img3nhigh)
                            }
                            if (img4n.isNotEmpty()) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img4n)
                                del.add(img4nhigh)
                            }
                            if (img5n.isNotEmpty()) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img5n)
                                del.add(img5nhigh)
                            }

                            //Delete images from storage and back action if service is not saved


                            if ((del.size >= 0)&&(net_status()==true)) {
                                for (i in del) {
                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {
                                                if (i == del.get(del.size - 1)) {
                                                    progressDialog.dismiss()


                                                  //Navigate to makeup list

                                                    if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        setResult(Activity.RESULT_CANCELED, data)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                        finish()

                                                    }

                                                    //Navigate to service list

                                                    else if(frmmakeup.isEmpty()) {
                                                        val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                                        startActivity(t)
                                                        finish()
                                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                            }
                                }
                            }
                            else{
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }
                                else if(frmmakeup.isEmpty()) {
                                    val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                    startActivity(t)
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                }
                            }
                        } else if ((id.text.isNotEmpty())&&(net_status()==true)) {
                            val delname = ArrayList<String>()
                            val delnameedit = ArrayList<String>()
                            val delnamehigh = ArrayList<String>()
                            val delnameedithigh = ArrayList<String>()
                            val delurl = ArrayList<String>()
                            val delurledit = ArrayList<String>()
                            val delurledithigh = ArrayList<String>()
                            val deldbnm = ArrayList<String>()

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);

                            if (img1n != fn1edit) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img1n)
                                delnamehigh.add(img1nhigh)
                            }
                            if (img2n != sn1edit) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img2n)
                                delnamehigh.add(img2nhigh)
                            }
                            if (img3n != tn1edit) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img3n)
                                delnamehigh.add(img3nhigh)
                            }
                            if (img4n != fon1edit) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img4n)
                                delnamehigh.add(img4nhigh)
                            }
                            if (img5n != fifn1edit) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img5n)
                                delnamehigh.add(img5nhigh)
                            }


                            println("DELE NAME" + delname)
                            println("DELE NAME HIGH" + delnamehigh)


                            delurl.add(f1edit)
                            delnameedit.add(fn1edit)

                            delurledithigh.add(f1edithigh)
                            delnameedithigh.add(fn1edithigh)

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@ScrollActivity);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);
                            deletedb()
                            if ((delname.size >= 0)&&(net_status()==true)) {
                                for (i in delname) {
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()

                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {

                                                if (i == delname.get(delname.size - 1)) {
                                                    for (i in delnamehigh) {
                                                        val imagesRef = storageRef.child("service").child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    if (i == delnamehigh.get(delnamehigh.size - 1)) {

                                                                        progressDialog.dismiss()
                                                                        if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                                                            val data = Intent(applicationContext,Main_makeup::class.java)
                                                                            setResult(Activity.RESULT_CANCELED, data)
                                                                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                                            finish()

                                                                        }
                                                                        else if(frmmakeup.isEmpty()) {
                                                                            val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                                                            startActivity(t)
                                                                            finish()
                                                                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                                                        }

                                                                    }

                                                                }
                                                    }
                                                }

                                            }
                                }


                            }
                            else{
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }
                                else if(frmmakeup.isEmpty()) {
                                    val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                    startActivity(t)
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                }
                            }
                        }
                        else{
                            Toast.makeText(applicationContext,"No internet Connection",Toast.LENGTH_SHORT).show()
                            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                val data = Intent(applicationContext,Main_makeup::class.java)
                                setResult(Activity.RESULT_CANCELED, data)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()

                            }
                            else if(frmmakeup.isEmpty()) {
                                val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                startActivity(t)
                                finish()
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                            }
                        }
                    }

            val dialog = builder.create()

            dialog.show()
        }
    }



    ///Delete images when updated images are not saved

            fun deletedb() {
if(((img1n != fn1edit)||(img2n != sn1edit)||(img3n != tn1edit)|| (img4n != fon1edit)||(img5n != fifn1edit))&&(net_status()==true)) {
    if ((id.text.isNotEmpty()) && (img1n != fn1edit)) {
        db.collection("${branchky}_service").document(id.text.toString())
                .update("img1url", f1edit)
                .addOnSuccessListener {
                    db.collection("${branchky}_service").document(id.text.toString())
                            .update("img1n", fn1edit)
                            .addOnCompleteListener {
                                db.collection("${branchky}_service").document(id.text.toString())
                                        .update("img1urlhigh", f1edithigh)
                                        .addOnSuccessListener {
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update("img1nhigh", fn1edithigh)

                                        }
                            }

                }
    }
    if ((id.text.isNotEmpty()) && (img2n != sn1edit)) {

        db.collection("${branchky}_service").document(id.text.toString())
                .update("img2url", s1edit)
                .addOnSuccessListener {
                    db.collection("${branchky}_service").document(id.text.toString())
                            .update("img2n", sn1edit)
                            .addOnCompleteListener {
                                db.collection("${branchky}_service").document(id.text.toString())
                                        .update("img2urlhigh", s1edithigh)
                                        .addOnSuccessListener {
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update("img2nhigh", sn1edithigh)


                                        }
                            }

                }
    }
    if ((id.text.isNotEmpty()) && (img3n != tn1edit)) {
        db.collection("${branchky}_service").document(id.text.toString())
                .update("img3url", t1edit)
                .addOnSuccessListener {
                    db.collection("${branchky}_service").document(id.text.toString())
                            .update("img3n", tn1edit)
                            .addOnCompleteListener {
                                db.collection("${branchky}_service").document(id.text.toString())
                                        .update("img3urlhigh", t1edithigh)
                                        .addOnSuccessListener {
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update("img3nhigh", tn1edithigh)


                                        }
                            }

                }

    }
    if ((id.text.isNotEmpty()) && (img4n != fon1edit)) {
        db.collection("${branchky}_service").document(id.text.toString())
                .update("img4url", fo1edit)
                .addOnSuccessListener {
                    db.collection("${branchky}_service").document(id.text.toString())
                            .update("img4n", fon1edit)
                            .addOnCompleteListener {
                                db.collection("${branchky}_service").document(id.text.toString())
                                        .update("img4urlhigh", fo1edithigh)
                                        .addOnSuccessListener {
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update("img4nhigh", fon1edithigh)


                                        }
                            }

                }

    }
    if ((id.text.isNotEmpty()) && (img5n != fifn1edit)) {
        db.collection("${branchky}_service").document(id.text.toString())
                .update("img5url", fif1edit)
                .addOnSuccessListener {
                    db.collection("${branchky}_service").document(id.text.toString())
                            .update("img5n", fifn1edit)
                            .addOnCompleteListener {
                                db.collection("${branchky}_service").document(id.text.toString())
                                        .update("img5urlhigh", fif1edithigh)
                                        .addOnSuccessListener {
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update("img5nhigh", fifn1edithigh)

                                        }
                            }

                }
    }
}
                else{

    val t = Intent(applicationContext, servicelistActivity::class.java)
    startActivity(t)
    finish()
    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                }
            }




    //Existing service update

    fun update(){
        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialogs!!.setTitleText("Saving...")
        pDialogs!!.setCancelable(false);
        pDialogs!!.show();
        println("id  "+id.text)
        val upid=id.text.toString()
        val sname = (textInputLayout.editText!!.text).toString()
        val sid = (textInputLayout2.editText!!.text).toString()
        val sdur = (textInputLayout3.editText!!.text).toString()
        val hsnT = (hsnT.text).toString()
        val hsndes = (hsndes.text).toString()
        val pr = (price.text).toString()
        val Tax = (Tax.isChecked.toString())
        val intax = (intax.text).toString()
        val cess = (cess.text).toString()
        val Ctax = (Ctax.text).toString()
        val Stax = (Stax.text).toString()
        val taxtot = (taxtot.text).toString()
        val css = (css.text).toString()
        val Gtot = (grosstot.text).toString()
        val payemp = (payemp.isChecked.toString())
        val paybonus = (paybonus.isChecked.toString())
        val currency = (currency.isChecked.toString())
        val percentage = (percentage.isChecked.toString())
        val per = (per.text).toString()
        val gender = (scroll2_gender.selectedItem.toString())
        try {
            if(scroll2_category.selectedItemPosition == 0) {

                maincat = ""
            } else {
                maincat = (scroll2_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }


        if(scroll2_descrip.text.isNotEmpty()){
            des=scroll2_descrip.text.toString()

        }

        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcat = ""
            } else {
                subcat = (scroll2_sub_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }

        if(scroll2_fixed.isChecked==true){
            fix=scroll2_fixed_price.text.toString()
            from=""
            to=""
        }
        else if(scroll2_from.isChecked==true){
            fix=""
            from=scroll2_price_from.text.toString()
            to=scroll2_price_to.text.toString()
        }
        if(frmmakeup=="makeup"){
            makeupitemstr="makeup service"
        }
        else if(frmmakeup.isEmpty()){
            makeupitemstr=""

        }

        //val desc = (descrip.text).toString()
        val status = (state.text.toString())
        val data = s(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess,
                cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp, ebns = paybonus, cry = currency,
                ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcat,mctgkey=mctgkeys,
                sctgkey=sctgkeys ,desc = des, fp = fix, fpr = from, tpr = to, status = status, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url,
                img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,retdate = retdatedup,makeupitem = makeupitemstr)
        //if ((did.text.toString()).isEmpty()) {

            val fix_check=intent.getBooleanExtra("fix_check",false).toString()
            val form_check=intent.getBooleanExtra("form_check",false).toString()
            if (fix_check.equals("true")){
                fixed_error="true"

            }

                if (from.isEmpty()) {
                    from_error="true"

                }
                if (to.isEmpty()){
                    to_error="true"

                }


        if (textInputLayout.editText!!.text.isEmpty() || price.text.isEmpty()) {
            if (textInputLayout.editText!!.text.isEmpty()) {
                sname_error.visibility = View.VISIBLE

            }
            if (price.text.isEmpty()) {
                price_error.visibility = View.VISIBLE

            }
            if (gender.isEmpty()){
                gen_error="true"
            }
            if (maincat.isEmpty()){
                main_error="true"
            }
            if (subcat.isEmpty()){
                sub_error="true"
            }
            Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()

        } else if (textInputLayout.editText!!.text.isNotEmpty() && price.text.isNotEmpty()) {



                        if (newid.text.isEmpty() && id.text.isNotEmpty()) {
                            save.isEnabled = false
                            save_progress.visibility = android.view.View.VISIBLE
                            val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax,
                                    intax, cess, Ctax, Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage,
                                    per, gender, maincat, subcat, des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n,
                                    img1url, img2url, img3url, img4url, img5url,img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                    img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,mctgkeys,sctgkeys,retdatedup,makeupitemstr)
                            if (isInserted == true){
                                Toast.makeText(this, "Data updated", Toast.LENGTH_SHORT).show()
                                save_progress.visibility = android.view.View.GONE}
                            else{
                                Toast.makeText(this, "Data not updated", Toast.LENGTH_SHORT).show()}
                            db = FirebaseFirestore.getInstance()
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .set(data)
                                    .addOnSuccessListener {
                                        Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                        save_progress.visibility = android.view.View.GONE
                                        pDialogs!!.dismiss()
                                        if(frmmakeup.isEmpty()) {
                                            val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                                            startActivity(t)
                                            finish()
                                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                        }
                                        else if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                                            val data = Intent(applicationContext,Main_makeup::class.java)

                                            // Add the required data to be returned to the MainActivity


                                            // Set the resultCode to Activity.RESULT_OK to
                                            // indicate a success and attach the Intent
                                            // which contains our result data
                                            setResult(Activity.RESULT_OK, data)

                                            // With finish() we close the AnotherActivity to
                                            // return to MainActivity
                                            finish()

                                            Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()



                                        }
                                        overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);
                                    }
                                    .addOnFailureListener {
                                        Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                        save_progress.visibility = android.view.View.GONE
                                    }
                        }
                    }else{
                        Toast.makeText(this, "please fill required fields", Toast.LENGTH_LONG).show()
                    }
    }



    fun save(){   //Save action
        if (fix.isEmpty()||from.isEmpty() || to.isEmpty()){
            val fix_check=intent.getBooleanExtra("fix_check",false).toString()
            val form_check=intent.getBooleanExtra("form_check",false).toString()
            if (fix_check.equals("true")){

            }
            if (form_check.equals("true")){
                if (from.isEmpty()) {

                }
                if (to.isEmpty()){

                }
            }
        }
        if ((sname.text.toString().isEmpty()|| price.text.isEmpty())) {
            if (sname.text.toString().isEmpty()) {
                sname_error.visibility = View.VISIBLE

            }
            if (price.text.isEmpty()) {
                price_error.visibility = View.VISIBLE

            }
            if (gender.isEmpty()){
                gen_error="true"
            }
            if (maincat.isEmpty()){
                main_error="true"
            }
            if (subcat.isEmpty()){
                sub_error="true"
            }

        } else if (sname.text.toString().isNotEmpty() && price.text.isNotEmpty()) {   //If service name and prie arenot empty

                        if ((newid.text.isNotEmpty() && id.text.isEmpty())&&(net_status()==true)) {
                            onStarClicked1()     //For new service insert
                        }
                     else if((id.text.toString().isNotEmpty())&&(net_status()==true)){
                            update()  //for existing service update

                    }
                 else{
                            Toast.makeText(this@ScrollActivity, "No Internet connection", Toast.LENGTH_LONG).show()

                        }

            }
        else {
                Toast.makeText(this@ScrollActivity, "please fill required fields!", Toast.LENGTH_LONG).show()
                println("fix.isNotEmpty()fix.isEmpty()" + fix)
            }
        }




    fun popup(st:String){   //Access Denined alert
        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Access Denied!")
                .setContentText("You dont have Access to $st")
                .setConfirmText("ok")
                .setConfirmClickListener(null)
                .show()
        /*val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()*/
    }
    fun poplow() {  //Preview prices from-to validation alert
        if(scroll2_price_from.text.toString().isNotEmpty()&&scroll2_price_to.text.toString().isNotEmpty()) {
            if ((scroll2_price_from.text.toString().toFloat() >= scroll2_price_to.text.toString().toFloat())) {
                val builder = AlertDialog.Builder(this@ScrollActivity)
                with(builder) {
                    setTitle("Price details not valid")
                    setMessage("Example: 500-1000")
                    setCancelable(false)
                    setPositiveButton("Ok") { dialog, state ->
                        dialog.dismiss()
                        scroll2_price_to.requestFocus()
                        scroll2_price_from.requestFocus()


                    }
                    val dialog = builder.create()
                    dialog.show()
                }


            }
        }

    }
    fun net_status():Boolean{ //checks net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    companion object {


        //Listens inetrnet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis:RelativeLayout?=null
        private var consermaindis: ConstraintLayout?=null

        private var firstreldis:RelativeLayout?=null
        private var secreldis:RelativeLayout?=null
        private var texreldis:RelativeLayout?=null
        private var inreldis:RelativeLayout?=null
        private var catreldis:RelativeLayout?=null
        private var desreldis:RelativeLayout?=null
        private var pricereldis:RelativeLayout?=null
        private var lastreldis:RelativeLayout?=null
        private var scrollView2dis:ScrollView?=null

        private var scroll2_gallerydis:ImageButton?=null

        private var editdis:ImageButton?=null
        private var constraintLayout3dis:ConstraintLayout?=null
        /*    private var relativeLayout2dis:RelativeLayout?=null

        private var lineardis:LinearLayout?=null
        private var cambackdis:ImageView?=null*/
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                //And some views will be disabled when net is off


                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                scroll2_gallerydis!!.isEnabled=false



               /* firstreldis
                secreldis!!.
                texreldis!!.
                inreldis!!.
                catreldis!!.
                desreldis!!.
                pricereldis!!.
                lastreldis!!.*/


                for (i  in 0 until consermaindis!!.getChildCount()) {
                    val child = consermaindis!!.getChildAt(i);
                    child.setEnabled(false);
                }









/*
                relativeLayout2dis!!.setBackgroundColor(Color.parseColor("#96ffffff"))

                lineardis!!.setBackgroundColor(Color.parseColor("#96ffffff"))
                cambackdis!!.setBackgroundColor(Color.parseColor("#96ffffff"))*/


                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }

            }
            else
            {
                                //And some views will be enabled when net is on


                constraintLayout3dis!!.visibility=View.GONE
                relativeslayoutdis!!.visibility=View.GONE


                scroll2_gallerydis!!.isEnabled=true


                    for (i  in 0 until consermaindis!!.getChildCount()) {
                        val child = consermaindis!!.getChildAt(i);
                        child.setEnabled(true);
                    }


                   /* for (i in 0 until consermaindis!!.getChildCount()) {
                        val child = consermaindis!!.getChildAt(i);
                        child.setEnabled(true);
                    }

                    for (i in 0 until firstreldis!!.getChildCount()) {
                        val child = firstreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }

                    for (i in 0 until secreldis!!.getChildCount()) {
                        val child = secreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                    for (i in 0 until texreldis!!.getChildCount()) {
                        val child = texreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }

                    for (i in 0 until inreldis!!.getChildCount()) {
                        val child = inreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                    for (i in 0 until catreldis!!.getChildCount()) {
                        val child = catreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                    for (i in 0 until desreldis!!.getChildCount()) {
                        val child = desreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                    for (i in 0 until pricereldis!!.getChildCount()) {
                        val child = pricereldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }
                    for (i in 0 until lastreldis!!.getChildCount()) {
                        val child = lastreldis!!.getChildAt(i);
                        child.setEnabled(true);
                    }*/


/*}
                relativeLayout2dis!!.setBackgroundColor(Color.parseColor("#eceff1"))

                lineardis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                cambackdis!!.setBackgroundColor(Color.parseColor("#263238"))*/
            }
        }
    }


}
