package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.print.PrintAttributes
import android.print.PrintManager
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter
import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_main_branch_pdf.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.spec.ECField
import java.util.*

@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

class MainBranchPdf : AppCompatActivity() {


    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""




    var orignm=String()


    var proiddelete= arrayListOf<String>()
    var quantitydelete= arrayListOf<String>()

    var htmlDocument= String()


    var names = String()
    var addressnames = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var smlistidss= String()
    var brkey= String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var receivear= String()
    var cgstt= String()
    var sgstt= String()
    var cesst= String()
    var grosstt= String()
    var downstatus= String()
    var ids=arrayOf<String>()
    var singrosstot= arrayOf<String>()

    var deletelistener= String()

    var stdatedup=String()
    var descripdup=String()
var grosschk=String()



    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var cgstArray = arrayListOf<String>()
    var sgstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var proidArray = arrayListOf<String>()
    var proidArraycpy=arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var quantityArraycpy=arrayListOf<String>()
    var tt=arrayListOf<String>()
    var orikys= String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null




    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
    private var myWebView: WebView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_branch_pdf)

        net_status()        //Check net status


        val webView = findViewById<WebView>(R.id.webviews) as WebView //Initaialize web view

        myWebView = webView//Assign web view globally


//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainBranchPdf) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


 //Define No connection view when inetrnet connection is off.
        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)


        //Transfer within state access
        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }





        val bundle = intent.extras
        var frm = bundle!!.get("from").toString()



        //Get details from stock transfer (Mainbranch_one)


        var a= bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy=bundle.get("phsn") as ArrayList<String>
        val ly=bundle.get("pmanu")    as ArrayList<String>
        val fy=bundle.get("barcode") as ArrayList<String>
        val gy=bundle.get("quan")  as ArrayList<String>
        val hy=bundle.get("price") as ArrayList<String>
        val ky=bundle.get("tot") as ArrayList<String>
        val my=bundle.get("cessup") as ArrayList<String>
        val ny=bundle.get("igst") as ArrayList<String>
        val oy=bundle.get("igsttotal") as ArrayList<String>
        val py=bundle.get("cesstotarray") as ArrayList<String>
        val iddd=bundle.get("idsofli") as ArrayList<String>
        val idtally=bundle.get("tallyarray") as ArrayList<String>
        val idrec=bundle.get("receivedarray") as ArrayList<String>
        val proidarr=bundle.get("proidarray") as ArrayList<String>
        val quancpy=bundle.get("quancpyarray") as ArrayList<String>
        val proidarrcpy=bundle.get("proidarraycpy") as ArrayList<String>




try {
    val prodel = bundle.get("proiddelete") as ArrayList<String>

    if (prodel.isNotEmpty() == true) {
        proiddelete = prodel
    } else {

    }

    val quandel = bundle.get("quantitydelete") as ArrayList<String>

    if (quandel.isNotEmpty() == true) {
        quantitydelete = prodel
    } else {

    }
}
catch (e:Exception){

}



        try{

            grosschk=intent.getStringExtra("grosschk")
            stdatedup=intent.getStringExtra("stdatedup")
            descripdup=intent.getStringExtra("descripdup")


        }
catch (e:Exception){

}




        deletelistener=intent.getStringExtra("deletelistener")



        try {
            val immy = bundle.get("image") as ArrayList<String>
            tt=immy
        }
        catch(e:Exception){

        }


      ids = bundle.get("ids") as Array<String>



        pronameArray = a
        hsnArray = dsy
        manufacturerArray = ly
        barcodeArray = fy
        quantityArray = gy
        priceArray = hy
        totArray = ky
        cessArray = my
        igstArray = ny
        igsttotArray = oy
        cesstotalArray = py
        keyArray = iddd
        tallyArray = idtally
        receivedArray = idrec
        proidArray=proidarr
        quantityArraycpy=quancpy
        proidArraycpy=proidarrcpy

        try {
            imageArray = tt
        } catch (e: Exception) {

        }

        try {
            val namebr = intent.getStringExtra("branch")

            names = namebr
            println("Names" + names)

            val locbr = intent.getStringExtra("address")
            addressnames = locbr

        }
        catch(e:Exception) {
            val locbr = intent.getStringExtra("address")
            addressnames = locbr

        }




        try{
            orignm=intent.getStringExtra("orignm")
        }
        catch (e:Exception){

        }


try {

    val kybrnch = intent.getStringExtra("keybrnch")
    brkey = kybrnch


    println("KEY OF branch"+brkey)


    val smlistid = intent.getStringExtra("smlistids")
    smlistidss = smlistid

    val oribrnky=intent.getStringExtra("originkeys")
    orikys=oribrnky

    val iddb = intent.getStringExtra("idofdb")
    iddbs = iddb
}
catch (e:Exception) {
    val smlistid = intent.getStringExtra("smlistids")
    smlistidss = smlistid

    val oribrnky=intent.getStringExtra("originkeys")
    orikys=oribrnky


    val iddb = intent.getStringExtra("idofdb")
    iddbs = iddb
}



       try {


           val stockid = intent.getStringExtra("ssstockid")
           idstk = stockid

           val grosst = intent.getStringExtra("gross")
           grosstt = grosst
           println("GROSS TOT"+grosstt)



           val cgst = intent.getStringExtra("cgsttot")
           cgstt = cgst
           val sgst = intent.getStringExtra("sgsttot")
           sgstt = sgst
           val cess = intent.getStringExtra("cesstot")
           cesst = cess
           val datest = intent.getStringExtra("sstkdate")
           datestk = datest
           val stockdesc = intent.getStringExtra("ssstkdesc")
           descstk = stockdesc

           println("address" + addressnames)
           println("ID" + idstk)

       }

       catch (e:Exception)
        {
            val datest = intent.getStringExtra("sstkdate")
            datestk = datest

            val stockdesc = intent.getStringExtra("ssstkdesc")
            descstk = stockdesc
        }




            //names

           /* if (names.isNotEmpty()) {
                branchnm.setText(names)
            } else {
                branchnm.setText("-")
            }


            //address

            if (addressnames.isNotEmpty()) {
                branchaddress.setText(addressnames)
            } else {
                branchaddress.setText("-")
            }


            //Gross tot
            if (grosstt.isNotEmpty()) {
                gross.setText(grosstt)
            } else {
                gross.setText("-")
            }

            //cgst

            if (cgstt.isNotEmpty()) {
                cgsttot.setText(cgstt)
            } else {
                cgsttot.setText("-")
            }

            //Date
            if (datestk.isNotEmpty()) {
                date.setText(datestk)
            } else {
                date.setText("-")
            }

            //sgst
            if (sgstt.isNotEmpty()) {
                sgsttot.setText(sgstt)
            } else {
                sgsttot.setText("-")
            }

            //stock id
            if (idstk.isNotEmpty()) {
                stno.setText(idstk)
            } else {
                stno.setText("-")
            }

            //description
            if (descstk.isNotEmpty()) {
                descrition.setText(descstk)
            } else {
                descrition.setText("-")
            }

            //cess
            if (cesst.isNotEmpty()) {
                cesstot.setText(cesst)
            } else {
                cesstot.setText("-")
            }*/




        addData();
        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView,
                                                  url: String): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                createWebPrintJob(view)
                myWebView = null
            }
        }



    /*pdf.setOnClickListener {

        //Create local path storage for this pdf

        val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

        val dir = File(path);
        if (!dir.exists())
            dir.mkdirs()

        var f = idstk + "_stock transfer"

        var y = f + ".pdf"

        val file = File(dir, y)

        if (file.exists()) {        //If file already exist alert


            val builder = AlertDialog.Builder(this)
            with(builder) {
                setTitle("File Already Exist")
                setMessage("Do you want to overwrite the existing file?")





                setPositiveButton("Yes") { dialog, whichButton ->//Overwrite the exist pdf




                    val dialo = SpotsDialog(context, "Downloading pdf...")

                    dialo.show();

                    createandDisplayPdf(idstk, datestk, names, addressnames,descstk, cgstt, sgstt, cesst, grosstt)  //Pdf write fiunction

                    val timer2 = Timer()
                    timer2.schedule(object : TimerTask() {
                        override fun run() {



                            if(downstatus=="success"){
                                val mBuilder = NotificationCompat.Builder(this@MainBranchPdf)
                                val intent = Intent(Intent.ACTION_GET_CONTENT)
                                val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                                intent.setDataAndType(uri, "application/pdf")       //Open pdf with pdf reader

                                val pendingIntent = PendingIntent.getActivity(this@MainBranchPdf, 0, intent, 0)
                                mBuilder.setContentIntent(pendingIntent)


                                val mNotifyManager = this@MainBranchPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;


                                //Notification alert

                                mBuilder.setContentTitle(idstk + "_stock transfer.pdf")
                                mBuilder.setContentText("Downloaded")
                                mBuilder.setSmallIcon(R.drawable.ic_logo)
                                mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                                mBuilder.setProgress(100, 100, false)
                                mNotifyManager.notify(0, mBuilder.build());
                            }

                            dialo.dismiss()

                            timer2.cancel() //this will cancel the timer of the system
                        }


                    }, 3000)

                    val handler = Handler()
                    handler.postDelayed({
                        println("INSIDE IF" + a)
                        if (file.exists()) {
                            val builder = AlertDialog.Builder(this@MainBranchPdf)
                            with(builder) {
                                setTitle("File downloaded")
                                setMessage("Do you want to open a file?")
                                setPositiveButton("Open") { dialog, whichButton ->
                                    var f = idstk + "_stock transfer"


                                    var y = f + ".pdf"
                                    viewPdf("Stock Transfer", y)
                                }
                                setNegativeButton("Cancel") { dialog, whichButton ->
                                    //showMessage("Close the game or anything!")
                                    dialog.dismiss()
                                }

                                // Dialog
                                val dialog = builder.create()

                                dialog.show()
                            }
                        } else {

                        }
                    }, 4000)

                }

                setNegativeButton("NO") { dialog, whichButton ->
                    //showMessage("Close the game or anything!")
                    dialog.dismiss()
                }

                // Dialog
                val dialog = builder.create()

                dialog.show()
            }


             val u = findViewById<ScrollView>(R.id.ss) as ScrollView
        val zx=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView
        val yx=findViewById<RelativeLayout>(R.id.relative) as RelativeLayout
        val cx=findViewById<TableLayout>(R.id.table) as TableLayout

        val totalHeight = cx.height+u.height
        val totalWidth = cx.width+u.width

        val b = getBitmapFromView(yx, totalHeight, totalWidth)
          val share = Intent(Intent.ACTION_SEND)
              share.type = "image/jpeg"
            val bytes = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

            val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            try {
                f.createNewFile()
                val fo = FileOutputStream(f)
                fo.write(bytes.toByteArray())
                imageToPDF()

            } catch (e: IOException) {
                e.printStackTrace()
            }


        } else {

            val dialo = SpotsDialog(this, "Downloading pdf...")

            dialo.show();

            createandDisplayPdf(idstk, datestk, names, addressnames,descstk, cgstt, sgstt, cesst, grosstt)//Pdf write fiunction

            val timer2 = Timer()
            timer2.schedule(object : TimerTask() {
                override fun run() {

                    if(downstatus=="success"){
                        val mBuilder = NotificationCompat.Builder(this@MainBranchPdf)
                        val intent = Intent(Intent.ACTION_GET_CONTENT)
                        val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                        intent.setDataAndType(uri, "application/pdf")    //Open pdf with pdf reader

                        val pendingIntent = PendingIntent.getActivity(this@MainBranchPdf, 0, intent, 0)
                        mBuilder.setContentIntent(pendingIntent)


                        val mNotifyManager = this@MainBranchPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;


 //Notification alert
                        mBuilder.setContentTitle(idstk + "_stock transfer.pdf")
                        mBuilder.setContentText("Downloaded")
                        mBuilder.setSmallIcon(R.drawable.ic_logo)
                        mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                        mBuilder.setProgress(100, 100, false)
                        mNotifyManager.notify(0, mBuilder.build());
                    }

                    dialo.dismiss()
                    var b = "null"

                    timer2.cancel() //this will cancel the timer of the system
                }


            }, 3000)

            val handler = Handler()
            handler.postDelayed({
                println("INSIDE IF" + a)
                if (file.exists()) {
                    val builder = AlertDialog.Builder(this@MainBranchPdf)
                    with(builder) {
                        setTitle("File downloaded")
                        setMessage("Do you want to open a file?")
                        setPositiveButton("Open") { dialog, whichButton ->

                            var f = idstk + "_stock transfer"


                            var y = f + ".pdf"
                            viewPdf("Stock Transfer", y)
                        }
                        setNegativeButton("Cancel") { dialog, whichButton ->
                            //showMessage("Close the game or anything!")
                            dialog.dismiss()
                        }

                        // Dialog
                        val dialog = builder.create()

                        dialog.show()
                    }
                } else {

                }

            }, 4000)
        }
    }*/
        back.setOnClickListener{
           //Back action

            val o=Intent(this@MainBranchPdf,Mainstk_branch_one::class.java)

            o.putExtra("renm",a)
            o.putExtra("from","frm_pdf")
            o.putExtra("remanu",ly)
            o.putExtra("rekey",iddd)
            o.putExtra("rehsn",dsy)
            o.putExtra("reprice",hy)
            o.putExtra("requan",gy)
            o.putExtra("rebc",fy)
            o.putExtra("retotal",ky)
            o.putExtra("recess",my)
            o.putExtra("reigst",ny)
            o.putExtra("retally",idtally)
            o.putExtra("rereceived",idrec)
            o.putExtra("reigst_total",oy)
            o.putExtra("recesstotal",py)
            o.putExtra("reproids",proidarr)
            o.putExtra("reproidscpy",proidarrcpy)
            o.putExtra("requancpy",quancpy)

            o.putExtra("stdatedup", stdatedup)
            o.putExtra("descripdup", descripdup)

            o.putExtra("proiddelete",proiddelete)
            o.putExtra("quantitydelete",quantitydelete)

            o.putExtra("reimmg",tt)
            o.putExtra("branch",names)
            o.putExtra("address",addressnames)
            o.putExtra("redate",datestk)
            o.putExtra("redesc",descstk)
            o.putExtra("restkid",idstk)
            o.putExtra("reiddb",iddbs)
            o.putExtra("smlistidss",smlistidss)
            o.putExtra("brnchky",brkey)
            o.putExtra("oribrnky",orikys)
            o.putExtra("reiddofli",idli)
o.putExtra("grosschk",grosschk)

            o.putExtra("deletelistener",deletelistener)



            o.putExtra("orignm",orignm)










            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


           o.putExtra("viewtransano", viewtransano)
           o.putExtra("addtransano", addtransano)
           o.putExtra("edittransano", editetransano)
           o.putExtra("deletetransano", deletetransano)
           o.putExtra("transfertransano", transfertransano)
           o.putExtra("exporttransano", exporttransano)
           o.putExtra("sendtransano", sendtransano)

           o.putExtra("viewrec", viewrec)
           o.putExtra("addrec", addrec)
           o.putExtra("deleterec", deleterec)
           o.putExtra("editrec", editrec)
           o.putExtra("transferrec", transferrec)
           o.putExtra("exportrec", exportrec)
           o.putExtra("sendstrec",sendstrec)

            o.putExtra("gross",grosstt)
            o.putExtra("cgsttot",cgstt)
            o.putExtra("sgsttot",sgstt)
            o.putExtra("cesstot",cesst)











            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
}


    override fun onBackPressed() {


        val bundle = intent.extras
        var frm = bundle!!.get("from").toString()

        var a= bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<StListring>*/

        val dsy=bundle.get("phsn") as ArrayList<String>
        val ly=bundle.get("pmanu")    as ArrayList<String>
        val fy=bundle.get("barcode") as ArrayList<String>
        val gy=bundle.get("quan")  as ArrayList<String>
        val hy=bundle.get("price") as ArrayList<String>
        val ky=bundle.get("tot") as ArrayList<String>
        val my=bundle.get("cessup") as ArrayList<String>
        val ny=bundle.get("igst") as ArrayList<String>
        val oy=bundle.get("igsttotal") as ArrayList<String>
        val py=bundle.get("cesstotarray") as ArrayList<String>
        val iddd=bundle.get("idsofli") as ArrayList<String>
        val idtally=bundle.get("tallyarray") as ArrayList<String>
        val idrec=bundle.get("receivedarray") as ArrayList<String>
        val prids=bundle.get("proidarray") as ArrayList<String>
        val quancpy=bundle.get("quancpyarray") as ArrayList<String>
        val proidarrcpy=bundle.get("proidarraycpy") as ArrayList<String>




        try {
            val prodel = bundle.get("proiddelete") as ArrayList<String>

            if (prodel.isNotEmpty() == true) {
                proiddelete = prodel
            } else {

            }

            val quandel = bundle.get("quantitydelete") as ArrayList<String>

            if (quandel.isNotEmpty() == true) {
                quantitydelete = prodel
            } else {

            }
        }
        catch (e:Exception){

        }

        try {
            val immy = bundle.get("image") as ArrayList<String>
            tt=immy
        }
        catch(e:Exception){

        }

        pronameArray = a
        hsnArray = dsy
        manufacturerArray = ly
        barcodeArray = fy
        quantityArray = gy
        priceArray = hy
        totArray = ky
        cessArray = my
        igstArray = ny
        igsttotArray = oy
        cesstotalArray = py
        keyArray = iddd
        tallyArray = idtally
        receivedArray = idrec
        proidArray=prids
        proidArraycpy=proidarrcpy
        try {
            imageArray = tt
        } catch (e: Exception) {

        }

        try {
            val namebr = intent.getStringExtra("branch")

            names = namebr
            println("Names" + names)

            val locbr = intent.getStringExtra("address")
            addressnames = locbr

        }
        catch(e:Exception) {
            val locbr = intent.getStringExtra("address")
            addressnames = locbr

        }



        try
        {
            grosschk=intent.getStringExtra("grosschk")

            stdatedup=intent.getStringExtra("stdatedup")
            descripdup=intent.getStringExtra("descripdup")
        }
        catch (e:Exception){

        }

        try{
            orignm=intent.getStringExtra("orignm")
        }
        catch (e:Exception){

        }




        try {

            val kybrnch = intent.getStringExtra("keybrnch")
            brkey = kybrnch


            val smlistid = intent.getStringExtra("smlistids")
            smlistidss = smlistid

            val oribrnky=intent.getStringExtra("originkeys")
            orikys=oribrnky

            val iddb = intent.getStringExtra("idofdb")
            iddbs = iddb
        }
        catch (e:Exception) {
            val smlistid = intent.getStringExtra("smlistids")
            smlistidss = smlistid

            val oribrnky=intent.getStringExtra("originkeys")
            orikys=oribrnky


            val iddb = intent.getStringExtra("idofdb")
            iddbs = iddb
        }



        try {


            val stockid = intent.getStringExtra("ssstockid")
            idstk = stockid

            val grosst = intent.getStringExtra("gross")
            grosstt = grosst
            println("GROSS TOT"+grosstt)



            val cgst = intent.getStringExtra("cgsttot")
            cgstt = cgst
            val sgst = intent.getStringExtra("sgsttot ")
            sgstt = sgst
            val cess = intent.getStringExtra("cesstot")
            cesst = cess
            val datest = intent.getStringExtra("sstkdate")
            datestk = datest
            val stockdesc = intent.getStringExtra("ssstkdesc")
            descstk = stockdesc

            println("address" + addressnames)
            println("ID" + idstk)

        }

        catch (e:Exception)
        {
            val datest = intent.getStringExtra("sstkdate")
            datestk = datest

            val stockdesc = intent.getStringExtra("ssstkdesc")
            descstk = stockdesc
        }

        val o=Intent(this@MainBranchPdf,Mainstk_branch_one::class.java)

        o.putExtra("renm",a)
        o.putExtra("from","frm_pdf")
        o.putExtra("remanu",ly)
        o.putExtra("rekey",iddd)
        o.putExtra("rehsn",dsy)
        o.putExtra("reprice",hy)
        o.putExtra("requan",gy)
        o.putExtra("rebc",fy)
        o.putExtra("retotal",ky)
        o.putExtra("recess",my)
        o.putExtra("reigst",ny)
        o.putExtra("retally",idtally)
        o.putExtra("rereceived",idrec)
        o.putExtra("reproids",prids)
        o.putExtra("reproidscpy",proidarrcpy)
        o.putExtra("requancpy",quancpy)


        o.putExtra("proiddelete",proiddelete)
        o.putExtra("quantitydelete",quantitydelete)

        o.putExtra("reigst_total",oy)
        o.putExtra("recesstotal",py)
        o.putExtra("reimmg",tt)
        o.putExtra("branch",names)
        o.putExtra("address",addressnames)
        o.putExtra("redate",datestk)
        o.putExtra("redesc",descstk)
        o.putExtra("restkid",idstk)
        o.putExtra("reiddb",iddbs)
        o.putExtra("smlistidss",smlistidss)
        o.putExtra("brnchky",brkey)
        o.putExtra("oribrnky",orikys)
        o.putExtra("reiddofli",idli)

        o.putExtra("deletelistener",deletelistener)

o.putExtra("grosschk",grosschk)
        o.putExtra("orignm",orignm)

        o.putExtra("stdatedup", stdatedup)

        o.putExtra("descripdup", descripdup)

        o.putExtra("gross",grosstt)
        o.putExtra("cgsttot",cgstt)
        o.putExtra("sgsttot",sgstt)
        o.putExtra("cesstot",cesst)





        o.putExtra("viewtrans", viewtrans)
        o.putExtra("addtrans", addtrans)
        o.putExtra("edittrans", editetrans)
        o.putExtra("deletetrans", deletetrans)
        o.putExtra("transfertrans", transfertrans)
        o.putExtra("exporttrans", exporttrans)
        o.putExtra("sendtrans", sendtrans)


        o.putExtra("viewtransano", viewtransano)
        o.putExtra("addtransano", addtransano)
        o.putExtra("edittransano", editetransano)
        o.putExtra("deletetransano", deletetransano)
        o.putExtra("transfertransano", transfertransano)
        o.putExtra("exporttransano", exporttransano)
        o.putExtra("sendtransano", sendtransano)

        o.putExtra("viewrec", viewrec)
        o.putExtra("addrec", addrec)
        o.putExtra("deleterec", deleterec)
        o.putExtra("editrec", editrec)
        o.putExtra("transferrec", transferrec)
        o.putExtra("exportrec", exportrec)
        o.putExtra("sendstrec",sendstrec)



        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()

    }










    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {  //Document's fonts and design

        val tv = TextView(this)
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()

        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {          //Table row layout design
        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {                  //TAble headers

        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)
        tr.layoutParams = getLayoutParams()

        tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tl.addView(tr, getTblLayoutParams())
    }

    var ee=0.0F
    var cc=0.0F
    var gros=0.0F
    var ig=0.0F
    var cg=0.0F
    var sg=0.0F
    var ces=0.0F

    fun addData() { //Fill datas on table








        htmlDocument = "<html><body><h3>Vinitas Enterprises Pvt Ltd</h3><h4>" + "Stock Transfer</h4>" +
                "<p>ST No:                $idstk <p/>" +
                "<p>Date:                 $datestk  <p/>" +
                "<p>Description:                 $descstk  <p/>" +

                "<p>Branch Name: $names  <p/> "+
                "<p>Branch Phone: $addressnames  <p/> "+
                "<p></p>"+

                /* "<h5>Purchase Details</h5>"+

                 "<p>Requestor name:          $reqnm <p/>" +
                 "<p>Requestor phone:       $reqph  <p/> "+
                 "<p>Requestor Email:          $reqmail  <p/> "+
                 "<p>Estimated date: $restimt  <p/> "+
                 "<p></p>"+*/




                "<style>"+
                "table, th, td {"+
                "border: 1px solid black;"+
                "border-collapse: collapse;"+
                "}"+
                "th, td {"+
                "padding: 15px;"+
                "}"+
                "th {"+
                "text-align: left;"+
                "}"+
                "td.Hidden {"+
                "visibility: hidden;"+
                "}"+
                "</style>"+
                "<h4>" + "Product Details</h4>"+
                "<table style=\"width:100%\">"+
                "<tr>"+







                "<th>S.No</th>"+
                "<th>Product name</th>"+
                "<th>HSN/SAC Code</th>"+

                "<th>Price</th>"+
                "<th>Quantity</th>"+
                "<th>Tax</th>"+
                "<th>Total</th>"+
                "</tr>"


        val tl = findViewById<TableLayout>(R.id.table)
        for (i in 0 until priceArray.size) {
            val tr = TableRow(this)
            tr.layoutParams = getLayoutParams()
            var pri=priceArray[i].toFloat()
            var quan=quantityArray[i].toFloat()
            var e=igsttotArray[i].toFloat()
            var f=cesstotalArray[i].toFloat()

            var jj=e+f

            var grtt=jj
            var grflo=grtt
            var gttt=grflo+(pri*quan)

            var grossrealtot=gttt+gros

            singrosstot=singrosstot.plusElement(grossrealtot.toString())




            htmlDocument=htmlDocument+
                    "<tr>"+
                    "<td>${i+1}</td>"+
                    "<td>${pronameArray[i]}</td>"+
                    "<td>${hsnArray[i]}</td>"+
                    "<td>${priceArray[i]}</td>"+
                    "<td>${quantityArray[i]}</td>"+
                    "<td>$grtt</td>"+
                    "<td>$gttt</td>"+
                    "</tr>"

            if(priceArray.size==i){

            }

/*





            tr.addView(getTextView(i + 1, (i+1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr, getTblLayoutParams())*/
        }


        htmlDocument=htmlDocument+

                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>CGST TOTAL:</td>"+
                "<td>$cgstt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>SGST TOTAL:</td>"+
                "<td>$sgstt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>Cess TOTAL:</td>"+
                "<td>$cesst</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td> Gross TOTAL:</td>"+
                "<td>$grosstt</td>"+

                "</tr>"+"</body></html>"


        myWebView!!.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)


        /*val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2= TableRow(this)
        val trval3= TableRow(this)
        val trval4= TableRow(this)
        val trval5= TableRow(this)
        val trval6= TableRow(this)



        tr2.layoutParams = getLayoutParams()

        trval3.addView(getTextView( 0,cgstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval4.addView(getTextView( 0,sgstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView( 0,cesst, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView( 0,grosstt,ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        //tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr3.addView(getTextView( 1,"CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr4.addView(getTextView( 1,"SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView( 1,"Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView( 1,"Gross TOTAL:",ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        //t2.addView(tr2, getTblLayoutParams())
        t2.addView(tr3, getTblLayoutParams())
        t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        //t3.addView(trval2, getTblLayoutParams())
        t3.addView(trval3, getTblLayoutParams())
        t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())*/
    }

    /*override fun onClick(v: View)
    {
        val id = v.id
        val tv = findViewById<TextView>(id)
        if (null != tv) {
            Log.i("onClick", "Clicked on row :: " + id)
            Toast.makeText(this, "Clicked on row :: " + id + ", Text :: " + tv.text, Toast.LENGTH_SHORT).show()
        }
    }*/


    //Create,write,export pdf

    /*fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqphone:String,reqestidate:String,cgsttotal:String, sgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()
            var f = idstk + "_stock transfer"

            var y = f + ".pdf"

            val file = File(dir, y)
            val fOut = FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b = Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizeheading, b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizesubheading, b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSize);
            val h1 = Paragraph("Vinitas Enterprises Pvt Ltd", fontheading)
            val hs1 = Paragraph("Stock Transfer", fontsubheading)

            val a1 = Paragraph("Branch Name:             " + reqname, font)
            val b1 = Paragraph("Branch Address:           " + reqphone, font)
            val c1 = Paragraph("ST No:                        " + id, font)
            val d1 = Paragraph("Date:                          " + requestdt, font)
            val e1 = Paragraph("Description:                    " + reqestidate, font)
            val p13 = Paragraph("CGST Total:                  " + cgsttotal, font)
            val p14 = Paragraph("SGST Total:                  " + sgsttotal, font)
            val p15 = Paragraph("CESS Total:                  " + cesstotal, font)
            val p7 = Paragraph("Gross Total:                 " + grosstot, font)
            val p8 = Paragraph("Product Details", fontsubheading)

            val pnm = Paragraph("Product Name")
            val pri = Paragraph("Price")

            val table = PdfPTable(floatArrayOf(2F, 6F, 5F, 5F, 4F, 6F, 4F));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for (j in 0 until cells.size) {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee = 0.0F
            var cc = 0.0F
            var ig = 0.0F
            var cg = 0.0F
            var sg = 0.0F
            var ces = 0.0F

            for (i in 0 until priceArray.size) {


                var pri = priceArray[i].toFloat()
                var quan = quantityArray[i].toFloat()
                var e = igsttotArray[i].toFloat()
                var f = cesstotalArray[i].toFloat()



                    var jj = e + f

                    var grtt = jj
                    var grflo = grtt
                    var gttt = grflo + (pri * quan)

                    var grossrealtot = gttt + gros



                    table.addCell((i + 1).toString())
                    table.addCell(pronameArray[i])
                    table.addCell(hsnArray[i])
                    table.addCell(priceArray[i])

                    table.addCell(quantityArray[i])
                    table.addCell(grtt.toString())

                    table.addCell(gttt.toString())
                }
                table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")


                *//* table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igstto)*//*

                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("CGST Total")
                table.addCell(cgstt)

                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("SGST Total")
                table.addCell(sgstt)

                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("Cess Total")
                table.addCell(cesst)

                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("GrossTotal")
                table.addCell(grosstt)

                *//*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*//*


                //add paragraph to document
                doc.add(h1)
                doc.add(Chunk.NEWLINE);
                doc.add(hs1)


                doc.add(Chunk.NEWLINE);
                doc.add(c1)
                doc.add(Chunk.NEWLINE);
                doc.add(d1)
                doc.add(Chunk.NEWLINE);
                doc.add(e1)
                doc.add(Chunk.NEWLINE);
                doc.add(a1)
                doc.add(Chunk.NEWLINE);
                doc.add(b1)
                doc.add(Chunk.NEWLINE);
                *//*doc.add( Chunk.NEWLINE );
            doc.add(p13)
            doc.add( Chunk.NEWLINE );
            doc.add(p14)
            doc.add( Chunk.NEWLINE );
            doc.add(p15)
            doc.add( Chunk.NEWLINE );
            doc.add(p7)*//*



                doc.add(Chunk.NEWLINE);
                doc.add(table)

                downstatus = "success"


            } catch (de: DocumentException) {
                downstatus = "not"
            } catch (e: IOException) {
                Log.e("PDFCreator", "ioException:" + e)
            }
            finally {
                doc.close()
            }



    }*/
    companion object {

        //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

               /// if connection is off then all views becomes disable
                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

                /// if connection is off then all views becomes enabled


                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
    /*fun viewPdf(folder:String,file:String) {  //Open created pdf document from local storage using pdf reader.
        try {




            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + folder,file)
            println("SD CARD URL" + pdfFile)
            val path = Uri.fromFile(pdfFile)

            // Setting the intent for pdf reader
            val pdfIntent = Intent(Intent.ACTION_VIEW)
            pdfIntent.setDataAndType(path,"application/pdf")
            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

            try {
                startActivity(pdfIntent);
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }


        }

        catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW)
            val k = folder.replace("%20", "")
            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + folder + "/" + file
            println("PATH"+path)
            val targetFile = File(path)
            println("TARGET PATH"+targetFile)
            val targetUri = Uri.fromFile(targetFile)


            try {
                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider",targetFile)
                println("URI"+photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(photoURI, "application/pdf")
                startActivity(intent);
                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }

        }

    }*/


    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createWebPrintJob(webView: WebView) {

        val printManager = this
                .getSystemService(Context.PRINT_SERVICE) as PrintManager

        val printAdapter = webView.createPrintDocumentAdapter("MyDocument")

        val jobName = getString(R.string.app_name) + " Print Test"

        printManager.print(jobName, printAdapter,
                PrintAttributes.Builder().build())
    }

    fun net_status():Boolean{//Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}


