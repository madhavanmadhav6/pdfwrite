package com.example.vinitas.inventory_app

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.vinitas.inventory_app.R
import de.hdodenhof.circleimageview.CircleImageView
import java.net.URI
import java.net.URL

/**
 * Created by vinitas stock on 18-01-2018.
 */
class listAdapter(private val context: Activity,    //Adapter for product,manufacturer,units categories lists.
                  private val category: ArrayList<String>,

                  private val d: ArrayList<String>) : ArrayAdapter<Any>(context, R.layout.list_style_products,category as List<Any>?) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.list_style_products, null, true)
        val cat = rowView.findViewById<TextView>(R.id.cat_list_name) as TextView
        val id = rowView.findViewById<TextView>(R.id.cat_list_id) as TextView

        val imagename = rowView.findViewById<TextView>(R.id.image_name) as TextView
        cat.text = category[position]
        id.text = d[position]

        return rowView
    }
}