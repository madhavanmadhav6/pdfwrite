package com.example.vinitas.inventory_app

import android.app.Activity
import android.content.*
import android.support.v4.app.Fragment


import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog

import com.example.vinitas.inventory_app.R
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.opencsv.CSVWriter



import kotlinx.android.synthetic.main.fragment_list.*



import java.io.*
import java.util.*
import kotlin.collections.ArrayList





class SupplierSecondmain :AppCompatActivity() {

    var aps = arrayOf<String>()
    var kys = arrayOf<String>()
    var radioGroup1: RadioGroup? = null
    var deals: RadioButton? = null

    var prosavesingleky=""
    private val REQUEST_CODE_EXAMPLE = 2
    private val REQUEST_CODE_EXAMPLE2 = 21
    private val REQUEST_CODE_EXAMPLE3 = 22
    private val REQUEST_CODE_EXAMPLE1 = 23


    var frmadd=String()

    private var viewpro = String()
    private var addpro = String()
    private var deletepro = String()
    private var editpro = String()
    private var importpro = String()
    private var exportpro = String()
    private var  stockin_hand= String()

    var img1urlhigh:String=""
    var img2urlhigh:String=""
    var img3urlhigh:String=""
    var img4urlhigh:String=""
    var img5urlhigh:String=""
    //image name's
    var img1nhigh:String=""
    var img2nhigh:String=""
    var img3nhigh:String=""
    var img4nhigh:String=""
    var img5nhigh:String=""

    //image url's
    var f1edit:String=""
    var s1edit:String=""
    var t1edit:String=""
    var fo1edit:String=""
    var fif1edit:String=""
    //image name's
    var fn1edit:String=""
    var sn1edit:String=""
    var tn1edit:String=""
    var fon1edit:String=""
    var fifn1edit:String=""

    var service_access:SessionManagement?=null
    var user= HashMap<String,String>()
    var f1edithigh:String=""
    var s1edithigh:String=""
    var t1edithigh:String=""
    var fo1edithigh:String=""
    var fif1edithigh:String=""
    //image name's
    var fn1edithigh:String=""
    var sn1edithigh:String=""
    var tn1edithigh:String=""
    var fon1edithigh:String=""
    var fifn1edithigh:String=""


    var suppnamevalidate= String()
    var suppmobcat1validate= String()
    var suppmobcat2validate= String()
    var suppmobcat3validate= String()
    var suppaddress1validate= String()
    var suppmobilevalidate= String()
    var suppmobile21validate= String()
    var suppmobile31validate= String()
    var suppmobile41validate= String()
    var suppaddress2validate= String()
    var suppaddress3validate= String()
    var suppcityvalidate= String()
    var suppstatevalidate= String()
    var supppinvalidate= String()
    var contactprsvalidate= String()
    var prodkyvalidate= String()
    var gpsvalidate= String()
    var suppemailvalidate= String()
    var suppgstvalidate= String()
    var file_maps = arrayListOf<String>()
    var mresultsarr= arrayListOf<String>()





    var startlistprokey= String()
    var productprokey= String()
    val TAG = "FragmentOne"
    var db = FirebaseFirestore.getInstance()

    var supd=String()

    var listenerssave= String()
    var f1=String()
    var s1=String()
    var t1=String()
    var fo1=String()
    var fif1=String()
    //image name's
    var fn1=String()
    var sn1=String()
    var tn1=String()
    var fon1=String()
    var fifn1=String()


    var f1sup = String()
    var s1sup = String()
    var t1sup = String()
    var fo1sup = String()
    var fif1sup = String()
    //image name's
    var fn1sup = String()
    var sn1sup = String()
    var tn1sup = String()
    var fon1sup = String()
    var fifn1sup = String()


    var esc= String()
    var upstr= String()
    var numberstr= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
var editcli= String()

    var delepros=ArrayList<String>()
    var editclipro= String()
    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()


    //Suppproduts access
var savelistnr= String()
    var fieldlistener= String()
    private var addsupppro: String=""
    private var editesupppro:String=""
    private var deletesupppro:String=""
    private var viewsupppro:String=""
    private var importsupppro:String=""
    private var exportsupppro:String=""


    var idpArraydup=arrayOf<String>()
    var nameArraydup=arrayOf<String>()
    var sunbnmArraydup=arrayOf<String>()
    var bcArraydup=arrayOf<String>()
    var sohArraydup=arrayOf<String>()
    var mlArraydup=arrayOf<String>()
    var mhArraydup=arrayOf<String>()
    var priceArraydup=arrayOf<String>()
    var disproArraydup=arrayOf<String>()
    var primgArraydup=arrayOf<String>()
    var icohighArraydup = arrayOf<String>()
    var icohighnmArraydup = arrayOf<String>()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    val REQUESTCODE_PICK_VIDEO:Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_list)
        var sd= String()
        var x= String()
        var reg= String()


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SupplierSecondmain) > 0)
        {

        }
        else{

        }

        //Define No connection view and other views when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        bottonNavBardis=findViewById(R.id.bottonNavBar)
        cont=findViewById<ConstraintLayout>(R.id.constrain)

        payment_tk_PGdis=findViewById<LinearLayout>(R.id.payment_tk_PG)


        addLogText(NetworkUtil.getConnectivityStatusString(this@SupplierSecondmain))

        net_status()    //Check net status



        imageButtonsrch.setOnClickListener {   //Image button search  action

            cardsearch.visibility=View.VISIBLE
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@SupplierSecondmain,R.anim.slide_to_right))
        }


        supp_edit.setOnClickListener {


            editcli="clicked"
            supp_edit.visibility=View.GONE
            imageButtonsrch.visibility=View.VISIBLE
            imageButtonvert.visibility=View.VISIBLE
            sadd_fab.visibility=View.VISIBLE
            supp_prod_list.isClickable=true

            val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArraydup, disproArraydup,
                    nameArraydup, sunbnmArraydup, bcArraydup, sohArraydup, priceArraydup, mhArraydup, mlArraydup,
                    primgArraydup,icohighnmArraydup,icohighArraydup)
            supp_prod_list.adapter = whatever


        }






        userback.setOnClickListener {
           onBackPressed()
        }


        val proky = intent.extras
        val i=proky.getString("sndproky")



        //Comes from 'SupplieAddmain'

        if(i=="fromsupplier") {
            /* val id= intent.getStringExtra("id").toString()
        println(id)*/
            val sup_name = intent.getStringExtra("supp_name")
            val sup_id = intent.getStringExtra("supp_id")
            val sup_cont = intent.getStringExtra("supp_cont")
            val sup_mob = intent.getStringExtra("mob")
            val sup_mob1 = intent.getStringExtra("mob1")
            val sup_mob2 = intent.getStringExtra("mob2")
            val sup_mobile = intent.getStringExtra("mobile")
            val sup_mobile1 = intent.getStringExtra("mobile1")
            val sup_mobile2 = intent.getStringExtra("mobile2")
            val sup_addr = intent.getStringExtra("supp_address")
            val sup_addr1 = intent.getStringExtra("supp_address1")
            val sup_addr2 = intent.getStringExtra("supp_address2")
            val sup_city = intent.getStringExtra("supp_city")
            val sup_state = intent.getStringExtra("supp_state")
            val sup_pin = intent.getStringExtra("supp_pin")
            val sup_gps = intent.getStringExtra("supp_gps")
            val sup_mail = intent.getStringExtra("supp_mail")
            val sup_gstcd = intent.getStringExtra("supp_gstcd")
            val sup_imgurl = intent.getStringExtra("supp_imurl")
            val sup_status = intent.getStringExtra("supp_status")
            val ids = intent.getStringExtra("s_id")
            val key = intent.getStringExtra("supp_key")
            val prosavekey = intent.getStringExtra("supprod_key")
            val liiss=intent.getStringExtra("listener")
            savelistnr=liiss
            val fieldliiss=intent.getStringExtra("fieldlistener")
            fieldlistener=fieldliiss
            editcli=intent.getStringExtra("editcli")


            try{

                img1urlhigh=intent.getStringExtra("img1urlhigh")
                img2urlhigh=intent.getStringExtra("img2urlhigh")
                img3urlhigh=intent.getStringExtra("img3urlhigh")
                img4urlhigh=intent.getStringExtra("img4urlhigh")
                img5urlhigh=intent.getStringExtra("img5urlhigh")
                //image name's
              img1nhigh=intent.getStringExtra("img1nhigh")
              img2nhigh=intent.getStringExtra("img2nhigh")
              img3nhigh=intent.getStringExtra("img3nhigh")
              img4nhigh=intent.getStringExtra("img4nhigh")
              img5nhigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1edit=intent.getStringExtra("f1edit")
                s1edit=intent.getStringExtra("s1edit")
                t1edit=intent.getStringExtra("t1edit")
                fo1edit=intent.getStringExtra("fo1edit")
                fif1edit=intent.getStringExtra("fif1edit")
                //image name's
                fn1edit=intent.getStringExtra("fn1edit")
                sn1edit=intent.getStringExtra("sn1edit")
                tn1edit=intent.getStringExtra("tn1edit")
                fon1edit=intent.getStringExtra("fon1edit")
                fifn1edit=intent.getStringExtra("fifn1edit")


                f1edithigh=intent.getStringExtra("f1edithigh")
                s1edithigh=intent.getStringExtra("s1edithigh")
                t1edithigh=intent.getStringExtra("t1edithigh")
                fo1edithigh=intent.getStringExtra("fo1edithigh")
                fif1edithigh=intent.getStringExtra("fif1edithigh")
                //image name's
              fn1edithigh=intent.getStringExtra("fn1edithigh")
              sn1edithigh=intent.getStringExtra("sn1edithigh")
              tn1edithigh=intent.getStringExtra("tn1edithigh")
              fon1edithigh=intent.getStringExtra("fon1edithigh")
              fifn1edithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                 mresultsarr=intent.getStringArrayListExtra("mresultsarr")

            }
            catch (e:Exception){

            }




try {
    startlistprokey = intent.getStringExtra("startlistprky")
    productprokey = intent.getStringExtra("profrmprky")
}
catch (e:Exception){

}




            if((editcli.isEmpty()==true)&&(sup_id!="Auto - generated"))
            {
                imageButtonsrch.visibility=View.GONE
                imageButtonvert.visibility=View.GONE
                supp_edit.visibility=View.VISIBLE
                sadd_fab.visibility=View.INVISIBLE
                supp_prod_list.isClickable=false


            }



            val ad = intent.getStringExtra("addsupp")
            val ed = intent.getStringExtra("editesupp")
            val vie= intent.getStringExtra("viewsupp")
            val dele = intent.getStringExtra("deletesupp")
            val imp = intent.getStringExtra("importsupp")
            val expo = intent.getStringExtra("exportsupp")


            if (ad != null) {
                addsupppro = ad

                println("ADD PERMISSION"+addsupppro)
            }
            if (ed != null) {
                editesupppro = ed
            }
            if (dele != null) {
                deletesupppro = dele
            }
            if (vie != null) {
                viewsupppro = vie
            }
            if (imp != null) {
                importsupppro = imp
            }
            if (expo != null) {
                exportsupppro = expo
            }









            val f = intent.getStringExtra("f")
            val s = intent.getStringExtra("s")
            val t = intent.getStringExtra("t")
            val fo = intent.getStringExtra("fo")
            val fif = intent.getStringExtra("fif")

            //image name's

            val fn = intent.getStringExtra("fn")
            val sn = intent.getStringExtra("sn")
            val tn = intent.getStringExtra("tn")
            val fon = intent.getStringExtra("fon")
            val fifn = intent.getStringExtra("fifn")






            f1sup=f
            s1sup=s
            t1sup= t
            fo1sup=fo
            fif1sup=fif
            fn1sup= fn
            sn1sup=sn
            tn1sup=tn
            fon1sup=fon
            fifn1sup=fifn


            println("LNK"+f1sup)


            println(sup_name)
            println(key)

            textView1.setText(sup_name)


            textView22.setText(sup_id)
            println(sup_id)
            println(ids)
            textView33.setText(sup_cont)


            textView4.setText(sup_mob.toString())


            textView5.setText(sup_mob1.toString())


            textView6.setText(sup_mob2.toString())


            textView7.setText(sup_mobile)


            println(sup_mobile)
            textView8.setText(sup_mobile1)


            textView9.setText(sup_mobile2)


            textView10.setText(sup_addr)


            textView11.setText(sup_addr1)



            textView12.setText(sup_addr2)


            textView13.setText(sup_city)


            textView14.setText(sup_state)


            textView15.setText(sup_pin)



            println(sup_pin)
            textView16.setText(sup_gps)



            textView17.setText(sup_mail)



            println(sup_mail)
            textView18.setText(sup_gstcd)

            textView19.setText(sup_imgurl)
            textView20.setText(sup_status)
            saveky.setText(key)
            textView21.setText(ids)
            prokey.setText(prosavekey)


            if(sup_id!="Auto - generated") {


                suppnamevalidate = sup_name
                contactprsvalidate = sup_cont
                suppmobcat1validate = sup_mob.toString()
                suppmobcat2validate = sup_mob2.toString()
                suppmobcat3validate = sup_mob2.toString()
                suppmobilevalidate = sup_mobile.toString()
                suppmobile21validate = sup_mobile1
                suppmobile31validate = sup_mobile2
                suppaddress1validate = sup_addr
                suppaddress2validate = sup_addr1
                suppaddress3validate = sup_addr2
                suppcityvalidate = sup_city
                suppstatevalidate = sup_state
                supppinvalidate = sup_pin
                gpsvalidate = sup_gps
                suppemailvalidate = sup_mail
                suppgstvalidate = sup_gstcd

            }
            gets()
        }

        else if(i=="eventlist") {

            val ad = intent.getStringExtra("addspro")
            val ed = intent.getStringExtra("editspro")
            val vie= intent.getStringExtra("viewspro")
            val dele = intent.getStringExtra("deletespro")
            val imp = intent.getStringExtra("importspro")
            val expo = intent.getStringExtra("exportspro")

            val liiss=intent.getStringExtra("listenersave")
            savelistnr=liiss

            val fieldliiss=intent.getStringExtra("fieldlistenersave")
            fieldlistener=fieldliiss


            val sup_name = intent.getStringExtra("prret_sname1")
            val listeners=intent.getStringExtra("listener")
            val sup_id = intent.getStringExtra("proret_sid1")
            val sup_cont = intent.getStringExtra("proret_scon1")
            val sup_mob = intent.getStringExtra("proret_mob")
            val sup_mob1 = intent.getStringExtra("proret_mob1")
            val sup_mob2 =intent.getStringExtra("proret_mob2")
            val sup_mobile = intent.getStringExtra("proret_mobile")
            val sup_mobile1 =intent.getStringExtra("proret_mobile1")
            val sup_mobile2 = intent.getStringExtra("proret_mobile2")
            val sup_addr = intent.getStringExtra("proret_saddress")
            val sup_addr1 = intent.getStringExtra("proret_saddress1")
            val sup_addr2 = intent.getStringExtra("proret_saddress2")
            val sup_city = intent.getStringExtra("proret_scity")
            val sup_state = intent.getStringExtra("proret_sstate")
            val sup_pin = intent.getStringExtra("proret_spin")
            val sup_gps = intent.getStringExtra("proret_sgps")
            val sup_mail = intent.getStringExtra("proret_smail")
            val sup_gstcd = intent.getStringExtra("proret_sgstcd")
            val sup_imgurl = intent.getStringExtra("proret_url")
            val sup_status = intent.getStringExtra("proret_status")
            val ids = intent.getStringExtra("proret_sids")
            val key = intent.getStringExtra("svky")
            val f = intent.getStringExtra("returl1")
            val s = intent.getStringExtra("returl2")
            val t = intent.getStringExtra("returl3")
            val fo = intent.getStringExtra("returl4")
            val fif = intent.getStringExtra("returl5")
            //image name's
            val fn = intent.getStringExtra("retimg1")
            val sn = intent.getStringExtra("retimg2")
            val tn = intent.getStringExtra("retimg3")
            val fon = intent.getStringExtra("retimg4")
            val fifn = intent.getStringExtra("retimg5")

            editclipro = intent.getStringExtra("editclipro")
            editcli= intent.getStringExtra("editclisupp")

try {
    startlistprokey = intent.getStringExtra("startlistprky")
    productprokey = intent.getStringExtra("profrmprky")
}
catch (e:Exception){

}

            try{

                img1urlhigh=intent.getStringExtra("img1urlhigh")
                img2urlhigh=intent.getStringExtra("img2urlhigh")
                img3urlhigh=intent.getStringExtra("img3urlhigh")
                img4urlhigh=intent.getStringExtra("img4urlhigh")
                img5urlhigh=intent.getStringExtra("img5urlhigh")
                //image name's
                img1nhigh=intent.getStringExtra("img1nhigh")
                img2nhigh=intent.getStringExtra("img2nhigh")
                img3nhigh=intent.getStringExtra("img3nhigh")
                img4nhigh=intent.getStringExtra("img4nhigh")
                img5nhigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1edit=intent.getStringExtra("f1edit")
                s1edit=intent.getStringExtra("s1edit")
                t1edit=intent.getStringExtra("t1edit")
                fo1edit=intent.getStringExtra("fo1edit")
                fif1edit=intent.getStringExtra("fif1edit")
                //image name's
                fn1edit=intent.getStringExtra("fn1edit")
                sn1edit=intent.getStringExtra("sn1edit")
                tn1edit=intent.getStringExtra("tn1edit")
                fon1edit=intent.getStringExtra("fon1edit")
                fifn1edit=intent.getStringExtra("fifn1edit")


                f1edithigh=intent.getStringExtra("f1edithigh")
                s1edithigh=intent.getStringExtra("s1edithigh")
                t1edithigh=intent.getStringExtra("t1edithigh")
                fo1edithigh=intent.getStringExtra("fo1edithigh")
                fif1edithigh=intent.getStringExtra("fif1edithigh")
                //image name's
                fn1edithigh=intent.getStringExtra("fn1edithigh")
                sn1edithigh=intent.getStringExtra("sn1edithigh")
                tn1edithigh=intent.getStringExtra("tn1edithigh")
                fon1edithigh=intent.getStringExtra("fon1edithigh")
                fifn1edithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                mresultsarr=intent.getStringArrayListExtra("mresultsarr")

            }
            catch (e:Exception){

            }

            if((editcli.isEmpty()==true)&&(sup_id!="Auto - generated"))
            {
                imageButtonsrch.visibility=View.GONE
                imageButtonvert.visibility=View.GONE
                supp_edit.visibility=View.VISIBLE
                sadd_fab.visibility=View.INVISIBLE
                supp_prod_list.isClickable=false


            }



            if (ad != null) {
                addsupppro = ad

                println("ADD PERMISSION"+addsupppro)
            }
            if (ed != null) {
                editesupppro = ed
            }
            if (dele != null) {
                deletesupppro = dele
            }
            if (vie != null) {
                viewsupppro = vie
            }
            if (imp != null) {
                importsupppro = imp
            }
            if (expo != null) {
                exportsupppro = expo
            }


            try

            {
                f1sup = f
                s1sup = s
                t1sup = t
                fo1sup = fo
                fif1sup = fif
                fn1sup = fn
                sn1sup = sn
                tn1sup = tn
                fon1sup = fon
                fifn1sup = fifn


            }
            catch (e:Exception){

            }


                textView1.setText(sup_name)
                println("NAME "+textView1.text)
                textView22.setText(sup_id)
                println(sup_id)
                textView33.setText(sup_cont)
                textView4.setText(sup_mob.toString())
                textView5.setText(sup_mob1.toString())
                textView6.setText(sup_mob2.toString())
                textView7.setText(sup_mobile)
                println(sup_mobile)
                textView8.setText(sup_mobile1)
                textView9.setText(sup_mobile2)
                textView10.setText(sup_addr)
                textView11.setText(sup_addr1)
                textView12.setText(sup_addr2)
                textView13.setText(sup_city)
                textView14.setText(sup_state)
                textView15.setText(sup_pin)
                println(sup_pin)
                textView16.setText(sup_gps)
                textView17.setText(sup_mail)
                println(sup_mail)
                textView18.setText(sup_gstcd)
                textView19.setText(sup_imgurl)
                textView20.setText(sup_status)
                saveky.setText(key)
                textView21.setText(ids)


            if(sup_id!="Auto - generated") {


                suppnamevalidate = sup_name
                contactprsvalidate = sup_cont
                suppmobcat1validate = sup_mob.toString()
                suppmobcat2validate = sup_mob2.toString()
                suppmobcat3validate = sup_mob2.toString()
                suppmobilevalidate = sup_mobile.toString()
                suppmobile21validate = sup_mobile1
                suppmobile31validate = sup_mobile2
                suppaddress1validate = sup_addr
                suppaddress2validate = sup_addr1
                suppaddress3validate = sup_addr2
                suppcityvalidate = sup_city
                suppstatevalidate = sup_state
                supppinvalidate = sup_pin
                gpsvalidate = sup_gps
                suppemailvalidate = sup_mail
                suppgstvalidate = sup_gstcd

            }

                println("TEXTVIEW OF NAMEEE" + textView1.text)



            println("EVENT LIST LA VANDHURUKU ")
            val prosavekey = intent.getStringExtra("keys")
            prokey.setText(prosavekey)

            if (prokey.text != "") {

                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                pDialog.setTitleText("Loading...")
                pDialog.setCancelable(false)
                pDialog.show();

                var idpArray = arrayOf<String>()
                var nameArray = arrayOf<String>()
                var sunbnmArray = arrayOf<String>()
                var bcArray = arrayOf<String>()
                var sohArray = arrayOf<String>()

                var mlArray = arrayOf<String>()
                var mhArray = arrayOf<String>()
                var priceArray = arrayOf<String>()
                var disproArray = arrayOf<String>()
                var primgArray = arrayOf<String>()
                var icohighArray = arrayOf<String>()
                var icohighnmArray = arrayOf<String>()



                var db = FirebaseFirestore.getInstance()
                suppprodprogress.visibility = android.view.View.VISIBLE
                val path = prokey.text.toString()
                var ii = path.split(",")
                println("DELIMETERSSSS" + ii.size)
                kys = kys.plusElement(path)
                for (i in 0 until ii.size) {
                    println("ONE BY ONE KYS OF IDDDDSSSSS " + prokey_dup.text)
                    var a = ii[i]
                    prokey_dup.setText(a)
                    a = a.trim()
                    println("RECORDS OF PRODUCT KEYYYYYSSSSS ," + a)

                    delepros.add(a)

                    db.collection("supplier_products").document(a)
                            .get()
                            .addOnCompleteListener { task ->
                                println(task.result)
                                if (task.isSuccessful) {
                                    if (task.getResult().exists()) {
                                        if (task.result != null) {
                                            imageView10.visibility=View.GONE
                                            dayview.visibility=View.VISIBLE


                                            println("TASK RESULT" + task.result.get("sp_nm").toString())
                                            var name = task.result.get("sp_nm").toString()
                                            var mble = task.result.get("spwg_vol").toString()
                                            var ut=task.result.get("sput").toString()
                                            var manufacturer = task.result.get("spmfr").toString()
                                            var stkonhand = task.result.get("spstock_hand").toString()
                                            var maxstock = task.result.get("spmx_stk").toString()
                                            var price = task.result.get("spmrp").toString()
                                            var dispro = task.result.get("status").toString()
                                            var barcodeid = task.result.get("spbc").toString()
                                            var im=task.result.get("img1url").toString()

                                            var idp = task.result.id



                                            if(barcodeid.isEmpty()){
                                                bcArray=bcArray.plusElement("Not Available")
                                            }
                                            else if(barcodeid.isNotEmpty()){
                                                bcArray = bcArray.plusElement(barcodeid)
                                            }


                                            nameArray = nameArray.plusElement(name)

                                            if((mble.isEmpty())&&(ut!="Select")){
                                                mlArray = mlArray.plusElement("")
                                            }
                                            else if((mble.isNotEmpty())&&(ut!="Select")){
                                                mlArray = mlArray.plusElement(mble+ut)

                                            }
                                            else if((mble.isNotEmpty())&&(ut=="Select")){
                                                mlArray = mlArray.plusElement("")
                                            }
                                            else if((mble.isEmpty())&&(ut=="Select")){
                                                mlArray = mlArray.plusElement("")
                                            }

                                            if((manufacturer=="Select")||(manufacturer.isEmpty())){
                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                            }
                                            else if((manufacturer!="Select")&&(manufacturer.isNotEmpty())){
                                                sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                            }

                                            sohArray = sohArray.plusElement(stkonhand)
                                            mhArray = mhArray.plusElement(maxstock)
                                            priceArray = priceArray.plusElement(price)
                                            disproArray = disproArray.plusElement(dispro)
                                            idpArray = idpArray.plusElement(idp)
                                            aps = idpArray
                                            if(im.isNotEmpty()){
                                                val high = task.result.get("img1urlhigh").toString()
                                                val highnm = task.result.get("img1nhigh").toString()
                                                icohighnmArray=icohighnmArray.plusElement(highnm)
                                                icohighArray=icohighArray.plusElement(high)
                                                primgArray=primgArray.plusElement(im)
                                            }
                                            else {
                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                            }


                                        }
                                        pDialog.dismiss()

                                        idpArraydup=idpArray
                                        nameArraydup=nameArray
                                        sunbnmArraydup=sunbnmArray
                                        bcArraydup=bcArray
                                        sohArraydup=sohArray
                                        mlArraydup=mlArray
                                        mhArraydup=mhArray
                                        priceArraydup=priceArray
                                        disproArraydup=disproArray
                                        primgArraydup=primgArray


                                        dayview.setText("${priceArray.count()} options")
                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray,icohighnmArray,icohighArray)
                                        supp_prod_list.adapter = whatever
                                        suppprodprogress.visibility = View.GONE

                                    } else {
                                        imageView10.visibility=View.VISIBLE
                                        dayview.setText("0 options")

                                        pDialog.dismiss()

                                        println("NO RECORDSSSS FOUNDD")
                                    }


                                } else {
                                    imageView10.visibility=View.VISIBLE
                                    dayview.setText("0 options")

                                    pDialog.dismiss()
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }
                            }
                }





            }
            else {
                dayview.setText("0 options")
                imageView10.visibility=View.VISIBLE
                suppprodprogress.visibility = View.GONE
                Toast.makeText(applicationContext, "No records found", Toast.LENGTH_SHORT).show()
            }





        }



       /* else if(i=="prod_key_snd"){*/

           /* val liiss=intent.getStringExtra("listenersave")
            savelistnr=liiss

            val fieldliiss=intent.getStringExtra("fieldlistenersave")
            fieldlistener=fieldliiss

            editclipro = intent.getStringExtra("editclipro")
            editcli= intent.getStringExtra("editclisupp")



            val sup_name = intent.getStringExtra("prret_sname1")
            val sup_id = intent.getStringExtra("proret_sid1")
            val sup_cont = intent.getStringExtra("proret_scon1")
            val sup_mob = intent.getStringExtra("proret_mob")
            val sup_mob1 = intent.getStringExtra("proret_mob1")
            val sup_mob2 =intent.getStringExtra("proret_mob2")
            val sup_mobile = intent.getStringExtra("proret_mobile")
            val sup_mobile1 =intent.getStringExtra("proret_mobile1")
            val sup_mobile2 = intent.getStringExtra("proret_mobile2")
            val sup_addr = intent.getStringExtra("proret_saddress")
            val sup_addr1 = intent.getStringExtra("proret_saddress1")
            val sup_addr2 = intent.getStringExtra("proret_saddress2")
            val sup_city = intent.getStringExtra("proret_scity")
            val sup_state = intent.getStringExtra("proret_sstate")
            val sup_pin = intent.getStringExtra("proret_spin")
            val sup_gps = intent.getStringExtra("proret_sgps")
            val sup_mail = intent.getStringExtra("proret_smail")
            val sup_gstcd = intent.getStringExtra("proret_sgstcd")
            val sup_imgurl = intent.getStringExtra("proret_url")
            val sup_status = intent.getStringExtra("proret_status")
            val ids = intent.getStringExtra("proret_sids")
            val key = intent.getStringExtra("svky")

            //image name's
            val fnsup = intent.getStringExtra("retimg1")
            val snsup = intent.getStringExtra("retimg2")
            val tn = intent.getStringExtra("retimg3")
            val fon = intent.getStringExtra("retimg4")
            val fifn = intent.getStringExtra("retimg5")

            //image urls
            val f = intent.getStringExtra("returl1")
            val s = intent.getStringExtra("returl2")
            val t = intent.getStringExtra("returl3")
            val fo = intent.getStringExtra("returl4")
            val fif = intent.getStringExtra("returl5")

            val ad = intent.getStringExtra("retadd")
            val ed = intent.getStringExtra("retedit")
            val vie= intent.getStringExtra("retview")
            val dele = intent.getStringExtra("retdelete")
            val imp = intent.getStringExtra("retimport")
            val expo = intent.getStringExtra("retexport")

            if((editcli.isEmpty()==true)&&(sup_id!="Auto - generated"))
            {
                imageButtonsrch.visibility=View.GONE
                imageButtonvert.visibility=View.GONE
                supp_edit.visibility=View.VISIBLE
                sadd_fab.visibility=View.INVISIBLE
                supp_prod_list.isClickable=false


            }

try {
    startlistprokey = intent.getStringExtra("startlistprky")
    productprokey = intent.getStringExtra("profrmprky")
}
catch (e:Exception){

}

            try{

                img1urlhigh=intent.getStringExtra("img1urlhigh")
                img2urlhigh=intent.getStringExtra("img2urlhigh")
                img3urlhigh=intent.getStringExtra("img3urlhigh")
                img4urlhigh=intent.getStringExtra("img4urlhigh")
                img5urlhigh=intent.getStringExtra("img5urlhigh")
                //image name's
                img1nhigh=intent.getStringExtra("img1nhigh")
                img2nhigh=intent.getStringExtra("img2nhigh")
                img3nhigh=intent.getStringExtra("img3nhigh")
                img4nhigh=intent.getStringExtra("img4nhigh")
                img5nhigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1edit=intent.getStringExtra("f1edit")
                s1edit=intent.getStringExtra("s1edit")
                t1edit=intent.getStringExtra("t1edit")
                fo1edit=intent.getStringExtra("fo1edit")
                fif1edit=intent.getStringExtra("fif1edit")
                //image name's
                fn1edit=intent.getStringExtra("fn1edit")
                sn1edit=intent.getStringExtra("sn1edit")
                tn1edit=intent.getStringExtra("tn1edit")
                fon1edit=intent.getStringExtra("fon1edit")
                fifn1edit=intent.getStringExtra("fifn1edit")


                f1edithigh=intent.getStringExtra("f1edithigh")
                s1edithigh=intent.getStringExtra("s1edithigh")
                t1edithigh=intent.getStringExtra("t1edithigh")
                fo1edithigh=intent.getStringExtra("fo1edithigh")
                fif1edithigh=intent.getStringExtra("fif1edithigh")
                //image name's
                fn1edithigh=intent.getStringExtra("fn1edithigh")
                sn1edithigh=intent.getStringExtra("sn1edithigh")
                tn1edithigh=intent.getStringExtra("tn1edithigh")
                fon1edithigh=intent.getStringExtra("fon1edithigh")
                fifn1edithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                mresultsarr=intent.getStringArrayListExtra("mresultsarr")

            }
            catch (e:Exception){

            }

            if (ad != null) {
                addsupppro = ad
            }
            if (ed != null) {
                editesupppro = ed
            }
            if (dele != null) {
                deletesupppro = dele
            }
            if (vie != null) {
                viewsupppro = vie
            }
            if (imp != null) {
                importsupppro = imp
            }
            if (expo != null) {
                exportsupppro = expo
            }




            gets()



            println(sup_name)
            println(key)

try {
    f1sup = f
    s1sup = s
    t1sup = t
    fo1sup = fo
    fif1sup = fif
    fn1sup = fnsup
    sn1sup = snsup
    tn1sup = tn
    fon1sup = fon
    fifn1sup = fifn


}
catch (e:Exception){

}

            try{
                textView1.setText(sup_name)
                println("NAME "+textView1.text)
                textView22.setText(sup_id)
                println(sup_id)
                textView33.setText(sup_cont)
                textView4.setText(sup_mob.toString())
                textView5.setText(sup_mob1.toString())
                textView6.setText(sup_mob2.toString())
                textView7.setText(sup_mobile)
                println(sup_mobile)
                textView8.setText(sup_mobile1)
                textView9.setText(sup_mobile2)
                textView10.setText(sup_addr)
                textView11.setText(sup_addr1)
                textView12.setText(sup_addr2)
                textView13.setText(sup_city)
                textView14.setText(sup_state)
                textView15.setText(sup_pin)
                println(sup_pin)
                textView16.setText(sup_gps)
                textView17.setText(sup_mail)
                println(sup_mail)
                textView18.setText(sup_gstcd)
                textView19.setText(sup_imgurl)
                textView20.setText(sup_status)
                saveky.setText(key)
                textView21.setText(ids)

                println("TEXTVIEW OF NAMEEE" + textView1.text)


                if(sup_id!="Auto - generated") {


                    suppnamevalidate = sup_name
                    contactprsvalidate = sup_cont
                    suppmobcat1validate = sup_mob.toString()
                    suppmobcat2validate = sup_mob2.toString()
                    suppmobcat3validate = sup_mob2.toString()
                    suppmobilevalidate = sup_mobile.toString()
                    suppmobile21validate = sup_mobile1
                    suppmobile31validate = sup_mobile2
                    suppaddress1validate = sup_addr
                    suppaddress2validate = sup_addr1
                    suppaddress3validate = sup_addr2
                    suppcityvalidate = sup_city
                    suppstatevalidate = sup_state
                    supppinvalidate = sup_pin
                    gpsvalidate = sup_gps
                    suppemailvalidate = sup_mail
                    suppgstvalidate = sup_gstcd

                }
            }
            catch (e:Exception){

            }*/


       /* }*/







        radioGroup1 = (findViewById<View>(R.id.radioGroup1) as RadioGroup)

println("PRODUCT KEYYYYSSSSS"   +prokey.text)







        /*swipeContainer.setOnRefreshListener {
            gets()
        }*/
        // Configure the refreshing colors
       /* swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/

        searback1.setOnClickListener {   //Image button search back action
            cardsearch.visibility=View.GONE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@SupplierSecondmain,R.anim.slide_to_left))
            gets()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }




        //-------Search action-----------------------//
        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                suppprodprogress.visibility=View.VISIBLE
                supp_prod_list.visibility=View.GONE

                noresfo.visibility=View.GONE

                println("KEYS OF SEARCHHH" + kyval)
                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

                fun bcodeget(){


                    if ((prokey.text != "") && (s.length >= 2)) {
                        var idpArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var sunbnmArray = arrayOf<String>()
                        var bcArray = arrayOf<String>()
                        var sohArray = arrayOf<String>()

                        var mlArray = arrayOf<String>()
                        var mhArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var disproArray = arrayOf<String>()
                        var primgArray = arrayOf<String>()

                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()




                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                val dd = document.data
                                                var supkey = dd["supp_key"].toString()
                                                if (saveky.text== supkey) {

                                                    val id = document.id;//0
                                                    println("TASK RESULT" + dd["p_nm"].toString())
                                                    var name = dd["p_nm"].toString()
                                                    var mble = dd["wg_vol"].toString()
                                                    var ut=dd["ut"].toString()

                                                    var manufacturer = dd["mfr"].toString()
                                                    var stkonhand = dd["stock_hand"].toString()
                                                    var maxstock = dd["mx_stk"].toString()
                                                    var price = dd["mrp"].toString()
                                                    var dispro = dd["status"].toString()
                                                    var im=dd["img1url"].toString()
                                                    var barcodeid = dd["bc"].toString()
                                                    var idp = id


                                                    if(barcodeid.isEmpty()){
                                                        bcArray=bcArray.plusElement("Not Available")
                                                    }
                                                    else if(barcodeid.isNotEmpty()){
                                                        bcArray = bcArray.plusElement(barcodeid)
                                                    }
                                                    nameArray = nameArray.plusElement(name)
                                                    if((mble.isEmpty())&&(ut!="Select")){
                                                        mlArray = mlArray.plusElement("")
                                                    }
                                                    else if((mble.isNotEmpty())&&(ut!="Select")){
                                                        mlArray = mlArray.plusElement(mble+ut)

                                                    }
                                                    else if((mble.isNotEmpty())&&(ut=="Select")){
                                                        mlArray = mlArray.plusElement("")
                                                    }
                                                    else if((mble.isEmpty())&&(ut=="Select")){
                                                        mlArray = mlArray.plusElement("")
                                                    }
                                                    if((manufacturer=="Select")||(manufacturer.isEmpty())){
                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                                    }
                                                    else if((manufacturer!="Select")&&(manufacturer.isNotEmpty())){
                                                        sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                                    }

                                                    sohArray = sohArray.plusElement(stkonhand)
                                                    mhArray = mhArray.plusElement(maxstock)
                                                    priceArray = priceArray.plusElement(price)
                                                    disproArray = disproArray.plusElement(dispro)
                                                    idpArray = idpArray.plusElement(idp)
                                                    bsupkykyarray = bsupkykyarray.plusElement(supkey)
                                                    aps = idpArray

                                                    println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))

                                                    if(im.isNotEmpty()){
                                                        val high = dd["img1urlhigh"].toString()
                                                        val highnm = dd["img1nhigh"].toString()
                                                        icohighnmArray=icohighnmArray.plusElement(highnm)
                                                        icohighArray=icohighArray.plusElement(high)

                                                        primgArray=primgArray.plusElement(im)
                                                    }
                                                    else {
                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                    }

                                                    supp_prod_list.visibility=View.VISIBLE
                                                    suppprodprogress.visibility=View.GONE

                                                    println("SAVE KEYYYY"+saveky.text)
                                                    val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray,icohighnmArray,icohighArray)
                                                    supp_prod_list.adapter = whatever
                                                    suppprodprogress.visibility = View.GONE
                                                } else {
                                                    if(idpArray.isNotEmpty()){
                                                        supp_prod_list.visibility = View.VISIBLE
                                                        suppprodprogress.visibility = View.GONE
                                                        println("SAVE KEYYYY" + saveky.text)
                                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                        supp_prod_list.adapter = whatever
                                                        suppprodprogress.visibility = View.GONE

                                                    }
                                                }







                                            }
                                           /* for (i in 0 until bsupkykyarray.count()) {
                                                var ail = bsupkykyarray[i]
                                                bsupkyval = ail
                                            }*/
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK"+(bsupkyval))
                                            println("SAVE KEYYYY"+saveky.text)



                                        } else {
                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    val dd = document.data
                                                                    var supkey = dd["supp_key"].toString()


                                                                    if (saveky.text == supkey) {
                                                                        val id = document.id;//0
                                                                        println("TASK RESULT" + dd["p_nm"].toString())
                                                                        var name = dd["p_nm"].toString()
                                                                        var mble = dd["wg_vol"].toString()
                                                                        var ut = dd["ut"].toString()

                                                                        var manufacturer = dd["mfr"].toString()
                                                                        var stkonhand = dd["stock_hand"].toString()
                                                                        var maxstock = dd["mx_stk"].toString()
                                                                        var price = dd["mrp"].toString()
                                                                        var dispro = dd["status"].toString()
                                                                        var im = dd["img1url"].toString()
                                                                        var barcodeid = dd["bc"].toString()
                                                                        var idp = id


                                                                        if (barcodeid.isEmpty()) {
                                                                            bcArray = bcArray.plusElement("Not Available")
                                                                        } else if (barcodeid.isNotEmpty()) {
                                                                            bcArray = bcArray.plusElement(barcodeid)
                                                                        }
                                                                        nameArray = nameArray.plusElement(name)
                                                                        if ((mble.isEmpty()) && (ut != "Select")) {
                                                                            mlArray = mlArray.plusElement("")
                                                                        } else if ((mble.isNotEmpty()) && (ut != "Select")) {
                                                                            mlArray = mlArray.plusElement(mble + ut)

                                                                        } else if ((mble.isNotEmpty()) && (ut == "Select")) {
                                                                            mlArray = mlArray.plusElement("")
                                                                        } else if ((mble.isEmpty()) && (ut == "Select")) {
                                                                            mlArray = mlArray.plusElement("")
                                                                        }
                                                                        if ((manufacturer == "Select") || (manufacturer.isEmpty())) {
                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                                                        } else if ((manufacturer != "Select") && (manufacturer.isNotEmpty())) {
                                                                            sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                                                        }

                                                                        sohArray = sohArray.plusElement(stkonhand)
                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                        priceArray = priceArray.plusElement(price)
                                                                        disproArray = disproArray.plusElement(dispro)
                                                                        idpArray = idpArray.plusElement(idp)
                                                                        bsupkykyarray = bsupkykyarray.plusElement(supkey)
                                                                        aps = idpArray

                                                                        println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))

                                                                        if (im.isNotEmpty()) {
                                                                            val high = dd["img1urlhigh"].toString()
                                                                            val highnm = dd["img1nhigh"].toString()
                                                                            icohighnmArray = icohighnmArray.plusElement(highnm)
                                                                            icohighArray = icohighArray.plusElement(high)

                                                                            primgArray = primgArray.plusElement(im)
                                                                        } else {
                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                        }

                                                                        supp_prod_list.visibility = View.VISIBLE
                                                                        suppprodprogress.visibility = View.GONE

                                                                        println("SAVE KEYYYY" + saveky.text)
                                                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                        supp_prod_list.adapter = whatever
                                                                        suppprodprogress.visibility = View.GONE
                                                                    } else {
                                                                        if(idpArray.isNotEmpty()){
                                                                            supp_prod_list.visibility = View.VISIBLE
                                                                            suppprodprogress.visibility = View.GONE
                                                                            println("SAVE KEYYYY" + saveky.text)
                                                                            val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                            supp_prod_list.adapter = whatever
                                                                            suppprodprogress.visibility = View.GONE

                                                                        }
                                                                    }




                                                                }
                                                              /*  for (i in 0 until bsupkykyarray.count()) {
                                                                    var ail = bsupkykyarray[i]
                                                                    bsupkyval = ail
                                                                }*/
                                                                println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                                                println("SAVE KEYYYY" + saveky.text)

                                                            } else {

                                                                db.collection("product").orderBy("stock_hand").startAt(numberstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {
                                                                                        val dd = document.data
                                                                                        var supkey = dd["supp_key"].toString()

                                                                                        if (saveky.text == supkey) {
                                                                                            val id = document.id;//0
                                                                                            println("TASK RESULT" + dd["p_nm"].toString())
                                                                                            var name = dd["p_nm"].toString()
                                                                                            var mble = dd["wg_vol"].toString()
                                                                                            var ut = dd["ut"].toString()

                                                                                            var manufacturer = dd["mfr"].toString()
                                                                                            var stkonhand = dd["stock_hand"].toString()
                                                                                            var maxstock = dd["mx_stk"].toString()
                                                                                            var price = dd["mrp"].toString()
                                                                                            var dispro = dd["status"].toString()
                                                                                            var im = dd["img1url"].toString()
                                                                                            var barcodeid = dd["bc"].toString()
                                                                                            var idp = id


                                                                                            if (barcodeid.isEmpty()) {
                                                                                                bcArray = bcArray.plusElement("Not Available")
                                                                                            } else if (barcodeid.isNotEmpty()) {
                                                                                                bcArray = bcArray.plusElement(barcodeid)
                                                                                            }
                                                                                            nameArray = nameArray.plusElement(name)
                                                                                            if ((mble.isEmpty()) && (ut != "Select")) {
                                                                                                mlArray = mlArray.plusElement("")
                                                                                            } else if ((mble.isNotEmpty()) && (ut != "Select")) {
                                                                                                mlArray = mlArray.plusElement(mble + ut)

                                                                                            } else if ((mble.isNotEmpty()) && (ut == "Select")) {
                                                                                                mlArray = mlArray.plusElement("")
                                                                                            } else if ((mble.isEmpty()) && (ut == "Select")) {
                                                                                                mlArray = mlArray.plusElement("")
                                                                                            }
                                                                                            if ((manufacturer == "Select") || (manufacturer.isEmpty())) {
                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                                                                            } else if ((manufacturer != "Select") && (manufacturer.isNotEmpty())) {
                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                                                                            }

                                                                                            sohArray = sohArray.plusElement(stkonhand)
                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                            priceArray = priceArray.plusElement(price)
                                                                                            disproArray = disproArray.plusElement(dispro)
                                                                                            idpArray = idpArray.plusElement(idp)
                                                                                            bsupkykyarray = bsupkykyarray.plusElement(supkey)
                                                                                            aps = idpArray

                                                                                            println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))

                                                                                            if (im.isNotEmpty()) {
                                                                                                val high = dd["img1urlhigh"].toString()
                                                                                                val highnm = dd["img1nhigh"].toString()
                                                                                                icohighnmArray = icohighnmArray.plusElement(highnm)
                                                                                                icohighArray = icohighArray.plusElement(high)

                                                                                                primgArray = primgArray.plusElement(im)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                            }

                                                                                            supp_prod_list.visibility = View.VISIBLE
                                                                                            suppprodprogress.visibility = View.GONE

                                                                                            println("SAVE KEYYYY" + saveky.text)
                                                                                            val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                                            supp_prod_list.adapter = whatever
                                                                                            suppprodprogress.visibility = View.GONE
                                                                                        } else {
                                                                                            if(idpArray.isNotEmpty()){
                                                                                                supp_prod_list.visibility = View.VISIBLE
                                                                                                suppprodprogress.visibility = View.GONE
                                                                                                println("SAVE KEYYYY" + saveky.text)
                                                                                                val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                                                supp_prod_list.adapter = whatever
                                                                                                suppprodprogress.visibility = View.GONE

                                                                                            }
                                                                                        }




                                                                                    }
                                                                                  /*  for (i in 0 until bsupkykyarray.count()) {
                                                                                        var ail = bsupkykyarray[i]
                                                                                        bsupkyval = ail
                                                                                    }*/
                                                                                    println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                                                                    println("SAVE KEYYYY" + saveky.text)

                                                                                } else {
                                                                                    noresfo.visibility = View.VISIBLE
                                                                                    supp_prod_list.visibility = View.GONE
                                                                                    suppprodprogress.visibility = View.GONE
                                                                                }

                                                                        })


                                                            }

                                                    })
                                        }


                                    /*} else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }


                }




                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    bcodeget()
                    //write code here for success
                }

                if((s.length==1)&&(x!==reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    nmstr = upstr
                    var escp = upperString + '\uf8ff'
                    esc = escp

                    println("CAPPPSSSS" + upperString)
                }
                else if ((prokey.text!="")&&(s.length >= 3)&&(x!==reg)) {
                    var idpArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var sunbnmArray = arrayOf<String>()
                    var bcArray = arrayOf<String>()
                    var sohArray = arrayOf<String>()

                    var mlArray = arrayOf<String>()
                    var mhArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var disproArray = arrayOf<String>()
                    var primgArray = arrayOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {
                                            val dd = document.data
                                            var supkey = dd["supp_key"].toString()
                                            if(saveky.text==supkey) {
                                                val id = document.id;//0
                                                println("TASK RESULT" + dd["p_nm"].toString())
                                                var name = dd["p_nm"].toString()
                                                var mble = dd["wg_vol"].toString()
                                                var ut=dd["ut"].toString()
                                                var manufacturer = dd["mfr"].toString()
                                                var stkonhand = dd["stock_hand"].toString()
                                                var maxstock = dd["mx_stk"].toString()
                                                var price = dd["mrp"].toString()
                                                var dispro = dd["status"].toString()
                                                var barcodeid = dd["bc"].toString()

                                                var im=dd["img1url"].toString()




                                                var idp = id

                                                if(barcodeid.isEmpty()){
                                                    bcArray=bcArray.plusElement("Not Available")
                                                }
                                                else if(barcodeid.isNotEmpty()){
                                                    bcArray = bcArray.plusElement(barcodeid)
                                                }

                                                nameArray = nameArray.plusElement(name)
                                                if((mble.isEmpty())&&(ut!="Select")){
                                                    mlArray = mlArray.plusElement("")
                                                }
                                                else if((mble.isNotEmpty())&&(ut!="Select")){
                                                    mlArray = mlArray.plusElement(mble+ut)

                                                }
                                                else if((mble.isNotEmpty())&&(ut=="Select")){
                                                    mlArray = mlArray.plusElement("")
                                                }
                                                else if((mble.isEmpty())&&(ut=="Select")){
                                                    mlArray = mlArray.plusElement("")
                                                }
                                                if((manufacturer=="Select")||(manufacturer.isEmpty())){
                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                                }
                                                else if((manufacturer!="Select")&&(manufacturer.isNotEmpty())){
                                                    sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                                }

                                                sohArray = sohArray.plusElement(stkonhand)
                                                mhArray = mhArray.plusElement(maxstock)
                                                priceArray = priceArray.plusElement(price)
                                                disproArray = disproArray.plusElement(dispro)
                                                idpArray = idpArray.plusElement(idp)
                                                supkyarray=supkyarray.plusElement(supkey)
                                                aps = idpArray

                                                println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))
                                                if(im.isNotEmpty()){

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)

                                                    primgArray=primgArray.plusElement(im)
                                                }
                                                else {
                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                }
                                                supp_prod_list.visibility=View.VISIBLE
                                                suppprodprogress.visibility=View.GONE
                                                println("SAVE KEYYYY"+saveky.text)
                                                val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray,icohighArray)
                                                supp_prod_list.adapter = whatever
                                                suppprodprogress.visibility = View.GONE
                                            }
                                            else{
                                                if(idpArray.isNotEmpty()){
                                                    supp_prod_list.visibility = View.VISIBLE
                                                    suppprodprogress.visibility = View.GONE
                                                    println("SAVE KEYYYY" + saveky.text)
                                                    val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                    supp_prod_list.adapter = whatever
                                                    suppprodprogress.visibility = View.GONE

                                                }
                                            }



                                        }
                                       /* for(i in 0 until supkyarray.count()) {
                                            var ail = supkyarray[i]
                                            supkyval=ail
                                        }*/
                                        println("SAVEKEYS GET FRESTORE TO IF CHECK"+supkyval)
                                        println("SAVE KEYYYY"+saveky.text)



                                    } else {
                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {
                                                                val dd = document.data
                                                                var supkey = dd["supp_key"].toString()

                                                                if (saveky.text == supkey) {
                                                                    val id = document.id;//0
                                                                    println("TASK RESULT" + dd["p_nm"].toString())
                                                                    var name = dd["p_nm"].toString()
                                                                    var mble = dd["wg_vol"].toString()
                                                                    var ut = dd["ut"].toString()
                                                                    var manufacturer = dd["mfr"].toString()
                                                                    var stkonhand = dd["stock_hand"].toString()
                                                                    var maxstock = dd["mx_stk"].toString()
                                                                    var price = dd["mrp"].toString()
                                                                    var dispro = dd["status"].toString()
                                                                    var barcodeid = dd["bc"].toString()
                                                                    var im = dd["img1url"].toString()


                                                                    var idp = id

                                                                    if (barcodeid.isEmpty()) {
                                                                        bcArray = bcArray.plusElement("Not Available")
                                                                    } else if (barcodeid.isNotEmpty()) {
                                                                        bcArray = bcArray.plusElement(barcodeid)
                                                                    }

                                                                    nameArray = nameArray.plusElement(name)
                                                                    if ((mble.isEmpty()) && (ut != "Select")) {
                                                                        mlArray = mlArray.plusElement("")
                                                                    } else if ((mble.isNotEmpty()) && (ut != "Select")) {
                                                                        mlArray = mlArray.plusElement(mble + ut)

                                                                    } else if ((mble.isNotEmpty()) && (ut == "Select")) {
                                                                        mlArray = mlArray.plusElement("")
                                                                    } else if ((mble.isEmpty()) && (ut == "Select")) {
                                                                        mlArray = mlArray.plusElement("")
                                                                    }
                                                                    if ((manufacturer == "Select") || (manufacturer.isEmpty())) {
                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                                                    } else if ((manufacturer != "Select") && (manufacturer.isNotEmpty())) {
                                                                        sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                                                    }

                                                                    sohArray = sohArray.plusElement(stkonhand)
                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                    priceArray = priceArray.plusElement(price)
                                                                    disproArray = disproArray.plusElement(dispro)
                                                                    idpArray = idpArray.plusElement(idp)
                                                                    supkyarray = supkyarray.plusElement(supkey)
                                                                    aps = idpArray

                                                                    println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))
                                                                    if (im.isNotEmpty()) {

                                                                        val high = dd["img1urlhigh"].toString()
                                                                        val highnm = dd["img1nhigh"].toString()
                                                                        icohighnmArray = icohighnmArray.plusElement(highnm)
                                                                        icohighArray = icohighArray.plusElement(high)

                                                                        primgArray = primgArray.plusElement(im)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }
                                                                    supp_prod_list.visibility = View.VISIBLE
                                                                    suppprodprogress.visibility = View.GONE
                                                                    println("SAVE KEYYYY" + saveky.text)
                                                                    val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                    supp_prod_list.adapter = whatever
                                                                    suppprodprogress.visibility = View.GONE
                                                                } else {
                                                                    if(idpArray.isNotEmpty()){
                                                                        supp_prod_list.visibility = View.VISIBLE
                                                                        suppprodprogress.visibility = View.GONE
                                                                        println("SAVE KEYYYY" + saveky.text)
                                                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray, icohighnmArray, icohighArray)
                                                                        supp_prod_list.adapter = whatever
                                                                        suppprodprogress.visibility = View.GONE

                                                                    }
                                                                    else{

                                                                    }
                                                                }




                                                            }
                                                         /*   for (i in 0 until supkyarray.count()) {
                                                                var ail = supkyarray[i]
                                                                supkyval = ail
                                                            }*/
                                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + supkyval)
                                                            println("SAVE KEYYYY" + saveky.text)

                                                        }
                                                        else{
                                                            noresfo.visibility=View.VISIBLE
                                                            supp_prod_list.visibility=View.GONE
                                                            suppprodprogress.visibility = View.GONE
                                                        }

                                                })



                                    }


                               /* } else {

                                }*/
                            })

                }






                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    supp_prod_list.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    suppprodprogress.visibility = View.GONE
                    gets()



                }
            }
        })


//----------------------------------NAVIGATION  BUTTON CLICK & navigate to 'SupplierAddMain' activity ------------------------------------------------//

        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val `in`: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.matching -> {

                        Log.i("matching", "matching inside1 matching" + checkedId)
                        `in` = Intent(baseContext, SupplierAddMain::class.java)
                        val sname = (textView1.text).toString()
                    println("NAME"+sname +textView1.text)
                        val sid = textView22.text.toString()
                        val scon = textView33.text.toString()
                        val mob = textView4.text.toString()
                        val mob1 = textView5.text.toString()
                        val mob2 = textView6.text.toString()
                        val mobile = textView7.text.toString()
                        val mobile1 = textView8.text.toString()
                        val mobile2 = textView9.text.toString()
                        val saddre = textView10.text.toString()
                        val saddre1 = textView11.text.toString()
                        val saddre2 = textView12.text.toString()
                        val scity = textView13.text.toString()
                        val sstate = textView14.text.toString()
                        val spin = textView15.text.toString()
                        val sgps = textView16.text.toString()
                        val smail = textView17.text.toString()
                        val sgstcode = textView18.text.toString()
                        val urlim = textView19.text.toString()
                        val sids = textView21.text.toString()
                        println("IDDDDSSSS OOOFFFF RRREAAAL   " + textView21.text)

                        val status = textView20.text.toString()
                        val prodky = prokey.text.toString()
                        val svsky = saveky.text.toString()

                        println("READY TO SEND TO SUPPLIER ADDDDD" + prodky)
                        if (prokey.text != "") {
                            `in`.putExtra("prky", prodky)
                        } else {

                        }

                        `in`.putExtra("supppro", "productfrm")
                        `in`.putExtra("editclisupp",editcli)

                        `in`.putExtra("sname1", sname)
                        `in`.putExtra("sid1", sid)
                        `in`.putExtra("scon1", scon)
                        `in`.putExtra("mob", mob)
                        `in`.putExtra("mob1", mob1)
                        `in`.putExtra("mob2", mob2)
                        `in`.putExtra("mobile", mobile)
                        `in`.putExtra("mobile1", mobile1)
                        `in`.putExtra("mobile2", mobile2)
                        `in`.putExtra("saddress", saddre)
                        `in`.putExtra("saddress1", saddre1)
                        `in`.putExtra("listnrsaves", savelistnr)
                        `in`.putExtra("fieldlistnrsaves", fieldlistener)


                    `in`.putExtra("saddress2", saddre2)
                        `in`.putExtra("scity", scity)
                        `in`.putExtra("sstate", sstate)
                        `in`.putExtra("spin", spin)
                        `in`.putExtra("sgps", sgps)
                        `in`.putExtra("smail", smail)
                        `in`.putExtra("sgstcd", sgstcode)
                        `in`.putExtra("status", status)
                        `in`.putExtra("url", urlim)
                        `in`.putExtra("sids", sids)
                        `in`.putExtra("svsky", svsky)



                        `in`.putExtra("url1", f1sup)
                    println("LNK RET"+f1sup)
                        `in`.putExtra("url2", s1sup)
                        `in`.putExtra("url3", t1sup)
                        `in`.putExtra("url4", fo1sup)
                        `in`.putExtra("url5", fif1sup)
                    `in`.putExtra("img1", fn1sup)
                    `in`.putExtra("img2", sn1sup)
                    `in`.putExtra("img3", tn1sup)
                    `in`.putExtra("img4", fon1sup)
                    `in`.putExtra("img5", fifn1sup)

                    `in`.putExtra("addspro", addsupppro)
                    `in`.putExtra("editspro", editesupppro)
                    `in`.putExtra("viewspro", viewsupppro)
                    `in`.putExtra("deletespro", deletesupppro)
                    `in`.putExtra("importspro", importsupppro)
                    `in`.putExtra("exportspro", exportsupppro)


                    `in`.putExtra("img1urlhigh",img1urlhigh)
                    `in`.putExtra("img2urlhigh",img2urlhigh)
                    `in`.putExtra("img3urlhigh",img3urlhigh)
                    `in`.putExtra("img4urlhigh",img4urlhigh)
                    `in`.putExtra("img5urlhigh",img5urlhigh)
                    `in`.putExtra("img1nhigh",img1nhigh)
                    `in`.putExtra("img2nhigh",img2nhigh)
                    `in`.putExtra("img3nhigh",img3nhigh)
                    `in`.putExtra("img4nhigh",img4nhigh)
                    `in`.putExtra("img5nhigh",img5nhigh)


                    `in`.putExtra("f1edit",f1edit)
                    `in`.putExtra("s1edit",s1edit)
                    `in`.putExtra("t1edit",t1edit)
                    `in`.putExtra("fo1edit",fo1edit)
                    `in`.putExtra("fif1edit",fif1edit)
                    `in`.putExtra("fn1edit",fn1edit)
                    `in`.putExtra("sn1edit",sn1edit)
                    `in`.putExtra("tn1edit",tn1edit)
                    `in`.putExtra("fon1edit",fon1edit)
                    `in`.putExtra("fifn1edit",fifn1edit)
                    `in`.putExtra("f1edithigh",f1edithigh)
                    `in`.putExtra("s1edithigh",s1edithigh)
                    `in`.putExtra("t1edithigh",t1edithigh)
                    `in`.putExtra("fo1edithigh",fo1edithigh)
                    `in`.putExtra("fif1edithigh",fif1edithigh)
                    `in`.putExtra("fn1edithigh",fn1edithigh)
                    `in`.putExtra("sn1edithigh",sn1edithigh)
                    `in`.putExtra("tn1edithigh",tn1edithigh)
                    `in`.putExtra("fon1edithigh",fon1edithigh)
                    `in`.putExtra("fifn1edithigh",fifn1edithigh)

                    `in`.putExtra("file_maps",file_maps)
                    `in`.putExtra("mresultsarr",mresultsarr)

                    `in`.putExtra("startlistprky",startlistprokey)
                    `in`.putExtra("profrmprky",productprokey)





                    startActivity(`in`)
                        overridePendingTransition(0, 0)
                        finish()
                    }



                R.id.watchList -> {

                }
                else -> {
                }
            }
        })





        /*fun get() {
            suppprodprogress.visibility = View.VISIBLE
            db.collection("supplier_products")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        var idpArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()
                        var sunbnmArray = arrayOf<String>()
                        var bcArray = arrayOf<String>()
                        var sohArray = arrayOf<String>()

                        var mlArray = arrayOf<String>()
                        var mhArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var disproArray = arrayOf<String>()
                        var primgArray = arrayOf<Int>()

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        for (document in value) {

                            Log.d("d", "key --- " + document.id + " => " + document.data)
                            println(document.data)

                            var dt = document.data
                            var idp = (document.id)
                            var name = (dt["sp_nm"]).toString()
                            var mble = (dt["spwg_vol"]).toString()
                            var manufacturer = (dt["spmfr"]).toString()
                            var stkonhand = (dt["spstock_hand"]).toString()
                            var maxstock = (dt["spmx_stk"]).toString()
                            var price = (dt["spprice"]).toString()
                            var dispro = (dt["status"]).toString()


                            var barcodeid = (dt["spbc"]).toString()

                            nameArray = nameArray.plusElement(name)
                            mlArray = mlArray.plusElement(mble)
                            sunbnmArray = sunbnmArray.plusElement(manufacturer)
                            bcArray = bcArray.plusElement(barcodeid)
                            sohArray = sohArray.plusElement(stkonhand)
                            mhArray = mhArray.plusElement(maxstock)
                            priceArray = priceArray.plusElement(price)
                            disproArray = disproArray.plusElement(dispro)
                            idpArray = idpArray.plusElement(idp)
                            aps = idpArray

                            primgArray = primgArray.plusElement(R.drawable.loreal_bottl)

                        }
                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray)
                        supp_prod_list.adapter = whatever
                        suppprodprogress.visibility = View.GONE


                    })
        }*/



        //Click (FAB) add button and open menu which contains 2 options - 'Select product','Add new product'


        sadd_fab.setOnClickListener {
            if (addsupppro == "true") {
                val mShowButton = AnimationUtils.loadAnimation(this, R.anim.show_button)
                val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)
                if (payment_tk_PG.visibility == View.VISIBLE) {
                    payment_tk_PG.visibility = View.GONE

                    sadd_fab.startAnimation(mHideButton)

                } else if (payment_tk_PG.visibility == View.GONE) {
                    payment_tk_PG.visibility = View.VISIBLE
                    sadd_fab.startAnimation(mShowButton)

                }
            }

            else{

                popup("add")

            }
        }



        //select product click and navigate to 'SuppSelectActivity' for select some product and assign to suppliers.
        selectpro.setOnClickListener {

            payment_tk_PG.visibility = View.GONE

            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            sadd_fab.startAnimation(mHideButton)






                val prodky = prokey.text.toString()


                val a = Intent(this@SupplierSecondmain,SuppSelectActivity::class.java)
                a.putExtra("from","emptylist")

                if (prokey.text != "") {

                    a.putExtra("prky", prodky)
                    println("PUT EXTRA OF PROKEYYYYYYSSSSS" + prodky)
                }
                else {

                }
                startActivityForResult(a, REQUEST_CODE_EXAMPLE2);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)







        }


        //Add new product option click & navigate to (MainActivityScroll) for add new product.
        addnewpro.setOnClickListener {
            payment_tk_PG.visibility = View.GONE


            val mHideButton = AnimationUtils.loadAnimation(this, R.anim.hide_button)

            sadd_fab.startAnimation(mHideButton)

            var frmsupp="supplier"
            service_access = SessionManagement(this)
            user = service_access!!.userDetails
            val name = user[SessionManagement.KEY_NAME]

            val pro_access =SessionManagement(this)
            viewpro=pro_access.userDetails[SessionManagement.pview].toString()
            addpro=pro_access.userDetails[SessionManagement.padd].toString()
            deletepro=pro_access.userDetails[SessionManagement.pdelete].toString()
            editpro=pro_access.userDetails[SessionManagement.pedit].toString()
            importpro=pro_access.userDetails[SessionManagement.pimport].toString()
            exportpro=pro_access.userDetails[SessionManagement.pexport].toString()
            stockin_hand=pro_access.userDetails[SessionManagement.pstockin_hand].toString()



            val a = Intent(this@SupplierSecondmain, MainActivityScroll::class.java)
            a.putExtra("newid", db.collection("product").document().id)
            a.putExtra("from","add")
            a.putExtra("addpro", addpro)
            a.putExtra("editpro", editpro)
            a.putExtra("deletepro", deletepro)
            a.putExtra("viewpro", viewpro)
            a.putExtra("importpro", importpro)
            a.putExtra("changestock", stockin_hand)
            a.putExtra("exportpro", exportpro)

            a.putExtra("addforsupp",frmsupp)
            a.putExtra("suppky",saveky.text.toString())
            a.putExtra("suppname",textView1.text.toString())
            a.putExtra("keybr",name)
            val prodky = prokey.text.toString()


            if (prokey.text != "") {
                a.putExtra("prky", prodky)
                println("PUT EXTRA OF PROKEYYYYYYSSSSS" + prodky)
            } else {

            }

            startActivityForResult(a, REQUEST_CODE_EXAMPLE);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)



        }

        imageButtonvert.setOnClickListener({


            val popup = PopupMenu(this@SupplierSecondmain, imageButtonvert)

            popup.menuInflater.inflate(R.menu.menu_supp_prod, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                var ky=arrayOf<String>()
                var sp_nmvars=arrayOf<String>()
                var sp_idvars=arrayOf<String>()
                var spbcvars=arrayOf<String>()
                var spwg_volvars=arrayOf<String>()
                var sputvars=arrayOf<String>()
                var spctgyvars=arrayOf<String>()
                var spmfrvars=arrayOf<String>()
                var sphsnvars=arrayOf<String>()
                var spdescvars=arrayOf<String>()
                var sppricevars=arrayOf<String>()
                var sptaxchkvars=arrayOf<String>()
                var spigstvars=arrayOf<String>()
                var spcgstvars=arrayOf<String>()
                var spsgstvars=arrayOf<String>()
                var spcessvars=arrayOf<String>()
                var sptaxtotvars=arrayOf<String>()
                var spcesstotvars=arrayOf<String>()
                var spmrpvars=arrayOf<String>()
                var spstock_handvars=arrayOf<String>()
                var spmin_stkvars=arrayOf<String>()
                var spmx_stkvars=arrayOf<String>()
                var statusvars=arrayOf<String>()
                var spsave_keyvars=arrayOf<String>()
                var img1nvars=arrayOf<String>()
                var img2nvars=arrayOf<String>()
                var img3nvars=arrayOf<String>()
                var img4nvars=arrayOf<String>()
                var img5nvars=arrayOf<String>()
                var img1urlvars=arrayOf<String>()
                var img2urlvars=arrayOf<String>()
                var img3urlvars=arrayOf<String>()
                var img4urlvars=arrayOf<String>()
                var img5urlvars=arrayOf<String>()

                val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)

                if (item.itemId == R.id.exsupppro) {   ///'Export Supplier's product'
                    if (exportsupppro == "true") {
                        if(prokey.text != "") {
                        val path = prokey.text.toString()
                        var ii = path.split(",")
                        println("DELIMETERSSSS" + ii.size)
                        kys = kys.plusElement(path)
                        for (i in 0 until ii.size) {
                            println("ONE BY ONE KYS OF IDDDDSSSSS " + prokey_dup.text)
                            var a = ii[i]
                            prokey_dup.setText(a)
                            a = a.trim()

                              db.collection("product").document(a)
                                      .get()
                                      .addOnCompleteListener { task ->
                                          if (task.isSuccessful) {
                                              if (task.getResult().exists()) {
                                                  if (task.result != null) {
                                                      var dd = task.result
                                                      ky = ky.plusElement(dd.id)
                                                      sp_nmvars = sp_nmvars.plusElement(dd["p_nm"].toString())
                                                      sp_idvars = sp_idvars.plusElement(dd["p_id"].toString())
                                                      spbcvars = spbcvars.plusElement(dd["bc"].toString())
                                                      spwg_volvars = spwg_volvars.plusElement(dd["wg_vol"].toString())
                                                      sputvars = sputvars.plusElement(dd["ut"].toString())
                                                      spctgyvars = spctgyvars.plusElement(dd["ctgy"].toString())
                                                      spmfrvars = spmfrvars.plusElement(dd["mfr"].toString())
                                                      sphsnvars = sphsnvars.plusElement(dd["hsn"].toString())
                                                      spdescvars = spdescvars.plusElement(dd["desc"].toString())
                                                      sppricevars = sppricevars.plusElement(dd["price"].toString())
                                                      sptaxchkvars = sptaxchkvars.plusElement(dd["taxchk"].toString())
                                                      spigstvars = spigstvars.plusElement(dd["igst"].toString())
                                                      spcgstvars = spcgstvars.plusElement(dd["cgst"].toString())
                                                      spsgstvars = spsgstvars.plusElement(dd["sgst"].toString())
                                                      spcessvars = spcessvars.plusElement(dd["cess"].toString())
                                                      sptaxtotvars = sptaxtotvars.plusElement(dd["taxtot"].toString())
                                                      spcesstotvars = spcesstotvars.plusElement(dd["cesstot"].toString())
                                                      spmrpvars = spmrpvars.plusElement(dd["mrp"].toString())
                                                      spstock_handvars = spstock_handvars.plusElement(dd["stock_hand"].toString())
                                                      spmin_stkvars = spmin_stkvars.plusElement(dd["min_stk"].toString())
                                                      spmx_stkvars = spmx_stkvars.plusElement(dd["mx_stk"].toString())
                                                      statusvars = statusvars.plusElement(dd["status"].toString())
                                                      spsave_keyvars = spsave_keyvars.plusElement(dd["supp_key"].toString())


                                                  }
                                              }
                                          }

                                      }


                                      .addOnSuccessListener {
                                          val baseDir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                                          println(baseDir)
                                          val tsLong = System.currentTimeMillis() / 1000
                                          val ts = tsLong.toString()
                                          val fileName = "SupplierProductlist$ts.xlsx";
                                          val filePath = baseDir + File.separator + fileName;
                                          println(filePath)
                                          val f = File(filePath);
                                          val writer: CSVWriter
                                          if (f.exists() && !f.isDirectory()) {
                                              val mFileWriter = FileWriter(filePath, true);
                                              writer = CSVWriter(mFileWriter, ',', CSVWriter.NO_QUOTE_CHARACTER);

                                          } else {
                                              writer = CSVWriter(FileWriter(filePath), ',', CSVWriter.NO_QUOTE_CHARACTER);

                                          }
                                          val otherStrings = arrayOf("Product Name", "Product id", "Barcode", "Weight/volume", "category", "Manufacturer", "HSN", "HSC DESCRIPTION", "price", "Taxable", "IGST", "CGST", "SGST", "CESS", "Taxtotal", "Cess total", "MRP", "Stock on hand", "MinStock", "Maxstock", "status", "savekey")
                                          writer.writeNext(otherStrings)
                                          for (i in 0 until ky.size) {
                                              val next = arrayOf(sp_nmvars[i], sp_idvars[i], spbcvars[i], spwg_volvars[i], sputvars[i], spctgyvars[i], spmfrvars[i], sphsnvars[i], spdescvars[i], sppricevars[i], sptaxchkvars[i],
                                                      spigstvars[i], spcgstvars[i], spsgstvars[i], spcessvars[i], sptaxtotvars[i], spcesstotvars[i], spmrpvars[i], spstock_handvars[i], spmin_stkvars[i], spmx_stkvars[i], statusvars[i], spsave_keyvars[i])
                                              writer.writeNext(next)
                                          }
                                          writer.close();
                                          pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                                          Toast.makeText(this, "Exported:" + filePath + " - " + fileName, Toast.LENGTH_LONG).show()
                                          pDialog1.titleText = "Exported!"
                                          pDialog1.contentText = filePath
                                          pDialog1.setConfirmText("Open")
                                          pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                          pDialog1.setConfirmClickListener {


                                              try {

                                                  pDialog1.hide()
                                                  val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + filePath, fileName)
                                                  println("SD CARD URL" + pdfFile)
                                                  val path = Uri.fromFile(pdfFile)

                                                  // Setting the intent for pdf reader
                                                  val pdfIntent = Intent(Intent.ACTION_VIEW)
                                                  pdfIntent.setDataAndType(path, "application/vnd.ms-excel")
                                                  pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

                                                  try {
                                                      startActivity(pdfIntent);
                                                  } catch (e: ActivityNotFoundException) {
                                                      Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                  }


                                              } catch (e: Exception) {
                                                  val intent = Intent(Intent.ACTION_VIEW)
                                                  val k = filePath.replace("%20", "")
                                                  val path = Environment.getExternalStorageDirectory().absolutePath + "/" + filePath + "/" + fileName
                                                  println("PATH" + path)
                                                  val targetFile = File(path)
                                                  println("TARGET PATH" + targetFile)
                                                  val targetUri = Uri.fromFile(targetFile)


                                                  try {
                                                      val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider", targetFile)
                                                      println("URI" + photoURI)
                                                      intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                      intent.setDataAndType(photoURI, "application/vnd.ms-excel")
                                                      startActivity(intent);
                                                      Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

                                                  } catch (e: Exception) {
                                                      Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                                  }

                                              }

                                          }
                                      }
                          }
                            pDialog1.show()
                        }
                        else{
                            Toast.makeText(applicationContext,"No products found",Toast.LENGTH_LONG).show()
                        }


                        } else {
                            popup("export")
                        }

                }


                true

            }

            popup.show()

        })


        //Select supplier product's list item and view or edit
        supp_prod_list.setOnItemClickListener { parent, view, position, id ->

            if(supp_prod_list.isClickable==true) {

                /*  onBackPressed()*/
                /*b.putExtra("pro_supppro", "proliclick")
                b.putExtra("idsofpro", prokey.text)
                b.putExtra("svky", saveky.text.toString())

                val sname = (textView1.text).toString()
                val sid = textView22.text.toString()
                val scon = textView33.text.toString()
                val mob = textView4.text.toString()
                val mob1 = textView5.text.toString()
                val mob2 = textView6.text.toString()
                val mobile = textView7.text.toString()
                val mobile1 = textView8.text.toString()
                val mobile2 = textView9.text.toString()
                val saddre = textView10.text.toString()
                val saddre1 = textView11.text.toString()
                val saddre2 = textView12.text.toString()
                val scity = textView13.text.toString()
                val sstate = textView14.text.toString()
                val spin = textView15.text.toString()
                val sgps = textView16.text.toString()
                val smail = textView17.text.toString()
                val sgstcode = textView18.text.toString()
                val urlim = textView19.text.toString()
                val sids = textView20.text.toString()
                val status = textView21.text.toString()
                b.putExtra("edtcli", editcli)


                b.putExtra("pro_sname1", sname)

                b.putExtra("pro_sid1", sid)
                b.putExtra("pro_scon1", scon)
                b.putExtra("pro_mob", mob)
                b.putExtra("pro_mob1", mob1)
                b.putExtra("pro_mob2", mob2)
                b.putExtra("pro_mobile", mobile)
                b.putExtra("pro_mobile1", mobile1)
                b.putExtra("pro_mobile2", mobile2)
                b.putExtra("pro_saddress", saddre)
                b.putExtra("pro_saddress1", saddre1)
                b.putExtra("listenr", savelistnr)
                b.putExtra("pro_saddress2", saddre2)
                b.putExtra("pro_scity", scity)
                b.putExtra("pro_sstate", sstate)
                b.putExtra("pro_spin", spin)
                b.putExtra("pro_sgps", sgps)
                b.putExtra("pro_smail", smail)
                b.putExtra("pro_sgstcd", sgstcode)
                b.putExtra("pro_status", status)
                b.putExtra("pro_url", urlim)
                b.putExtra("pro_sids", sids)
                b.putExtra("fieldlistenr", fieldlistener)

                b.putExtra("startlistprky",startlistprokey)
                b.putExtra("profrmprky",productprokey)
                b.putExtra("img1", fn1sup)
                b.putExtra("img2", sn1sup)
                b.putExtra("img3", tn1sup)
                b.putExtra("img4", fon1sup)
                b.putExtra("img5", fifn1sup)
                b.putExtra("url1", f1sup)
                b.putExtra("url2", s1sup)
                b.putExtra("url3", t1sup)
                b.putExtra("url4", fo1sup)
                b.putExtra("url5", fif1sup)

                b.putExtra("img1urlhigh",img1urlhigh)
                b.putExtra("img2urlhigh",img2urlhigh)
                b.putExtra("img3urlhigh",img3urlhigh)
                b.putExtra("img4urlhigh",img4urlhigh)
                b.putExtra("img5urlhigh",img5urlhigh)
                b.putExtra("img1nhigh",img1nhigh)
                b.putExtra("img2nhigh",img2nhigh)
                b.putExtra("img3nhigh",img3nhigh)
                b.putExtra("img4nhigh",img4nhigh)
                b.putExtra("img5nhigh",img5nhigh)


                b.putExtra("f1edit",f1edit)
                b.putExtra("s1edit",s1edit)
                b.putExtra("t1edit",t1edit)
                b.putExtra("fo1edit",fo1edit)
                b.putExtra("fif1edit",fif1edit)
                b.putExtra("fn1edit",fn1edit)
                b.putExtra("sn1edit",sn1edit)
                b.putExtra("tn1edit",tn1edit)
                b.putExtra("fon1edit",fon1edit)
                b.putExtra("fifn1edit",fifn1edit)
                b.putExtra("f1edithigh",f1edithigh)
                b.putExtra("s1edithigh",s1edithigh)
                b.putExtra("t1edithigh",t1edithigh)
                b.putExtra("fo1edithigh",fo1edithigh)
                b.putExtra("fif1edithigh",fif1edithigh)
                b.putExtra("fn1edithigh",fn1edithigh)
                b.putExtra("sn1edithigh",sn1edithigh)
                b.putExtra("tn1edithigh",tn1edithigh)
                b.putExtra("fon1edithigh",fon1edithigh)
                b.putExtra("fifn1edithigh",fifn1edithigh)

                b.putExtra("file_maps",file_maps)
                b.putExtra("mresultsarr",mresultsarr)

                b.putExtra("id", aps[position])
                b.putExtra("addspro", addsupppro)
                b.putExtra("viewspro", viewsupppro)
                b.putExtra("deletespro", deletesupppro)
                b.putExtra("importspro", importsupppro)
                b.putExtra("exportspro", exportsupppro)
                b.putExtra("editspro", editesupppro)*/


                var frmsupp="supplier"
                service_access = SessionManagement(this)
                user = service_access!!.userDetails
                val name = user[SessionManagement.KEY_NAME]

                val pro_access =SessionManagement(this)
                viewpro=pro_access.userDetails[SessionManagement.pview].toString()
                addpro=pro_access.userDetails[SessionManagement.padd].toString()
                deletepro=pro_access.userDetails[SessionManagement.pdelete].toString()
                editpro=pro_access.userDetails[SessionManagement.pedit].toString()
                importpro=pro_access.userDetails[SessionManagement.pimport].toString()
                exportpro=pro_access.userDetails[SessionManagement.pexport].toString()
                stockin_hand=pro_access.userDetails[SessionManagement.pstockin_hand].toString()



                val a = Intent(this@SupplierSecondmain, MainActivityScroll::class.java)

                a.putExtra("from","list")
                a.putExtra("id", aps[position])
                a.putExtra("addpro", addpro)
                a.putExtra("editpro", editpro)
                a.putExtra("deletepro", deletepro)
                a.putExtra("viewpro", viewpro)
                a.putExtra("importpro", importpro)
                a.putExtra("changestock", stockin_hand)
                a.putExtra("exportpro", exportpro)

                a.putExtra("addforsupp",frmsupp)
                a.putExtra("suppky",saveky.text.toString())
                a.putExtra("suppname",textView1.text.toString())
                a.putExtra("keybr",name)
                val prodky = prokey.text.toString()


                if (prokey.text != "") {
                    a.putExtra("prky", prodky)
                    println("PUT EXTRA OF PROKEYYYYYYSSSSS" + prodky)
                } else {

                }

                startActivityForResult(a, REQUEST_CODE_EXAMPLE1);
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                println("GET FROM LIST PRO IDDD" + aps[position])




            }
            else{

            }
        }


        //------------------------------Delete--------------------------------------------------------//


        var category = arrayListOf<String>()
        var d = arrayListOf<String>()
        var dlt = arrayListOf<String>()
        val list_item = ArrayList<String>()


        supp_prod_list.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL;
        supp_prod_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = supp_prod_list.checkedItemCount
                val l = aps[position]
                Log.i(TAG, " " + l)
                //setting CAB title
                mode.setTitle("" + checkedCount + " Selected")
                Log.d(TAG, " " + id)
                //list_item.add(id);
                if (checked) {
                    list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    Log.i(TAG, "itm " + dlt.size)
                    //Log.i(TAG,"itm "+dlt.get(position))
                } else {
                    list_item.remove(id.toString())
                    dlt.remove(l)
                    Log.i(TAG, "itm " + dlt.size)
                    Log.d(TAG, "id  " + id)
                }

            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB

                toolbar.visibility = View.GONE
                imageButtonsrch.visibility=View.GONE
                imageButtonvert.visibility=View.GONE
                textView.visibility=View.GONE
                dayview.visibility=View.GONE
                userback.visibility=View.GONE

                mode.getMenuInflater().inflate(R.menu.list, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {


                val alert=AlertDialog.Builder(this@SupplierSecondmain)
                with(alert)

                {
                    setTitle("Delete from list?")
                    setMessage("Are you sure want to delete?")
                    setPositiveButton("Yes") { dialog, whichButton ->

                        val deleteSize = dlt.size
                        Log.i("tsdfs", "  " + dlt.size)
                        /*val cate = null
                        val data = s(cat = cate)*/
                        val i = 0
                        Log.d("dlt", " " + dlt.get(i))
                        val itemId = item.getItemId()
                        if (itemId == R.id.delete) {
                            for (i in dlt) {
                                db.collection("product").document(i)
                                        .update("supp_key","")
                                        .addOnSuccessListener {
                                            dlt.clear()
                                            Toast.makeText(this@SupplierSecondmain, "Deleted", Toast.LENGTH_SHORT).show()

                                            delepros.remove(i.toString())

                                            println("dlepros"+delepros)

                                            prokey.setText(delepros.toString())


                                            var th=prokey.text.toString()
                                            var p=th.removePrefix("[")
                                            var pi=p.removeSuffix("]")
                                            prokey.text = pi

                                            println("PROKEY TEXT"+prokey.text.toString())


                                            gets()






                                            // save_progress.visibility = android.view.View.GONE

                                        }
                                        .addOnFailureListener {
                                            Toast.makeText(this@SupplierSecondmain, "not updated", Toast.LENGTH_LONG).show()
                                            //save_progress.visibility = android.view.View.GONE
                                        }
                            }

                        }

                        list_item.clear()
                        mode.finish()

                    }
                    setNegativeButton("No") { dialog, whichButton ->
                        list_item.clear()
                        mode.finish()
                        dialog.dismiss()

                    }
                    val dialog = alert.create()
                    dialog.show()
                }




                /* checkedCount = 0*/

                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                toolbar.visibility = View.VISIBLE
                imageButtonsrch.visibility=View.VISIBLE
                imageButtonvert.visibility=View.VISIBLE
                textView.visibility=View.VISIBLE
                dayview.visibility=View.VISIBLE
                userback.visibility=View.VISIBLE
            }
        })
    }

    /*public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUESTCODE_PICK_VIDEO && resultCode == Activity.RESULT_OK) {
            var sp_nm = ArrayList<String>()
            var sp_id = ArrayList<String>()
            var spbc = ArrayList<String>()
            var spwg_vol = ArrayList<String>()
            var sput = ArrayList<String>()
            var spctgy = ArrayList<String>()
            var spmfr = ArrayList<String>()
            var sphsn = ArrayList<String>()
            var spdesc = ArrayList<String>()
            var spprice = ArrayList<String>()
            var sptaxchk = ArrayList<String>()
            var spigst = ArrayList<String>()
            var spcgst = ArrayList<String>()
            var spsgst = ArrayList<String>()
            var spcess = ArrayList<String>()
            var sptaxtot = ArrayList<String>()
            var spcesstot = ArrayList<String>()
            var spmrp = ArrayList<String>()
            var spstock_hand = ArrayList<String>()
            var spmin_stk = ArrayList<String>()
            var spmx_stk = ArrayList<String>()
            var status = ArrayList<String>()
            var spsave_key = ArrayList<String>()


            data class s(var sp_nm: String,
                         var sp_id: String,
                         var spbc: String,
                         var spwg_vol: String,
                         var sput: String,
                         var spctgy: String,
                         var spmfr: String,
                         var sphsn: String,
                         var spdesc: String,
                         var spprice: String,
                         var sptaxchk: String,
                         var spigst: String,
                         var spcgst: String,
                         var spsgst: String,
                         var spcess: String,
                         var sptaxtot: String,
                         var spcesstot: String,
                         var spmrp: String,
                         var spstock_hand: String,
                         var spmin_stk: String,
                         var spmx_stk: String,
                         var status: String,
                         var spsave_key: String
            )
            if (data!!.data != null) {
                val fileUri = data.data
                Log.d("", "file URI= " + fileUri!! + "  " + fileUri.encodedPath + " " + data.data.lastPathSegment)
                val last = data.data.lastPathSegment
                val ed = last.replace("primary:", File.separator)
                val p = File(Environment.getExternalStorageDirectory()
                        .getAbsolutePath() + File.separator + ed.toString());
                val csvFile = p//Environment.getExternalStorageDirectory().absolutePath+File.separator+"servicelist.xlsx"
                println("csvFile  " + csvFile)
                var br: BufferedReader? = null
                val cvsSplitBy = ","
                try {
                    br = BufferedReader(FileReader(csvFile))
                    val li = br!!.readLine()
                    println("line 0  " + li.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                    while (br!!.readLine() != null) {
                        val line = br.readLine()
                        *//*println("line 1  " + line.split(cvsSplitBy.toRegex()))//line 1  ["key", "service name", "category", "price"]
                        println("line 2  " + line.split(cvsSplitBy.toRegex()).drop(2))//line 2  ["price"]*//*
                        //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })//line 3  ["key", "service name", "category", "price"]
                        //println("line 4  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray())//line 4  [Ljava.lang.String;@b731c54
                        try {
                            val pos = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                            //println("line 4  " + pos)
                            sp_nm.add(pos[0])
                            sp_id.add(pos[1])
                            spbc.add(pos[2])
                            spwg_vol.add(pos[3])
                            sput.add(pos[4])
                            spctgy.add(pos[5])
                            spmfr.add(pos[6])
                            sphsn.add(pos[7])
                            spdesc.add(pos[8])
                            spprice.add(pos[9])
                            sptaxchk.add(pos[10])
                            spigst.add(pos[11])
                            spcgst.add(pos[12])
                            spsgst.add(pos[13])
                            spcess.add(pos[14])
                            sptaxtot.add(pos[15])
                            spcesstot.add(pos[16])
                            spmrp.add(pos[17])
                            spstock_hand.add(pos[18])
                            spmin_stk.add(pos[19])
                            spmx_stk.add(pos[20])
                            status.add(pos[21])
                            spsave_key.add(pos[22])


                            val database = FirebaseDatabase.getInstance()
                            val myRef = database.getReference("supplier_product_counter")
                            myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                                override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                    var p = mutableData.value


                                    if (p == null) {
                                        p = 1
                                    }

                                    if (p == 0) {
                                        // Unstar the post and remove self from stars
                                        p = 1

                                    } else {
                                        // Star the post and add self to stars
                                        p = Integer.parseInt(p.toString()) + 1
                                    }

                                    // Set value and report transaction success
                                    mutableData.value = p
                                    //mutableData.setValue(p.number)
                                    return com.google.firebase.database.Transaction.success(mutableData)
                                }

                                override fun onComplete(
                                        databaseError: DatabaseError?,
                                        b: Boolean,
                                        dataSnapshot: DataSnapshot
                                ) {

                                    println(dataSnapshot)
                                    println(dataSnapshot.value)
                                    val id = dataSnapshot.value

                                    val datum = s(sp_nm = pos[0],
                                            sp_id = id.toString(),
                                            spbc = pos[2],
                                            spwg_vol = pos[3],
                                            sput = pos[4],
                                            spctgy = pos[5],
                                            spmfr = pos[6],
                                            sphsn = pos[7],
                                            spdesc = pos[8],
                                            spprice = pos[9],
                                            sptaxchk = pos[10],
                                            spigst = pos[11],
                                            spcgst = pos[12],
                                            spsgst = pos[13],
                                            spcess = pos[14],
                                            sptaxtot = pos[15],
                                            spcesstot = pos[16],
                                            spmrp = pos[17],
                                            spstock_hand = pos[18],
                                            spmin_stk = pos[19],
                                            spmx_stk = pos[20],
                                            status = pos[21],
                                            spsave_key = pos[22]
                                    )
                                    println(datum)
                                    db.collection("supplier_products")
                                            .add(datum)
                                            .addOnSuccessListener {refid ->
                                                println("data saved")
                                                var tt=refid.id
                                                prokey.setText(tt)
                                                val path = prokey.text.toString()
                                                gets()
                                            }

                                    // Transaction completed
                                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                                }
                            })


                        } catch (e: Exception) {


                        }

                       }


                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    e.printStackTrace()
                } finally {
                    if (br != null) {
                        try {
                            br!!.close()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }

                    }
                }
                val reader = BufferedReader(FileReader(csvFile))
                reader.readLine()
                val lin = reader.readLine()
                while (reader!!.readLine() != null) {
                    val line = reader.readLine()
                    if (line != null) {
                        val po = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                        //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                        sp_nm.add(po[0])
                        sp_id.add(po[1])
                        spbc.add(po[2])
                        spwg_vol.add(po[3])
                        sput.add(po[4])
                        spctgy.add(po[5])
                        spmfr.add(po[6])
                        sphsn.add(po[7])
                        spdesc.add(po[8])
                        spprice.add(po[9])
                        sptaxchk.add(po[10])
                        spigst.add(po[11])
                        spcgst.add(po[12])
                        spsgst.add(po[13])
                        spcess.add(po[14])
                        sptaxtot.add(po[15])
                        spcesstot.add(po[16])
                        spmrp.add(po[17])
                        spstock_hand.add(po[18])
                        spmin_stk.add(po[19])
                        spmx_stk.add(po[20])
                        status.add(po[21])
                        spsave_key.add(po[22])
                        //println("reader   " + line)
                        //println("snm   " + snm)
                        val database = FirebaseDatabase.getInstance()
                        val myRef = database.getReference("supplier_product_counter")
                        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                var p = mutableData.value


                                if (p == null) {
                                    p = 1
                                }

                                if (p == 0) {
                                    // Unstar the post and remove self from stars
                                    p = 1

                                } else {
                                    // Star the post and add self to stars
                                    p = Integer.parseInt(p.toString()) + 1
                                }

                                // Set value and report transaction success
                                mutableData.value = p
                                //mutableData.setValue(p.number)
                                return com.google.firebase.database.Transaction.success(mutableData)
                            }

                            override fun onComplete(
                                    databaseError: DatabaseError?,
                                    b: Boolean,
                                    dataSnapshot: DataSnapshot
                            ) {

                                println(dataSnapshot)
                                println(dataSnapshot.value)
                                val id = dataSnapshot.value

                                val datum = s(sp_nm = po[0],
                                        sp_id = id.toString(),
                                        spbc = po[2],
                                        spwg_vol = po[3],
                                        sput = po[4],
                                        spctgy = po[5],
                                        spmfr = po[6],
                                        sphsn = po[7],
                                        spdesc = po[8],
                                        spprice = po[9],
                                        sptaxchk = po[10],
                                        spigst = po[11],
                                        spcgst = po[12],
                                        spsgst = po[13],
                                        spcess = po[14],
                                        sptaxtot = po[15],
                                        spcesstot = po[16],
                                        spmrp = po[17],
                                        spstock_hand = po[18],
                                        spmin_stk = po[19],
                                        spmx_stk = po[20],
                                        status = po[21],
                                        spsave_key = po[22]
                                )
                                println(datum)
                                db.collection("supplier_products")
                                        .add(datum)
                                        .addOnSuccessListener {refid ->
                                            println("data saved")
                                            var tt=refid.id
                                            prokey.setText(tt)
                                            gets()
                                        }
                            }
                        })
                    }
                }

                println("vaeliye  " + lin)
                val po = lin.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                        val database = FirebaseDatabase.getInstance()
                        val myRef = database.getReference("supplier_product_counter")
                        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                var p = mutableData.value


                                if (p == null) {
                                    p = 1
                                }

                                if (p == 0) {
                                    // Unstar the post and remove self from stars
                                    p = 1

                                } else {
                                    // Star the post and add self to stars
                                    p = Integer.parseInt(p.toString()) + 1
                                }

                                // Set value and report transaction success
                                mutableData.value = p
                                //mutableData.setValue(p.number)
                                return com.google.firebase.database.Transaction.success(mutableData)
                            }

                            override fun onComplete(
                                    databaseError: DatabaseError?,
                                    b: Boolean,
                                    dataSnapshot: DataSnapshot
                            ) {

                                println(dataSnapshot)
                                println(dataSnapshot.value)
                                val id = dataSnapshot.value

                                val datum = s(sp_nm = po[0],
                                        sp_id = id.toString(),
                                        spbc = po[2],
                                        spwg_vol = po[3],
                                        sput = po[4],
                                        spctgy = po[5],
                                        spmfr = po[6],
                                        sphsn = po[7],
                                        spdesc = po[8],
                                        spprice = po[9],
                                        sptaxchk = po[10],
                                        spigst = po[11],
                                        spcgst = po[12],
                                        spsgst = po[13],
                                        spcess = po[14],
                                        sptaxtot = po[15],
                                        spcesstot = po[16],
                                        spmrp = po[17],
                                        spstock_hand = po[18],
                                        spmin_stk = po[19],
                                        spmx_stk = po[20],
                                        status = po[21],
                                        spsave_key = po[22]
                                )
                                println(datum)
                                db.collection("supplier_products")
                                        .add(datum)
                                        .addOnSuccessListener {refid ->
                                            println("data saved")
                                            var tt=refid.id
                                            prokey.setText(tt)
                                            gets()

                                        }
                            }
                        })
            }
        }
    }*/




    fun popup(st:String){    ///Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {

        if(cardsearch.visibility==View.VISIBLE)
        {
            cardsearch.visibility=View.GONE
            gets()
        }
        else {
           val `in`: Intent
           `in` = Intent(baseContext, SupplierAddMain::class.java)
                        val sname = (textView1.text).toString()
                    println("NAME"+sname +textView1.text)
                        val sid = textView22.text.toString()
                        val scon = textView33.text.toString()
                        val mob = textView4.text.toString()
                        val mob1 = textView5.text.toString()
                        val mob2 = textView6.text.toString()
                        val mobile = textView7.text.toString()
                        val mobile1 = textView8.text.toString()
                        val mobile2 = textView9.text.toString()
                        val saddre = textView10.text.toString()
                        val saddre1 = textView11.text.toString()
                        val saddre2 = textView12.text.toString()
                        val scity = textView13.text.toString()
                        val sstate = textView14.text.toString()
                        val spin = textView15.text.toString()
                        val sgps = textView16.text.toString()
                        val smail = textView17.text.toString()
                        val sgstcode = textView18.text.toString()
                        val urlim = textView19.text.toString()
                        val sids = textView21.text.toString()
                        println("IDDDDSSSS OOOFFFF RRREAAAL   " + textView21.text)

                        val status = textView20.text.toString()
                        val prodky = prokey.text.toString()
                        val svsky = saveky.text.toString()

                        println("READY TO SEND TO SUPPLIER ADDDDD" + prodky)
                        if (prokey.text != "") {
                            `in`.putExtra("prky", prodky)
                        } else {

                        }
                        `in`.putExtra("sname1", sname)
                        `in`.putExtra("supppro", "productfrm")
                        `in`.putExtra("sid1", sid)
                        `in`.putExtra("scon1", scon)
                        `in`.putExtra("mob", mob)
                        `in`.putExtra("mob1", mob1)
                        `in`.putExtra("mob2", mob2)
                        `in`.putExtra("mobile", mobile)
                        `in`.putExtra("mobile1", mobile1)
                        `in`.putExtra("mobile2", mobile2)
                        `in`.putExtra("saddress", saddre)
                        `in`.putExtra("saddress1", saddre1)
                        `in`.putExtra("listnrsaves", savelistnr)
                        `in`.putExtra("fieldlistnrsaves", fieldlistener)
                        `in`.putExtra("startlistprky",startlistprokey)
                        `in`.putExtra("profrmprky",productprokey)

                        `in`.putExtra("saddress2", saddre2)
                        `in`.putExtra("scity", scity)
                        `in`.putExtra("sstate", sstate)
                        `in`.putExtra("spin", spin)
                        `in`.putExtra("sgps", sgps)
                        `in`.putExtra("smail", smail)
                        `in`.putExtra("sgstcd", sgstcode)
                        `in`.putExtra("status", status)
                        `in`.putExtra("url", urlim)
                        `in`.putExtra("sids", sids)
                        `in`.putExtra("svsky", svsky)
                        `in`.putExtra("editclisupp",editcli)

                        `in`.putExtra("img1", fn1sup)
                        `in`.putExtra("img2", sn1sup)
                        `in`.putExtra("img3", tn1sup)
                        `in`.putExtra("img4", fon1sup)
                        `in`.putExtra("img5", fifn1sup)
                        `in`.putExtra("url1", f1sup)
                        `in`.putExtra("url2", s1sup)
                        `in`.putExtra("url3", t1sup)
                        `in`.putExtra("url4", fo1sup)
                        `in`.putExtra("url5", fif1sup)


           `in`.putExtra("img1urlhigh",img1urlhigh)
           `in`.putExtra("img2urlhigh",img2urlhigh)
           `in`.putExtra("img3urlhigh",img3urlhigh)
           `in`.putExtra("img4urlhigh",img4urlhigh)
           `in`.putExtra("img5urlhigh",img5urlhigh)
           `in`.putExtra("img1nhigh",img1nhigh)
           `in`.putExtra("img2nhigh",img2nhigh)
           `in`.putExtra("img3nhigh",img3nhigh)
           `in`.putExtra("img4nhigh",img4nhigh)
           `in`.putExtra("img5nhigh",img5nhigh)


            `in`.putExtra("f1edit",f1edit)
            `in`.putExtra("s1edit",s1edit)
            `in`.putExtra("t1edit",t1edit)
            `in`.putExtra("fo1edit",fo1edit)
            `in`.putExtra("fif1edit",fif1edit)
            `in`.putExtra("fn1edit",fn1edit)
            `in`.putExtra("sn1edit",sn1edit)
            `in`.putExtra("tn1edit",tn1edit)
            `in`.putExtra("fon1edit",fon1edit)
            `in`.putExtra("fifn1edit",fifn1edit)
            `in`.putExtra("f1edithigh",f1edithigh)
            `in`.putExtra("s1edithigh",s1edithigh)
            `in`.putExtra("t1edithigh",t1edithigh)
            `in`.putExtra("fo1edithigh",fo1edithigh)
            `in`.putExtra("fif1edithigh",fif1edithigh)
            `in`.putExtra("fn1edithigh",fn1edithigh)
            `in`.putExtra("sn1edithigh",sn1edithigh)
            `in`.putExtra("tn1edithigh",tn1edithigh)
            `in`.putExtra("fon1edithigh",fon1edithigh)
            `in`.putExtra("fifn1edithigh",fifn1edithigh)

            `in`.putExtra("file_maps",file_maps)
            `in`.putExtra("mresultsarr",mresultsarr)

                        `in`.putExtra("addspro", addsupppro)
                        `in`.putExtra("editspro", editesupppro)
                        `in`.putExtra("viewspro", viewsupppro)
                        `in`.putExtra("deletespro", deletesupppro)
                        `in`.putExtra("importspro", importsupppro)
                        `in`.putExtra("exportspro", exportsupppro)







                    startActivity(`in`)
                        overridePendingTransition(0, 0)
                        finish()
        }

    }

    //--------------------------------Get supplier's products and list out from online db------------------//
    fun gets() {
        noresfo.visibility=View.GONE
        if (prokey.text != "") {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            var idpArray = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var sunbnmArray = arrayOf<String>()
            var bcArray = arrayOf<String>()
            var sohArray = arrayOf<String>()

            var mlArray = arrayOf<String>()
            var mhArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var disproArray = arrayOf<String>()
            var primgArray = arrayOf<String>()
            var icohighArray = arrayOf<String>()
            var icohighnmArray = arrayOf<String>()

            var db = FirebaseFirestore.getInstance()
            suppprodprogress.visibility = android.view.View.VISIBLE
            val path = prokey.text.toString()
            var ii = path.split(",")
            println("DELIMETERSSSS" + ii.size)
            kys = kys.plusElement(path)
            for (i in 0 until ii.size) {
                println("ONE BY ONE KYS OF IDDDDSSSSS " + prokey_dup.text)
                var a = ii[i]
                prokey_dup.setText(a)
                a = a.trim()
                println("RECORDS OF PRODUCT KEYYYYYSSSSS ," + a)
                delepros.add(a)
                db.collection("product").document(a)
                        .get()
                        .addOnCompleteListener { task ->
                            println(task.result)
                            if (task.isSuccessful) {
                                if (task.getResult().exists()) {
                                    imageView10.visibility=View.GONE
                                    dayview.visibility=View.VISIBLE
                                    supp_prod_list.visibility=View.VISIBLE
                                    if (task.result != null) {



                                        println("TASK RESULT" + task.result.get("p_nm").toString())
                                        var name = task.result.get("p_nm").toString()
                                        var mble = task.result.get("wg_vol").toString()
                                        var manufacturer = task.result.get("mfr").toString()
                                        var ut=task.result.get("ut").toString()
                                        var stkonhand = task.result.get("stock_hand").toString()
                                        var maxstock = task.result.get("mx_stk").toString()
                                        var price = task.result.get("mrp").toString()
                                        var dispro = task.result.get("status").toString()
                                        var barcodeid = task.result.get("bc").toString()
                                        try {
                                            supd = task.result.get("supp_add").toString()
                                        }
                                        catch (e:Exception){

                                        }



                                        try {
                                            var im = task.result.get("img1url").toString()

                                            val high = task.result.get("img1urlhigh").toString()
                                            val highnm = task.result.get("img1nhigh").toString()

                                            icohighnmArray=icohighnmArray.plusElement(highnm)
                                            icohighArray=icohighArray.plusElement(high)


                                            if(im.isNotEmpty()){

                                                primgArray=primgArray.plusElement(im)
                                            }
                                            else {
                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                            }
                                        }
                                        catch (e:Exception){

                                        }

                                        if(barcodeid.isEmpty()){
                                            bcArray=bcArray.plusElement("Not Available")
                                        }
                                        else if(barcodeid.isNotEmpty()){
                                            bcArray = bcArray.plusElement(barcodeid)
                                        }


                                        var idp = task.result.id

                                        nameArray = nameArray.plusElement(name)
                                        if((mble.isEmpty())&&(ut!="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        else if((mble.isNotEmpty())&&(ut!="Select")){
                                            mlArray = mlArray.plusElement(mble+ut)

                                        }
                                        else if((mble.isNotEmpty())&&(ut=="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        else if((mble.isEmpty())&&(ut=="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        if((manufacturer=="Select")||(manufacturer.isEmpty())){
                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                        }
                                        else if((manufacturer!="Select")&&(manufacturer.isNotEmpty())){
                                            sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                        }

                                        sohArray = sohArray.plusElement(stkonhand)
                                        mhArray = mhArray.plusElement(maxstock)
                                        priceArray = priceArray.plusElement(price)
                                        disproArray = disproArray.plusElement(dispro)
                                        idpArray = idpArray.plusElement(idp)
                                        aps = idpArray

                                        try {

                                            if ((supd != "list") || (supd.isEmpty())||(frmadd=="addpage")) {
                                                db.collection("product").document(a)
                                                        .update("supp_add", "add")
                                                        .addOnSuccessListener {

                                                        }
                                            }
                                        }
                                        catch (e:Exception){

                                        }

                                        println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))
                                        /*swipeContainer.setRefreshing(false);*/

                                        pDialog.dismiss()


                                        idpArraydup=idpArray
                                        nameArraydup=nameArray
                                        sunbnmArraydup=sunbnmArray
                                        bcArraydup=bcArray
                                        sohArraydup=sohArray
                                        mlArraydup=mlArray
                                        mhArraydup=mhArray
                                        priceArraydup=priceArray
                                        disproArraydup=disproArray
                                        primgArraydup=primgArray

                                        icohighArraydup=icohighArray
                                        icohighnmArraydup=icohighnmArray


                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray,
                                                bcArray, sohArray, priceArray, mhArray, mlArray, primgArray,icohighnmArray,icohighArray)
                                        supp_prod_list.adapter = whatever
                                        suppprodprogress.visibility = View.GONE

                                        for(i in 0 until priceArray.count()){


                                            dayview.setText((i+1).toString()+" options")

                                        }

                                    }
                                    else{


                                        dayview.setText("0 options")
                                    }


                                } else {

                                    imageView10.visibility=View.VISIBLE
                                    supp_prod_list.visibility=View.GONE
                                    suppprodprogress.visibility = View.GONE
                                    dayview.setText("0 options")
                                    pDialog.dismiss()
                                    println("NO RECORDSSSS FOUND")
                                }


                            } else {
                                Log.w(TAG, "Error getting documents.", task.exception)
                            }
                        }
            }

        } else {
            suppprodprogress.visibility = View.GONE
            imageView10.visibility=View.VISIBLE
            supp_prod_list.visibility=View.GONE
            dayview.setText("0 options")
            Toast.makeText(applicationContext, "No supplier products found", Toast.LENGTH_SHORT).show()
        }
    }


    //--------------------------------Get supplier's products and list out from online db------------------//


    fun getsseladd() {
        if (prokey.text != "") {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            var idpArray = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var sunbnmArray = arrayOf<String>()
            var bcArray = arrayOf<String>()
            var sohArray = arrayOf<String>()

            var mlArray = arrayOf<String>()
            var mhArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var disproArray = arrayOf<String>()
            var primgArray = arrayOf<String>()
            var icohighArray = arrayOf<String>()
            var icohighnmArray = arrayOf<String>()

            var db = FirebaseFirestore.getInstance()
            suppprodprogress.visibility = android.view.View.VISIBLE
            val path = prokey.text.toString()
            var ii = path.split(",")
            println("DELIMETERSSSS" + ii.size)
            kys = kys.plusElement(path)
            for (i in 0 until ii.size) {
                println("ONE BY ONE KYS OF IDDDDSSSSS " + prokey_dup.text)
                var a = ii[i]
                prokey_dup.setText(a)
                a = a.trim()
                println("RECORDS OF PRODUCT KEYYYYYSSSSS ," + a)
                delepros.add(a)
                db.collection("product").document(a)
                        .get()
                        .addOnCompleteListener { task ->
                            println(task.result)
                            if (task.isSuccessful) {
                                if (task.getResult().exists()) {
                                    imageView10.visibility=View.GONE
                                    dayview.visibility=View.VISIBLE
                                    supp_prod_list.visibility=View.VISIBLE
                                    if (task.result != null) {



                                        println("TASK RESULT" + task.result.get("p_nm").toString())
                                        var name = task.result.get("p_nm").toString()
                                        var mble = task.result.get("wg_vol").toString()
                                        var manufacturer = task.result.get("mfr").toString()
                                        var ut=task.result.get("ut").toString()
                                        var stkonhand = task.result.get("stock_hand").toString()
                                        var maxstock = task.result.get("mx_stk").toString()
                                        var price = task.result.get("mrp").toString()
                                        var dispro = task.result.get("status").toString()
                                        var barcodeid = task.result.get("bc").toString()
                                        var ff=task.result.get("supp_key").toString()
                                        try {
                                            var im = task.result.get("img1url").toString()

                                            val high = task.result.get("img1urlhigh").toString()
                                            val highnm = task.result.get("img1nhigh").toString()

                                            icohighnmArray=icohighnmArray.plusElement(highnm)
                                            icohighArray=icohighArray.plusElement(high)


                                            if(im.isNotEmpty()){

                                                primgArray=primgArray.plusElement(im)
                                            }
                                            else {
                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                            }
                                        }
                                        catch (e:Exception){

                                        }

                                        if(barcodeid.isEmpty()){
                                            bcArray=bcArray.plusElement("Not Available")
                                        }
                                        else if(barcodeid.isNotEmpty()){
                                            bcArray = bcArray.plusElement(barcodeid)
                                        }


                                        var idp = task.result.id

                                        nameArray = nameArray.plusElement(name)
                                        if((mble.isEmpty())&&(ut!="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        else if((mble.isNotEmpty())&&(ut!="Select")){
                                            mlArray = mlArray.plusElement(mble+ut)

                                        }
                                        else if((mble.isNotEmpty())&&(ut=="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        else if((mble.isEmpty())&&(ut=="Select")){
                                            mlArray = mlArray.plusElement("")
                                        }
                                        if((manufacturer=="Select")||(manufacturer.isEmpty())){
                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")

                                        }
                                        else if((manufacturer!="Select")&&(manufacturer.isNotEmpty())){
                                            sunbnmArray = sunbnmArray.plusElement(manufacturer)

                                        }

                                        sohArray = sohArray.plusElement(stkonhand)
                                        mhArray = mhArray.plusElement(maxstock)
                                        priceArray = priceArray.plusElement(price)
                                        disproArray = disproArray.plusElement(dispro)
                                        idpArray = idpArray.plusElement(idp)
                                        aps = idpArray


                                        if(ff.isEmpty()) {
                                            db.collection("product").document(a)
                                                    .update("supp_key", saveky.text.toString())

                                                    .addOnSuccessListener {

                                                            db.collection("product").document(a)
                                                                    .update("supp_add", "list")
                                                                    .addOnSuccessListener {

                                                                    }

                                                    }
                                        }


                                        println("GET FROM LIST PRO IDDD" + Arrays.toString(aps))
                                        /*swipeContainer.setRefreshing(false);*/

                                        pDialog.dismiss()


                                        idpArraydup=idpArray
                                        nameArraydup=nameArray
                                        sunbnmArraydup=sunbnmArray
                                        bcArraydup=bcArray
                                        sohArraydup=sohArray
                                        mlArraydup=mlArray
                                        mhArraydup=mhArray
                                        priceArraydup=priceArray
                                        disproArraydup=disproArray
                                        primgArraydup=primgArray

                                        icohighArraydup=icohighArray
                                        icohighnmArraydup=icohighnmArray


                                        val whatever = supp_second__list_adap(this@SupplierSecondmain, idpArray, disproArray, nameArray, sunbnmArray, bcArray, sohArray, priceArray, mhArray, mlArray, primgArray,icohighnmArray,icohighArray)
                                        supp_prod_list.adapter = whatever
                                        suppprodprogress.visibility = View.GONE

                                        for(i in 0 until priceArray.count()){


                                            dayview.setText((i+1).toString()+" options")

                                        }

                                    }
                                    else{


                                        dayview.setText("0 options")
                                    }


                                } else {

                                    imageView10.visibility=View.VISIBLE
                                    supp_prod_list.visibility=View.GONE
                                    suppprodprogress.visibility = View.GONE
                                    dayview.setText("0 options")
                                    pDialog.dismiss()
                                    println("NO RECORDSSSS FOUND")
                                }


                            } else {
                                Log.w(TAG, "Error getting documents.", task.exception)
                            }
                        }
            }

        } else {
            suppprodprogress.visibility = View.GONE
            imageView10.visibility=View.VISIBLE
            supp_prod_list.visibility=View.GONE
            dayview.setText("0 options")
            Toast.makeText(applicationContext, "No supplier products found", Toast.LENGTH_SHORT).show()
        }
    }



    //-------------------------GET product keys--------------------//
    fun prokydiv(){
        try {


            var o=prosavesingleky
            var p=o.removePrefix("[")
            var pi=p.removeSuffix("]")



            prokey.text = pi
            delepros.clear()
            println("COMEEEEE IDDDDDD  "+prokey.text)


            gets()



        }
        catch (e:Exception) {

        }
    }

    //-------------------------GET product keys--------------------//

    fun prokydivseladd(){
        try {


            var o=prosavesingleky
            var p=o.removePrefix("[")
            var pi=p.removeSuffix("]")



            prokey.text = pi
            delepros.clear()
            println("COMEEEEE IDDDDDD  "+prokey.text)


            getsseladd()



        }
        catch (e:Exception) {

        }
    }
    companion object {

        //Listens internet status whether net is on/off.

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var bottonNavBardis:LinearLayout?=null
        private var relatively:RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null
        private var payment_tk_PGdis:LinearLayout?=null
        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                /// if connection is off then all views becomes disable


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                bottonNavBardis!!.visibility=View.GONE
                payment_tk_PGdis!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                /// if connection is off then all views becomes enabled

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                bottonNavBardis!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            2 -> {          // From 'MainActivityScroll' result
                if ((resultCode == Activity.RESULT_OK)) {

                    frmadd="addpage"

                    val  result = data!!.getStringExtra("proky");
                    prosavesingleky=result
                    println("RESULT NAME"+prosavesingleky)
                    prokydiv()




                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")
                        println("RESULT NAME"+textView1.text.toString())

                    }
                }

            }
            21 -> {  // From 'SuppSelectActivity' result
                if ((resultCode == Activity.RESULT_OK)) {

                    val  result = data!!.getStringExtra("proky");
                    prosavesingleky=result
                    println("RESULT NAME"+prosavesingleky)
                    prokydivseladd()




                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")
                        println("RESULT NAME"+textView1.text.toString())

                    }
                }

            }
            23 -> {
                if ((resultCode == Activity.RESULT_OK)) {

                    val  result = data!!.getStringExtra("proky");
                    prosavesingleky=result
                    println("RESULT NAME"+prosavesingleky)
                    prokydiv()




                }
                else{
                    if ((resultCode == Activity.RESULT_CANCELED)){
                        println("RESULT CANCELLED")
                        println("RESULT NAME"+textView1.text.toString())

                    }
                }

            }
        }
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}







       /* imageButtonvert.setOnClickListener({


            val popup = PopupMenu(this@SupplierSecondFragment, imageButtonvert)

            popup.menuInflater.inflate(R.menu.menu, popup.menu)

            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@SupplierSecondFragment, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()

                true

            }

            popup.show()

        })
*/
       /* d_fab.setOnClickListener {
            val intent=Intent(this@SupplierSecondFragment,MainActivityScroll::class.java)
            startActivity(intent)
     */

