package com.example.vinitas.inventory_app
/**
 * Created by Vinitas on 22-12-2017.
 */
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import com.squareup.picasso.Picasso

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.scroll_branch_one.*
import java.io.File
import java.nio.file.Files.size



/**
 * Created by vinitas IT on 13-12-2017.
 */
class scrolladd_stock_one_adap(//to reference the Activity
        private val context: Activity,
        //to store the list of countries
        private val pronameArray:   ArrayList<String>,
        /* private val idArray:   ArrayList<String>,*/ //to store the list of countries
        private val manufacturerArray:  ArrayList<String>,
        private val hsnArray:  ArrayList<String>,
        private val barcodeArray :     ArrayList<String>,
        private val quantityArray:    ArrayList<String>,
        private val priceArray:  ArrayList<String>,
        private val totArray:  ArrayList<String>,
        private val cessArray:  ArrayList<String>,
        private val keyArray:  ArrayList<String>,
        private val igstArray:  ArrayList<String>,
        private val igsttotArray:  ArrayList<String>,
        private val cesstotArray:  ArrayList<String>,
        private val tallyArray:  ArrayList<String>,
        private val receivedArray:  ArrayList<String>,
        private val productImArray: ArrayList<String>
        ): ArrayAdapter<Any>(context, R.layout.act_stock_first_items, pronameArray as List<Any>) {


    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val u=position
        val rowView = inflater.inflate(R.layout.act_stock_first_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val nameTextField = rowView.findViewById<View>(R.id.pnm) as TextView
        /*       val idTextField = rowView.findViewById<View>(R.id.id) as TextView*/
        val subnameTextField = rowView.findViewById<View>(R.id.psubnm) as TextView
        val hsnTextField = rowView.findViewById<View>(R.id.hsn) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.bc) as TextView
        val cessTextField = rowView.findViewById<View>(R.id.cess) as TextView
        val sohnameTextField = rowView.findViewById<View>(R.id.soh) as TextView
        val totnameTextField = rowView.findViewById<View>(R.id.tot) as  TextView
        val pricenameTextField = rowView.findViewById<View>(R.id.price) as TextView
        val keyarrayTextField = rowView.findViewById<View>(R.id.keyarr) as TextView
        val igstarrayTextField = rowView.findViewById<View>(R.id.Igst) as TextView
        val igsttotarrayTextField = rowView.findViewById<View>(R.id.igsttot) as TextView
        val cesstotarrayTextField = rowView.findViewById<View>(R.id.cesstot) as TextView
        val tallyarrayTextField = rowView.findViewById<View>(R.id.tally) as TextView
        val receivearrayTextField = rowView.findViewById<View>(R.id.received) as TextView
        val productim= rowView.findViewById<View>(R.id.primg) as CircleImageView

        val bc=rowView.findViewById<View>(R.id.textView10) as TextView
        val rec=rowView.findViewById<View>(R.id.textView12) as TextView

        //this code sets the values of the objects to values from the arrays
        nameTextField.text = pronameArray[position]
        /*   idTextField.text = idArray[position]*/
        subnameTextField.text = manufacturerArray[position]
        cessTextField.text = cessArray[position]
        totnameTextField.text=totArray[position]
        hsnTextField.text = hsnArray[position]
        bcnameTextField.text=barcodeArray[position]
        sohnameTextField.text=quantityArray[position]
        pricenameTextField.text = priceArray[position]
        keyarrayTextField.text = keyArray[position]
        igstarrayTextField.text=igstArray[position]
        igsttotarrayTextField.text=igsttotArray[position]
        cesstotarrayTextField.text=cesstotArray[position]
        tallyarrayTextField.text=tallyArray[position]
        receivearrayTextField.text=receivedArray[position]




        try {
            if (context.br_st__list.isClickable == false) {

                nameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cessTextField.setTextColor(Color.parseColor("#d3d3d3"));
                totnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                hsnTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bcnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                sohnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                pricenameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                keyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                igstarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));

                igsttotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                tallyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                receivearrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                subnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bc.setTextColor(Color.parseColor("#d3d3d3"));
                rec.setTextColor(Color.parseColor("#d3d3d3"));

            }


            if (context.br_st__list.isClickable == true) {


                nameTextField.setTextColor(Color.parseColor("#000000"));
                cessTextField.setTextColor(Color.parseColor("#666666"));
                totnameTextField.setTextColor(Color.parseColor("#666666"));
                hsnTextField.setTextColor(Color.parseColor("#666666"));
                bcnameTextField.setTextColor(Color.parseColor("#666666"));
                sohnameTextField.setTextColor(Color.parseColor("#808080"));
                pricenameTextField.setTextColor(Color.parseColor("#666666"));
                keyarrayTextField.setTextColor(Color.parseColor("#666666"));
                igstarrayTextField.setTextColor(Color.parseColor("#666666"));

                igsttotarrayTextField.setTextColor(Color.parseColor("#666666"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#666666"));
                tallyarrayTextField.setTextColor(Color.parseColor("#666666"));
                receivearrayTextField.setTextColor(Color.parseColor("#808080"));
                subnameTextField.setTextColor(Color.parseColor("#666666"));
                bc.setTextColor(Color.parseColor("#666666"));
                rec.setTextColor(Color.parseColor("#666666"));
                bc.setTextColor(Color.parseColor("#666666"));
                rec.setTextColor(Color.parseColor("#666666"));

            }


        }
        catch (e:Exception){

        }

        try {
            Picasso.with(context)
                    .load(productImArray[position])
                    .into(productim);
        }
        catch (e:Exception){

        }


        if(barcodeArray[position]==" - "){
            bcnameTextField.setText("NA")
        }


        /*productim.setOnClickListener {position
            val kd = imnmhigh[position]
            println("IMAG NAME VIEW"+kd)

            val k=productim.drawable


            println("POSITION OF ICO"+position)

            val jk=context.findViewById<ListView>(R.id.product_list) as ListView

            jk.isEnabled=false
            jk.isClickable=false


            val kj=context.findViewById<ConstraintLayout>(R.id.conststk) as ConstraintLayout
            kj.setBackgroundColor(Color.parseColor("#43161616"))
            zoomImageFromThumb(productim,k,position)


        }*/




        //infoTextField.text = infoArray[position]




        return rowView



    }



}