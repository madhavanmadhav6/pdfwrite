package com.example.vinitas.inventory_app

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.squareup.picasso.Picasso
import com.vansuita.pickimage.bean.PickResult
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import com.vansuita.pickimage.listeners.IPickResult
import kotlinx.android.synthetic.main.activity_setdefault.view.*


import kotlinx.android.synthetic.main.supplier_third.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*



class Supplier_thirdMainActivity : AppCompatActivity(),IPickResult {

    private val datePicker: DatePicker? = null
    private var calendar: Calendar? = null
    private var dateView: TextView? = null

    private var dateView1: TextView? = null

    private var year: Int = 0
    private var month: Int = 0
    private var day: Int = 0

    private val myDateListener = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day
        showDate(arg1, arg2 + 1, arg3)

    }

    private val myDateListener1 = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day

        showDate1(arg1, arg2 + 1, arg3)
    }
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()

    var prodnms = arrayOf<String>()
    var brnchids = String()


    var vounodup=String()
    var statdup=String()
    var invoicedatedup=String()
    var payduedatedup=String()
    var suppdescripdup=String()

    var savecli=String()
    var imgname= String()

    var imgnameedit= String()

    var db= FirebaseFirestore.getInstance()
    var TAG="some"


    var frmval= String()

    data class s(

            var voucher_number: String,
            var branchid: String,
            var date: Any,
            var datest: Any,
            var invoice_date: Any,
            var payment_duedate: Any,
            var description: Any,
            var igst_tot : Any,
            var cgst_tot : Any,
            var sgst_tot : Any,
            var cess_tot : Any,
            var gross_tot : Any,
            var status : Any,
            var prod_nms : Any,
            var supplier_name : Any,
            var supplier_phone : Any,
            var imgurl:Any,
            var imagename:Any,
            var stk_brid:Any,
            var voucher_id:Any

            /*    var stk_wg_vol: Any,
                var stk_name: String,
                var stk_mfr: String,

                var taxchk: Any*/
    )
    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_cgst: Any,
            var otherstk_sgst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_received: Any,
            var received_price: Any,
            var received_taxtotal: Any,
            var received_cesstotal: Any,
            var otherstk_img:Any,
            var received_grosstotal: Any,
            var received_total: Any,

            var stk_key:Any
    )


    var pronameArray = arrayOf<String>()
    var hsnArray = arrayOf<String>()
    var manufacturerArray = arrayOf<String>()
    var barcodeArray = arrayOf<String>()
    var quantityArray = arrayOf<String>()
    var priceArray = arrayOf<String>()
    var totArray = arrayOf<String>()
    var cessArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var igstArray = arrayOf<String>()
    var cgstArray = arrayOf<String>()
    var sgstArray = arrayOf<String>()
    var igsttotArray = arrayOf<String>()
    var cesstotalArray = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var receivedpriceArray = arrayOf<String>()
    var receivedtotalArray = arrayOf<String>()
    var receivedcesstotArray = arrayOf<String>()
    var receivedtaxtotalArray = arrayOf<String>()
    var receivedgrosstotArray = arrayOf<String>()
    var imageArray = arrayOf<String>()
    var ids = arrayOf<String>()

    var vou_id=String()

    var descriplistener= String()

    var editclick= String()
    var listListener= String()
    var deletelistener=String()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplier_third)


        net_status() //Check internet status.
        calendar = Calendar.getInstance()
        year = calendar!!.get(Calendar.YEAR)
        month = calendar!!.get(Calendar.MONTH)
        day = calendar!!.get(Calendar.DAY_OF_MONTH)

        dateView =  findViewById<TextView>(R.id.textView49)
        dateView1=findViewById<TextView>(R.id.textView50)

        showDate(year, month + 1, day)
        showDate1(year, month + 1, day)

//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Supplier_thirdMainActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }

 //Define No connection view and other views when inetrnet connection is off.
        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)

        userbackdis=findViewById(R.id.userback)
        mnudis=findViewById(R.id.mnu)
        editdis=findViewById(R.id.edit)
        savedis=findViewById(R.id.save)
        vounodis=findViewById(R.id.vouno)
        suppdescripdis=findViewById(R.id.suppdescrip)
        invoicedatedis=findViewById(R.id.invoicedate)
        payduedatedis=findViewById(R.id.payduedate)
        imageButton2dis=findViewById(R.id.imageButton2)
        paidspin2dis=findViewById(R.id.paidspin2)

        bottnav = findViewById(R.id.bottonNavBar)
        addLogText(NetworkUtil.getConnectivityStatusString(this@Supplier_thirdMainActivity))

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)



        val bundle = intent.extras
        var frm = bundle!!.get("from_suppin").toString()
        val dl = intent.getStringArrayExtra("id")

        listoids.setText(Arrays.toString(dl))
        var t=listoids.text
        var u=t.removePrefix("[")
        var ui=u.removeSuffix("]")
        listoids.setText(ui)





        //Click imageview and show it on popup and navigate to zoom activity when clicking popup.
        card.setOnClickListener {


            if(edit.visibility==View.GONE) {

                if (imgurl.text.toString().isNotEmpty() == true) {


                    var redrawb = card.drawable

                    val alert = AlertDialog.Builder(this@Supplier_thirdMainActivity)
                    val inflater = this.layoutInflater
                    /*with(alert) {
setTitle("Select Branch")
}*/
                    val dialog = alert.create()
                    dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                    dialog.show()
                    val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                    stkedt.setImageDrawable(redrawb)
                    val bitmap = (redrawb as BitmapDrawable).getBitmap()
                    val baos = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                    val b = baos.toByteArray()

                    stkedt.setOnClickListener {
                        val k = Intent(this@Supplier_thirdMainActivity, ZoomActivity::class.java)
                        k.putExtra("imgurl", imgurl.text.toString())
                        k.putExtra("drawb", b)
                        dialog.dismiss()
                        startActivity(k)


                    }


                    val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                    val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                    okact.setOnClickListener {

                        PickImageDialog.build(PickSetup()).show(this)
                        dialog.dismiss()


                    }
                    cancelact.setOnClickListener {
                        dialog.dismiss()
                    }
                } else {
                    PickImageDialog.build(PickSetup()).show(this)
                }
            }
            else{

            }

        }




       /* invoicedate.setOnClickListener(View.OnClickListener {
            errinv.visibility=View.INVISIBLE
            errinv.setError(null)
            invoicedate.setError(null)
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
          val fragment =  DatePickerFragment();
        fragment.setup(cldr, DatePickerDialog.OnDateSetListener() { datePicker: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            invoicedate.setText(dayOfMonth.toString() + "/" + (month + 1) + "/" + year)
        });
            fragment.show(getSupportFragmentManager(), null);

        })*/

      /*  payduedate.setOnClickListener(View.OnClickListener {
            errpaydue.visibility=View.INVISIBLE
            errpaydue.setError(null)
            payduedate.setError(null)
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@Supplier_thirdMainActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> payduedate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })*/




        if(imgurl.text.toString().isNotEmpty()==true){

            imageButton2.visibility= View.GONE
            imageView4.visibility=View.GONE
        }


        edit.setOnClickListener {

            if(editesuppin=="true") {

                editclick="clicked"
                supp_third_list.isEnabled=true

                save.visibility = View.VISIBLE
                edit.visibility = View.GONE
                mnu.visibility=View.VISIBLE

                vouno.isEnabled=true
                paidspin.isEnabled=true
                suppdescrip.isEnabled=true
                payduedate.isEnabled=true
                invoicedate.isEnabled=true
                fab.isEnabled=true
                imageButton2.isEnabled=true


              /*  val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,receivedtotalArray, imageArray)
                supp_third_list.adapter = whatever
                Helper.getListViewSize(supp_third_list);*/

            }
            else if(editesuppin=="false"){
                popup("Edit")
            }

        }


        names.setText("")


        //--------------------------------Bottom navigation to view product list (supplierFiveMainAct) -----------------//
        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val suppadd: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.matching -> {

                }
                R.id.watchList -> {
                    val b = Intent(this@Supplier_thirdMainActivity, supplierFiveMainAct::class.java)

                    b.putExtra("from_suppin", "update_suppinvoice")
                    b.putExtra("pnm", pronameArray)
                    b.putExtra("pmanu", manufacturerArray)
                    b.putExtra("phsn", hsnArray)
                    b.putExtra("barcode", barcodeArray)
                    b.putExtra("price", priceArray)
                    b.putExtra("quan", quantityArray)
                    b.putExtra("tot", totArray)

                    b.putExtra("cessup", cessArray)
                    b.putExtra("igst", igstArray)
                    b.putExtra("cgst", cgstArray)
                    b.putExtra("sgst", sgstArray)
                    b.putExtra("igsttotal", igsttotArray)
                    b.putExtra("cesstotarray", cesstotalArray)
                    b.putExtra("tallyarray", tallyArray)
                    b.putExtra("receivedarray", receivedArray)
                    b.putExtra("received_price", receivedpriceArray)
                    b.putExtra("received_total", receivedtotalArray)
                    b.putExtra("received_taxtot", receivedtaxtotalArray)
                    b.putExtra("received_cesstot", receivedcesstotArray)
                    b.putExtra("received_grosstot", receivedgrosstotArray)
                    b.putExtra("idsofli", keyArray)
                    b.putExtra("datest", dates.text.toString())
                    b.putExtra("image", imageArray)
                    b.putExtra("reprnms", names.text.toString())
                    b.putExtra("reqliid", listoids.text.toString())
                    b.putExtra("nms", comttname.text.toString())
                    b.putExtra("ph", comphone.text.toString())
                    b.putExtra("pono", vouno.text.toString())
                    b.putExtra("orddate", suppdate.text.toString())
                    b.putExtra("desc", suppdescrip.text.toString())
                    b.putExtra("reqdate", invoicedate.text.toString())
                    b.putExtra("duedate", payduedate.text.toString())
                    b.putExtra("status", paidspin.selectedItem.toString())

                    b.putExtra("imgurl", imgurl.text.toString())
                    b.putExtra("bridkey", brnchids)


                    b.putExtra("edclick",editclick)

                    b.putExtra("vounodup",vounodup)
                    b.putExtra("invoicedatedup",invoicedatedup)
                    b.putExtra("payduedatedup",payduedatedup)
                    b.putExtra("stadup",statdup)

                    b.putExtra("suppdescripdup",suppdescripdup)

                    b.putExtra("viewsuppin", viewsuppin)
                    b.putExtra("addsuppin", addsuppin)
                    b.putExtra("deletesuppin", deletesuppin)
                    b.putExtra("editsuppin", editesuppin)
                    b.putExtra("transfersuppin", transfersuppin)
                    b.putExtra("exportsuppin", exportsuppin)


                    b.putExtra("viewpurord", viewpurord)
                    b.putExtra("addpurord", addpurord)
                    b.putExtra("deletepurord", deletepurord)
                    b.putExtra("editpurord", editepurord)
                    b.putExtra("transferpurord", transferpurord)
                    b.putExtra("exportpurord", exportpurord)

                    b.putExtra("sendpurord", sendpurpo)



                    b.putExtra("viewpurreq", viewpurreq)
                    b.putExtra("addpurreq", addpurreq)
                    b.putExtra("deletepurreq", deletepurreq)
                    b.putExtra("editpurreq", editepurreq)
                    b.putExtra("transferpurreq", transferpurreq)
                    b.putExtra("exportpurreq", exportpurreq)





                    b.putExtra("backvald", frmval)


                    startActivity(b)
                    overridePendingTransition(0, 0)
                    finish()
                }
                else -> {
                }

            }



            })


        /*cardView2.setOnClickListener {





        }*/




        Log.d("IDDDDDSSASSSS", "  " + listoids.text)




        //----------------For make new supplier invoice----------------///
       if(frm=="supp_invoice") {

           frmval="supp_invoice"



           mnu.visibility=View.GONE


    val c = Calendar.getInstance()
    System.out.println("Current time =&gt; " + c.time)

           val o=intent.getStringExtra("id")
           listoids.setText(o)
           val od=intent.getStringExtra("brid")
           brnchids=od

           val spnm=intent.getStringExtra("supname")
          comttname.setText(spnm)

           val spph=intent.getStringExtra("supmob")
           comphone.setText(spph)


           val df = SimpleDateFormat("dd MMM yyyy")
           val dfs = SimpleDateFormat("dd/MM/yyyy")
    val formattedDate = df.format(c.time)
           val formattedDates = dfs.format(c.time)

    suppdate.setText(formattedDate)
           dates.setText(formattedDates)


           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")
           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")

           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
           }



           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }


           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")


           sendpurpo=intent.getStringExtra("sendpurord")

           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }










              //------------------------- Spinner paid--------------//


               val categories = ArrayList<String>()
               categories.add("Not Paid")
               categories.add("Paid")
               val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
               dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
               paidspin.adapter = dataAdapter



           //---------------------Get purchase order details from db --------------------//

           pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
           pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
           pDialogs!!.setTitleText("Loading...")
           pDialogs!!.setCancelable(false)
           pDialogs!!.show();
           var count = 0
             db.collection("${brnchids}_Purchase Orders/${listoids.text}/purchase_products")
                 .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                if (e != null) {
                    Log.w("", "Listen failed.", e)
                    return@EventListener
                }
                if(value.isEmpty==false) {
                    for (document in value) {
                        count = value.documents.size


                        Log.d("d", "key --- " + document.id + " => " + document.data)
                        println(document.data)

                        var dt = document.data
                        var id = (document.id)
                        id = id
                        ids = ids.plusElement(id)
                        /*idsforup=ids*/
                        println("Heyyyyyyy" + Arrays.toString(ids))
                        println("HELLOOOOOOOOO" + id)
                        pronameArray = pronameArray.plusElement(dt["stk_name"].toString())

                       var mfr=(dt["stk_mfr"].toString())
                        if(mfr=="Select"){
                            manufacturerArray = manufacturerArray.plusElement("Not Available")
                        }
                        else if(mfr!="Select"){
                            manufacturerArray = manufacturerArray.plusElement("MFR - "+mfr)

                        }

                        hsnArray = hsnArray.plusElement(dt["stk_hsn"].toString())

                        quantityArray = quantityArray.plusElement(dt["stk_received"].toString())

                        priceArray = priceArray.plusElement(dt["stk_price"].toString())
                        totArray = totArray.plusElement(dt["stk_total"].toString())
                        var bcode=(dt["stk_barcode"].toString())

                        if((bcode==" - ")||(bcode.isEmpty())){

                            barcodeArray = barcodeArray.plusElement("Not Available")
                        }
                        else if((bcode.isNotEmpty())&&(bcode!=" - ")){
                            barcodeArray = barcodeArray.plusElement(bcode)

                        }


                        cessArray = cessArray.plusElement(dt["stk_cess"].toString())
                        igstArray = igstArray.plusElement(dt["otherstk_igst"].toString())
                        cgstArray = cgstArray.plusElement(dt["otherstk_cgst"].toString())
                        sgstArray = sgstArray.plusElement(dt["otherstk_sgst"].toString())
                        igsttotArray = igsttotArray.plusElement(dt["otherstk_igsttotal"].toString())
                        cesstotalArray = cesstotalArray.plusElement(dt["otherstk_cesstotal"].toString())
                        tallyArray = tallyArray.plusElement(dt["otherstk_tally"].toString())
                        receivedArray = receivedArray.plusElement(dt["otherstk_received"].toString())
                        println("RECEIVED ARRAYYY" + Arrays.toString(receivedArray))
                        receivedpriceArray = receivedpriceArray.plusElement(dt["received_price"].toString())
                        receivedtaxtotalArray = receivedtaxtotalArray.plusElement(dt["received_taxtotal"].toString())
                        receivedcesstotArray = receivedcesstotArray.plusElement(dt["received_cesstotal"].toString())
                        receivedgrosstotArray = receivedgrosstotArray.plusElement(dt["received_grosstotal"].toString())
                        receivedtotalArray = receivedtotalArray.plusElement(dt["received_total"].toString())
                        try {
                            var im = (dt["otherstk_img"].toString())
                            if (im.isNotEmpty()) {

                                imageArray = imageArray.plusElement(im)
                            } else {
                                imageArray = imageArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                            }
                        } catch (e: Exception) {

                        }
                        keyArray = keyArray.plusElement("")

                    }
                }
                else
                {
                    pDialogs!!.dismiss()
                }
                pDialogs!!.dismiss()
                /*val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray, receivedtaxtotalArray, receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, imageArray)
                supp_third_list.adapter = whatever
                Helper.getListViewSize(supp_third_list);*/
                progress.visibility = View.GONE
                     var kk=priceArray.count()

                     watchList.setText("Products ($kk)")


                     //Calculates price and other toal values.

                     if(savecli!="clicked") {
                         try {
                             var total = 0.0F
                             var igsttot = 0.0F
                             var cesstotals = 0.0F
                             var b = 2
                             for (i in 0 until priceArray.count()) {
                                 if (receivedArray[i].isEmpty()) {

                                     Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                     var d = pronameArray[i]
                                     var t = d.removeSuffix("- ml")
                                     prodnms = prodnms.plusElement(t)
                                     names.setText(Arrays.toString(prodnms))
                                     var u = names.text
                                     var s = u.removePrefix("[")
                                     var y = s.removeSuffix("]")
                                     names.setText(y)



                                     println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                                 }
                                 else if(receivedArray[i].isNotEmpty()){
                                     var c = (priceArray[i])
                                     var cy = (igsttotArray[i])
                                     var cyz = (cesstotalArray[i])
                                     var qyz = (receivedArray[i])

                                     var cdec = c.toBigDecimal()
                                     var qyzdec = qyz.toBigDecimal()
                                     var totquanpri = (cdec * qyzdec)




                                     total = total.plus(totquanpri.toInt())

                                     igsttot = igsttot.plus(cy.toFloat())
                                     cesstotals = cesstotals.plus(cyz.toFloat())

                                     igst_tot.setText((String.format("%.2f", igsttot)))
                                     var l = igst_tot.text.toString()
                                     var ss = l.toBigDecimal()
                                     var tt = ss / b.toBigDecimal()
                                     cgst_tot.setText((String.format("%.2f", tt)))
                                     sgst_tot.setText((String.format("%.2f", tt)))

                                     cess_tot.setText((String.format("%.2f", cesstotals)))

                                     var f = cesstotals
                                     var g = igsttot

                                     var op = total
                                     var m = f.toFloat()
                                     var n = g.toFloat()

                                     var yy = m + n + op

                                     try {
                                         gross_tot.setText((String.format("%.2f", yy)))
                                     } catch (e: Exception) {
                                         gross_tot.setText((String.format("%.2f", yy)))
                                     }
                                     Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                     var d = pronameArray[i]
                                     var t = d.removeSuffix("- ml")
                                     prodnms = prodnms.plusElement(t)
                                     names.setText(Arrays.toString(prodnms))
                                     var u = names.text
                                     var s = u.removePrefix("[")
                                     var y = s.removeSuffix("]")
                                     names.setText(y)



                                     println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                                 }
                             }
                         } catch (e: Exception) {
                             Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                         }
                     }
            })

           editclick="suppinv"
}

       //Start list from 'Supply_MainActivityfirst' for updating existing supplier invoice

       else if(frm=="startlist_suppinv"){

           frmval="startlist_suppinv"
           save.visibility=View.INVISIBLE
           edit.visibility=View.VISIBLE
            mnu.visibility=View.GONE
           fab.isEnabled=false


           supp_third_list.isEnabled=false
           supp_third_list.isClickable=false

           vouno.isEnabled=false
           suppdate.isEnabled=false
           suppdescrip.isEnabled=false
           payduedate.isEnabled=false
           invoicedate.isEnabled=false


           paidspin.isEnabled=false










           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")

           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")

           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
           }



           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }


           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")
           sendpurpo=intent.getStringExtra("sendpurord")

           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }





           //Paid not paid spinner adapter


           val categories = ArrayList<String>()
           categories.add("Not Paid")
           categories.add("Paid")
           val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
           dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
           paidspin.adapter = dataAdapter



           val name = intent.getStringExtra("sinvnm")
           val sta=intent.getStringExtra("status")
           val dtdate=intent.getStringExtra("dtdate")
           val phone = intent.getStringExtra("sinvph")
           val date = intent.getStringExtra("date")
           val datess = intent.getStringExtra("estidate")
           val Stockids = intent.getStringExtra("reqids")
           val listids = intent.getStringExtra("listids")
           val imurl = intent.getStringExtra("imurl")


           if (sta.isNullOrEmpty() != true) {
               val spinnerPosition = dataAdapter.getPosition(sta.toString())
               paidspin.setSelection(spinnerPosition)

           }

           try {
               vou_id = intent.getStringExtra("vouid")
           }
           catch (e:Exception){

           }
           try {
               Picasso.with(this)
                       .load(imurl)
                       .into(comp_toolimg)
           }
           catch (e:Exception){

           }
           val brnchid = intent.getStringExtra("brnchids")
           val desccs = intent.getStringExtra("descss")
           val dtdatest=intent.getStringExtra("dtdatest")

           try{
               val imname = intent.getStringExtra("imname")
               imgnameedit=imname

           }
           catch(e:Exception){
               imgnameedit=""

           }

           comttname.setText(name)
           comphone.setText(phone)

           dates.setText(dtdatest)

           vouno.setText(Stockids)
           suppinids.setText(listids)
           invoicedate.setText(date)
           payduedate.setText(datess)
           listoids.setText(listids)
           suppdescrip.setText(desccs)
           suppdate.setText(dtdate)
           imgurl.setText(imurl)

           vounodup=Stockids
           statdup=sta
           invoicedatedup=date
           payduedatedup=datess
           suppdescripdup=desccs

           if(imgurl.text.toString().isNotEmpty()==true){

               imageButton2.visibility= View.GONE
               imageView4.visibility=View.GONE
           }
           brnchids=brnchid
           try {
              Picasso.with(this)
                      .load(imurl)
                      .into(card)
           }
           catch (e:Exception){

           }


           if(imurl.isNotEmpty()==true){
               imageButton2.visibility=View.GONE
               imageView4.visibility=View.GONE
           }




           //Click imageview and show it on popup and navigate to zoom activity when clicking popup.

           card.setOnClickListener {
               if(imgurl.text.toString().isNotEmpty()==true) {


                   var redrawb=card.drawable

                   val alert = AlertDialog.Builder(this@Supplier_thirdMainActivity)
                   val inflater = this.layoutInflater
                   /*with(alert) {
setTitle("Select Branch")
}*/
                   val dialog = alert.create()
                   dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                   dialog.show()
                   val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                   stkedt.setImageDrawable(redrawb)
                  val bitmap = (redrawb as BitmapDrawable).getBitmap()
                   val baos = ByteArrayOutputStream()
                   bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                   val b = baos.toByteArray()

                   stkedt.setOnClickListener {
                       val k=   Intent(this@Supplier_thirdMainActivity,ZoomActivity::class.java)
                                k.putExtra("imgurl",imgurl.text.toString())
                       k.putExtra("drawb",b)
                                dialog.dismiss()
                                startActivity(k)


                   }




                   val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                   val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                   okact.setOnClickListener {

                       PickImageDialog.build(PickSetup()).show(this)
                       dialog.dismiss()


                   }
                   cancelact.setOnClickListener {
                       dialog.dismiss()
                   }
               }
               else{
                   PickImageDialog.build(PickSetup()).show(this)
               }


           }


           //-------------------Get supplier invoice details from db-------------------//
            pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
           pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
           pDialogs!!.setTitleText("Loading...")
           pDialogs!!.setCancelable(false)
           pDialogs!!.show();
           var count = 0


           db.collection("${brnchids}_Supplier Invoice/${suppinids.text}/purchase_products")
                   .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                       if (e != null) {
                           Log.w("", "Listen failed.", e)
                           return@EventListener
                       }
                       if(value.isEmpty==false) {
                           for (document in value) {

                               count = value.documents.size
                               /*procnt.setText(count.toString())*/

                               Log.d("d", "key --- " + document.id + " => " + document.data)
                               println(document.data)

                               var dt = document.data
                               var id = (document.id)
                               id = id
                               ids = ids.plusElement(id)
                               /*idsforup=ids*/
                               println("Heyyyyyyy" + Arrays.toString(ids))
                               println("HELLOOOOOOOOO" + id)
                               pronameArray = pronameArray.plusElement(dt["stk_name"].toString())

                               manufacturerArray = manufacturerArray.plusElement(dt["stk_mfr"].toString())
                               hsnArray = hsnArray.plusElement(dt["stk_hsn"].toString())

                               quantityArray = quantityArray.plusElement(dt["stk_received"].toString())

                               priceArray = priceArray.plusElement(dt["stk_price"].toString())
                               totArray = totArray.plusElement(dt["stk_total"].toString())
                               barcodeArray = barcodeArray.plusElement(dt["stk_barcode"].toString())
                               cessArray = cessArray.plusElement(dt["stk_cess"].toString())
                               igstArray = igstArray.plusElement(dt["otherstk_igst"].toString())
                               cgstArray = cgstArray.plusElement(dt["otherstk_cgst"].toString())
                               sgstArray = sgstArray.plusElement(dt["otherstk_sgst"].toString())
                               igsttotArray = igsttotArray.plusElement(dt["otherstk_igsttotal"].toString())
                               cesstotalArray = cesstotalArray.plusElement(dt["otherstk_cesstotal"].toString())
                               tallyArray = tallyArray.plusElement(dt["otherstk_tally"].toString())
                               receivedArray = receivedArray.plusElement(dt["otherstk_received"].toString())
                               println("RECEIVED ARRAYYY" + Arrays.toString(receivedArray))
                               receivedpriceArray = receivedpriceArray.plusElement(dt["received_price"].toString())
                               receivedtaxtotalArray = receivedtaxtotalArray.plusElement(dt["received_taxtotal"].toString())
                               receivedcesstotArray = receivedcesstotArray.plusElement(dt["received_cesstotal"].toString())
                               receivedgrosstotArray = receivedgrosstotArray.plusElement(dt["received_grosstotal"].toString())
                               receivedtotalArray = receivedtotalArray.plusElement(dt["received_total"].toString())




                               try {
                                   var im = (dt["otherstk_img"].toString())
                                   if (im.isNotEmpty()) {

                                       imageArray = imageArray.plusElement(im)
                                   } else {
                                       imageArray = imageArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                   }
                               } catch (e: Exception) {

                               }
                               keyArray = keyArray.plusElement(id)

                           }
                       }
                       else{
                           pDialogs!!.dismiss()
                       }
                       pDialogs!!.dismiss()
                       /*val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,receivedtotalArray, imageArray)
                      supp_third_list.adapter = whatever
                       Helper.getListViewSize(supp_third_list);*/

                       progress.visibility = View.GONE

                       var kk=priceArray.count()

                       watchList.setText("Products ($kk)")
                       if(savecli!="clicked") {
                           try {
                               var total = 0.0F
                               var igsttot = 0.0F
                               var cesstotals = 0.0F
                               var b = 2
                               for (i in 0 until priceArray.count()) {
                                   if (receivedArray[i].isEmpty()) {

                                       Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                       var d = pronameArray[i]
                                       var t = d.removeSuffix("- ml")
                                       prodnms = prodnms.plusElement(t)
                                       names.setText(Arrays.toString(prodnms))
                                       var u = names.text
                                       var s = u.removePrefix("[")
                                       var y = s.removeSuffix("]")
                                       names.setText(y)



                                       println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                                   }
                                   else if(receivedArray[i].isNotEmpty()){
                                       var c = (priceArray[i])
                                       var cy = (igsttotArray[i])
                                       var cyz = (cesstotalArray[i])
                                       var qyz = (receivedArray[i])

                                       var cdec = c.toBigDecimal()
                                       var qyzdec = qyz.toBigDecimal()
                                       var totquanpri = (cdec * qyzdec)




                                       total = total.plus(totquanpri.toInt())

                                       igsttot = igsttot.plus(cy.toFloat())
                                       cesstotals = cesstotals.plus(cyz.toFloat())

                                       igst_tot.setText((String.format("%.2f", igsttot)))
                                       var l = igst_tot.text.toString()
                                       var ss = l.toBigDecimal()
                                       var tt = ss / b.toBigDecimal()
                                       cgst_tot.setText((String.format("%.2f", tt)))
                                       sgst_tot.setText((String.format("%.2f", tt)))

                                       cess_tot.setText((String.format("%.2f", cesstotals)))

                                       var f = cesstotals
                                       var g = igsttot

                                       var op = total
                                       var m = f.toFloat()
                                       var n = g.toFloat()

                                       var yy = m + n + op

                                       try {
                                           gross_tot.setText((String.format("%.2f", yy)))
                                       } catch (e: Exception) {
                                           gross_tot.setText((String.format("%.2f", yy)))
                                       }
                                       Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                       var d = pronameArray[i]
                                       var t = d.removeSuffix("- ml")
                                       prodnms = prodnms.plusElement(t)
                                       names.setText(Arrays.toString(prodnms))
                                       var u = names.text
                                       var s = u.removePrefix("[")
                                       var y = s.removeSuffix("]")
                                       names.setText(y)



                                       println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                                   }
                               }
                           } catch (e: Exception) {
                               pDialogs!!.dismiss()
                               Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                           }
                       }

                   })


       }
       else if(frm=="from_pdf")
       {

           //from pdf activity













           frmval=intent.getStringExtra("backvald")

           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")
           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")

           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
           }

           try{
               vounodup=intent.getStringExtra("vounodup")
               invoicedatedup=intent.getStringExtra("invoicedatedup")
               payduedatedup=intent.getStringExtra("payduedatedup")
               suppdescripdup=intent.getStringExtra("suppdescripdup")
           }
           catch (e:Exception){

           }

           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }


           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")
           sendpurpo=intent.getStringExtra("sendpurord")

           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }

           val av = bundle!!.get("renm") as Array<String>
           val bv = bundle!!.get("rehsn") as Array<String>
           val mv = bundle!!.get("remanu") as Array<String>
           /*   val dv=bundle!!.get("reprice") as Array<String>*/
           val ev = bundle!!.get("requan") as Array<String>
           val fv = bundle!!.get("rebc") as Array<String>
           val hv = bundle!!.get("retotal") as Array<String>
           val gv = bundle!!.get("recess") as Array<String>
           val iv = bundle!!.get("reigst") as Array<String>
           val idv = bundle!!.get("recgst") as Array<String>
           val isv = bundle!!.get("resgst") as Array<String>
           val jv = bundle!!.get("reigst_total") as Array<String>
           val kv = bundle!!.get("recesstotal") as Array<String>
           val rekey = bundle!!.get("rekey") as Array<String>
           val ktally = bundle!!.get("retally") as Array<String>
           val rereceive = bundle!!.get("rereceived") as Array<String>
           val rereceivepri = bundle!!.get("rereceived_pri") as Array<String>
           val rereceivetot = bundle!!.get("rereceived_tot") as Array<String>
           val rereceivetaxtot = bundle!!.get("rereceived_taxtot") as Array<String>
           val rereceivecesstot = bundle!!.get("rereceived_cesstot") as Array<String>
           val rereceivegrosstot = bundle!!.get("rereceived_grosstot") as Array<String>
           val immv = bundle!!.get("reimmg") as Array<String>



           val datests=intent.getStringExtra("datest")
           dates.setText(datests)

           val grosst = intent.getStringExtra("regross")
           val igstt = intent.getStringExtra("reigsts")
           val cgstt = intent.getStringExtra("recgsts")
           val sgstt = intent.getStringExtra("resgsts")
           val cesstt = intent.getStringExtra("recessts")


           val uppono = intent.getStringExtra("pono")
           val orddtup = intent.getStringExtra("reorddate")
           val reqdtup = intent.getStringExtra("reestdt")
           val descup = intent.getStringExtra("redesc")
           val postatusup = intent.getStringExtra("restatus")
           val mainidup = intent.getStringExtra("reids")
           val prnmsup = intent.getStringExtra("names")
           val comnmup = intent.getStringExtra("titnm")
           val comphup = intent.getStringExtra("tiphone")
           val im=intent.getStringExtra("reimgurl")
           val branchids = intent.getStringExtra("brnchids")

           var sta=intent.getStringExtra("status")


           try{
               Picasso.with(this)
                       .load(im)
                       .into(comp_toolimg)
           }
           catch (e:Exception){

           }

           try {
               imgname = intent.getStringExtra("imgname")
           }
           catch (e:Exception){

           }


           try{
statdup=intent.getStringExtra("statdup")
           }
           catch (e:Exception){

           }


           try {
               imgnameedit = intent.getStringExtra("imgnameedit")

           }
           catch (e:Exception){

           }

           try{
               editclick=intent.getStringExtra("edclick")
           }
catch (e:Exception){

}

           if(editclick.isEmpty()==true){
               save.visibility=View.INVISIBLE
               edit.visibility=View.VISIBLE
               mnu.visibility=View.GONE
               fab.isEnabled=false

               supp_third_list.isEnabled=false
               supp_third_list.isClickable=false
               vouno.isEnabled=false
               suppdate.isEnabled=false
               suppdescrip.isEnabled=false
               payduedate.isEnabled=false
               invoicedate.isEnabled=false
               imageButton2.isEnabled=false

           }

           vouno.setText(uppono)
           suppdate.setText(orddtup)
           invoicedate.setText(reqdtup)
           payduedate.setText(postatusup)
           suppdescrip.setText(descup)
           listoids.setText(mainidup)
           names.setText(prnmsup)
           comttname.setText(comnmup)
           comphone.setText(comphup)
           suppinids.setText(mainidup)
           imgurl.setText(im)
           if(imgurl.text.toString().isNotEmpty()==true){

               imageButton2.visibility= View.GONE
               imageView4.visibility=View.GONE
           }
           card.setOnClickListener {
               if(imgurl.text.toString().isNotEmpty()==true) {


                   var redrawb=card.drawable

                   val alert = AlertDialog.Builder(this@Supplier_thirdMainActivity)
                   val inflater = this.layoutInflater
                   /*with(alert) {
setTitle("Select Branch")
}*/
                   val dialog = alert.create()
                   dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                   dialog.show()
                   val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                   stkedt.setImageDrawable(redrawb)
                   val bitmap = (redrawb as BitmapDrawable).getBitmap()
                   val baos = ByteArrayOutputStream()
                   bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                   val b = baos.toByteArray()

                   stkedt.setOnClickListener {
                       val k=   Intent(this@Supplier_thirdMainActivity,ZoomActivity::class.java)
                       k.putExtra("imgurl",imgurl.text.toString())
                       k.putExtra("drawb",b)
                       dialog.dismiss()
                       startActivity(k)


                   }




                   val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                   val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                   okact.setOnClickListener {

                       PickImageDialog.build(PickSetup()).show(this)
                       dialog.dismiss()


                   }
                   cancelact.setOnClickListener {
                       dialog.dismiss()
                   }
               }
               else{
                   PickImageDialog.build(PickSetup()).show(this)
               }


           }

           igst_tot.setText((String.format("%.2f",igstt.toFloat())))

           cgst_tot.setText((String.format("%.2f",cgstt.toFloat())))

           sgst_tot.setText((String.format("%.2f",sgstt.toFloat())))

           cess_tot.setText((String.format("%.2f",cesstt.toFloat())))

           gross_tot.setText((String.format("%.2f",grosst.toFloat())))


           val categories = ArrayList<String>()
           categories.add("Not Paid")
           categories.add("Paid")
           val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
           dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
           paidspin.adapter = dataAdapter


           if(sta.isNotEmpty()){
               val spinnerPosition = dataAdapter.getPosition(sta.toString())
               paidspin.setSelection(spinnerPosition)
           }

           try {
               imgurl.setText(im)
               val newurl = URL(imgurl.text as String?).openStream()
               val mIcon_val = BitmapFactory.decodeStream(newurl)
               card.setImageBitmap(mIcon_val)
           }
           catch (e:Exception){

           }


           brnchids=branchids







           pronameArray = (av.clone())
           manufacturerArray = mv.clone()
           quantityArray = ev.clone()
           priceArray = hv.clone()
           hsnArray = bv.clone()
           barcodeArray = fv.clone()
           totArray = hv.clone()
           cessArray = gv.clone()
           keyArray = rekey.clone()
           igstArray = iv.clone()
           cgstArray = idv.clone()
           sgstArray = isv.clone()
           igsttotArray = jv.clone()
           cesstotalArray = kv.clone()
           tallyArray = ktally.clone()
           receivedArray = rereceive.clone()
           receivedpriceArray=rereceivepri.clone()
           receivedtaxtotalArray=rereceivetaxtot.clone()
           receivedcesstotArray=rereceivecesstot.clone()
           receivedgrosstotArray=rereceivegrosstot.clone()
           receivedtotalArray=rereceivetot.clone()
           imageArray = immv.clone()


           /*val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray,igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,receivedtotalArray,imageArray)
           supp_third_list.adapter = whatever


           Helper.getListViewSize(supp_third_list);*/

           var kk=priceArray.count()

           watchList.setText("Products ($kk)")
        /*   procnt.setText(kk)*/

           /*try {
               var total = 0.0F
               var igsttot = 0.0F
               var cesstotals = 0.0F
               var b = 2
               for (i in 0 until priceArray.count()) {
                   var c = (priceArray[i])
                   var cy=(igsttotArray[i])
                   var cyz=(cesstotalArray[i])
                   var qyz=(quantityArray[i])

                   var cdec=c.toBigDecimal()
                   var qyzdec=qyz.toBigDecimal()
                   var totquanpri=(cdec*qyzdec)




                   total = total.plus(totquanpri.toInt())

                   igsttot = igsttot.plus(cy.toFloat())
                   cesstotals = cesstotals.plus(cyz.toFloat())

                   igst_tot.text=DecimalFormat("##.##").format(igsttot)
                   var l = igst_tot.text.toString()
                   var ss = l.toBigDecimal()
                   var tt = ss / b.toBigDecimal()
                   cgst_tot.text = DecimalFormat("##.##").format(tt)
                   sgst_tot.text = DecimalFormat("##.##").format(tt)

                  cess_tot.text=DecimalFormat("##.##").format(cesstotals)

                   var f=cesstotals
                   var g=igsttot

                   var op=total
                   var m=f.toFloat()
                   var n=g.toFloat()

                   var yy=m+n+op

                   try {
                      gross_tot.text=DecimalFormat("##.##").format(yy)
                   }
                   catch (e:Exception){
                       gross_tot.text=DecimalFormat("##.##").format(yy)
                   }
                   Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                   var d = pronameArray[i]
                   var t = d.removeSuffix("- ml")
                   prodnms = prodnms.plusElement(t)
                   names.setText(Arrays.toString(prodnms))
                   var u = names.text
                   var s = u.removePrefix("[")
                   var y = s.removeSuffix("]")
                   names.setText(y)



                   println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
               }
           } catch (e: Exception) {
               Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
           }*/
           }













       else if(frm=="update_supplier"){



           //From update activity



           frmval=intent.getStringExtra("backvald")










           val adsuppin = intent.getStringExtra("addsuppin")
           val edsuppin = intent.getStringExtra("editsuppin")
           val delsuppin = intent.getStringExtra("deletesuppin")
           val visuppin=intent.getStringExtra("viewsuppin")
           val transuppin=intent.getStringExtra("transfersuppin")
           val exsuppin=intent.getStringExtra("exportsuppin")



           if (adsuppin != null) {
               addsuppin = adsuppin
           }
           if (edsuppin != null) {
               editesuppin = edsuppin
           }
           if (delsuppin != null) {
               deletesuppin = delsuppin
           }
           if (visuppin != null) {
               viewsuppin = visuppin
           }
           if (transuppin != null) {
               transfersuppin = transuppin
           }
           if (exsuppin != null) {
               exportsuppin = exsuppin
           }


           val adpr = intent.getStringExtra("addpurreq")
           val edpr = intent.getStringExtra("editpurreq")
           val delpr = intent.getStringExtra("deletepurreq")
           val vipr=intent.getStringExtra("viewpurreq")
           val tranpr=intent.getStringExtra("transferpurreq")
           val expr=intent.getStringExtra("exportpurreq")

           if (adpr != null) {
               addpurreq = adpr
           }
           if (edpr != null) {
               editepurreq = edpr
           }
           if (delpr != null) {
               deletepurreq = delpr
           }
           if (vipr != null) {
               viewpurreq = vipr
           }
           if (tranpr != null) {
               transferpurreq = tranpr
           }
           if (expr != null) {
               exportpurreq = expr
           }


           val adord = intent.getStringExtra("addpurord")
           val edord = intent.getStringExtra("editpurord")
           val delord = intent.getStringExtra("deletepurord")
           val viord=intent.getStringExtra("viewpurord")
           val tranord=intent.getStringExtra("transferpurord")
           val exord=intent.getStringExtra("exportpurord")
           sendpurpo=intent.getStringExtra("sendpurord")
           if (adord != null) {
               addpurord = adord
           }
           if (edord != null) {
               editepurord = edord
           }
           if (delord != null) {
               deletepurord = delord
           }
           if (viord != null) {
               viewpurord = viord
           }
           if (tranord != null) {
               transferpurord = tranord
           }
           if (exord != null) {
               exportpurord = exord
           }




           val av = bundle!!.get("renm") as Array<String>
           val bv = bundle!!.get("rehsn") as Array<String>
           val mv = bundle!!.get("remanu") as Array<String>
              val dv=bundle!!.get("reprice") as Array<String>
           val ev = bundle!!.get("requan") as Array<String>
           val fv = bundle!!.get("rebc") as Array<String>
           val hv = bundle!!.get("retotal") as Array<String>
           val gv = bundle!!.get("recess") as Array<String>
           val iv = bundle!!.get("reigst") as Array<String>
           val idv = bundle!!.get("recgst") as Array<String>
           val isv = bundle!!.get("resgst") as Array<String>
           val jv = bundle!!.get("reigst_total") as Array<String>
           val kv = bundle!!.get("recesstotal") as Array<String>
           val rekey = bundle!!.get("rekey") as Array<String>
           val ktally = bundle!!.get("retally") as Array<String>
           val rereceive = bundle!!.get("rereceived") as Array<String>
           val rereceivepri = bundle!!.get("rereceived_pri") as Array<String>
           val rereceivetot = bundle!!.get("rereceived_tot") as Array<String>
           val rereceivetaxtot = bundle!!.get("rereceived_taxtot") as Array<String>
           val rereceivecesstot = bundle!!.get("rereceived_cesstot") as Array<String>
           val rereceivegrosstot = bundle!!.get("rereceived_grosstot") as Array<String>
           val immv = bundle!!.get("reimmg") as Array<String>

           val uppono = intent.getStringExtra("pono")
           val orddtup = intent.getStringExtra("reorddate")
           val reqdtup = intent.getStringExtra("reestdt")
           val descup = intent.getStringExtra("redesc")
           val postatusup = intent.getStringExtra("restatus")
           val mainidup = intent.getStringExtra("reids")
           val prnmsup = intent.getStringExtra("names")
           val comnmup = intent.getStringExtra("titnm")
           val comphup = intent.getStringExtra("tiphone")
           val im=intent.getStringExtra("reimgurl")
           val branchids = intent.getStringExtra("brnchids")

           var sta=intent.getStringExtra("status")




           try{
               editclick=intent.getStringExtra("edclick")
           }
           catch (e:Exception){

           }

           try{
               vounodup=intent.getStringExtra("vounodup")
               invoicedatedup=intent.getStringExtra("invoicedatedup")
               payduedatedup=intent.getStringExtra("payduedatedup")
               suppdescripdup=intent.getStringExtra("suppdescripdup")
               statdup=intent.getStringExtra("stadupspin")
           }
           catch (e:Exception){

           }


           if(editclick.isEmpty()==true){
               save.visibility=View.INVISIBLE
               edit.visibility=View.VISIBLE
               mnu.visibility=View.GONE
               fab.isEnabled=false

               supp_third_list.isEnabled=false
               supp_third_list.isClickable=false


               vouno.isEnabled=false
               suppdate.isEnabled=false
               suppdescrip.isEnabled=false
               payduedate.isEnabled=false
               invoicedate.isEnabled=false
               imageButton2.isEnabled=false

           }



           val datests=intent.getStringExtra("datest")



           vouno.setText(uppono)
           suppdate.setText(orddtup)
           invoicedate.setText(reqdtup)
           payduedate.setText(postatusup)
           suppdescrip.setText(descup)
           listoids.setText(mainidup)
           names.setText(prnmsup)
           comttname.setText(comnmup)
           comphone.setText(comphup)

           if((frmval=="supp_invoice")){
               mnu.visibility=View.GONE

           }
           else if((frm=="startlist_suppinv")){
               suppinids.setText(mainidup)
           }

           dates.setText(datests)

           val categories = ArrayList<String>()
           categories.add("Not Paid")
           categories.add("Paid")
           val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
           dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
           paidspin.adapter = dataAdapter


           if(sta.isNotEmpty()){
               val spinnerPosition = dataAdapter.getPosition(sta.toString())
               paidspin.setSelection(spinnerPosition)


           }

           try {
               imgurl.setText(im)
              Picasso.with(this)
                      .load(imgurl.text.toString())
                      .into(card)
           }
           catch (e:Exception){

           }

try {
    Picasso.with(this)
            .load(im)
            .into(comp_toolimg)
}
catch (e:Exception){

}


           if(imgurl.text.toString().isNotEmpty()==true){

               imageButton2.visibility= View.GONE
               imageView4.visibility=View.GONE
           }

           card.setOnClickListener {
               if(imgurl.text.toString().isNotEmpty()==true) {


                   var redrawb=card.drawable

                   val alert = AlertDialog.Builder(this@Supplier_thirdMainActivity)
                   val inflater = this.layoutInflater
                   /*with(alert) {
setTitle("Select Branch")
}*/
                   val dialog = alert.create()
                   dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                   dialog.show()
                   val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                   stkedt.setImageDrawable(redrawb)
                   val bitmap = (redrawb as BitmapDrawable).getBitmap()
                   val baos = ByteArrayOutputStream()
                   bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                   val b = baos.toByteArray()

                   stkedt.setOnClickListener {
                       val k=   Intent(this@Supplier_thirdMainActivity,ZoomActivity::class.java)
                       k.putExtra("imgurl",imgurl.text.toString())
                       k.putExtra("drawb",b)
                       dialog.dismiss()
                       startActivity(k)


                   }




                   val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                   val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                   okact.setOnClickListener {

                       PickImageDialog.build(PickSetup()).show(this)
                       dialog.dismiss()


                   }
                   cancelact.setOnClickListener {
                       dialog.dismiss()
                   }
               }
               else{
                   PickImageDialog.build(PickSetup()).show(this)
               }


           }

           brnchids=branchids







           pronameArray = (av.clone())
           manufacturerArray = mv.clone()
           quantityArray = ev.clone()
           priceArray = dv.clone()
           hsnArray = bv.clone()
           barcodeArray = fv.clone()
           totArray = hv.clone()
           cessArray = gv.clone()
           keyArray = rekey.clone()
           igstArray = iv.clone()
           cgstArray = idv.clone()
           sgstArray = isv.clone()
           igsttotArray = jv.clone()
           cesstotalArray = kv.clone()
           tallyArray = ktally.clone()
           receivedArray = rereceive.clone()
           receivedpriceArray=rereceivepri.clone()
           receivedtaxtotalArray=rereceivetaxtot.clone()
           receivedcesstotArray=rereceivecesstot.clone()
           receivedgrosstotArray=rereceivegrosstot.clone()
           receivedtotalArray=rereceivetot.clone()
           imageArray = immv.clone()


         /*  val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
         priceArray, totArray, cessArray, keyArray,igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,
         receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,receivedtotalArray,imageArray)
           supp_third_list.adapter = whatever
           Helper.getListViewSize(supp_third_list);*/
           var kk=priceArray.count()

           watchList.setText("Products ($kk)")
        /*   procnt.setText(kk.toString())*/
           if(savecli!="clicked") {
               try {
                   var total = 0.0F
                   var igsttot = 0.0F
                   var cesstotals = 0.0F
                   var b = 2
                   for (i in 0 until priceArray.count()) {
                       if (receivedArray[i].isEmpty()) {

                           Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                           var d = pronameArray[i]
                           var t = d.removeSuffix("- ml")
                           prodnms = prodnms.plusElement(t)
                           names.setText(Arrays.toString(prodnms))
                           var u = names.text
                           var s = u.removePrefix("[")
                           var y = s.removeSuffix("]")
                           names.setText(y)



                           println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                       }
                       else if(receivedArray[i].isNotEmpty()){
                           var c = (priceArray[i])
                           var cy = (igsttotArray[i])
                           var cyz = (cesstotalArray[i])
                           var qyz = (receivedArray[i])

                           var cdec = c.toBigDecimal()
                           var qyzdec = qyz.toBigDecimal()
                           var totquanpri = (cdec * qyzdec)




                           total = total.plus(totquanpri.toInt())

                           igsttot = igsttot.plus(cy.toFloat())
                           cesstotals = cesstotals.plus(cyz.toFloat())

                           igst_tot.setText((String.format("%.2f", igsttot)))
                           var l = igst_tot.text.toString()
                           var ss = l.toBigDecimal()
                           var tt = ss / b.toBigDecimal()
                           cgst_tot.setText((String.format("%.2f", tt)))
                           sgst_tot.setText((String.format("%.2f", tt)))

                           cess_tot.setText((String.format("%.2f", cesstotals)))

                           var f = cesstotals
                           var g = igsttot

                           var op = total
                           var m = f.toFloat()
                           var n = g.toFloat()

                           var yy = m + n + op

                           try {
                               gross_tot.setText((String.format("%.2f", yy)))
                           } catch (e: Exception) {
                               gross_tot.setText((String.format("%.2f", yy)))
                           }
                           Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                           var d = pronameArray[i]
                           var t = d.removeSuffix("- ml")
                           prodnms = prodnms.plusElement(t)
                           names.setText(Arrays.toString(prodnms))
                           var u = names.text
                           var s = u.removePrefix("[")
                           var y = s.removeSuffix("]")
                           names.setText(y)



                           println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                       }
                   }
               } catch (e: Exception) {
                   Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
               }
           }




       }
       else if(frm=="suppin_list"){
           val aw = bundle!!.get("pur_pname") as Array<String>
           val bw = bundle!!.get("pur_pitem") as Array<String>
           val cw = bundle!!.get("pur_phsn") as Array<String>
           val dw = bundle!!.get("pur_porder") as Array<String>
           /*    val ew=bundle!!.get("pcomplete") as Array<String>*/
           val fw = bundle!!.get("pur_pprice") as Array<String>
           val hw = bundle!!.get("pur_ptot") as Array<String>
           val gw = bundle!!.get("pur_poarray") as Array<String>
           val lw = bundle!!.get("pur_cessarray") as Array<String>
           val mw = bundle!!.get("pur_igstarray") as Array<String>
           val cgw = bundle!!.get("pur_cgstarray") as Array<String>
           val sgw = bundle!!.get("pur_sgstarray") as Array<String>
           val nw = bundle!!.get("pur_igsttotarray") as Array<String>
           val ow = bundle!!.get("pur_cesstotalarray") as Array<String>
           val pw = bundle!!.get("pur_tallyarray") as Array<String>
           val rew = bundle!!.get("pur_receivedarray") as Array<String>
           val rewpri = bundle!!.get("pur_receivedarraypri") as Array<String>
           val rewtot = bundle!!.get("pur_receivedarraytotal") as Array<String>
           val rewtaxtot = bundle!!.get("pur_receivedarraytaxtot") as Array<String>
           val rewgrosstot = bundle!!.get("pur_receivedarraygrosstot") as Array<String>
           val rewcesstot = bundle!!.get("pur_receivedarraycesstot") as Array<String>
           val piddli = bundle!!.get("pur_reiddofli") as Array<String>
           val imm = bundle!!.get("pur_imi") as Array<String>
           val uppono = intent.getStringExtra("pono")
           val orddtup = intent.getStringExtra("reorddate")
           val reqdtup = intent.getStringExtra("reestdt")
           val descup = intent.getStringExtra("redesc")
           val postatusup = intent.getStringExtra("reduedate")
           val mainidup = intent.getStringExtra("reids")
           val prnmsup = intent.getStringExtra("names")
           val comnmup = intent.getStringExtra("titnm")
           val comphup = intent.getStringExtra("tiphone")


           frmval=intent.getStringExtra("backvald")

           vouno.setText(uppono)
           suppdate.setText(orddtup)
           invoicedate.setText(reqdtup)
           payduedate.setText(postatusup)
           suppdescrip.setText(descup)
           listoids.setText(mainidup)

           names.setText(prnmsup)
           comttname.setText(comnmup)
           comphone.setText(comphup)

           /*       val c = Calendar.getInstance()
                  System.out.println("Current time =&gt; " + c.time)

                  val df = SimpleDateFormat("dd/MM/yyyy")
                  val formattedDate = df.format(c.time)

                  orddate.setText(formattedDate)*/

           pronameArray = aw.clone()
           manufacturerArray = bw.clone()
           quantityArray = dw.clone()
           priceArray = fw.clone()
           hsnArray = cw.clone()
           barcodeArray = gw.clone()
           totArray = hw.clone()
           cessArray = lw.clone()
           keyArray = piddli.clone()
           igstArray = mw.clone()
           cgstArray = cgw.clone()
           sgstArray = sgw.clone()
           igsttotArray = nw.clone()
           cesstotalArray = ow.clone()
           tallyArray = pw.clone()
           receivedArray = rew.clone()
           receivedpriceArray = rewpri.clone()
           receivedtaxtotalArray = rewtaxtot.clone()
           receivedcesstotArray = rewcesstot.clone()
           receivedgrosstotArray = rewgrosstot.clone()
           receivedtotalArray = rewtot.clone()
           imageArray = imm.clone()

        /*   val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray,igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,receivedtotalArray,imageArray)
           supp_third_list.adapter = whatever
           Helper.getListViewSize(supp_third_list);*/
           var kk=priceArray.count()

           watchList.setText("Products ($kk)")
         /*  procnt.setText(kk)*/
           if(savecli!="clicked") {
               try {
                   var total = 0.0F
                   var igsttot = 0.0F
                   var cesstotals = 0.0F
                   var b = 2
                   for (i in 0 until priceArray.count()) {
                       var c = (priceArray[i])
                       var cy = (igsttotArray[i])
                       var cyz = (cesstotalArray[i])
                       var qyz = (quantityArray[i])

                       var cdec = c.toBigDecimal()
                       var qyzdec = qyz.toBigDecimal()
                       var totquanpri = (cdec * qyzdec)




                       total = total.plus(totquanpri.toInt())

                       igsttot = igsttot.plus(cy.toFloat())
                       cesstotals = cesstotals.plus(cyz.toFloat())

                       igst_tot.setText((String.format("%.2f",igsttot)))
                       var l = igst_tot.text.toString()
                       var ss = l.toBigDecimal()
                       var tt = ss / b.toBigDecimal()
                       cgst_tot.setText((String.format("%.2f",tt)))
                       sgst_tot.setText((String.format("%.2f",tt)))

                       cess_tot.setText((String.format("%.2f",cesstotals)))

                       var f = cesstotals
                       var g = igsttot

                       var op = total
                       var m = f.toFloat()
                       var n = g.toFloat()

                       var yy = m + n + op

                       try {
                           gross_tot.setText((String.format("%.2f",yy)))
                       } catch (e: Exception) {
                           gross_tot.setText((String.format("%.2f",yy)))
                       }
                       Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                       var d = pronameArray[i]
                       var t = d.removeSuffix("- ml")
                       prodnms = prodnms.plusElement(t)
                       names.setText(Arrays.toString(prodnms))
                       var u = names.text
                       var s = u.removePrefix("[")
                       var y = s.removeSuffix("]")
                       names.setText(y)



                       println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                   }
               } catch (e: Exception) {
                   Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
               }
           }
       }
       else if(frm=="suppin_list_single") {
           val aw = bundle!!.get("pur_pname") as Array<String>
           val bw = bundle!!.get("pur_pitem") as Array<String>
           val cw = bundle!!.get("pur_phsn") as Array<String>
           val dw = bundle!!.get("pur_porder") as Array<String>
           /*    val ew=bundle!!.get("pcomplete") as Array<String>*/
           val fw = bundle!!.get("pur_pprice") as Array<String>
           val hw = bundle!!.get("pur_ptot") as Array<String>
           val gw = bundle!!.get("pur_poarray") as Array<String>
           val lw = bundle!!.get("pur_cessarray") as Array<String>
           val mw = bundle!!.get("pur_igstarray") as Array<String>
           val cgw = bundle!!.get("pur_cgstarray") as Array<String>
           val sgw = bundle!!.get("pur_sgstarray") as Array<String>
           val nw = bundle!!.get("pur_igsttotarray") as Array<String>
           val ow = bundle!!.get("pur_cesstotalarray") as Array<String>
           val pw = bundle!!.get("pur_tallyarray") as Array<String>
           val rew = bundle!!.get("pur_receivedarray") as Array<String>
           val rewpri = bundle!!.get("pur_receivedarraypri") as Array<String>
           val rewtot = bundle!!.get("pur_receivedarraytotal") as Array<String>
           val rewtaxtot = bundle!!.get("pur_receivedarraytaxtot") as Array<String>
           val rewgrosstot = bundle!!.get("pur_receivedarraygrosstot") as Array<String>
           val rewcesstot = bundle!!.get("pur_receivedarraycesstot") as Array<String>
           val piddli = bundle!!.get("pur_reiddofli") as Array<String>
           val imm = bundle!!.get("pur_imi") as Array<String>
           val uppono = intent.getStringExtra("pono")
           val orddtup = intent.getStringExtra("reorddate")
           val reqdtup = intent.getStringExtra("reestdt")
           val descup = intent.getStringExtra("redesc")
           val postatusup = intent.getStringExtra("reduedate")
           val mainidup = intent.getStringExtra("reids")
           val prnmsup = intent.getStringExtra("names")
           val comnmup = intent.getStringExtra("titnm")
           val comphup = intent.getStringExtra("tiphone")

           frmval=intent.getStringExtra("backvald")


           vouno.setText(uppono)
           suppdate.setText(orddtup)
           invoicedate.setText(reqdtup)
           payduedate.setText(postatusup)
           suppdescrip.setText(descup)
           listoids.setText(mainidup)

           names.setText(prnmsup)
           comttname.setText(comnmup)
           comphone.setText(comphup)

           /*       val c = Calendar.getInstance()
                  System.out.println("Current time =&gt; " + c.time)

                  val df = SimpleDateFormat("dd/MM/yyyy")
                  val formattedDate = df.format(c.time)

                  orddate.setText(formattedDate)*/

           pronameArray = aw.clone()
           manufacturerArray = bw.clone()
           quantityArray = dw.clone()
           priceArray = fw.clone()
           hsnArray = cw.clone()
           barcodeArray = gw.clone()
           totArray = hw.clone()
           cessArray = lw.clone()
           keyArray = piddli.clone()
           igstArray = mw.clone()
           cgstArray = cgw.clone()
           sgstArray = sgw.clone()
           igsttotArray = nw.clone()
           cesstotalArray = ow.clone()
           tallyArray = pw.clone()
           receivedArray = rew.clone()
           receivedpriceArray = rewpri.clone()
           receivedtaxtotalArray = rewtaxtot.clone()
           receivedcesstotArray = rewcesstot.clone()
           receivedgrosstotArray = rewgrosstot.clone()
           receivedtotalArray = rewtot.clone()
           imageArray = imm.clone()
/*
           val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray, receivedtaxtotalArray, receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, imageArray)
           supp_third_list.adapter = whatever
           Helper.getListViewSize(supp_third_list);*/
           if(savecli!="clicked") {
               try {
                   var total = 0.0F
                   var igsttot = 0.0F
                   var cesstotals = 0.0F
                   var b = 2
                   for (i in 0 until priceArray.count()) {
                       var c = (priceArray[i])
                       var cy = (igsttotArray[i])
                       var cyz = (cesstotalArray[i])
                       var qyz = (quantityArray[i])

                       var cdec = c.toBigDecimal()
                       var qyzdec = qyz.toBigDecimal()
                       var totquanpri = (cdec * qyzdec)




                       total = total.plus(totquanpri.toInt())

                       igsttot = igsttot.plus(cy.toFloat())
                       cesstotals = cesstotals.plus(cyz.toFloat())

                       igst_tot.text = igsttot.toString()
                       var l = igst_tot.text.toString()
                       var ss = l.toBigDecimal()
                       var tt = ss / b.toBigDecimal()
                       cgst_tot.text = tt.toString()
                       sgst_tot.text = tt.toString()

                       cess_tot.text = cesstotals.toString()

                       var f = cesstotals
                       var g = igsttot

                       var op = total
                       var m = f.toFloat()
                       var n = g.toFloat()

                       var yy = m + n + op

                       try {
                           gross_tot.setText(yy.toString())
                       } catch (e: Exception) {
                           gross_tot.text = yy.toString()
                       }
                       Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                       var d = pronameArray[i]
                       var t = d.removeSuffix("- ml")
                       prodnms = prodnms.plusElement(t)
                       names.setText(Arrays.toString(prodnms))
                       var u = names.text
                       var s = u.removePrefix("[")
                       var y = s.removeSuffix("]")
                       names.setText(y)



                       println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                   }
               } catch (e: Exception) {
                   Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
               }
           }
       }

        vouno.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {




            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })


        suppdate.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {




            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })

        invoicedate.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

               /* descriplistener="descchanged"*/

               errinv.visibility=View.INVISIBLE

                invoicedate.setError(null)


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })

        payduedate.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {


                errpaydue.visibility = View.INVISIBLE

                payduedate.setError(null)

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })

        suppdescrip.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {




            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })

















        save.setOnClickListener {

            if(net_status()==true) {
                 savecli="clicked"

                if (invoicedate.text.toString().isEmpty()) {


                    invoicedate.setError("Required field*")


                }
                if (payduedate.text.toString().isEmpty()) {


                    payduedate.setError("Required field*")
                }
                if ((suppinids.text == "") && (invoicedate.text.toString().isNotEmpty()) && (payduedate.text.toString().isNotEmpty()) && (transfersuppin == "true")) {
                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                    pDialog.setTitleText("Saving...");
                    pDialog.setCancelable(false);
                    pDialog.show();
                    onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, keyArray, receivedpriceArray, receivedcesstotArray, receivedtaxtotalArray, receivedgrosstotArray, receivedtotalArray, imageArray)
                } else if ((suppinids.text != "") && (transfersuppin == "true")) {
                    if( (vounodup!=vouno.text.toString())||(invoicedatedup!=invoicedate.text.toString())||(payduedatedup!=payduedate.text.toString())||(suppdescripdup!=suppdescrip.text.toString())||(statdup!=paidspin.selectedItem.toString()))
                    {
                        descriplistener="descchanged"
                    }
                    if(descriplistener=="descchanged") {
                        var brnchidd = brnchids
                        var pono = (vouno.text).toString()
                        var imurl = (imgurl.text).toString()
                        var datesc = (dates.text).toString()
                        var order_date = (suppdate.text).toString()
                        var po_Desc = (suppdescrip.text).toString()
                        var invoice = (invoicedate.text).toString()
                        var igsttot = (igst_tot.text).toString()
                        var cgsttot = (cgst_tot.text).toString()
                        var sgsttot = (sgst_tot.text).toString()
                        var cesstot = (cess_tot.text).toString()
                        var grosstot = (gross_tot.text).toString()
                        var brid = (listoids.text).toString()
                        var duedate = payduedate.text.toString()
                        var suppname = comttname.text.toString()
                        var suppphon = comphone.text.toString()
                        var product_nms = (names.text).toString()
                        var status = paidspin.selectedItem.toString()

                        val data = s(branchid = brnchidd, voucher_number = pono, date = order_date, description = po_Desc,
                                invoice_date = invoice, igst_tot = igsttot, cgst_tot = cgsttot, sgst_tot = sgsttot, cess_tot = cesstot,
                                gross_tot = grosstot, stk_brid = brid, payment_duedate = duedate, status = status, prod_nms = product_nms,
                                supplier_name = suppname, supplier_phone = suppphon, datest = datesc, imgurl = imurl, imagename = imgname, voucher_id = vou_id)


                        var db = FirebaseFirestore.getInstance()
                        println(Arrays.toString(ids))


                        if ((suppinids.text != "") && (invoicedate.text.toString().isNotEmpty()) && (payduedate.text.toString().isNotEmpty()) && (transfersuppin == "true")) {
                            pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();
                            db.collection("${brnchids}_Supplier Invoice").document(suppinids.text.toString())
                                    .set(data)
                                    .addOnSuccessListener { documentReference ->

                                        if (imgname.isNotEmpty() == true) {
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("imagename", imgname)
                                        } else {
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("imagename", imgnameedit)
                                        }
                                        var refid = suppinids.text.toString()
                                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                                        var path = "${brnchids}_Supplier Invoice/$refid/purchase_products"

                                        /*  for (i in 0 until priceArray.size) {
                                        var stk_name = pronameArray[i]
                                        var stk_mfr = manufacturerArray[i]
                                        var stk_hsn = hsnArray[i]
                                        var stk_bcode = barcodeArray[i]
                                        var stk_quan = quantityArray[i]
                                        var stk_pri = priceArray[i]
                                        var stk_tot = totArray[i]
                                        var stk_cess = cessArray[i]
                                        var stk_igst = igstArray[i]
                                        var stk_cgst = cgstArray[i]
                                        var stk_sgst = sgstArray[i]
                                        var stk_igsttot = igsttotArray[i]
                                        var stk_cesstot = cesstotalArray[i]
                                        var stk_tally = tallyArray[i]
                                        var stk_received = receivedArray[i]
                                        var stk_receivedpri = receivedpriceArray[i]
                                        var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                        var stk_receivedcesstot = receivedcesstotArray[i]
                                        var stk_receivedgrosstot = receivedgrosstotArray[i]
                                        var stk_receivedtot = receivedtotalArray[i]
                                        var stk_key = keyArray[i]
                                        var im_arr = imageArray[i]


                                        var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst, otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri, received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot, received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = im_arr)
                                        *//*  if (keyArray[i].equals("")) {
                                    db.collection(path)
                                            .add(d)
                                            .addOnSuccessListener { documentReference ->

                                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                var refid = documentReference.id

                                            }
                                }*//*

                                        *//* else if(getiddel.isNotEmpty()){
                                val deleteSize =  getiddel.size
                                val i = 0
                                for (i in getiddel) {
                                    db.collection(path).document(i.toString())
                                            .delete()
                                            .addOnSuccessListener {
                                                getiddel.clear()
                                                onBackPressed()


                                            }
                                }
                            }*//*

                                        db.collection(path).document(keyArray[i])
                                                .set(d)
                                                .addOnCompleteListener {*/


                                        Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()
                                        pDialogs!!.dismiss()

                                        val p = Intent(this@Supplier_thirdMainActivity, Supplier_first_MainActivity::class.java)

                                        p.putExtra("from_ver", "supp_four")
                                        p.putExtra("bridkey", brnchids)
                                        p.putExtra("viewsuppin", viewsuppin)
                                        p.putExtra("addsuppin", addsuppin)
                                        p.putExtra("deletesuppin", deletesuppin)
                                        p.putExtra("editsuppin", editesuppin)
                                        p.putExtra("transfersuppin", transfersuppin)
                                        p.putExtra("exportsuppin", exportsuppin)



                                        p.putExtra("viewpurord", viewpurord)
                                        p.putExtra("addpurord", addpurord)
                                        p.putExtra("deletepurord", deletepurord)
                                        p.putExtra("editpurord", editepurord)
                                        p.putExtra("transferpurord", transferpurord)
                                        p.putExtra("exportpurord", exportpurord)

                                        p.putExtra("sendpurord", sendpurpo)



                                        p.putExtra("viewpurreq", viewpurreq)
                                        p.putExtra("addpurreq", addpurreq)
                                        p.putExtra("deletepurreq", deletepurreq)
                                        p.putExtra("editpurreq", editepurreq)
                                        p.putExtra("transferpurreq", transferpurreq)
                                        p.putExtra("exportpurreq", exportpurreq)






                                        startActivity(p)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()


                                    }
                        }
                    }
                    else if(descriplistener!="descchanged"){
                        Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()
                    }
                } else if (transfersuppin == "false") {
                    popup("Make Invoice")
                }


            }
            else{
                Toast.makeText(applicationContext,"Please turn on your connection",Toast.LENGTH_SHORT).show()
            }

        }



















        fab.setOnClickListener {
            val intent= Intent(this,supplier_product_list::class.java)
            println(priceArray.size)
            println(pronameArray)
            println(priceArray)

            intent.putExtra("from_pur", "pur_datalist")
            intent.putExtra("namess", pronameArray)
            intent.putExtra("orderarray", manufacturerArray)
            intent.putExtra("hsn", hsnArray)
            intent.putExtra("poarray", barcodeArray)
            intent.putExtra("complete", quantityArray)
            intent.putExtra("price", priceArray)
            intent.putExtra("total", totArray)
            intent.putExtra("cess", cessArray)
            intent.putExtra("igst", igstArray)
            intent.putExtra("cgst", cgstArray)
            intent.putExtra("sgst", sgstArray)
            intent.putExtra("igsttotal", igsttotArray)
            intent.putExtra("cesstotarray", cesstotalArray)
            intent.putExtra("tallyarray", tallyArray)
            intent.putExtra("receivedarray", receivedArray)
            intent.putExtra("receivedarray_pri", receivedpriceArray)
            intent.putExtra("receivedarray_taxtot", receivedtaxtotalArray)
            intent.putExtra("receivedarray_tot", receivedtotalArray)
            intent.putExtra("receivedarray_cesstot", receivedcesstotArray)
            intent.putExtra("receivedarray_grosstot", receivedgrosstotArray)
            intent.putExtra("im", imageArray)
            intent.putExtra("idsofli",keyArray)

            intent.putExtra("backvald", frmval)

            intent.putExtra("reprnms", names.text.toString())
            intent.putExtra("nms", comttname.text.toString())
            intent.putExtra("ph", comphone.text.toString())
            intent.putExtra("pono", vouno.text.toString())

            intent.putExtra("orddate", suppdate.text.toString())
            intent.putExtra("desc", suppdescrip.text.toString())
            intent.putExtra("reqdate", invoicedate.text.toString())
            intent.putExtra("duedate", payduedate.text.toString())
            intent.putExtra("reqliid", listoids.text.toString())





            /* intent.putExtra("postatus",purc_spinner2.selectedItem.toString())*/
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()

        }
        mnu.setOnClickListener({


            val popup = PopupMenu(this@Supplier_thirdMainActivity, mnu)

            popup.menuInflater.inflate(R.menu.menu_suppinv, popup.menu)

            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@Supplier_thirdMainActivity, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()


                if(item.title=="Export as pdf")

                {
                    if((exportsuppin=="true")&&(net_status()==true)) {   //Navigate to pdf activity
                        val j = Intent(this@Supplier_thirdMainActivity, MainActivity_pdf::class.java)
                        j.putExtra("pnm", pronameArray)
                        j.putExtra("pmanu", manufacturerArray)
                        j.putExtra("phsn", hsnArray)
                        j.putExtra("barcode", barcodeArray)
                        j.putExtra("price", priceArray)
                        j.putExtra("quan", quantityArray)
                        j.putExtra("tot", totArray)
                        j.putExtra("backvald", frmval)
                        j.putExtra("cessup", cessArray)
                        j.putExtra("igst", igstArray)
                        j.putExtra("cgst", cgstArray)
                        j.putExtra("sgst", sgstArray)
                        j.putExtra("igsttotal", igsttotArray)
                        j.putExtra("cesstotarray", cesstotalArray)
                        j.putExtra("tallyarray", tallyArray)
                        j.putExtra("receivedarray", receivedArray)
                        j.putExtra("received_price", receivedpriceArray)
                        j.putExtra("received_total", receivedtotalArray)
                        j.putExtra("received_taxtot", receivedtaxtotalArray)
                        j.putExtra("received_cesstot", receivedcesstotArray)
                        j.putExtra("received_grosstot", receivedgrosstotArray)
                        j.putExtra("status", paidspin.selectedItem.toString())
                        j.putExtra("vounodup",vounodup)
                        j.putExtra("invoicedatedup",invoicedatedup)
                        j.putExtra("payduedatedup",payduedatedup)
                        j.putExtra("suppdescripdup",suppdescripdup)
                        j.putExtra("statdup",statdup)

                        j.putExtra("image", imageArray)
                        j.putExtra("pono", vouno.text.toString())
                        j.putExtra("reprnms", names.text.toString())
                        j.putExtra("reqliid", listoids.text.toString())
                        j.putExtra("orddate", suppdate.text.toString())
                        j.putExtra("desc", suppdescrip.text.toString())
                        j.putExtra("reqdate", invoicedate.text.toString())
                        j.putExtra("duedate", payduedate.text.toString())
                        j.putExtra("gross", gross_tot.text.toString())
                        j.putExtra("igsts", igst_tot.text.toString())
                        j.putExtra("cgsts", cgst_tot.text.toString())
                        j.putExtra("sgsts", sgst_tot.text.toString())
                        j.putExtra("cessts", cess_tot.text.toString())
                        j.putExtra("supnm", comttname.text.toString())
                        j.putExtra("supph", comphone.text.toString())
                        j.putExtra("datest",dates.text.toString())
                        j.putExtra("idsofli", keyArray)
                        j.putExtra("imgurl", imgurl.text.toString())
                        j.putExtra("bridkey", brnchids)
                        j.putExtra("edclick",editclick)

                        j.putExtra("viewsuppin", viewsuppin)
                        j.putExtra("addsuppin", addsuppin)
                        j.putExtra("deletesuppin", deletesuppin)
                        j.putExtra("editsuppin", editesuppin)
                        j.putExtra("transfersuppin", transfersuppin)
                        j.putExtra("exportsuppin", exportsuppin)





                        j.putExtra("viewpurord", viewpurord)
                        j.putExtra("addpurord", addpurord)
                        j.putExtra("deletepurord", deletepurord)
                        j.putExtra("editpurord", editepurord)
                        j.putExtra("transferpurord", transferpurord)
                        j.putExtra("exportpurord", exportpurord)
                        j.putExtra("sendpurord", sendpurpo)



                        j.putExtra("viewpurreq", viewpurreq)
                        j.putExtra("addpurreq", addpurreq)
                        j.putExtra("deletepurreq", deletepurreq)
                        j.putExtra("editpurreq", editepurreq)
                        j.putExtra("transferpurreq", transferpurreq)
                        j.putExtra("exportpurreq", exportpurreq)





                            j.putExtra("imgname", imgname)


                        j.putExtra("imgnameedit",imgnameedit)



                        startActivity(j)
                        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                        finish()
                    }
                    else{
                        if(net_status()==false){
                            Toast.makeText(this@Supplier_thirdMainActivity, "You're offline", Toast.LENGTH_SHORT).show()

                        }
                        else
                        {
                            popup("Export")

                        }
                    }
                }
                true

            }

            popup.show()

        })

        userback.setOnClickListener {
           onBackPressed()
        }





    }


    //Save action new supplier invoice insert and count


  private fun onStarClicked1(pronameArray:Array<String>, manufacturerArray:Array<String>, hsnArray:Array<String>, barcodeArray:Array<String>, quantityArray:Array<String>, priceArray:Array<String>, totArray:Array<String>, cessArray:Array<String>, igstArray:Array<String>,cgstArray:Array<String>, sgstArray:Array<String>, igsttotArray:Array<String>, cesstotalArray:Array<String>, tallyArray: Array<String>,receivedArray: Array<String>,keyArray:Array<String>,receivedpriceArray:Array<String>,receivedcesstotArray:Array<String>,receivedtaxtotalArray:Array<String>,receivedgrosstotArray:Array<String>,receivedtotalArray:Array<String>,imageArray: Array<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("Supplier_Invoice")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray.clone(),manufacturerArray.clone(),hsnArray.clone(),barcodeArray.clone(),quantityArray.clone(),priceArray.clone(),totArray.clone(),cessArray.clone(),igstArray.clone(),cgstArray.clone(),sgstArray.clone(),igsttotArray.clone(),cesstotalArray.clone(),tallyArray.clone(),receivedArray.clone(),keyArray.clone(),receivedpriceArray.clone(),receivedcesstotArray.clone(),receivedtaxtotalArray.clone(),receivedgrosstotArray.clone(),receivedtotalArray.clone(),imageArray.clone())


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }

 fun prod_insert(id1: String, pronameArray: Array<String>, manufacturerArray: Array<String>, hsnArray: Array<String>, barcodeArray: Array<String>, quantityArray: Array<String>, priceArray: Array<String>, totArray: Array<String>, cessArray: Array<String>,igstArray:Array<String>,cgstArray:Array<String>,sgstArray:Array<String>,igsttotArray:Array<String>,cesstotalArray:Array<String>,tallyArray:Array<String>,receivedArray:Array<String>,keyArray:Array<String>,receivedpriceArray:Array<String>,receivedcesstotArray:Array<String>,receivedtaxtotalArray:Array<String>,receivedgrosstotArray:Array<String>,receivedtotalArray:Array<String>,imageArray: Array<String>) {

     var pono = "Siv"+(vouno.text).toString()
     var bridsss=brnchids
     var imurl=(imgurl.text).toString()
     var suppname=comttname.text.toString()
     var datesc = (dates.text).toString()
     var suppphon=comphone.text.toString()
     var order_date = (suppdate.text).toString()
     var po_Desc = (suppdescrip.text).toString()
     var product_nms = (names.text).toString()
     var invoice=(invoicedate.text).toString()
     var igsttot = (igst_tot.text).toString()
     var cgsttot = (cgst_tot.text).toString()
     var sgsttot = (sgst_tot.text).toString()
     var cesstot = (cess_tot.text).toString()
     var grosstot = (gross_tot.text).toString()
     var brid=(listoids.text).toString()
     var duedate=payduedate.text.toString()
     var status=paidspin.selectedItem.toString()
     var imgnm=imgname


     println("SIV SSS"+pono)


     val data = s(branchid = bridsss,voucher_number = pono, date = order_date, description = po_Desc,invoice_date= invoice,igst_tot = igsttot ,
             cgst_tot = cgsttot,sgst_tot = sgsttot,cess_tot = cesstot,gross_tot = grosstot,stk_brid = brid,payment_duedate = duedate,
             status = status,prod_nms = product_nms,supplier_name = suppname,supplier_phone = suppphon,datest = datesc,
             imgurl = imurl,imagename = imgnm,voucher_id = id1)


     var db = FirebaseFirestore.getInstance()

     db.collection("${brnchids}_Supplier Invoice")
             .add(data)
             .addOnSuccessListener {documentReference ->
                 db.collection("${brnchids}_Purchase Orders").document(listoids.text.toString())
                         .update("supp_invoice","Add")
                         .addOnSuccessListener {
                             pDialogs!!.dismiss()
                         }
                 if(prodnms.isEmpty()){
                     pDialogs!!.dismiss()
                 }

                 var refid=documentReference.id

                 var path="${brnchids}_Supplier Invoice/$refid/purchase_products"
                 /*var receive_path="Receive Stock/$refid/Received stock items"*/
                 for(i in 0 until priceArray.size) {
                     var stk_name = pronameArray[i]
                     var stk_mfr = manufacturerArray[i]
                     var stk_hsn = hsnArray[i]
                     var stk_bcode = barcodeArray[i]
                     var stk_quan = quantityArray[i]
                     var stk_pri = priceArray[i]
                     var stk_tot = totArray[i]
                     var stk_cess = cessArray[i]
                     var stk_igst = igstArray[i]
                     var stk_cgst = cgstArray[i]
                     var stk_sgst = sgstArray[i]
                     var stk_igsttot = igsttotArray[i]
                     var stk_cesstot = cesstotalArray[i]
                     var stk_tally = tallyArray[i]
                     var stk_received = receivedArray[i]
                     var stk_receivedpri = receivedpriceArray[i]
                     var stk_receivedtaxtot = receivedtaxtotalArray[i]
                     var stk_receivedcesstot = receivedcesstotArray[i]
                     var stk_receivedgrosstot = receivedgrosstotArray[i]
                     var stk_receivedtot = receivedtotalArray[i]
                     var stk_key = keyArray[i]
                     var img_arr=imageArray[i]


                     println("keyaray[i]"+ keyArray[i])

                     var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess,otherstk_igst=stk_igst,otherstk_cgst=stk_cgst,otherstk_sgst=stk_sgst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot, stk_key = stk_key,otherstk_tally = stk_tally,otherstk_received = stk_received,received_price = stk_receivedpri,received_taxtotal = stk_receivedtaxtot,received_cesstotal = stk_receivedcesstot,received_grosstotal = stk_receivedgrosstot,received_total = stk_receivedtot,otherstk_img = img_arr)
                     if (keyArray[i].equals("")) {
                         db.collection(path)
                                 .add(d)
                                 .addOnSuccessListener { documentReference ->

                                     Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                     var refid = documentReference.id

                                     pDialogs!!.dismiss()

                                     Toast.makeText(this, "data is Saved", Toast.LENGTH_LONG).show()
                                     val p=Intent(this@Supplier_thirdMainActivity,Supplier_first_MainActivity::class.java)

                                     p.putExtra("from_ver","supp_four")
                                     p.putExtra("bridkey",brnchids)
                                     p.putExtra("viewsuppin", viewsuppin)
                                     p.putExtra("addsuppin", addsuppin)
                                     p.putExtra("deletesuppin", deletesuppin)
                                     p.putExtra("editsuppin", editesuppin)
                                     p.putExtra("transfersuppin", transfersuppin)
                                     p.putExtra("exportsuppin", exportsuppin)


                                     p.putExtra("viewpurord", viewpurord)
                                     p.putExtra("addpurord", addpurord)
                                     p.putExtra("deletepurord", deletepurord)
                                     p.putExtra("editpurord", editepurord)
                                     p.putExtra("transferpurord", transferpurord)
                                     p.putExtra("exportpurord", exportpurord)
                                     p.putExtra("sendpurord", sendpurpo)


                                     p.putExtra("viewpurreq", viewpurreq)
                                     p.putExtra("addpurreq", addpurreq)
                                     p.putExtra("deletepurreq", deletepurreq)
                                     p.putExtra("editpurreq", editepurreq)
                                     p.putExtra("transferpurreq", transferpurreq)
                                     p.putExtra("exportpurreq", exportpurreq)







                                     startActivity(p)
                                     overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                     finish()


                                     /*db.collection(receive_path).document(refid)
                                             .set(d)*/
                                 }
                     }

                    }



                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    /* save_progress.visibility = android.view.View.GONE*/
                }

    }



    //Back action



    override fun onBackPressed() {
        println("vounodup"+vounodup)
        println("statdup"+statdup)
        println("invoicedatedup"+invoicedatedup)
        println("payduedatedup"+payduedatedup)
        println("suppdescripdup"+suppdescripdup)

        println("vounodup text"+vouno.text.toString())
        println("statdup text"+paidspin.selectedItem.toString())
        println("invoicedatedup text"+invoicedate.text.toString())
        println("payduedatedup text"+payduedate.text.toString())
        println("suppdescripdup text"+suppdescrip.text.toString())

        if((vounodup!=vouno.text.toString())||(invoicedatedup!=invoicedate.text.toString())||
                (payduedatedup!=payduedate.text.toString())||(suppdescripdup!=suppdescrip.text.toString())||(statdup!=paidspin.selectedItem.toString()))
        {
            descriplistener="descchanged"
        }

        println("FRM VAL"+frmval)
        if(descriplistener=="descchanged"){

            savepopup()

        }
        else if(descriplistener.isEmpty()){

            if(frmval=="supp_invoice") {

                if(imgname.isNotEmpty()==true) {
                    val storage = FirebaseStorage.getInstance()
                    val storageRef = storage.getReference()
                    val imagesRef = storageRef.child("supplier_invoice").child(imgname)
                    imagesRef.delete()
                            .addOnSuccessListener {
                            }
                }


                val p = Intent(this@Supplier_thirdMainActivity, Supplier_first_MainActivity::class.java)
                p.putExtra("from_ver", "supp_four")
                p.putExtra("bridkey", brnchids)
                p.putExtra("viewsuppin", viewsuppin)
                p.putExtra("addsuppin", addsuppin)
                p.putExtra("deletesuppin", deletesuppin)
                p.putExtra("editsuppin", editesuppin)
                p.putExtra("transfersuppin", transfersuppin)
                p.putExtra("exportsuppin", exportsuppin)


                p.putExtra("viewpurord", viewpurord)
                p.putExtra("addpurord", addpurord)
                p.putExtra("deletepurord", deletepurord)
                p.putExtra("editpurord", editepurord)
                p.putExtra("transferpurord", transferpurord)
                p.putExtra("exportpurord", exportpurord)
                p.putExtra("sendpurord", sendpurpo)



                p.putExtra("viewpurreq", viewpurreq)
                p.putExtra("addpurreq", addpurreq)
                p.putExtra("deletepurreq", deletepurreq)
                p.putExtra("editpurreq", editepurreq)
                p.putExtra("transferpurreq", transferpurreq)
                p.putExtra("exportpurreq", exportpurreq)



                startActivity(p)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()


            }
            else if(frmval=="startlist_suppinv")
            {

                if((imgname.isNotEmpty()==true)&&(imgnameedit!=imgname)) {
                    val storage = FirebaseStorage.getInstance()
                    val storageRef = storage.getReference()
                    val imagesRef = storageRef.child("supplier_invoice").child(imgname)
                    imagesRef.delete()
                            .addOnSuccessListener {
                            }
                }



                val p = Intent(this@Supplier_thirdMainActivity,Supplier_first_MainActivity::class.java)
                p.putExtra("from_ver", "supp_four")
                p.putExtra("bridkey", brnchids)
                p.putExtra("viewsuppin", viewsuppin)
                p.putExtra("addsuppin", addsuppin)
                p.putExtra("deletesuppin", deletesuppin)
                p.putExtra("editsuppin", editesuppin)
                p.putExtra("transfersuppin", transfersuppin)
                p.putExtra("exportsuppin", exportsuppin)



                p.putExtra("viewpurord", viewpurord)
                p.putExtra("addpurord", addpurord)
                p.putExtra("deletepurord", deletepurord)
                p.putExtra("editpurord", editepurord)
                p.putExtra("transferpurord", transferpurord)
                p.putExtra("exportpurord", exportpurord)
                p.putExtra("sendpurord", sendpurpo)


                p.putExtra("viewpurreq", viewpurreq)
                p.putExtra("addpurreq", addpurreq)
                p.putExtra("deletepurreq", deletepurreq)
                p.putExtra("editpurreq", editepurreq)
                p.putExtra("transferpurreq", transferpurreq)
                p.putExtra("exportpurreq", exportpurreq)



                startActivity(p)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }
        }

    }




    //Save popup

    fun savepopup() {

        val builder = AlertDialog.Builder(this@Supplier_thirdMainActivity)
        with(builder) {


            if(frmval=="supp_invoice"){
                setTitle("Save changes?")
            }
            else if(frmval=="startlist_suppinv"){
                setTitle("Save?")
            }


            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->

                if (net_status() == true) {
                    savecli="clicked"
                    if ((suppinids.text == "") && (invoicedate.text.toString().isNotEmpty()) && (payduedate.text.toString().isNotEmpty()) && (transfersuppin == "true")) {
                        pDialogs = SweetAlertDialog(this@Supplier_thirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                        pDialogs!!.setTitleText("Saving...");
                        pDialogs!!.setCancelable(false);
                        pDialogs!!.show();
                        onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, keyArray, receivedpriceArray, receivedcesstotArray, receivedtaxtotalArray, receivedgrosstotArray, receivedtotalArray, imageArray)
                    } else if ((suppinids.text != "") && (transfersuppin == "true")) {
                        var brnchidd = brnchids
                        var pono = (vouno.text).toString()
                        var imurl = (imgurl.text).toString()
                        var datesc = (dates.text).toString()
                        var order_date = (suppdate.text).toString()
                        var po_Desc = (suppdescrip.text).toString()
                        var invoice = (invoicedate.text).toString()
                        var igsttot = (igst_tot.text).toString()
                        var cgsttot = (cgst_tot.text).toString()
                        var sgsttot = (sgst_tot.text).toString()
                        var cesstot = (cess_tot.text).toString()
                        var grosstot = (gross_tot.text).toString()
                        var brid = (listoids.text).toString()
                        var duedate = payduedate.text.toString()
                        var suppname = comttname.text.toString()
                        var suppphon = comphone.text.toString()
                        var product_nms = (names.text).toString()
                        var status = paidspin.selectedItem.toString()
                        var imgnm=imgname

                        val data = s(branchid = brnchidd, voucher_number = pono, date = order_date, description = po_Desc, invoice_date = invoice, igst_tot = igsttot,
                                cgst_tot = cgsttot, sgst_tot = sgsttot, cess_tot = cesstot,gross_tot = grosstot, stk_brid = brid, payment_duedate = duedate,
                                status = status, prod_nms = product_nms, supplier_name = suppname, supplier_phone = suppphon, datest = datesc, imgurl = imurl,
                                imagename = imgnm,voucher_id = vou_id)
                        var db = FirebaseFirestore.getInstance()

                        println(Arrays.toString(ids))
                        if ((suppinids.text !== "") && (invoicedate.text.toString().isNotEmpty()) && (payduedate.text.toString().isNotEmpty()) && (transfersuppin == "true")) {
                             pDialogs = SweetAlertDialog(this@Supplier_thirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();
                            db.collection("${brnchids}_Supplier Invoice").document(suppinids.text.toString())
                                    .set(data)
                                    .addOnSuccessListener { documentReference ->
                                        if(imgname.isNotEmpty()==true) {
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("imagename", imgname)
                                        }
                                        else{
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("imagename", imgnameedit)
                                        }
                                        var refid = suppinids.text.toString()
                                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                                        var path = "${brnchids}_Supplier Invoice/$refid/purchase_products"

                                        /*for (i in 0 until priceArray.size) {
                                            var stk_name = pronameArray[i]
                                            var stk_mfr = manufacturerArray[i]
                                            var stk_hsn = hsnArray[i]
                                            var stk_bcode = barcodeArray[i]
                                            var stk_quan = quantityArray[i]
                                            var stk_pri = priceArray[i]
                                            var stk_tot = totArray[i]
                                            var stk_cess = cessArray[i]
                                            var stk_igst = igstArray[i]
                                            var stk_cgst = cgstArray[i]
                                            var stk_sgst = sgstArray[i]
                                            var stk_igsttot = igsttotArray[i]
                                            var stk_cesstot = cesstotalArray[i]
                                            var stk_tally = tallyArray[i]
                                            var stk_received = receivedArray[i]
                                            var stk_receivedpri = receivedpriceArray[i]
                                            var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                            var stk_receivedcesstot = receivedcesstotArray[i]
                                            var stk_receivedgrosstot = receivedgrosstotArray[i]
                                            var stk_receivedtot = receivedtotalArray[i]
                                            var stk_key = keyArray[i]
                                            var im_arr = imageArray[i]


                                            var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst, otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri, received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot, received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = im_arr)
                                            *//*  if (keyArray[i].equals("")) {
                                        db.collection(path)
                                                .add(d)
                                                .addOnSuccessListener { documentReference ->

                                                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                    var refid = documentReference.id

                                                }
                                    }*//*

                                            *//* else if(getiddel.isNotEmpty()){
                                    val deleteSize =  getiddel.size
                                    val i = 0
                                    for (i in getiddel) {
                                        db.collection(path).document(i.toString())
                                                .delete()
                                                .addOnSuccessListener {
                                                    getiddel.clear()
                                                    onBackPressed()


                                                }
                                    }
                                }*//*

                                            db.collection(path).document(keyArray[i])
                                                    .set(d)
                                                    .addOnCompleteListener {*/
                                                        Toast.makeText(this@Supplier_thirdMainActivity, "Your Data is Saved", Toast.LENGTH_LONG).show()
                                                        pDialogs!!.dismiss()

                                                        val p = Intent(this@Supplier_thirdMainActivity, Supplier_first_MainActivity::class.java)
                                        p.putExtra("from_ver", "supp_four")
                                        p.putExtra("bridkey", brnchids)
                                                        p.putExtra("viewsuppin", viewsuppin)
                                                        p.putExtra("addsuppin", addsuppin)
                                                        p.putExtra("deletesuppin", deletesuppin)
                                                        p.putExtra("editsuppin", editesuppin)
                                                        p.putExtra("transfersuppin", transfersuppin)
                                                        p.putExtra("exportsuppin", exportsuppin)



                                                        p.putExtra("viewpurord", viewpurord)
                                                        p.putExtra("addpurord", addpurord)
                                                        p.putExtra("deletepurord", deletepurord)
                                                        p.putExtra("editpurord", editepurord)
                                                        p.putExtra("transferpurord", transferpurord)
                                                        p.putExtra("exportpurord", exportpurord)
                                                        p.putExtra("sendpurord", sendpurpo)


                                                        p.putExtra("viewpurreq", viewpurreq)
                                                        p.putExtra("addpurreq", addpurreq)
                                                        p.putExtra("deletepurreq", deletepurreq)
                                                        p.putExtra("editpurreq", editepurreq)
                                                        p.putExtra("transferpurreq", transferpurreq)
                                                        p.putExtra("exportpurreq", exportpurreq)






                                                        startActivity(p)
                                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                                        finish()





                                    }
                        }

                    } else if (transfersuppin == "false") {
                        popup("Make Invoice")
                    }


                }
                else{
                    dialog.dismiss()
                }
            }
            setNegativeButton("No") { dialog, whichButton ->


                if(frmval=="supp_invoice") {


                    // delete image from storage when invoice is not saved.
                    if(imgname.isNotEmpty()==true) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("supplier_invoice").child(imgname)
                        imagesRef.delete()
                                .addOnSuccessListener {
                                }
                    }


                    val p = Intent(this@Supplier_thirdMainActivity, Supplier_first_MainActivity::class.java)
                    p.putExtra("from_ver", "supp_four")
                    p.putExtra("bridkey", brnchids)
                    p.putExtra("viewsuppin", viewsuppin)
                    p.putExtra("addsuppin", addsuppin)
                    p.putExtra("deletesuppin", deletesuppin)
                    p.putExtra("editsuppin", editesuppin)
                    p.putExtra("transfersuppin", transfersuppin)
                    p.putExtra("exportsuppin", exportsuppin)


                    p.putExtra("viewpurord", viewpurord)
                    p.putExtra("addpurord", addpurord)
                    p.putExtra("deletepurord", deletepurord)
                    p.putExtra("editpurord", editepurord)
                    p.putExtra("transferpurord", transferpurord)
                    p.putExtra("exportpurord", exportpurord)
                    p.putExtra("sendpurord", sendpurpo)



                    p.putExtra("viewpurreq", viewpurreq)
                    p.putExtra("addpurreq", addpurreq)
                    p.putExtra("deletepurreq", deletepurreq)
                    p.putExtra("editpurreq", editepurreq)
                    p.putExtra("transferpurreq", transferpurreq)
                    p.putExtra("exportpurreq", exportpurreq)



                    startActivity(p)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()


                }
                else if(frmval=="startlist_suppinv")
                {

                    if((imgname.isNotEmpty()==true)&&(imgnameedit!=imgname)) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("supplier_invoice").child(imgname)
                        imagesRef.delete()
                                .addOnSuccessListener {
                                }
                    }


                    val p = Intent(this@Supplier_thirdMainActivity, Supplier_first_MainActivity::class.java)
                    p.putExtra("from_ver", "supp_four")
                    p.putExtra("bridkey", brnchids)
                    p.putExtra("viewsuppin", viewsuppin)
                    p.putExtra("addsuppin", addsuppin)
                    p.putExtra("deletesuppin", deletesuppin)
                    p.putExtra("editsuppin", editesuppin)
                    p.putExtra("transfersuppin", transfersuppin)
                    p.putExtra("exportsuppin", exportsuppin)


                    p.putExtra("viewpurord", viewpurord)
                    p.putExtra("addpurord", addpurord)
                    p.putExtra("deletepurord", deletepurord)
                    p.putExtra("editpurord", editepurord)
                    p.putExtra("transferpurord", transferpurord)
                    p.putExtra("exportpurord", exportpurord)
                    p.putExtra("sendpurord", sendpurpo)


                    p.putExtra("viewpurreq", viewpurreq)
                    p.putExtra("addpurreq", addpurreq)
                    p.putExtra("deletepurreq", deletepurreq)
                    p.putExtra("editpurreq", editepurreq)
                    p.putExtra("transferpurreq", transferpurreq)
                    p.putExtra("exportpurreq", exportpurreq)



                    startActivity(p)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()
                }

            }
            val dialog = builder.create()
            dialog.show()
        }

        }





            fun getImageView(): ImageView {
        val imageView = findViewById<ImageView>(R.id.card) as ImageView
        return imageView
    }



    //Image pick result and save it to sorage.

    override fun onPickResult(r: PickResult) {

        if (r.error == null) {

         pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialogs!!.setTitleText("Loading...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();
            //If you want the Uri.
            //Mandatory to refresh image from Uri.
            //getImageView().setImageURI(null);

            //Setting the real returned image.
            //getImageView().setImageURI(r.getUri());

            //If you want the Bitmap.

            getImageView().setImageBitmap(r.bitmap)
            imageView4.visibility=View.INVISIBLE
            imageButton2.visibility=View.INVISIBLE

            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.getReference()
            val generator = Random()
            var n = 100
            n = generator.nextInt(n)
            val imname = "supplierinvoice-$n.jpg"
            imgname=imname
            val imagesRef = storageRef.child("supplier_invoice").child(imname)

//
//
//            // Get the data from an ImageView as bytes
            card.isDrawingCacheEnabled = true
            card.buildDrawingCache()
            val bitmap = card.drawingCache

            val baos = ByteArrayOutputStream()

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)


            val data = baos.toByteArray()
            val uploadTask = imagesRef.putBytes(data)

            uploadTask.addOnFailureListener(OnFailureListener {
                // Handle unsuccessful uploads
            }).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->


                val ur = taskSnapshot.downloadUrl

                imgurl.text = ur.toString()
                descriplistener="descchanged"
                pDialogs!!.dismiss()



                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                val downloadUrl = taskSnapshot.downloadUrl

            })
            uploadTask.addOnProgressListener { taskSnapshot ->


            }.addOnPausedListener { println("Upload is paused") }


            //Image path
            r.getPath();
        } else {
            //Handle possible errors
            //TODO: do what you have to do with r.getError();
            Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
        }
        // Reference to an image file in Firebase Storage


    }




    fun selectpic(view:View)
    {
        PickImageDialog.build(PickSetup()).show(this)  //Image pick dialog
    }


    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    companion object {
        //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        private var bottnav: LinearLayout? = null
        private val log_str: String? = null
        private var userbackdis:ImageButton?=null
        private var mnudis:ImageButton?=null
         private var editdis:ImageButton?=null
        private var savedis:Button?=null
        private var vounodis:EditText?=null
        private var suppdescripdis:EditText?=null
        private var invoicedatedis:EditText?=null
        private var payduedatedis:EditText?=null
        private var paidspin2dis:Spinner?=null
        var pDialogs: SweetAlertDialog? = null
        var imageButton2dis:ImageButton?=null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                userbackdis!!.isEnabled=false
                imageButton2dis!!.isEnabled=false
                mnudis!!.isEnabled=false
                editdis!!.isEnabled=false
                savedis!!.isEnabled=false
                vounodis!!.isEnabled=false
                suppdescripdis!!.isEnabled=false
                invoicedatedis!!.isEnabled=false
                payduedatedis!!.isEnabled=false
                paidspin2dis!!.isEnabled=false
                bottnav!!.visibility=View.GONE
                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {

                                /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                bottnav!!.visibility=View.VISIBLE

                userbackdis!!.isEnabled=true
                mnudis!!.isEnabled=true
                editdis!!.isEnabled=true
                savedis!!.isEnabled=true

                if(editdis!!.visibility!=View.VISIBLE){
                    vounodis!!.isEnabled=true
                    suppdescripdis!!.isEnabled=true
                    invoicedatedis!!.isEnabled=true
                    imageButton2dis!!.isEnabled=true
                    payduedatedis!!.isEnabled=true
                    paidspin2dis!!.isEnabled=true
                }

            }
        }
    }

    fun setDateordinv(view: View) {
        showDialog(999)

    }
    fun setDateordinv1(view: View) {
        showDialog(998)

    }

    override fun onCreateDialog(id: Int): Dialog? {
        // TODO Auto-generated method stub
        return if (id == 999) {
            DatePickerDialog(this,
                    myDateListener, year, month, day)
        }
        else if(id==998){
            DatePickerDialog(this,
                    myDateListener1, year, month, day)
        }
        else null
    }

    private fun showDate(year: Int, month: Int, day: Int) {
        dateView!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)




        if(dateView!!.text.isNotEmpty()){
            var f=dateView!!.text.toString()
            invoicedate.setText(f)
        }



    }
    private fun showDate1(year: Int, month: Int, day: Int) {
        dateView1!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)


        if(dateView1!!.text.isNotEmpty()){
            var f=dateView1!!.text.toString()
            payduedate.setText(f)
        }
    }


    fun net_status():Boolean{   //Check net status

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}


