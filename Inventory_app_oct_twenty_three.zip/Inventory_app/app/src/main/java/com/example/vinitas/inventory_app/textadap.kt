package com.example.vinitas.inventory_app
/**
 * Created by Vinitas on 22-12-2017.
 */
import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.squareup.picasso.Picasso

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.scroll_branch_one.*
import kotlinx.android.synthetic.main.scroll_stk_one.*
import java.nio.file.Files.size



/**
 * Created by vinitas IT on 13-12-2017.
 */
class text_adap(//to reference the Activity
        private val context: Activity,
        //to store the list of countries
        private val pronameArray:   ArrayList<String>
        /* private val idArray:   ArrayList<String>,*/ //to store the list of countries
): ArrayAdapter<Any>(context, R.layout.act_stock_first_items, pronameArray as List<Any>) {

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val u=position
        val rowView = inflater.inflate(R.layout.textviewlistitems, null, true)

        //this code gets references to objects in the listview_row.xml file
        val nameTextField = rowView.findViewById<View>(R.id.textv) as TextView





        //this code sets the values of the objects to values from the arrays
        nameTextField.text = pronameArray[position]
        /*   idTextField.text = idArray[position]*/










        //infoTextField.text = infoArray[position]




        return rowView



    }


}