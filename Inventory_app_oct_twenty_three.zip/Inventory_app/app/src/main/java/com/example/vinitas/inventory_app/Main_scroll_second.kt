package com.example.vinitas.inventory_app

import android.annotation.SuppressLint
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.scroll_second_two.*
import java.text.DecimalFormat
import java.util.*

class Main_scroll_second : AppCompatActivity() {

    var halfpr= String()


    var names = String()
    var namesphones = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var smlistidss= String()
    var idli= String()
    var recons=String()
    var tallysend= String()
    var igstdiv= String()
    var receiv=String()
    var pzsave:Int = 0
    var asave=arrayOf<String>()
    var dsysave=arrayOf<String>()
    var fysave=arrayOf<String>()
    var gysave=arrayOf<String>()
    var hysave=arrayOf<String>()
    var kysave=arrayOf<String>()
    var mysave=arrayOf<String>()
    var nysave=arrayOf<String>()
    var oysave=arrayOf<String>()
    var pysave=arrayOf<String>()
    var tallysave=arrayOf<String>()
    var receivedsave=arrayOf<String>()
    var receivedsavecpy=arrayOf<String>()

    var idddsave= arrayOf<String>()
    var lysave= arrayOf<String>()
    var immysave= arrayOf<String>()

var oriprosave=arrayOf<String>()


var editchange= String()

    var bridds= String()

    //VALUES FOR TAX DETAILS

    var igsted=String()
    var igtot=String()
    var cestot=String()
    var grosstot=String()
var tallychckdis= String()
    var pri= String()

    var changecom= String()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""

    var descriplistener=String()
    var reccntlistener=String()
    var recdatelistener=String()
    var reconlistener=String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    var db = FirebaseFirestore.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll_second_two)

        net_status()//Check net status



        //Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Main_scroll_second) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view and other views when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        req_updatedis=findViewById(R.id.receiveupdate)
        userbackdis=findViewById(R.id.userback)


        quan_receiveddis=findViewById(R.id.quan_received)
        scrollView2dis=findViewById(R.id.scrollView2)

        var halfprflo:Float



        bcd_pid_rec.isEnabled=false
        orddate_rec.isEnabled=false
        prd_nm_rec.isEnabled=false
        rec_pri.isEnabled=false
        quan_transf_first_rec.isEnabled=false
        total_rec.isEnabled=false
        cess_edt_trans_rec.isEnabled=false
        cgst_rec.isEnabled=false
        sgst_rec.isEnabled=false
        quan_received.isEnabled=true


        edit.setOnClickListener{//Edit button click
            println("EDT PERMISSION"+editrec)
            if(editrec=="true"){

                edit.visibility=View.GONE
                receiveupdate.visibility=View.VISIBLE

               /* bcd_pid_rec.isEnabled=true
                orddate_rec.isEnabled=true
                prd_nm_rec.isEnabled=true
                rec_pri.isEnabled=true
                quan_transf_first_rec.isEnabled=true
                total_rec.isEnabled=true
                cess_edt_trans_rec.isEnabled=true
                cgst_rec.isEnabled=true
                sgst_rec.isEnabled=true*/
                quan_received.isEnabled=true
            }
            else if(editrec=="false"){
                popup("Receive")
            }
        }





        val bundle = intent.extras
        var frm = bundle!!.get("fromreceive").toString()

        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }


        //Purchase order





        //Place list items to each edittext

        var a= bundle.get("receivepnm") as Array<String>
        println(a)
        val dsy=bundle.get("receivephsn") as Array<String>
        val ly=bundle.get("receivepmanu")    as Array<String>
        val fy=bundle.get("receivebarcode") as Array<String>
        val gy=bundle.get("receive_quan")    as Array<String>
        val hy=bundle.get("receiveprice")   as Array<String>
        val ky=bundle.get("receive_tot")     as Array<String>
        val my=bundle.get("receive_cessup")  as Array<String>
        val ny=bundle.get("receive_igst") as Array<String>
        val oy=bundle.get("receive_igsttotal") as Array<String>
        val py=bundle.get("receive_cesstotarray") as Array<String>
        val iddd=bundle.get("receive_idsofli") as Array<String>
        val tally=bundle.get("tallyarray") as Array<String>
        val received=bundle.get("receivedarray") as Array<String>
        val receivedcpy=bundle.get("receivedarraycpy") as Array<String>

        val immy=bundle.get("receive_image") as Array<String>
        var  oripro=bundle.get("oriproarray") as Array<String>

        asave=a
        dsysave=dsy
        fysave=fy
        gysave=gy
        hysave=hy
        kysave=ky
        mysave=my
        nysave=ny
        oysave=oy
        pysave=py
        tallysave=tally
        receivedsave=received
        receivedsavecpy=receivedcpy

        idddsave=iddd
        immysave=immy
        lysave=ly
        oriprosave=oripro

        val namebr=intent.getStringExtra("otherst_branch")
        val datest=bundle.get("receive_sstkdate")
        val smlistid=intent.getStringExtra("otherst_smlistids")
        val locbr=intent.getStringExtra("otherst_address")
        val stockid=intent.getStringExtra("receive_ssstockid")
        val stockdesc=intent.getStringExtra("receive_ssstkdesc")
        val iddb=intent.getStringExtra("receive_idofdb")
        val recon=intent.getStringExtra("recon")
        val branid=intent.getStringExtra("brid")

        recons=recon
   try {
        descriplistener=intent.getStringExtra("descriplistener")
        reccntlistener=intent.getStringExtra("reccntlistener")
        recdatelistener=intent.getStringExtra("recdatelistener")
        reconlistener=intent.getStringExtra("reconlistener")
}
        catch (e:Exception){

        }

       

        val nm=intent.getStringExtra("receive_name")
        val addre=intent.getStringExtra("receive_addre")

        comttname.text = nm
        comphone.text  = addre
        println("NAME"+nm)




        println("TALLY VALUEeee " +tally)

        /*.setText(smlistid)
        smlistidss=other_idoflist.text.toString()*/

        idofre_rec.setText(iddb)
        desc_rec.setText(stockdesc)
        stkid_rec.setText(stockid)
        try {
            bridds = branid
        }
        catch (e:Exception){

        }


        date_rec.setText(datest.toString())
        println("PRINT THE DATEEEE  "+datest)


        names=comttname.text.toString()

        datestk=date_rec.text.toString()
        println("YOYO OO DATEEEE"+datestk)
        descstk=desc_rec.text.toString()
        idstk=stkid_rec.text.toString()
        iddbs=idofre_rec.text.toString()
        println(iddbs)


        namesphones=comphone.text.toString()







/*
        if(tallychk=="Not tallied")

        {



        }

        else if(tallychk=="Tallied")

        {
            edit.isEnabled=false
            receiveupdate.visibility= View.GONE
            edit.visibility=View.VISIBLE
            edit.setImageResource(R.drawable.disable_edit)

            bcd_pid_rec.isEnabled=false
            orddate_rec.isEnabled=false
            prd_nm_rec.isEnabled=false
            rec_pri.isEnabled=false
            quan_transf_first_rec.isEnabled=false
            total_rec.isEnabled=false
            cess_edt_trans_rec.isEnabled=false
            cgst_rec.isEnabled=false
            sgst_rec.isEnabled=false
            quan_received.isEnabled=false


        }*/




     /*      d.add(b.toString())*/
        val pz=bundle.get("receive_pos") as Int

        pzsave=pz

        //quantity
        var quant=gy[pz]
        var quan:Int
        quan=quant.toInt()
        quan_transf_first_rec.setText(quant)//Quantity

        //total
        var totalof=ky[pz]
        total_rec.setText(totalof)//Total

        try
        {
            var halfpri = totalof.toInt()
            halfpr=halfpri.toString()

        }

        catch(e:Exception){
            var halfpri = totalof.toFloat()
            halfprflo=halfpri
        }
        gross_tot_rec.setText((String.format("%.2f",totalof.toFloat())))//Gross total
        var j=gross_tot_rec.text.toString()
        var jflo=j.toFloat()

        //name edt text
        var prname=a[pz]
        prd_nm_rec.setText(prname)//Product name

        //hsn code
        var prord=dsy[pz]
        orddate_rec.setText(prord)//HSn





        //barcode
        var bar=fy[pz]
        bcd_pid_rec.setText(bar)//BARCODE



        //cess
        var cssof=my[pz]
        cess_edt_trans_rec.setText(cssof)

        ///IGST
        var igstof=ny[pz]
        igstt.setText(igstof)


         var cgcl=igstt.text.toString()
        var cgst:Float
        var d=cgcl.toFloat()
        cgst=d/2
        cgst_rec.setText(cgst.toString())
        sgst_rec.setText(cgst.toString())
        var h=cgst_rec.text.toString()
        var k=sgst_rec.text.toString()
        var hflo=h.toFloat()
        var kflo=k.toFloat()
        var tflo=hflo+kflo





        //CESS TTAL
        var cesstotof=py[pz]
        cess_tot_rec.setText((String.format("%.2f",cesstotof.toFloat())))
        var g=cess_tot_rec.text.toString()
        var gflo=g.toFloat()
        var totflo=gflo+tflo+jflo
        gross_tot_rec.setText((String.format("%.2f",totflo.toFloat())))



        //TALLY
        var talluof=tally[pz]
       tallyrec.setText(talluof)


        var idof=iddd[pz]
        newid_rec.setText(idof)
        idli=newid_rec.text.toString()

        var reci=received[pz]
       quan_received.setText(reci)



        try {

            var pr: Int
            var halfprice:Int
            halfprice=halfpr.toInt()

            pr=halfprice/quan
            var prdiv = pr

            //CGST TOTAL
            var igsttotof=oy[pz]
            var cgsttot=(pr*quan)*(cgst/100)
            cgst_tot_rec.setText((String.format("%.2f",cgsttot)))
            igsttot.setText(igsttotof)

            //IGST TOTAL
            var sgsttotof=oy[pz]
            var sgsttot=(pr*quan)*(cgst/100)
            sgst_tot_rec.setText((String.format("%.2f",sgsttot)))

            rec_pri.setText(prdiv.toString())
        }
        catch(e:Exception){
            var pr: Float
            var halfpri=totalof.toFloat()
            pr=halfpri/quan
            var prdiv = pr

            //CGST TOTAL
            var igsttotof=oy[pz]
            var cgsttot=(pr*quan)*(cgst/100)
            cgst_tot_rec.setText((String.format("%.2f",cgsttot)))
            igsttot.setText(igsttotof)

            //IGST TOTAL
            var sgsttotof=oy[pz]
            var sgsttot=(pr*quan)*(cgst/100)
            sgst_tot_rec.setText((String.format("%.2f",sgsttot)))

            rec_pri.setText(prdiv.toString())
        }



        var tt="Tallied"


        //Quantity received edittetx textchange listener
        quan_received.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
              if(ig.toString() == quan_transf_first_rec.text.toString()){

                  //If quantity is equals to received quantity status will be "TALLIED"
                  tallyrec.text = tt
              }
                else{
                  //If quantity is not equals to received quantity status will be "Not tallied"
                  tallyrec.text = "Not tallied"
              }



            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                if(s.toString() == quan_transf_first_rec.text.toString()){
                   //If quantity is equals to received quantity status will be "TALLIED"
                    tallyrec.text = tt
                }
                else{
                      //If quantity is not equals to received quantity status will be "Not tallied"
                    tallyrec.text = "Not tallied"
                }




            }
            override fun afterTextChanged(s: Editable) {
            }
        })






        var upnm= arrayListOf<String>()
        val p=intent.getStringArrayListExtra("liids")

        receiveupdate.setOnClickListener {//Update click

            if(receivedsave[pzsave]!=quan_received.text.toString()){

                editchange="changed"

            }

             if(quan_received.text.isEmpty()){
            quan_received.setText("0")
        }

            if((quan_received.text.isNotEmpty())&&(quan_received.text.toString().toInt()<=quan_transf_first_rec.text.toString().toInt())){

                //Navigate to ScrollStkOneActivity with updated list items


                    val o = Intent(this@Main_scroll_second, ScrollStkOneActivity::class.java)

                    var dx = prd_nm_rec.text
                    var ex = orddate_rec.text
                    var fx = rec_pri.text.toString()
                    var gx = quan_transf_first_rec.text
                    var hx = bcd_pid_rec.text
                    var ix = gross_tot_rec.text
                    var jx = cess_edt_trans_rec.text
                    var kx = igstt.text.toString()
                    var lx = igsttot.text.toString()
                    var mx = cess_tot_rec.text.toString()
                    var talx = tallyrec.text.toString()
                    var receivex = quan_received.text.toString()

                    //ASSIGNING TAXES VALUES FOR PUT EXTRA

                    igsted = igstt.text.toString()
                    igtot = igsttot.text.toString()
                    cestot = cess_tot_rec.text.toString()
                    grosstot = gross_tot_rec.text.toString()


                    a[pz] = dx.toString()
                    dsy[pz] = ex.toString()

                    fy[pz] = hx.toString()
                    gy[pz] = gx.toString()
                    hy[pz] = fx.toString()
                    ky[pz] = ix.toString()
                    my[pz] = jx.toString()
                    ny[pz] = kx.toString()
                    oy[pz] = lx.toString()
                    py[pz] = mx.toString()
                    tally[pz] = talx.toString()
                    received[pz] = receivex.toString()


                    o.putExtra("otheruprenm", a)
                    o.putExtra("fromreceive", "updatereceive")
                    o.putExtra("otherupremanu", ly)
                    o.putExtra("otheruprekey", iddd)
                    o.putExtra("otheruprehsn", dsy)
                    o.putExtra("otherupreprice", hy)
                    o.putExtra("otheruprequan", gy)
                    o.putExtra("otheruprebc", fy)
                    o.putExtra("otherupretotal", ky)
                    o.putExtra("otheruprecess", my)
                    o.putExtra("otherupreimmg", immy)
                o.putExtra("otheroriproid", oripro)

                    o.putExtra("otherupbranch", names)

                    o.putExtra("otherupaddress", namesphones)
                    o.putExtra("otherupredate", datestk)
                    o.putExtra("comchange", editchange)

                    o.putExtra("otherupredesc", descstk)
                    o.putExtra("otheruprestkid", idstk)
                    o.putExtra("otherupreiddb", iddbs)
                    o.putExtra("otherupsmlistidss", smlistidss)
                    o.putExtra("otherupreiddofli", idli)
                    o.putExtra("otherreigst", ny)
                    o.putExtra("otherreigst_total", oy)
                    o.putExtra("othertally", tally)
                    o.putExtra("otherreceive", received)
                o.putExtra("otherreceivecpy", receivedcpy)

                o.putExtra("otherrecesstotal", py)
                    o.putExtra("otherbrid", bridds)
                    o.putExtra("receive_name", comttname.text.toString())
                    o.putExtra("receive_addre", comphone.text.toString())

                o.putExtra("descriplistener",descriplistener)
                o.putExtra("reccntlistener",reccntlistener)
                o.putExtra("recdatelistener",recdatelistener)
                o.putExtra("reconlistener",reconlistener)

                o.putExtra("recons",recons)

                o.putExtra("viewtrans", viewtrans)
                o.putExtra("addtrans", addtrans)
                o.putExtra("edittrans", editetrans)
                o.putExtra("deletetrans", deletetrans)
                o.putExtra("transfertrans", transfertrans)
                o.putExtra("exporttrans", exporttrans)
                o.putExtra("sendtrans", sendtrans)


                o.putExtra("viewtransano", viewtransano)
                o.putExtra("addtransano", addtransano)
                o.putExtra("edittransano", editetransano)
                o.putExtra("deletetransano", deletetransano)
                o.putExtra("transfertransano", transfertransano)
                o.putExtra("exporttransano", exporttransano)
                o.putExtra("sendtransano", sendtransano)

                o.putExtra("viewrec", viewrec)
                o.putExtra("addrec", addrec)
                o.putExtra("deleterec", deleterec)
                o.putExtra("editrec", editrec)
                o.putExtra("transferrec", transferrec)
                o.putExtra("exportrec", exportrec)
                o.putExtra("sendstrec",sendstrec)




                    startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()

                }

            else{

                //if received qnty is greater than quantity transferred alert popup will be shown.
                if(quan_received.text.toString().toInt()>quan_transf_first_rec.text.toString().toInt()) {
                    val builder = AlertDialog.Builder(this@Main_scroll_second)
                    with(builder) {
                        setTitle("Alert")
                        setMessage("Stock transferred count is " + quan_transf_first_rec.text.toString() + " but you received " + quan_received.text.toString())
                        setPositiveButton("Ok") { dialog, whichButton ->
                            dialog.dismiss()
                        }


                        // Dialog
                        val dialog = builder.create()

                        dialog.show()
                    }
                }



            }



        }


    userback.setOnClickListener {
        onBackPressed()
    }






    }

    fun popup(st:String){//Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {

        println("RECEIVE SAVE"+receivedsave[pzsave])
        println("RECEIVE SAVE EDITTEXT"+quan_received.text.toString())

        if(receivedsave[pzsave]!=quan_received.text.toString()){

            editchange="changed"

        }


        if(editchange.isEmpty()){

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }





            var halfprflo:Float


             if(quan_received.text.isEmpty()){
                quan_received.setText("0")
            }

            if((quan_received.text.isNotEmpty())&&(quan_received.text.toString().toInt()<=quan_transf_first_rec.text.toString().toInt()))

            {

                //Navigate to ScrollStkOneActivity with updated list items
                val o = Intent(this@Main_scroll_second, ScrollStkOneActivity::class.java)

                var dx = prd_nm_rec.text
                var ex = orddate_rec.text
                var fx = rec_pri.text.toString()
                var gx = quan_transf_first_rec.text
                var hx = bcd_pid_rec.text
                var ix = gross_tot_rec.text
                var jx = cess_edt_trans_rec.text
                var kx = igstt.text.toString()
                var lx = igsttot.text.toString()
                var mx = cess_tot_rec.text.toString()
                var talx = tallyrec.text.toString()
                var receivex = quan_received.text.toString()

                //ASSIGNING TAXES VALUES FOR PUT EXTRA

                igsted = igstt.text.toString()
                igtot = igsttot.text.toString()
                cestot = cess_tot_rec.text.toString()
                grosstot = gross_tot_rec.text.toString()


                asave[pzsave] = dx.toString()
                dsysave[pzsave] = ex.toString()

                fysave[pzsave] = hx.toString()
                gysave[pzsave] = gx.toString()
                hysave[pzsave] = fx.toString()
                kysave[pzsave] = ix.toString()
                mysave[pzsave] = jx.toString()
                nysave[pzsave] = kx.toString()
                oysave[pzsave] = lx.toString()
                pysave[pzsave] = mx.toString()
                tallysave[pzsave] = talx.toString()
                receivedsave[pzsave] = receivex.toString()

                println("BARCODE RECEIVE" + hx + receivex)


                o.putExtra("otheruprenm", asave)
                o.putExtra("fromreceive", "updatereceive")
                o.putExtra("otherupremanu", lysave)
                o.putExtra("otheruprekey", idddsave)
                o.putExtra("otheruprehsn", dsysave)
                o.putExtra("otherupreprice", hysave)
                o.putExtra("otheruprequan", gysave)
                o.putExtra("otheruprebc", fysave)
                o.putExtra("otherupretotal", kysave)
                o.putExtra("otheruprecess", mysave)
                o.putExtra("otherupreimmg", immysave)
                o.putExtra("otherupbranch", names)
                o.putExtra("otherupaddress", namesphones)
                o.putExtra("otherupredate", datestk)
                o.putExtra("otherupredesc", descstk)
                o.putExtra("comchange", editchange)
                o.putExtra("otheroriproid", oriprosave)


                o.putExtra("otheruprestkid", idstk)
                o.putExtra("otherupreiddb", iddbs)
                o.putExtra("otherupsmlistidss", smlistidss)
                o.putExtra("otherupreiddofli", idli)

                o.putExtra("otherreigst", nysave)
                o.putExtra("otherreigst_total", oysave)
                o.putExtra("othertally", tallysave)
                o.putExtra("otherreceive", receivedsave)
                o.putExtra("otherreceivecpy", receivedsavecpy)

                o.putExtra("otherrecesstotal", pysave)
                o.putExtra("otherbrid", bridds)
                o.putExtra("receive_name", comttname.text.toString())
                o.putExtra("receive_addre", comphone.text.toString())


                o.putExtra("descriplistener",descriplistener)
                o.putExtra("reccntlistener",reccntlistener)
                o.putExtra("recdatelistener",recdatelistener)
                o.putExtra("reconlistener",reconlistener)

                o.putExtra("viewtrans", viewtrans)
                o.putExtra("addtrans", addtrans)
                o.putExtra("edittrans", editetrans)
                o.putExtra("deletetrans", deletetrans)
                o.putExtra("transfertrans", transfertrans)
                o.putExtra("exporttrans", exporttrans)
                o.putExtra("sendtrans", sendtrans)


                o.putExtra("viewtransano", viewtransano)
                o.putExtra("addtransano", addtransano)
                o.putExtra("edittransano", editetransano)
                o.putExtra("deletetransano", deletetransano)
                o.putExtra("transfertransano", transfertransano)
                o.putExtra("exporttransano", exporttransano)
                o.putExtra("sendtransano", sendtransano)

                o.putExtra("viewrec", viewrec)
                o.putExtra("addrec", addrec)
                o.putExtra("deleterec", deleterec)
                o.putExtra("editrec", editrec)
                o.putExtra("transferrec", transferrec)
                o.putExtra("exportrec", exportrec)
                o.putExtra("sendstrec",sendstrec)

                o.putExtra("recons",recons)

                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }

            else{
                //if received qnty is greater than quantity transferred alert popup will be shown.

                if(quan_received.text.toString().toInt()>quan_transf_first_rec.text.toString().toInt()) {
                    val builder = AlertDialog.Builder(this@Main_scroll_second)
                    with(builder) {
                        setTitle("Alert")
                        setMessage("Stock transferred count is " + quan_transf_first_rec.text.toString() + " but you received " + quan_received.text.toString())
                        setPositiveButton("Ok") { dialog, whichButton ->
                            dialog.dismiss()
                        }


                        // Dialog
                        val dialog = builder.create()

                        dialog.show()
                    }
                }



            }





        }
        else if(editchange=="changed"){
            savepopup()

        }



    }

    fun savepopup() {//Save changes alert popup
        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }





        var halfprflo: Float

        /*val bundle = intent.extras
        var frm = bundle!!.get("fromreceive").toString()

        var a = bundle.get("receivepnm") as Array<String>
        println(a)
        val dsy = bundle.get("receivephsn") as Array<String>
        val ly = bundle.get("receivepmanu") as Array<String>
        val fy = bundle.get("receivebarcode") as Array<String>
        val gy = bundle.get("receive_quan") as Array<String>
        val hy = bundle.get("receiveprice") as Array<String>
        val ky = bundle.get("receive_tot") as Array<String>
        val my = bundle.get("receive_cessup") as Array<String>
        val ny = bundle.get("receive_igst") as Array<String>
        val oy = bundle.get("receive_igsttotal") as Array<String>
        val py = bundle.get("receive_cesstotarray") as Array<String>
        val iddd = bundle.get("receive_idsofli") as Array<String>
        val tally = bundle.get("tallyarray") as Array<String>
        val received = bundle.get("receivedarray") as Array<String>
        val immy = bundle.get("receive_image") as Array<String>

        val namebr = intent.getStringExtra("otherst_branch")
        val datest = bundle.get("receive_sstkdate")
        val smlistid = intent.getStringExtra("otherst_smlistids")
        val locbr = intent.getStringExtra("otherst_address")
        val stockid = intent.getStringExtra("receive_ssstockid")
        val stockdesc = intent.getStringExtra("receive_ssstkdesc")
        val iddb = intent.getStringExtra("receive_idofdb")
        val branid = intent.getStringExtra("brid")
        val nm = intent.getStringExtra("receive_name")

        val addre = intent.getStringExtra("receive_addre")
        comttname.setText(nm)
        comphone.setText(addre)





        println("TALLY VALUEeee " + tally)

        *//*.setText(smlistid)
        smlistidss=other_idoflist.text.toString()*//*

        idofre_rec.setText(iddb)
        desc_rec.setText(stockdesc)
        stkid_rec.setText(stockid)
        try {
            bridds = branid
        } catch (e: Exception) {

        }


        date_rec.setText(datest.toString())
        println("PRINT THE   DATEEEE  " + datest)


        names = comttname.text.toString()

        datestk = date_rec.text.toString()
        println("YOYO OO DATEEEE" + datestk)
        descstk = desc_rec.text.toString()
        idstk = stkid_rec.text.toString()
        iddbs = idofre_rec.text.toString()
        println(iddbs)


        namesphones = comphone.text.toString()


        *//*      d.add(b.toString())*//*
        val pz = bundle.get("receive_pos") as Int

        //quantity
        var quant = gy[pz]
        var quan: Int
        quan = quant.toInt()
        quan_transf_first_rec.setText(quant)

        //total
        var totalof = ky[pz]
        total_rec.setText(totalof)
        try {
            var halfpri = totalof.toInt()
            halfpr = halfpri.toString()

        } catch (e: Exception) {
            var halfpri = totalof.toFloat()
            halfprflo = halfpri
        }
        gross_tot_rec.setText(totalof)
        var j = gross_tot_rec.text.toString()
        var jflo = j.toFloat()

        //name edt text
        var prname = a[pz]
        prd_nm_rec.setText(prname)

        //hsn code
        var prord = dsy[pz]
        orddate_rec.setText(prord)


        //barcode
        var bar = fy[pz]
        bcd_pid_rec.setText(bar)


        //cess
        var cssof = my[pz]
        cess_edt_trans_rec.setText(cssof)

        ///IGST
        var igstof = ny[pz]
        igstt.setText(igstof)


        var cgcl = igstt.text.toString()
        var cgst: Int
        var d = cgcl.toInt()
        cgst = d / 2
        cgst_rec.setText(cgst.toString())
        sgst_rec.setText(cgst.toString())
        var h = cgst_rec.text.toString()
        var k = sgst_rec.text.toString()
        var hflo = h.toFloat()
        var kflo = k.toFloat()
        var tflo = hflo + kflo


        //CESS TTAL
        var cesstotof = py[pz]
        cess_tot_rec.setText(cesstotof)
        var g = cess_tot_rec.text.toString()
        var gflo = g.toFloat()
        var totflo = gflo + tflo + jflo
        gross_tot_rec.setText(totflo.toString())


        //TALLY
        var talluof = tally[pz]
        tallyrec.setText(talluof)


        var idof = iddd[pz]
        newid_rec.setText(idof)
        idli = newid_rec.text.toString()

        var reci = received[pz]
        quan_received.setText(reci)



        try {

            var pr: Int
            var halfprice: Int
            halfprice = halfpr.toInt()

            pr = halfprice / quan
            var prdiv = pr

            //CGST TOTAL
            var igsttotof = oy[pz]
            var cgsttot = (pr * quan) * (cgst / 100)
            cgst_tot_rec.setText(cgsttot.toString())
            igsttot.setText(igsttotof)

            //IGST TOTAL
            var sgsttotof = oy[pz]
            var sgsttot = (pr * quan) * (cgst / 100)
            sgst_tot_rec.setText(sgsttot.toString())

            rec_pri.setText(prdiv.toString())
        } catch (e: Exception) {
            var pr: Float
            var halfpri = totalof.toFloat()
            pr = halfpri / quan
            var prdiv = pr

            //CGST TOTAL
            var igsttotof = oy[pz]
            var cgsttot = (pr * quan) * (cgst / 100)
            cgst_tot_rec.setText(cgsttot.toString())
            igsttot.setText(igsttotof)

            //IGST TOTAL
            var sgsttotof = oy[pz]
            var sgsttot = (pr * quan) * (cgst / 100)
            sgst_tot_rec.setText(sgsttot.toString())

            rec_pri.setText(prdiv.toString())
        }*/


        val builder = AlertDialog.Builder(this@Main_scroll_second)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")

            if (quan_received.text.isEmpty()) {
                quan_received.setText("0")
            }

            setPositiveButton("Yes") { dialog, whichButton ->
                println("YES")
                if((quan_received.text.isNotEmpty())&&(quan_received.text.toString()<=quan_transf_first_rec.text.toString())) {


                    //Navigate to ScrollStkOneActivity with updated list items

                    val o = Intent(this@Main_scroll_second, ScrollStkOneActivity::class.java)

                        var dx = prd_nm_rec.text
                        var ex = orddate_rec.text
                        var fx = rec_pri.text.toString()
                        var gx = quan_transf_first_rec.text
                        var hx = bcd_pid_rec.text
                        var ix = gross_tot_rec.text
                        var jx = cess_edt_trans_rec.text
                        var kx = igstt.text.toString()
                        var lx = igsttot.text.toString()
                        var mx = cess_tot_rec.text.toString()
                        var talx = tallyrec.text.toString()
                        var receivex = quan_received.text.toString()

                        //ASSIGNING TAXES VALUES FOR PUT EXTRA

                        igsted = igstt.text.toString()
                        igtot = igsttot.text.toString()
                        cestot = cess_tot_rec.text.toString()
                        grosstot = gross_tot_rec.text.toString()


                        asave[pzsave] = dx.toString()
                        dsysave[pzsave] = ex.toString()

                        fysave[pzsave] = hx.toString()
                        gysave[pzsave] = gx.toString()
                        hysave[pzsave] = fx.toString()
                        kysave[pzsave] = ix.toString()
                        mysave[pzsave] = jx.toString()
                        nysave[pzsave] = kx.toString()
                        oysave[pzsave] = lx.toString()
                        pysave[pzsave] = mx.toString()
                        tallysave[pzsave] = talx.toString()
                        receivedsave[pzsave] = receivex.toString()

                        println("BARCODE RECEIVE" + hx + receivex)


                        o.putExtra("otheruprenm", asave)
                        o.putExtra("fromreceive", "updatereceive")
                        o.putExtra("otherupremanu", lysave)
                        o.putExtra("otheruprekey", idddsave)
                        o.putExtra("otheruprehsn", dsysave)
                        o.putExtra("otherupreprice", hysave)
                        o.putExtra("otheruprequan", gysave)
                        o.putExtra("otheruprebc", fysave)
                        o.putExtra("otherupretotal", kysave)
                        o.putExtra("otheruprecess", mysave)
                        o.putExtra("otherupreimmg", immysave)
                        o.putExtra("otherupbranch", names)
                        o.putExtra("otherupaddress", namesphones)
                        o.putExtra("otherupredate", datestk)
                        o.putExtra("otherupredesc", descstk)
                        o.putExtra("comchange", editchange)
                    o.putExtra("otheroriproid", oriprosave)

                        o.putExtra("otheruprestkid", idstk)
                        o.putExtra("otherupreiddb", iddbs)
                        o.putExtra("otherupsmlistidss", smlistidss)
                        o.putExtra("otherupreiddofli", idli)

                        o.putExtra("otherreigst", nysave)
                        o.putExtra("otherreigst_total", oysave)
                        o.putExtra("othertally", tallysave)
                        o.putExtra("otherreceive", receivedsave)
                    o.putExtra("otherreceive", receivedsavecpy)

                    o.putExtra("otherrecesstotal", pysave)
                        o.putExtra("otherbrid", bridds)
                        o.putExtra("receive_name", comttname.text.toString())
                        o.putExtra("receive_addre", comphone.text.toString())

                    o.putExtra("recons",recons)

                    o.putExtra("descriplistener",descriplistener)
                    o.putExtra("reccntlistener",reccntlistener)
                    o.putExtra("recdatelistener",recdatelistener)
                    o.putExtra("reconlistener",reconlistener)
                    o.putExtra("viewtrans", viewtrans)
                    o.putExtra("addtrans", addtrans)
                    o.putExtra("edittrans", editetrans)
                    o.putExtra("deletetrans", deletetrans)
                    o.putExtra("transfertrans", transfertrans)
                    o.putExtra("exporttrans", exporttrans)
                    o.putExtra("sendtrans", sendtrans)


                    o.putExtra("viewtransano", viewtransano)
                    o.putExtra("addtransano", addtransano)
                    o.putExtra("edittransano", editetransano)
                    o.putExtra("deletetransano", deletetransano)
                    o.putExtra("transfertransano", transfertransano)
                    o.putExtra("exporttransano", exporttransano)
                    o.putExtra("sendtransano", sendtransano)

                    o.putExtra("viewrec", viewrec)
                    o.putExtra("addrec", addrec)
                    o.putExtra("deleterec", deleterec)
                    o.putExtra("editrec", editrec)
                    o.putExtra("transferrec", transferrec)
                    o.putExtra("exportrec", exportrec)
                    o.putExtra("sendstrec",sendstrec)



                        startActivity(o)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                        finish()


                }
                else {
                    //if received qnty is greater than quantity transferred alert popup will be shown.

                    if (quan_received.text.toString().toInt() > quan_transf_first_rec.text.toString().toInt()) {
                        val builder = AlertDialog.Builder(this@Main_scroll_second)
                        with(builder) {
                            setTitle("Alert")
                            setMessage("Stock transferred count is " + quan_transf_first_rec.text.toString() + " but you received " + quan_received.text.toString())
                            setPositiveButton("Ok") { dialog, whichButton ->
                                dialog.dismiss()
                            }


                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }
                }

            }

            setNegativeButton("No") { dialog, whichButton ->

                //Navigate to ScrollStkOneActivity with old list items

                //showMessage("Close the game or anything!")
                println("No")
                val o= Intent(this@Main_scroll_second,ScrollStkOneActivity::class.java)

                /*var dx=  prd_nm_rec.text
                var ex=  orddate_rec.text
                var fx= rec_pri.text.toString()
                var gx=quan_transf_first_rec.text
                var hx=bcd_pid_rec.text
                var ix=gross_tot_rec.text
                var jx=cess_edt_trans_rec.text
                var kx=igstt.text.toString()
                var lx=igsttot.text.toString()
                var mx=cess_tot_rec.text.toString()
                var talx=tallyrec.text.toString()
                var receivex=quan_received.text.toString()

                //ASSIGNING TAXES VALUES FOR PUT EXTRA

                igsted=igstt.text.toString()
                igtot=igsttot.text.toString()
                cestot=cess_tot_rec.text.toString()
                grosstot=gross_tot_rec.text.toString()


                a[pz]=dx.toString()
                dsy[pz]=ex.toString()

                fy[pz]=hx.toString()
                gy[pz]=gx.toString()
                hy[pz]=fx.toString()
                ky[pz]=ix.toString()
                my[pz]=jx.toString()
                ny[pz]=kx.toString()
                oy[pz]=lx.toString()
                py[pz]=mx.toString()
                tally[pz]=talx.toString()
                received[pz]=receivex.toString()*/


                o.putExtra("otheruprenm",asave)
                o.putExtra("fromreceive","updatereceive")
                o.putExtra("otherupremanu",lysave)
                o.putExtra("otheruprekey",idddsave)
                o.putExtra("otheruprehsn",dsysave)
                o.putExtra("otherupreprice",hysave)
                o.putExtra("otheruprequan",gysave)
                o.putExtra("otheruprebc",fysave)
                o.putExtra("otherupretotal",kysave)
                o.putExtra("otheruprecess",mysave)
                o.putExtra("otherupreimmg",immysave)
                o.putExtra("otherupbranch",names)
                o.putExtra("otherupaddress",namesphones)
                o.putExtra("otherupredate",datestk)
                o.putExtra("otherupredesc",descstk)
                o.putExtra("comchange",editchange)
                o.putExtra("otheroriproid", oriprosave)

                o.putExtra("recons",recons)

                o.putExtra("otheruprestkid",idstk)
                o.putExtra("otherupreiddb",iddbs)
                o.putExtra("otherupsmlistidss",smlistidss)
                o.putExtra("otherupreiddofli",idli)
                o.putExtra("otherreigst",nysave)
                o.putExtra("otherreigst_total",oysave)
                o.putExtra("othertally",tallysave)
                o.putExtra("otherreceive",receivedsave)
                o.putExtra("otherreceivecpy",receivedsavecpy)

                o.putExtra("otherrecesstotal",pysave)
                o.putExtra("otherbrid",bridds)
                o.putExtra("receive_name", comttname.text.toString())
                o.putExtra("receive_addre", comphone.text.toString())




         o.putExtra("viewtrans", viewtrans)
         o.putExtra("addtrans", addtrans)
         o.putExtra("edittrans", editetrans)
         o.putExtra("deletetrans", deletetrans)
         o.putExtra("transfertrans", transfertrans)
         o.putExtra("exporttrans", exporttrans)
         o.putExtra("sendtrans", sendtrans)


         o.putExtra("viewtransano", viewtransano)
         o.putExtra("addtransano", addtransano)
         o.putExtra("edittransano", editetransano)
         o.putExtra("deletetransano", deletetransano)
         o.putExtra("transfertransano", transfertransano)
         o.putExtra("exporttransano", exporttransano)
         o.putExtra("sendtransano", sendtransano)

         o.putExtra("viewrec", viewrec)
         o.putExtra("addrec", addrec)
         o.putExtra("deleterec", deleterec)
         o.putExtra("editrec", editrec)
         o.putExtra("transferrec", transferrec)
         o.putExtra("exportrec", exportrec)
         o.putExtra("sendstrec",sendstrec)

                o.putExtra("descriplistener",descriplistener)
                o.putExtra("reccntlistener",reccntlistener)
                o.putExtra("recdatelistener",recdatelistener)
                o.putExtra("reconlistener",reconlistener)


                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
                dialog.dismiss()
            }

            // Dialog
            val dialog = builder.create()

            dialog.show()
        }
    }
    companion object {

        //Listens inetrnet status whether net is on/off.if internet connection becomes off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null


        private var quan_receiveddis: EditText?=null
        private var req_updatedis: Button? = null

        private var userbackdis: ImageButton? = null
        private var scrollView2dis: ScrollView?=null
        private var editdis: ImageButton? =null
        private var taxtotdup=String()


        private val log_str: String? = null

        @RequiresApi(Build.VERSION_CODES.M)
        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                req_updatedis!!.isEnabled=false

                val color = 0x96ffffff;
                val  drawables =  ColorDrawable(color.toInt());
                scrollView2dis!!.foreground=drawables

                quan_receiveddis!!.isEnabled=false//Quantity received edittext disable
                userbackdis!!.isEnabled=false//userback imagebutton  disable


                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {



                constraintLayout3dis!!.visibility=View.GONE
                req_updatedis!!.isEnabled=true//Update button enable

                userbackdis!!.isEnabled=true//userback imagebutton  enable

                quan_receiveddis!!.isEnabled=true//Quantity received edittext enable
                scrollView2dis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                scrollView2dis!!.foreground=null
                relativeslayoutdis!!.visibility=View.GONE





            }
        }
    }
    fun net_status():Boolean{//Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}