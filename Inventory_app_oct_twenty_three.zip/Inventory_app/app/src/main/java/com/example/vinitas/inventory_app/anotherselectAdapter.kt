package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView

/**
 * Created by vinitas stock on 04-01-2018.
 */
class anotherselectAdapter(
        private val context: Activity,
        private val bn: Array<String>,
        private val loc: Array<String>,
        private val dpic: Array<Int>) : ArrayAdapter<Any>(context,R.layout.anotherselect_list,bn){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.anotherselect_list, null, true)
        val branchname = rowView.findViewById<TextView>(R.id.branchname1) as TextView
        val location = rowView.findViewById<TextView>(R.id.location1) as TextView
        val dp = rowView.findViewById<CircleImageView>(R.id.dp1) as CircleImageView
        branchname.text = bn[position]
        location.text = loc[position]
        dp.setImageResource(dpic[position])
        return rowView
    }
}