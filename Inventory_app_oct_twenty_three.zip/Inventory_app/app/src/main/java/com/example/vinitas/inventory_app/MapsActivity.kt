package com.example.vinitas.inventory_app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.support.v7.app.AppCompatActivity
import android.support.v4.app.Fragment;
import android.os.Bundle
import android.provider.Settings
import android.support.v4.app.FragmentManager
import android.util.Log
import android.view.View

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.GoogleMap.OnMapClickListener
import android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS
import android.location.Criteria
import android.location.LocationListener
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AlertDialog
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnSuccessListener
import java.util.logging.Logger


class MapsActivity : AppCompatActivity(), OnMapReadyCallback  {
    var f11=String()
    var s11=String()
    var t11=String()
    var fo11=String()
    var fif11=String()
    //image name's
    var fn11=String()
    var sn11=String()
    var tn11=String()
    var fon11=String()
    var fifn11=String()
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        //9.932811, 78.145947
        //mMap.addMarker(MarkerOptions().position())



        googleMap.setOnMapClickListener(OnMapClickListener { point ->
            Log.d("DEBUG", "Map clicked [" + point.latitude + " / " + point.longitude + "]")
            //Do your stuff with LatLng here
            //Then pass LatLng to other activity
            mMap.clear()
            val lats = LatLng(point.latitude,point.longitude)
            lat = point.latitude.toString()
            long = point.longitude.toString()
            mMap.addMarker(MarkerOptions().position(lats).title("Marker in $point"))
            mMap.moveCamera(CameraUpdateFactory.newLatLng(lats))


        })
        googleMap.setOnInfoWindowClickListener { marker ->
            // Remove the marker
            // marker.remove()
            val returnIntent = Intent(this,SupplierAddMain::class.java)
            returnIntent.putExtra("f", lat+","+long)
            returnIntent.putExtra("im1",fn11)
            returnIntent.putExtra("im2",sn11)
            returnIntent.putExtra("im3",tn11)
            returnIntent.putExtra("im4",fon11)
            returnIntent.putExtra("im5",fifn11)
            returnIntent.putExtra("url6",f11)
            returnIntent.putExtra("url7",s11)
            returnIntent.putExtra("url8",t11)


            returnIntent.putExtra("url9",fo11)
            returnIntent.putExtra("url10",fif11)
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }


    }
    private lateinit var mMap: GoogleMap
    lateinit var lat : String
    lateinit var long : String

   private var locationManager : LocationManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)


        val a=intent.getStringExtra("img1")
        val b=intent.getStringExtra("img2")
        val c=intent.getStringExtra("img3")
        val d=intent.getStringExtra("img4")
        val e=intent.getStringExtra("img5")
        val f=intent.getStringExtra("url1")
        val g=intent.getStringExtra("url2")
        val h=intent.getStringExtra("url3")
        val i=intent.getStringExtra("url4")
        val j=intent.getStringExtra("url5")

        f11=f
        s11=g
        t11=h
        fo11=i
        fif11=j
        fn11=   a
        sn11= b
        tn11= c
        fon11= d
        fifn11= e
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager?;
        try {
            // Request location updates
            locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, locationListener);
        } catch(ex: SecurityException) {
            Log.d("myTag", "Security Exception, no location available");
        }
        checkLocation()
    }
    private val locationListener: LocationListener = object : LocationListener {
        override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {
        }
        override fun onProviderEnabled(p0: String?) {
        }
        override fun onProviderDisabled(p0: String?) {
        }
        override fun onLocationChanged(location: Location) {
           // thetext.setText("" + location.longitude + ":" + location.latitude);
            mMap.clear()
            val vinitas = LatLng(location.latitude,location.longitude)
            lat = location.latitude.toString()
            long = location.longitude.toString()
            mMap.addMarker(MarkerOptions().position(vinitas).title("Marker in $vinitas"))
            mMap.moveCamera(CameraUpdateFactory.newLatLng(vinitas))
        }

    }
    private fun checkLocation(): Boolean {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private fun isLocationEnabled(): Boolean {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun showAlert() {
        val dialog = AlertDialog.Builder(this)
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " + "use this app")
                .setPositiveButton("Location Settings", DialogInterface.OnClickListener { paramDialogInterface, paramInt ->
                    val myIntent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                    startActivity(myIntent)
                })
                .setNegativeButton("Cancel", DialogInterface.OnClickListener { paramDialogInterface, paramInt -> })
        dialog.show()
    }

    override fun onBackPressed() {


        val returnIntent = Intent(this,SupplierAddMain::class.java)
        setResult(Activity.RESULT_CANCELED, returnIntent)
        finish()
    }

}
