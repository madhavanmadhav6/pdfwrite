package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_scroll.*
import kotlinx.android.synthetic.main.activity_select_branch.*

class SelectBranchActivity : AppCompatActivity() {
    var bn= arrayOf<String>()
    var brnchid= arrayOf<String>()
    var loc=arrayOf<String>()
    var rekey=String()
    var db = FirebaseFirestore.getInstance()
    var esc= String()
    var upstr= String()
    var numberstr= String()
    var pin= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
    var origisearch= arrayOf<String>()

var brstates= String()
    var states= String()
    var pins= String()
    internal lateinit var session: SessionManagement








    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""



    var origid= String()
    val TAG = "some"

    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
    internal var dpic=arrayOf(R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,R.drawable.ic_launcher_background)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_branch)

        net_status()  //Check net status

                //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SelectBranchActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view and other views when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)

        session = SessionManagement(applicationContext)


        session.checkLogin()
        val user = session.userDetails
        val name = user[SessionManagement.KEY_STATE]
        states = name.toString()



        search.setOnClickListener {   //Image button search  action
            card.visibility= View.VISIBLE
            card.startAnimation(AnimationUtils.loadAnimation(this@SelectBranchActivity,R.anim.slide_to_right))
            search.visibility=View.GONE
            vert.visibility=View.GONE

            editText.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
        }



        vert.setOnClickListener({    //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@SelectBranchActivity, vert)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->  //Navigate to pin activity


                if (item.title == "Logout") {
                    if(net_status()==true) {
                        Toast.makeText(this@SelectBranchActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                        val f = Intent(this@SelectBranchActivity, PinActivity::class.java)
                        startActivity(f)
                        finish()
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }

                }
                true
            }

            popup.show()
        })



        var sd= String()
        var x= String()
        var reg= String()

        val u=intent.getStringExtra("rbky")
        rekey=u

println("REKEY"+rekey)




        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }





        back3.setOnClickListener {
            onBackPressed()
        }






        get()  //Get branches and list out  from 'branch' collection db


        editText.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar8.visibility=View.VISIBLE
                blist.visibility=View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val pinStr="^\\d{6,}\$"


                println("TYPED VALUED" + x)

//-----------------------------------------Pin code search-------------------------//
                fun pincodeget() {
                    if ((s.length >= 6)&&(regtr=="pin")) {
                        noresfo.visibility=View.GONE
                        blist.visibility=View.VISIBLE
                        var branchid = arrayOf<String>()
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        db.collection("branch").orderBy("pcd").startAt(pin).endAt(esc)
                                .get()
                                .addOnCompleteListener { task ->
                                    println(task.result)
                                    if (task.isSuccessful) {
                                        if (task.result.isEmpty == false) {
                                            for (document in task.result) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data
                                                var ids = (document.id)



                                                var name = (dt["nm"]).toString()

                                                var mble = (dt["cty"]).toString()
                                                var brpin = (dt["pcd"]).toString()
                                                var brstate = (dt["st"]).toString()
                                                branchid=branchid.plusElement(ids)
                                                nameArray = nameArray.plusElement(name)
                                                bn=nameArray
                                                if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$mble  $brpin , $brstate")

                                                }
                                                else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$brpin , $brstate")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$mble , $brstate")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$mble , $brpin")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$mble")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$brpin")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$brstate")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("")
                                                }
                                                loc=idsArray
                                                brnchid=branchid

                                                brstates=brstate

                                                /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/
                                            }
                                            for (i in 0 until branchid.count()) {
                                                var ail = branchid[i]
                                                bsupkyval = ail
                                            }
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + origid)
                                            if(bsupkyval==rekey){
                                                noresfo.visibility = View.VISIBLE
                                                blist.visibility = View.GONE
                                                progressBar8.visibility=View.GONE
                                            }
                                            else {
                                                blist.visibility = View.VISIBLE

                                                progressBar8.visibility=View.GONE
                                               if(states==brstates){
                                                val whatever = selectbranchAdapter(this@SelectBranchActivity,branchid,nameArray,idsArray)
                                                blist.adapter = whatever
                                                }
                                            }


                                        } else {
                                            progressBar8.visibility=View.GONE
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility=View.VISIBLE
                                            blist.visibility=View.GONE
                                        }
                                    }
                                    else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }
                                }

                    }
                }

                ///-----------------------------BRANCH ID SEARCH------------------------//

                fun priget() {
                    if (s.length >= 2) {
                        noresfo.visibility=View.GONE
                        blist.visibility=View.VISIBLE
                        var branchid = arrayOf<String>()
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        db.collection("branch").orderBy("id").startAt(numberstr).endAt(esc)
                                .get()
                                .addOnCompleteListener { task ->
                                    println(task.result)
                                    if (task.isSuccessful) {
                                        if (task.result.isEmpty == false) {
                                            for (document in task.result) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data
                                                var ids = (document.id)

                                                var name = (dt["nm"]).toString()

                                                var mble = (dt["cty"]).toString()
                                                var brpin = (dt["pcd"]).toString()
                                                var brstate = (dt["st"]).toString()
                                                branchid=branchid.plusElement(ids)
                                                nameArray = nameArray.plusElement(name)
                                                bn=nameArray
                                                if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$mble  $brpin , $brstate")

                                                }
                                                else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$brpin , $brstate")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$mble , $brstate")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$mble , $brpin")
                                                }
                                                else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$mble")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("$brpin")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                    idsArray = idsArray.plusElement("$brstate")
                                                }
                                                else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                    idsArray = idsArray.plusElement("")
                                                }
                                                loc=idsArray
                                                brnchid=branchid

                                                brstates=brstate


                                                /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/
                                            }
                                            for (i in 0 until branchid.count()) {
                                                var ail = branchid[i]
                                                bsupkyval = ail
                                            }
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + origid)
                                            if(bsupkyval==rekey){
                                                noresfo.visibility = View.VISIBLE
                                                blist.visibility = View.GONE
                                                progressBar8.visibility=View.GONE

                                            }
                                            else {
                                                blist.visibility = View.VISIBLE

                                                progressBar8.visibility=View.GONE
                                                if(states==brstates){
                                                    val whatever = selectbranchAdapter(this@SelectBranchActivity,branchid,nameArray,idsArray)
                                                    blist.adapter = whatever
                                                }

                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                           pincodeget()
                                        }
                                    }
                                    else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }
                                }

                    }
                }





                if (x.trim().matches(pinStr.toRegex()))
                {
                    upstr = x
                    println("CAME INTO PIN NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    pin=upstr
                    regtr="pin"
                    pincodeget()

                    //write code here for success
                }

                else if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    priget()

                    //write code here for success
                }


                if(x!==reg) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString

                    var escp = upperString + '\uf8ff'
                    esc = escp

                    println("CAPPPSSSS" + upperString)
                }

//-----------------------------BRAANCH NAME SEARCH-------------------------------//
                if ((s.length >= 3)&&(x!==reg)) {

                    noresfo.visibility=View.GONE
                    blist.visibility=View.VISIBLE
                    var branchid = arrayOf<String>()
                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    db.collection("branch").orderBy("nm").startAt(upstr).endAt(esc)
                            .get()
                            .addOnCompleteListener { task ->
                                println(task.result)
                                if (task.isSuccessful) {
                                    if (task.result.isEmpty == false) {
                                        for (document in task.result) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)
                                            var dt = document.data
                                            var ids = (document.id)



                                            var name = (dt["nm"]).toString()

                                            var mble = (dt["cty"]).toString()
                                            var brpin = (dt["pcd"]).toString()
                                            var brstate = (dt["st"]).toString()
                                            branchid=branchid.plusElement(ids)
                                            nameArray = nameArray.plusElement(name)
                                            bn=nameArray
                                            if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                idsArray = idsArray.plusElement("$mble  $brpin , $brstate")

                                            }
                                            else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                                idsArray = idsArray.plusElement("$brpin , $brstate")
                                            }
                                            else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                idsArray = idsArray.plusElement("$mble , $brstate")
                                            }
                                            else if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                idsArray = idsArray.plusElement("$mble , $brpin")
                                            }
                                            else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                idsArray = idsArray.plusElement("$mble")
                                            }
                                            else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                                idsArray = idsArray.plusElement("$brpin")
                                            }
                                            else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                                idsArray = idsArray.plusElement("$brstate")
                                            }
                                            else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                                idsArray = idsArray.plusElement("")
                                            }
                                            loc=idsArray
                                            brnchid=branchid

                                            brstates=brstate
                                            /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/






                                        }
                                        for (i in 0 until branchid.count()) {
                                            var ail = branchid[i]
                                            bsupkyval = ail
                                        }
                                        println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                        println("SAVE KEYYYY" + origid)
                                        if(bsupkyval==rekey){
                                            noresfo.visibility = View.VISIBLE
                                            blist.visibility = View.GONE
                                            progressBar8.visibility=View.GONE

                                        }
                                        else {
                                            blist.visibility = View.VISIBLE

                                            progressBar8.visibility=View.GONE

                                            if(states==brstates){
                                               val whatever = selectbranchAdapter(this@SelectBranchActivity,branchid,nameArray,idsArray)
                                               blist.adapter = whatever
                                             }
                                        }






                                    } else {
                                        println("NO RECORDSSSS FOUNDD")
                                        noresfo.visibility=View.VISIBLE
                                        blist.visibility=View.GONE
                                        progressBar8.visibility=View.GONE

                                    }


                                } else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }
                            }

                }








                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(editText.text.toString().isEmpty())
                {
                    blist.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    progressBar8.visibility=View.GONE

                    get()


                }
            }
        })
        searchback.setOnClickListener {   //search back action
            editText.setText("")

            card.startAnimation(AnimationUtils.loadAnimation(this@SelectBranchActivity,R.anim.slide_to_left))
            card.visibility=View.GONE
            search.visibility=View.VISIBLE
            vert.visibility=View.VISIBLE
            noresfo.visibility=View.GONE
            blist.visibility=View.VISIBLE

            progressBar8.visibility=View.GONE

            get()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }




        //List item click and navigate to stock trasfer (Mainstk_branch_one) activity.

       blist.setOnItemClickListener { parent, views, position, id  ->

            val b = Intent(applicationContext,Mainstk_branch_one::class.java)
                    b.putExtra("brchnm",bn[position])
                     b.putExtra("brchloc",loc[position])
                      b.putExtra("brnchky",brnchid[position])
                        b.putExtra("originky",rekey)




           b.putExtra("viewtrans", viewtrans)
           b.putExtra("addtrans", addtrans)
           b.putExtra("edittrans", editetrans)
           b.putExtra("deletetrans", deletetrans)
           b.putExtra("transfertrans", transfertrans)
           b.putExtra("exporttrans", exporttrans)
           b.putExtra("sendtrans", sendtrans)


           b.putExtra("viewtransano", viewtransano)
           b.putExtra("addtransano", addtransano)
           b.putExtra("edittransano", editetransano)
           b.putExtra("deletetransano", deletetransano)
           b.putExtra("transfertransano", transfertransano)
           b.putExtra("exporttransano", exporttransano)
           b.putExtra("sendtransano", sendtransano)

           b.putExtra("viewrec", viewrec)
           b.putExtra("addrec", addrec)
           b.putExtra("deleterec", deleterec)
           b.putExtra("editrec", editrec)
           b.putExtra("transferrec", transferrec)
           b.putExtra("exportrec", exportrec)
           b.putExtra("sendstrec",sendstrec)



                        b.putExtra("from","branch")
                        startActivity(b)
           overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
           finish()
        }
    }

    //--------------------------Get all branches except current loggin branch from db

    fun get() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("branch")
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    var branchid = arrayOf<String>()
                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }


                    for (document in value) {

                        Log.d("d", "key --- " + document.id + " => " + document.data)
                        println(document.data)

                        var dt = document.data
                        var ids = (document.id)


                        var name = (dt["nm"]).toString()

                        var mble = (dt["cty"]).toString()
                        var brpin = (dt["pcd"]).toString()
                        var brstate = (dt["st"]).toString()

                        brstates=brstate

                        if (ids == rekey) {

                            println("BR SATES"+states)
                            println("BR STATE"+brstates)
                        } else {

                            branchid = branchid.plusElement(ids)
                            nameArray = nameArray.plusElement(name)
                            bn = nameArray

                            if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                idsArray = idsArray.plusElement("$mble  $brpin , $brstate")

                            }
                            else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isNotEmpty())){
                                idsArray = idsArray.plusElement("$brpin , $brstate")
                            }
                            else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                idsArray = idsArray.plusElement("$mble , $brstate")
                            }
                            else if((mble.isNotEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                idsArray = idsArray.plusElement("$mble , $brpin")
                            }
                            else if((mble.isNotEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                idsArray = idsArray.plusElement("$mble")
                            }
                            else if((mble.isEmpty())&&(brpin.isNotEmpty())&&(brstate.isEmpty())){
                                idsArray = idsArray.plusElement("$brpin")
                            }
                            else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isNotEmpty())){
                                idsArray = idsArray.plusElement("$brstate")
                            }
                            else if((mble.isEmpty())&&(brpin.isEmpty())&&(brstate.isEmpty())){
                                idsArray = idsArray.plusElement("")
                            }


                            loc = idsArray
                            brnchid = branchid

                        }

                    }
                    pDialog.dismiss()


                    println("BR SATES OUT"+states)
                    println("BR STATE OUT"+brstates)

                    println("STATES"+states)
                    if(states==brstates){
                        locat.setText("${nameArray.count()} at Locations")
                        val whatever = selectbranchAdapter(this@SelectBranchActivity, branchid, nameArray, idsArray)
                        blist.adapter = whatever
                    }

                    /*whatever.notifyDataSetChanged()*/

                })

    }
    override fun onBackPressed()


    //Back action

    {

        if(card.visibility==View.VISIBLE){
            card.visibility=View.GONE
            search.visibility=View.VISIBLE
            vert.visibility=View.VISIBLE
            get()
        }
        else{

            val b = Intent(applicationContext, WithStateActivity::class.java)



            b.putExtra("from_br","main")
            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)



            b.putExtra("bkey", rekey)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }
    companion object {


        //Listens inetrnet status whether net is on/off. .

        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                /// if connection is off then all views becomes disable


                constraintLayout3dis!!.visibility= View.VISIBLE
                relativeslayoutdis!!.visibility= View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

                /// if connection is off then all views becomes enabled


                constraintLayout3dis!!.visibility= View.GONE

                relativeslayoutdis!!.visibility= View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
    fun net_status():Boolean{     // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
