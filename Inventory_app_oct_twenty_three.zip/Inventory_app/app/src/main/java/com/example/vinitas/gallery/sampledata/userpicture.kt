package com.example.vinitas.gallery.sampledata

import android.app.Application

import com.facebook.drawee.backends.pipeline.Fresco

/**
 * Created by zfdang on 2016-4-15.
 */
class DemoApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // the following line is important

    }
}