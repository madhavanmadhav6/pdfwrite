package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.ListPopupWindow
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.AdapterView
import android.widget.TextView

import android.widget.ArrayAdapter
import android.widget.Spinner
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_allbranches.*
import java.util.*
import kotlin.collections.ArrayList


class AllbranchesActivity : AppCompatActivity(){

    private var mAdapter: ArrayAdapter<*>? = null
    private var mSelectedIndex = 0


    var esc= String()
    var upstr= String()
    var numberstr= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()


    var kknagar:Int=0
    var byepassval:Int=0
    var periyarval:Int=0
    var sivakasival:Int=0


    var priceArraydup= arrayOf<String>()

    var db = FirebaseFirestore.getInstance()
    val TAG = "some"
    var idss = String()
    var idssiv = String()
    var bridssi = String()
    var lststr = String()
    var qntArray = arrayOf<String>()
    var ffstr = String()
    var idstr = String()
    var qn1 = String()
    var countss = 0
    var idstrarr = arrayOf<String>()

    var datach = String()

    var bpress=String()
    var qn = String()
    private var viewstklvls = String()

    var brnchkeys=arrayListOf<String>()
    var brnchnms=arrayListOf<String>()

    var brids = String()
    var maincatId = ArrayList<String>()

    var alert:AlertDialog?=null

    var listPopupWindow: ListPopupWindow? = null
var dialog:AlertDialog?=null
    var brnmsarr=ArrayList<String>()
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_allbranches)
        var sd = String()

        var x = String()

        var reg = String()


        val k=intent.extras


            var frm = k!!.get("frm")



        val maincat = ArrayList<String>()


        //Highlight the selected item in spinner
        mAdapter = object : ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, maincat) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                // Cast the spinner collapsed item (non-popup item) as a text view
                val tv = super.getView(position, convertView, parent) as TextView

                // Set the text color of spinner item
                tv.setTextColor(Color.BLACK)

                // Return the view
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                // Cast the drop down items (popup items) as text view
                val tv = super.getDropDownView(position, convertView, parent) as TextView

                // Set the text color of drop down items
                tv.setTextColor(Color.BLACK)

                // If this item is selected item
                if (position == mSelectedIndex) {
                    // Set spinner selected popup item's text color
                    tv.setTextColor(resources.getColor(R.color.shadetwo))
                }

                // Return the modified view
                return tv
            }
        }


        back2.setOnClickListener {
            onBackPressed()
        }


    /*    val adp1 = ArrayAdapter(this@AllbranchesActivity, R.layout.spinner_view, maincat)
        adp1.setDropDownViewResource(R.layout.spinner_view)*/


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@AllbranchesActivity) > 0)
        {

        }
        else{

        }
        //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively =findViewById(R.id.relativeslayout)
        cont =findViewById<ConstraintLayout>(R.id.container)

        addLogText(NetworkUtil.getConnectivityStatusString(this@AllbranchesActivity))


        if(frm=="main") {


            brnmsarr=intent.getStringArrayListExtra("brnmsarr")//branchnames array
            brnchkeys=intent.getStringArrayListExtra("brnchkeys")//branch keys array
            maincatId=intent.getStringArrayListExtra("maincatId")//maincategory ID array

                                val alert = AlertDialog.Builder(this@AllbranchesActivity)
                                val inflater = this.layoutInflater
                                /*with(alert) {
                        setTitle("Select Branch")
                        }*/
                                dialog = alert.create()


                                dialog!!.setCancelable(false)

                                dialog!!.setView(inflater.inflate(R.layout.popupwindowlistitem, null))
                                dialog!!.show()



                                val whatever = text_adap(this@AllbranchesActivity, brnmsarr)
                                val stkedt = dialog!!.findViewById<ListView>(R.id.listView1) as ListView
                                stkedt.adapter = whatever//Popup list cntains of branch names

                                val cancelact = dialog!!.findViewById<Button>(R.id.holicancel) as Button

                                cancelact.setOnClickListener {
                                    onBackPressed()//Exit action
                                }


                                stkedt.setOnItemClickListener { parent, views, position, id ->//List item click

                                    if (position != 0) {

                                        dialog!!.dismiss()



                                        db.collection("branch")//Get branches from db and put to array spinner
                                                .get()
                                                .addOnCompleteListener { task ->
                                                    if (task.result.isEmpty == false) {
                                                       /* progress.visibility=View.VISIBLE*/

                                                        if (task.result != null) {
                                                            maincat.clear()
                                                            maincatId.clear()
                                                            maincat.add("Select Branch")
                                                            maincatId.add("")
                                                            brnchkeys.add("")

                                                            for (document in task.result) {

                                                                var brid = document.id
                                                                var dt = document.data
                                                                var brnms = dt["nm"].toString()
                                                                maincatId.add(document.id)
                                                                maincat.add(brnms)
                                                                brnmsarr.add(brnms)
                                                                brnchkeys.add(brid)

                                                                brspinner!!.adapter = mAdapter
                                                                brspinner.setSelection(position)
                                                                progress.visibility=View.VISIBLE

                                                                selectbr()//Select branch and get stock levels relevent to that branch


                                                            }
                                                        }
                                                    }
                                                }


                                    }
                                }
                            } else {
                                maincat.add("Select")
                                brspinner!!.adapter = mAdapter
                            }


















        net_status()





/*        viewstklvls = intent.getStringExtra("viewstklvl")

        val j = intent.getStringExtra("bkey")*/
        viewstklvls = intent.getStringExtra("viewstklvl")

        val jf = intent.getStringExtra("bkey")

        bridssi = jf






        //scroll2_gender spinner onItemSeletedListener
        brspinner.onItemSelectedListener=object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {
                return
            }
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectbr()
                mSelectedIndex = p2
            }
        }




        search2.setOnClickListener {

            println("clicked")
            card.visibility=View.VISIBLE
            alltitle.visibility=View.GONE
            editText.setHint("Search")
            card.startAnimation(AnimationUtils.loadAnimation(this@AllbranchesActivity,R.anim.slide_to_right))
            editText.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
        }
        searchback.setOnClickListener {
            card.visibility=View.GONE
            alltitle.visibility=View.VISIBLE
            editText.text.clear()
            card.startAnimation(AnimationUtils.loadAnimation(this@AllbranchesActivity,R.anim.slide_to_left))
            selectbr()
        }

        imageButton2.setOnClickListener({


            val popup = PopupMenu(this@AllbranchesActivity, imageButton2)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {
                    Toast.makeText(this@AllbranchesActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@AllbranchesActivity, PinActivity::class.java)
                    startActivity(f)
                    finish()
                }
                true
            }

            popup.show()
        })





        editText.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {



                progress.visibility=View.VISIBLE

               alllist.visibility=View.GONE

                brspinner.visibility=View.GONE




                println("KEYS OF SEARCHHH" + kyval)
                sd = des.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";





                var ddpos=brspinner.selectedItemPosition

                fun bcodeget() {//BArcode search


                    if ((des.length >= 3)) {
                        noresfo.visibility = View.GONE

                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status

                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()



                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0


                                                lststr = "in"
                                                var ddstr = id + "_" + brnchkeys[ddpos]
                                                var ad = brnchkeys[ddpos]
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + ad)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ad", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)
                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$ad").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)
                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }
                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))

                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }


                                                                                    }


                                                                                    progress.visibility = View.GONE

                                                                                    alllist.visibility = View.VISIBLE
                                                                                    brspinner.visibility = View.VISIBLE


                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        } else {


                                                            noresfo.visibility = View.VISIBLE

                                                            alllist.visibility = View.GONE
                                                            brspinner.visibility = View.GONE

                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {
                                        //Stock level search
                                            db.collection("product").orderBy("${brnchkeys[ddpos]}").startAt(numberstr).endAt(esc)//herebuddy
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0


                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brnchkeys[ddpos]
                                                                    var ad = brnchkeys[ddpos]
                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + ad)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$ad", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)
                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$ad").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)
                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }
                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))

                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }


                                                                                                        }


                                                                                                        progress.visibility = View.GONE

                                                                                                        alllist.visibility = View.VISIBLE
                                                                                                        brspinner.visibility = View.VISIBLE


                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            } else {


                                                                                noresfo.visibility = View.VISIBLE

                                                                                alllist.visibility = View.GONE
                                                                                brspinner.visibility = View.GONE

                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {

                                                            //MRP SERARCh
                                                                db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {
                                                                                        Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                                        val dd = document.data

                                                                                        val id = document.id;//0


                                                                                        lststr = "in"
                                                                                        var ddstr = id + "_" + brnchkeys[ddpos]
                                                                                        var ad = brnchkeys[ddpos]
                                                                                        val database = FirebaseDatabase.getInstance()
                                                                                        val myRef = database.getReference(ddstr)
                                                                                        myRef.root

                                                                                        val messageListener = object : ValueEventListener {
                                                                                            override fun onCancelled(p0: DatabaseError?) {
                                                                                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                                            }


                                                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                                datach = "changed"

                                                                                                if (dataSnapshot.exists()) {


                                                                                                    val docid = dataSnapshot.key

                                                                                                    var ff = docid.removeSuffix("-" + ad)

                                                                                                    println("DOC ID" + docid)
                                                                                                    println("TRIMMED DOC ID" + ff)
                                                                                                    ffstr = ff
                                                                                                    val message = dataSnapshot.value
                                                                                                    val qnty = message.toString()
                                                                                                    var tt = qnty
                                                                                                    qn = tt

                                                                                                    val map = mutableMapOf<String, Any?>()
                                                                                                    map.put("$ad", qn)
                                                                                                    db.collection("product").document(id)
                                                                                                            .update(map)
                                                                                                            .addOnSuccessListener {

                                                                                                                db.collection("product").document(id)

                                                                                                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                                            println("e : "+e)
                                                                                                                            if (e==null) {
                                                                                                                                var doc = task.data

                                                                                                                                val ids = task.id;//0
                                                                                                                                val stockonhand = doc.get("$ad").toString();//7
                                                                                                                                val pid = doc.get("p_id").toString();//1
                                                                                                                                val pname = doc.get("p_nm").toString();//2
                                                                                                                                val bcode = doc.get("bc").toString();//3
                                                                                                                                val pdes = doc.get("desc").toString();//4
                                                                                                                                val weight = doc.get("wg_vol").toString();//5
                                                                                                                                val psac = doc.get("hsn").toString();//6
                                                                                                                                val minstock = doc.get("min_stk").toString();//8
                                                                                                                                val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                                val price = doc.get("price").toString();//10
                                                                                                                                val taxable = doc.get("taxchk").toString();//11
                                                                                                                                val igst = doc.get("igst").toString();//12
                                                                                                                                val cgst = doc.get("cgst").toString();//13
                                                                                                                                val sgst = doc.get("sgst").toString();//14
                                                                                                                                val cess = doc.get("taxchk").toString();//15
                                                                                                                                val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                                val cessval = doc.get("cesstot").toString();//17
                                                                                                                                val currency = doc.get("curency").toString();//18
                                                                                                                                val percentage = doc.get("percentage").toString();//19
                                                                                                                                val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                                val product_dec = doc.get("product_desc").toString();//21
                                                                                                                                val mrP = doc.get("mrp").toString();//22
                                                                                                                                val cate = doc.get("ctgy").toString();//23
                                                                                                                                val manufacture = doc.get("mfr").toString();//24
                                                                                                                                val ut = doc.get("ut").toString();//25
                                                                                                                                val consold = doc.get("cn_sold").toString();//26
                                                                                                                                val comm = doc.get("emp_com").toString();//27
                                                                                                                                val status = doc.get("status").toString();//27
                                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                                val img5url = doc.get("img5url").toString();//37

                                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)
                                                                                                                                idsArray = idsArray.plusElement(ids)
                                                                                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                }




                                                                                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                                } else {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                                }
                                                                                                                                if (bcode.isNotEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                                } else if (bcode.isEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                                }
                                                                                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                                mhArray = mhArray.plusElement(maxstock)
                                                                                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                                                                                disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                                                println(Arrays.toString(disArray))

                                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                                } else {
                                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                                }


                                                                                                                            }


                                                                                                                            progress.visibility = View.GONE

                                                                                                                            alllist.visibility = View.VISIBLE
                                                                                                                            brspinner.visibility = View.VISIBLE


                                                                                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                                            slist.adapter = whatever


                                                                                                                        })

                                                                                                            }


                                                                                                } else {


                                                                                                    noresfo.visibility = View.VISIBLE

                                                                                                    alllist.visibility = View.GONE
                                                                                                    brspinner.visibility = View.GONE

                                                                                                }


                                                                                            }


                                                                                        }
                                                                                        myRef!!.addValueEventListener(messageListener)

                                                                                    }
                                                                                }
                                                                            else{
                                                                                noresfo.visibility = View.VISIBLE

                                                                                alllist.visibility = View.GONE
                                                                                brspinner.visibility = View.GONE
                                                                            }

                                                                        })


                                                            }




                                                    })
                                        }

                                })
                    }
                   /* if((des.length >= 3)&&(brspinner.selectedItemPosition==1)){
                        noresfo.visibility=View.GONE
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status

                        var icohighArray=arrayOf<String>()
                        var icohighnmArray=arrayOf<String>()

                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)//herebuddy
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0




                                                lststr = "in"
                                                var ddstr = id + "_" + brnchkeys[1]
                                                var ads=brnchkeys[1].toString()
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + ads)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn1 = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ads", qn1)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)


                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$ads").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37
                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        }
                                                                                        else{
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))

                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }


                                                                                    }

                                                                                    progress.visibility=View.GONE
                                                                                    alllist.visibility=View.VISIBLE
                                                                                    brspinner.visibility=View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever







                                                                                })

                                                                    }


                                                        }
                                                        else{
                                                            noresfo.visibility=View.VISIBLE
                                                            progress.visibility=View.GONE
                                                            alllist.visibility=View.GONE
                                                            brspinner.visibility=View.GONE
                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        }
                                    else{
                                        db.collection("product").orderBy("${brnchkeys[1]}").startAt(numberstr).endAt(esc)//herebuddy
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {

                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                            val dd = document.data

                                                            val id = document.id;//0




                                                            lststr = "in"
                                                            var ddstr = id + "_" + brnchkeys[1]
                                                            var ads=brnchkeys[1].toString()
                                                            val database = FirebaseDatabase.getInstance()
                                                            val myRef = database.getReference(ddstr)
                                                            myRef.root

                                                            val messageListener = object : ValueEventListener {
                                                                override fun onCancelled(p0: DatabaseError?) {
                                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                }


                                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                    datach = "changed"

                                                                    if (dataSnapshot.exists()) {


                                                                        val docid = dataSnapshot.key

                                                                        var ff = docid.removeSuffix("-" + ads)

                                                                        println("DOC ID" + docid)
                                                                        println("TRIMMED DOC ID" + ff)
                                                                        ffstr = ff
                                                                        val message = dataSnapshot.value
                                                                        val qnty = message.toString()
                                                                        var tt = qnty
                                                                        qn1 = tt

                                                                        val map = mutableMapOf<String, Any?>()
                                                                        map.put("$ads", qn1)
                                                                        db.collection("product").document(id)
                                                                                .update(map)
                                                                                .addOnSuccessListener {

                                                                                    db.collection("product").document(id)
                                                                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                println("e : "+e)
                                                                                                if (e==null) {
                                                                                                    var doc = task.data

                                                                                                    val ids = task.id;//0
                                                                                                    idss = ids
                                                                                                    val stockonhand = doc.get("$ads").toString();//7
                                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                                    val price = doc.get("price").toString();//10
                                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                                    val igst = doc.get("igst").toString();//12
                                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                                    val currency = doc.get("curency").toString();//18
                                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                                    val ut = doc.get("ut").toString();//25
                                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                                    val status = doc.get("status").toString();//27
                                                                                                    val img1n = doc.get("img1n").toString();//28
                                                                                                    val img2n = doc.get("img2n").toString();//29
                                                                                                    val img3n = doc.get("img3n").toString();//30
                                                                                                    val img4n = doc.get("img4n").toString();//31
                                                                                                    val img5n = doc.get("img5n").toString();//32
                                                                                                    val img1url = doc.get("img1url").toString();//33
                                                                                                    val img2url = doc.get("img2url").toString();//34
                                                                                                    val img3url = doc.get("img3url").toString();//35
                                                                                                    val img4url = doc.get("img4url").toString();//36
                                                                                                    val img5url = doc.get("img5url").toString();//37
                                                                                                    val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                    val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                    }
                                                                                                    else{
                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                    }




                                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                    } else {
                                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                    }
                                                                                                    if (bcode.isNotEmpty()) {
                                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                    } else if (bcode.isEmpty()) {
                                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                                    }

                                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                    println(Arrays.toString(disArray))

                                                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                    if (ur.isNotEmpty()) {
                                                                                                        primgArray = primgArray.plusElement(ur)
                                                                                                    } else {
                                                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                    }


                                                                                                }

                                                                                                progress.visibility=View.GONE
                                                                                                alllist.visibility=View.VISIBLE
                                                                                                brspinner.visibility=View.VISIBLE

                                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                slist.adapter = whatever







                                                                                            })

                                                                                }


                                                                    }
                                                                    else{
                                                                        noresfo.visibility=View.VISIBLE
                                                                        progress.visibility=View.GONE
                                                                        alllist.visibility=View.GONE
                                                                        brspinner.visibility=View.GONE
                                                                    }


                                                                }


                                                            }
                                                            myRef!!.addValueEventListener(messageListener)

                                                        }
                                                    }
                                                    else{
                                                        db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                    if (e != null) {
                                                                    }
                                                                    if (value.isEmpty == false) {
                                                                        for (document in value) {
                                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                            val dd = document.data

                                                                            val id = document.id;//0




                                                                            lststr = "in"
                                                                            var ddstr = id + "_" + brnchkeys[1]
                                                                            var ads=brnchkeys[1].toString()
                                                                            val database = FirebaseDatabase.getInstance()
                                                                            val myRef = database.getReference(ddstr)
                                                                            myRef.root

                                                                            val messageListener = object : ValueEventListener {
                                                                                override fun onCancelled(p0: DatabaseError?) {
                                                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                                }


                                                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                    datach = "changed"

                                                                                    if (dataSnapshot.exists()) {


                                                                                        val docid = dataSnapshot.key

                                                                                        var ff = docid.removeSuffix("-" + ads)

                                                                                        println("DOC ID" + docid)
                                                                                        println("TRIMMED DOC ID" + ff)
                                                                                        ffstr = ff
                                                                                        val message = dataSnapshot.value
                                                                                        val qnty = message.toString()
                                                                                        var tt = qnty
                                                                                        qn1 = tt

                                                                                        val map = mutableMapOf<String, Any?>()
                                                                                        map.put("$ads", qn1)
                                                                                        db.collection("product").document(id)
                                                                                                .update(map)
                                                                                                .addOnSuccessListener {

                                                                                                    db.collection("product").document(id)

                                                                                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                                println("e : "+e)
                                                                                                                if (e==null) {
                                                                                                                    var doc = task.data

                                                                                                                    val ids = task.id;//0
                                                                                                                    idss = ids
                                                                                                                    val stockonhand = doc.get("$ads").toString();//7
                                                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                    val price = doc.get("price").toString();//10
                                                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                                                    val igst = doc.get("igst").toString();//12
                                                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                                                    val currency = doc.get("curency").toString();//18
                                                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                                                    val ut = doc.get("ut").toString();//25
                                                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                                                    val status = doc.get("status").toString();//27
                                                                                                                    val img1n = doc.get("img1n").toString();//28
                                                                                                                    val img2n = doc.get("img2n").toString();//29
                                                                                                                    val img3n = doc.get("img3n").toString();//30
                                                                                                                    val img4n = doc.get("img4n").toString();//31
                                                                                                                    val img5n = doc.get("img5n").toString();//32
                                                                                                                    val img1url = doc.get("img1url").toString();//33
                                                                                                                    val img2url = doc.get("img2url").toString();//34
                                                                                                                    val img3url = doc.get("img3url").toString();//35
                                                                                                                    val img4url = doc.get("img4url").toString();//36
                                                                                                                    val img5url = doc.get("img5url").toString();//37
                                                                                                                    val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                    val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                                    }
                                                                                                                    else{
                                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                                    }




                                                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                    } else {
                                                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                    }
                                                                                                                    if (bcode.isNotEmpty()) {
                                                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                    } else if (bcode.isEmpty()) {
                                                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                    }

                                                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                                    println(Arrays.toString(disArray))

                                                                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                    if (ur.isNotEmpty()) {
                                                                                                                        primgArray = primgArray.plusElement(ur)
                                                                                                                    } else {
                                                                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                    }


                                                                                                                }

                                                                                                                progress.visibility=View.GONE
                                                                                                                alllist.visibility=View.VISIBLE
                                                                                                                brspinner.visibility=View.VISIBLE

                                                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                                slist.adapter = whatever







                                                                                                            })

                                                                                                }


                                                                                    }
                                                                                    else{
                                                                                        noresfo.visibility=View.VISIBLE
                                                                                        progress.visibility=View.GONE
                                                                                        alllist.visibility=View.GONE
                                                                                        brspinner.visibility=View.GONE
                                                                                    }


                                                                                }


                                                                            }
                                                                            myRef!!.addValueEventListener(messageListener)

                                                                        }
                                                                    }
                                                                    else{
                                                                        noresfo.visibility=View.VISIBLE
                                                                        progress.visibility=View.GONE
                                                                        alllist.visibility=View.GONE
                                                                        brspinner.visibility=View.GONE
                                                                    }





                                                                })
                                                    }





                                                })
                                    }





                                })

                    }


                    if((des.length >= 3)&&(brspinner.selectedItemPosition==3)){
                        noresfo.visibility=View.GONE
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status

                        var icohighArray=arrayOf<String>()
                        var icohighnmArray=arrayOf<String>()

                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)//herebuddy
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0




                                                lststr = "in"
                                                var ddstr = id + "_" + brnchkeys[3]
                                                var ads=brnchkeys[3].toString()
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + ads)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn1 = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ads", qn1)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)

                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$ads").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        }
                                                                                        else{
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)


                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray=icohighnmArray.plusElement(img1nhigh)


                                                                                        println(Arrays.toString(disArray))

                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }


                                                                                    }

                                                                                    progress.visibility=View.GONE
                                                                                    alllist.visibility=View.VISIBLE
                                                                                    brspinner.visibility=View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                            disArray, primgArray,icohighnmArray,icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever







                                                                                })

                                                                    }


                                                        }
                                                        else{
                                                            noresfo.visibility=View.VISIBLE
                                                            progress.visibility=View.GONE
                                                            alllist.visibility=View.GONE
                                                            brspinner.visibility=View.GONE
                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        }
                                        else{
                                            db.collection("product").orderBy("${brnchkeys[3]}").startAt(numberstr).endAt(esc)//herebuddy
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0




                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brnchkeys[3]
                                                                    var ads=brnchkeys[3].toString()
                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + ads)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn1 = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$ads", qn1)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)

                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0

                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$ads").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            }
                                                                                                            else{
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)


                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray=icohighnmArray.plusElement(img1nhigh)


                                                                                                            println(Arrays.toString(disArray))

                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }


                                                                                                        }

                                                                                                        progress.visibility=View.GONE
                                                                                                        alllist.visibility=View.VISIBLE
                                                                                                        brspinner.visibility=View.VISIBLE

                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                                                disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever







                                                                                                    })

                                                                                        }


                                                                            }
                                                                            else{
                                                                                noresfo.visibility=View.VISIBLE
                                                                                progress.visibility=View.GONE
                                                                                alllist.visibility=View.GONE
                                                                                brspinner.visibility=View.GONE
                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            }
                                                            else{
                                                                db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {
                                                                                        Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                                        val dd = document.data

                                                                                        val id = document.id;//0




                                                                                        lststr = "in"
                                                                                        var ddstr = id + "_" + brnchkeys[3]
                                                                                        var ads=brnchkeys[3].toString()
                                                                                        val database = FirebaseDatabase.getInstance()
                                                                                        val myRef = database.getReference(ddstr)
                                                                                        myRef.root

                                                                                        val messageListener = object : ValueEventListener {
                                                                                            override fun onCancelled(p0: DatabaseError?) {
                                                                                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                                            }


                                                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                                datach = "changed"

                                                                                                if (dataSnapshot.exists()) {


                                                                                                    val docid = dataSnapshot.key

                                                                                                    var ff = docid.removeSuffix("-" + ads)

                                                                                                    println("DOC ID" + docid)
                                                                                                    println("TRIMMED DOC ID" + ff)
                                                                                                    ffstr = ff
                                                                                                    val message = dataSnapshot.value
                                                                                                    val qnty = message.toString()
                                                                                                    var tt = qnty
                                                                                                    qn1 = tt

                                                                                                    val map = mutableMapOf<String, Any?>()
                                                                                                    map.put("$ads", qn1)
                                                                                                    db.collection("product").document(id)
                                                                                                            .update(map)
                                                                                                            .addOnSuccessListener {

                                                                                                                db.collection("product").document(id)
                                                                                                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                                            println("e : "+e)
                                                                                                                            if (e==null) {
                                                                                                                                var doc = task.data

                                                                                                                                val ids = task.id;//0
                                                                                                                                idss = ids
                                                                                                                                val stockonhand = doc.get("$ads").toString();//7
                                                                                                                                val pid = doc.get("p_id").toString();//1
                                                                                                                                val pname = doc.get("p_nm").toString();//2
                                                                                                                                val bcode = doc.get("bc").toString();//3
                                                                                                                                val pdes = doc.get("desc").toString();//4
                                                                                                                                val weight = doc.get("wg_vol").toString();//5
                                                                                                                                val psac = doc.get("hsn").toString();//6
                                                                                                                                val minstock = doc.get("min_stk").toString();//8
                                                                                                                                val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                                val price = doc.get("price").toString();//10
                                                                                                                                val taxable = doc.get("taxchk").toString();//11
                                                                                                                                val igst = doc.get("igst").toString();//12
                                                                                                                                val cgst = doc.get("cgst").toString();//13
                                                                                                                                val sgst = doc.get("sgst").toString();//14
                                                                                                                                val cess = doc.get("taxchk").toString();//15
                                                                                                                                val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                                val cessval = doc.get("cesstot").toString();//17
                                                                                                                                val currency = doc.get("curency").toString();//18
                                                                                                                                val percentage = doc.get("percentage").toString();//19
                                                                                                                                val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                                val product_dec = doc.get("product_desc").toString();//21
                                                                                                                                val mrP = doc.get("mrp").toString();//22
                                                                                                                                val cate = doc.get("ctgy").toString();//23
                                                                                                                                val manufacture = doc.get("mfr").toString();//24
                                                                                                                                val ut = doc.get("ut").toString();//25
                                                                                                                                val consold = doc.get("cn_sold").toString();//26
                                                                                                                                val comm = doc.get("emp_com").toString();//27
                                                                                                                                val status = doc.get("status").toString();//27
                                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                                val img5url = doc.get("img5url").toString();//37


                                                                                                                                idsArray = idsArray.plusElement(ids)
                                                                                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                }
                                                                                                                                else{
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                }




                                                                                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                                } else {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                                }
                                                                                                                                if (bcode.isNotEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                                } else if (bcode.isEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                                }

                                                                                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                                mhArray = mhArray.plusElement(maxstock)
                                                                                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                                                                                disArray = disArray.plusElement("Qty - " + stockonhand)


                                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)


                                                                                                                                println(Arrays.toString(disArray))

                                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                                } else {
                                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                                }


                                                                                                                            }

                                                                                                                            progress.visibility=View.GONE
                                                                                                                            alllist.visibility=View.VISIBLE
                                                                                                                            brspinner.visibility=View.VISIBLE

                                                                                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                                                                    disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                                            slist.adapter = whatever







                                                                                                                        })

                                                                                                            }


                                                                                                }
                                                                                                else{
                                                                                                    noresfo.visibility=View.VISIBLE
                                                                                                    progress.visibility=View.GONE
                                                                                                    alllist.visibility=View.GONE
                                                                                                    brspinner.visibility=View.GONE
                                                                                                }


                                                                                            }


                                                                                        }
                                                                                        myRef!!.addValueEventListener(messageListener)

                                                                                    }
                                                                                }
                                                                            else{
                                                                                noresfo.visibility=View.VISIBLE
                                                                                progress.visibility=View.GONE
                                                                                alllist.visibility=View.GONE
                                                                                brspinner.visibility=View.GONE
                                                                            }





                                                                        })
                                                            }






                                                    })
                                        }





                                })
                    }



                    if((des.length >= 3)&&(brspinner.selectedItemPosition==4)){

                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status
                        var icohighArray=arrayOf<String>()
                        var icohighnmArray=arrayOf<String>()
                        noresfo.visibility=View.GONE

                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)//herebuddy
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0




                                                lststr = "in"
                                                var ddstr = id + "_" + brnchkeys[4]
                                                var ads=brnchkeys[4].toString()
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + ads)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn1 = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ads", qn1)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)


                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$ads").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        }
                                                                                        else{
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))

                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }


                                                                                    }

                                                                                    progress.visibility=View.GONE
                                                                                    alllist.visibility=View.VISIBLE
                                                                                    brspinner.visibility=View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray,
                                                                                            sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever







                                                                                })

                                                                    }


                                                        }
                                                        else{
                                                            noresfo.visibility=View.VISIBLE
                                                            progress.visibility=View.GONE
                                                            alllist.visibility=View.GONE
                                                            brspinner.visibility=View.GONE
                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        }
                                        else{
                                            db.collection("product").orderBy("${brnchkeys[4]}").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0




                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brnchkeys[4]
                                                                    var ads=brnchkeys[4].toString()
                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + ads)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn1 = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$ads", qn1)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)

                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$ads").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            }
                                                                                                            else{
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))

                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }


                                                                                                        }

                                                                                                        progress.visibility=View.GONE
                                                                                                        alllist.visibility=View.VISIBLE
                                                                                                        brspinner.visibility=View.VISIBLE

                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray,
                                                                                                                sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever







                                                                                                    })

                                                                                        }


                                                                            }
                                                                            else{
                                                                                noresfo.visibility=View.VISIBLE
                                                                                progress.visibility=View.GONE
                                                                                alllist.visibility=View.GONE
                                                                                brspinner.visibility=View.GONE
                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            }
                                                            else{
                                                                db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {
                                                                                        Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                                        val dd = document.data

                                                                                        val id = document.id;//0




                                                                                        lststr = "in"
                                                                                        var ddstr = id + "_" + brnchkeys[4]
                                                                                        var ads=brnchkeys[4].toString()
                                                                                        val database = FirebaseDatabase.getInstance()
                                                                                        val myRef = database.getReference(ddstr)
                                                                                        myRef.root

                                                                                        val messageListener = object : ValueEventListener {
                                                                                            override fun onCancelled(p0: DatabaseError?) {
                                                                                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                                            }


                                                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                                datach = "changed"

                                                                                                if (dataSnapshot.exists()) {


                                                                                                    val docid = dataSnapshot.key

                                                                                                    var ff = docid.removeSuffix("-" + ads)

                                                                                                    println("DOC ID" + docid)
                                                                                                    println("TRIMMED DOC ID" + ff)
                                                                                                    ffstr = ff
                                                                                                    val message = dataSnapshot.value
                                                                                                    val qnty = message.toString()
                                                                                                    var tt = qnty
                                                                                                    qn1 = tt

                                                                                                    val map = mutableMapOf<String, Any?>()
                                                                                                    map.put("$ads", qn1)
                                                                                                    db.collection("product").document(id)
                                                                                                            .update(map)
                                                                                                            .addOnSuccessListener {

                                                                                                                db.collection("product").document(id)

                                                                                                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                                            println("e : "+e)
                                                                                                                            if (e==null) {
                                                                                                                                var doc = task.data

                                                                                                                                val ids = task.id;//0
                                                                                                                                idss = ids
                                                                                                                                val stockonhand = doc.get("$ads").toString();//7
                                                                                                                                val pid = doc.get("p_id").toString();//1
                                                                                                                                val pname = doc.get("p_nm").toString();//2
                                                                                                                                val bcode = doc.get("bc").toString();//3
                                                                                                                                val pdes = doc.get("desc").toString();//4
                                                                                                                                val weight = doc.get("wg_vol").toString();//5
                                                                                                                                val psac = doc.get("hsn").toString();//6
                                                                                                                                val minstock = doc.get("min_stk").toString();//8
                                                                                                                                val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                                val price = doc.get("price").toString();//10
                                                                                                                                val taxable = doc.get("taxchk").toString();//11
                                                                                                                                val igst = doc.get("igst").toString();//12
                                                                                                                                val cgst = doc.get("cgst").toString();//13
                                                                                                                                val sgst = doc.get("sgst").toString();//14
                                                                                                                                val cess = doc.get("taxchk").toString();//15
                                                                                                                                val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                                val cessval = doc.get("cesstot").toString();//17
                                                                                                                                val currency = doc.get("curency").toString();//18
                                                                                                                                val percentage = doc.get("percentage").toString();//19
                                                                                                                                val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                                val product_dec = doc.get("product_desc").toString();//21
                                                                                                                                val mrP = doc.get("mrp").toString();//22
                                                                                                                                val cate = doc.get("ctgy").toString();//23
                                                                                                                                val manufacture = doc.get("mfr").toString();//24
                                                                                                                                val ut = doc.get("ut").toString();//25
                                                                                                                                val consold = doc.get("cn_sold").toString();//26
                                                                                                                                val comm = doc.get("emp_com").toString();//27
                                                                                                                                val status = doc.get("status").toString();//27
                                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                                val img5url = doc.get("img5url").toString();//37

                                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                                                                                idsArray = idsArray.plusElement(ids)
                                                                                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                }
                                                                                                                                else{
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                }




                                                                                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                                } else {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                                }
                                                                                                                                if (bcode.isNotEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                                } else if (bcode.isEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                                }

                                                                                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                                mhArray = mhArray.plusElement(maxstock)
                                                                                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                                                                                disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                                                println(Arrays.toString(disArray))

                                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                                } else {
                                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                                }


                                                                                                                            }

                                                                                                                            progress.visibility=View.GONE
                                                                                                                            alllist.visibility=View.VISIBLE
                                                                                                                            brspinner.visibility=View.VISIBLE

                                                                                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray,
                                                                                                                                    sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                                            slist.adapter = whatever







                                                                                                                        })

                                                                                                            }


                                                                                                }
                                                                                                else{
                                                                                                    noresfo.visibility=View.VISIBLE
                                                                                                    progress.visibility=View.GONE
                                                                                                    alllist.visibility=View.GONE
                                                                                                    brspinner.visibility=View.GONE
                                                                                                }


                                                                                            }


                                                                                        }
                                                                                        myRef!!.addValueEventListener(messageListener)

                                                                                    }
                                                                                }
                                                                            else{
                                                                                noresfo.visibility=View.VISIBLE
                                                                                progress.visibility=View.GONE
                                                                                alllist.visibility=View.GONE
                                                                                brspinner.visibility=View.GONE
                                                                            }





                                                                        })
                                                            }





                                                    })
                                        }





                                })
                    }*/


                }

                fun priget() {//Price serach
                    /*   nores.visibility = View.GONE
   */


                    if ((des.length >= 1)) {

                        var ad = brnchkeys[ddpos]

                        noresfo.visibility = View.GONE


                        var idsArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status


                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()



//Stock level search
                        db.collection("product").orderBy("$ad").startAt(numberstr).endAt(esc)//herebuddy
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + brnchkeys[ddpos]

                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + ad)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ad", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)
                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$ad").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        try {
                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                            val img5url = doc.get("img5url").toString();//37


                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                            if (ur.isNotEmpty()) {
                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                            }
                                                                                        } catch (e: Exception) {

                                                                                        }


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))



                                                                                        progress.visibility = View.GONE

                                                                                        alllist.visibility = View.VISIBLE
                                                                                        brspinner.visibility = View.VISIBLE
                                                                                    }


                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                            nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                            disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {

                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brnchkeys[ddpos]

                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + ad)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$ad", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)
                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$ad").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                val img5url = doc.get("img5url").toString();//37


                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                }
                                                                                                            } catch (e: Exception) {

                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))



                                                                                                            progress.visibility = View.GONE

                                                                                                            alllist.visibility = View.VISIBLE
                                                                                                            brspinner.visibility = View.VISIBLE
                                                                                                        }


                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                                nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                                                disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {
                                                                bcodeget()
                                                            }




                                                    })


                                        }

                                })
                    }

                    /*if ((des.length >= 1) && (brspinner.selectedItemPosition == 1)) {
                        noresfo.visibility = View.GONE

                        var idsArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()


                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()


                        var disArray = arrayOf<String>()//status
                        var adss = brnchkeys[1]

                        db.collection("product").orderBy("$adss").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + adss

                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + adss)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$adss", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)

                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        try {
                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                            val img5url = doc.get("img5url").toString();//37
                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)



                                                                                            if (ur.isNotEmpty()) {
                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                            }
                                                                                        } catch (e: Exception) {

                                                                                        }


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))


                                                                                        *//*progressBar3.visibility=View.GONE*//*
                                                                                        *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                    }

                                                                                    progress.visibility = View.GONE
                                                                                    alllist.visibility = View.VISIBLE
                                                                                    brspinner.visibility = View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray,
                                                                                            bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {
                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + adss

                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + adss)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$adss", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)
                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$adss").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                val img5url = doc.get("img5url").toString();//37
                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)



                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                }
                                                                                                            } catch (e: Exception) {

                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))


                                                                                                            *//*progressBar3.visibility=View.GONE*//*
                                                                                                            *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                                        }

                                                                                                        progress.visibility = View.GONE
                                                                                                        alllist.visibility = View.VISIBLE
                                                                                                        brspinner.visibility = View.VISIBLE

                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray, sunbnmArray,
                                                                                                                bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {
                                                                bcodeget()
                                                            }




                                                    })


                                        }

                                })
                    }



                    if ((des.length >= 1) && (brspinner.selectedItemPosition == 3)) {

                        noresfo.visibility = View.GONE


                        var idsArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status


                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()


                        var adss = brnchkeys[3]

                        db.collection("product").orderBy("$adss").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + adss

                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + adss)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$adss", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)

                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        try {
                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                            val img5url = doc.get("img5url").toString();//37
                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"


                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)
                                                                                            if (ur.isNotEmpty()) {
                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                            }
                                                                                        } catch (e: Exception) {

                                                                                        }


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))


                                                                                        *//*progressBar3.visibility=View.GONE*//*
                                                                                        *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                    }

                                                                                    progress.visibility = View.GONE
                                                                                    alllist.visibility = View.VISIBLE
                                                                                    brspinner.visibility = View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                            nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {
                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + adss

                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + adss)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$adss", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)

                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$adss").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                val img5url = doc.get("img5url").toString();//37
                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"


                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)
                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                }
                                                                                                            } catch (e: Exception) {

                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))


                                                                                                            *//*progressBar3.visibility=View.GONE*//*
                                                                                                            *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                                        }

                                                                                                        progress.visibility = View.GONE
                                                                                                        alllist.visibility = View.VISIBLE
                                                                                                        brspinner.visibility = View.VISIBLE

                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                                nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {
                                                                bcodeget()
                                                            }




                                                    })


                                        }

                                })
                    }



                    if ((des.length >= 1) && (brspinner.selectedItemPosition == 4)) {

                        noresfo.visibility = View.GONE


                        var idsArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status


                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()


                        var adss = brnchkeys[4]

                        db.collection("product").orderBy("$adss").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + adss

                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + adss)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$adss", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)
                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        try {
                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                            val img5url = doc.get("img5url").toString();//37
                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                            if (ur.isNotEmpty()) {
                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                            }
                                                                                        } catch (e: Exception) {

                                                                                        }


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))


                                                                                        *//*progressBar3.visibility=View.GONE*//*
                                                                                        *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                    }

                                                                                    progress.visibility = View.GONE
                                                                                    alllist.visibility = View.VISIBLE
                                                                                    brspinner.visibility = View.VISIBLE

                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                            nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                            disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {
                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + adss

                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + adss)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$adss", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)


                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            val stockonhand = doc.get("$adss").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                val img5url = doc.get("img5url").toString();//37
                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                }
                                                                                                            } catch (e: Exception) {

                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))


                                                                                                            *//*progressBar3.visibility=View.GONE*//*
                                                                                                            *//*sivakasibrancheslist.visibility = View.VISIBLE*//*
                                                                                                        }

                                                                                                        progress.visibility = View.GONE
                                                                                                        alllist.visibility = View.VISIBLE
                                                                                                        brspinner.visibility = View.VISIBLE

                                                                                                        val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                                nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                                                disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {
                                                                bcodeget()
                                                            }




                                                    })


                                        }



                                })
                    }*/
                }

                if (x.trim().matches(regexStr.toRegex())) {//typed string matches only numbers  then barcode search initiated.
                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    bcodeget()
                    //write code here for success
                }

                if((des.length==1)&&(x!==reg)) {//typed string matches only alphabets first letter convert to CAPS.
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    nmstr = upstr
                    var escp = upperString + '\uf8ff'
                    esc = escp

                    println("CAPPPSSSS" + upperString)
                }

                if((des.length>=1)&&(x==reg)) {//typed string matches only numbers then price search initiated.

                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    priget()
                }

                if ((des.length >= 3)&&(x!==reg)) {//Names search initiated.
                    noresfo.visibility = View.GONE

                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    var sunbnmArray = arrayOf<String>() //mfr

                    var bcArray = arrayOf<String>()//bc

                    var sohArray = arrayOf<String>()//stock_hand


                    var mlArray = arrayOf<String>()//wg_vol

                    var mhArray = arrayOf<String>()//mx_stk

                    var priceArray = arrayOf<String>()//price
                    var primgArray = arrayOf<String>()

                    var disArray = arrayOf<String>()//status

                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()

                    db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {
                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data

                                            val id = document.id;//0
                                            idstr = id

                                            idstrarr = idstrarr.plusElement(idstr)



                                            lststr = "in"
                                            var ddstr = id + "_" + brnchkeys[ddpos]
                                            val database = FirebaseDatabase.getInstance()
                                            val myRef = database.getReference(ddstr)
                                            myRef.root

                                            val messageListener = object : ValueEventListener {
                                                override fun onCancelled(p0: DatabaseError?) {
                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                }


                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                    datach = "changed"

                                                    if (dataSnapshot.exists()) {


                                                        val docid = dataSnapshot.key

                                                        var ff = docid.removeSuffix("-" + brnchkeys[ddpos])
                                                        var adss = brnchkeys[ddpos]
                                                        println("DOC ID" + docid)
                                                        println("TRIMMED DOC ID" + ff)
                                                        ffstr = ff
                                                        val message = dataSnapshot.value
                                                        val qnty = message.toString()
                                                        var tt = qnty
                                                        qn = tt

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$adss", qn)
                                                        db.collection("product").document(id)
                                                                .update(map)
                                                                .addOnSuccessListener {

                                                                    db.collection("product").document(id)
                                                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                println("e : "+e)
                                                                                if (e==null) {
                                                                                    var doc = task.data

                                                                                    val ids = task.id;//0
                                                                                    idss = ids
                                                                                    val stockonhand = doc.get("$adss").toString();//7
                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                    val price = doc.get("price").toString();//10
                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                    val igst = doc.get("igst").toString();//12
                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                    val currency = doc.get("curency").toString();//18
                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                    val ut = doc.get("ut").toString();//25
                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                    val status = doc.get("status").toString();//27
                                                                                    try {
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }
                                                                                    } catch (e: Exception) {

                                                                                    }


                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    }




                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                    } else {
                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                    }
                                                                                    if (bcode.isNotEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                    } else if (bcode.isEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                    }

                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                    println(Arrays.toString(disArray))


                                                                                }

                                                                                progress.visibility = View.GONE

                                                                                alllist.visibility = View.VISIBLE
                                                                                brspinner.visibility = View.VISIBLE

                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                        nameArray, mlArray, sunbnmArray, bcArray,
                                                                                        priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                slist.adapter = whatever


                                                                            })

                                                                }


                                                    }


                                                }


                                            }
                                            myRef!!.addValueEventListener(messageListener)

                                        }
                                    } else {


                                    //Manufacturer search initiated.

                                        /*     mylist.visibility=View.GONE
                                             nores.visibility=View.VISIBLE*/

                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {
                                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                val dd = document.data

                                                                val id = document.id;//0
                                                                idstr = id

                                                                idstrarr = idstrarr.plusElement(idstr)



                                                                lststr = "in"
                                                                var ddstr = id + "_" + brnchkeys[ddpos]
                                                                val database = FirebaseDatabase.getInstance()
                                                                val myRef = database.getReference(ddstr)
                                                                myRef.root

                                                                val messageListener = object : ValueEventListener {
                                                                    override fun onCancelled(p0: DatabaseError?) {
                                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                    }


                                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                        datach = "changed"

                                                                        if (dataSnapshot.exists()) {


                                                                            val docid = dataSnapshot.key

                                                                            var ff = docid.removeSuffix("-" + brnchkeys[ddpos])
                                                                            var adss = brnchkeys[ddpos]
                                                                            println("DOC ID" + docid)
                                                                            println("TRIMMED DOC ID" + ff)
                                                                            ffstr = ff
                                                                            val message = dataSnapshot.value
                                                                            val qnty = message.toString()
                                                                            var tt = qnty
                                                                            qn = tt

                                                                            val map = mutableMapOf<String, Any?>()
                                                                            map.put("$adss", qn)
                                                                            db.collection("product").document(id)
                                                                                    .update(map)
                                                                                    .addOnSuccessListener {

                                                                                        db.collection("product").document(id)
                                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                    println("e : "+e)
                                                                                                    if (e==null) {
                                                                                                        var doc = task.data

                                                                                                        val ids = task.id;//0
                                                                                                        idss = ids
                                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                                        val price = doc.get("price").toString();//10
                                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                                        val igst = doc.get("igst").toString();//12
                                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                                        val currency = doc.get("curency").toString();//18
                                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                                        val ut = doc.get("ut").toString();//25
                                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                                        val status = doc.get("status").toString();//27
                                                                                                        try {
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }
                                                                                                        } catch (e: Exception) {

                                                                                                        }


                                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        }




                                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                        } else {
                                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                        }
                                                                                                        if (bcode.isNotEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                        } else if (bcode.isEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                                        }

                                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                        println(Arrays.toString(disArray))


                                                                                                    }
                                                                                                    progress.visibility = View.GONE

                                                                                                    alllist.visibility = View.VISIBLE
                                                                                                    brspinner.visibility = View.VISIBLE

                                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                            nameArray, mlArray, sunbnmArray, bcArray,
                                                                                                            priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                    slist.adapter = whatever


                                                                                                })

                                                                                    }


                                                                        }


                                                                    }


                                                                }
                                                                myRef!!.addValueEventListener(messageListener)

                                                            }
                                                        }
                                                        else{
                                                        noresfo.visibility=View.VISIBLE
                                                        progress.visibility=View.GONE
                                                        alllist.visibility=View.GONE
                                                        brspinner.visibility=View.GONE
                                                        }




                                                })


                                    }

                            })
                }




              /*  if ((des.length >= 3)&&(x!==reg)&&(brspinner.selectedItemPosition==1)) {
                    noresfo.visibility = View.GONE

                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    var sunbnmArray = arrayOf<String>() //mfr

                    var bcArray = arrayOf<String>()//bc

                    var sohArray = arrayOf<String>()//stock_hand


                    var mlArray = arrayOf<String>()//wg_vol

                    var mhArray = arrayOf<String>()//mx_stk

                    var priceArray = arrayOf<String>()//price
                    var primgArray = arrayOf<String>()

                    var disArray = arrayOf<String>()//status

                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {
                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data

                                            val id = document.id;//0
                                            idstr = id

                                            idstrarr = idstrarr.plusElement(idstr)



                                            lststr = "in"
                                            var ddstr = id + "_" + brnchkeys[1]
                                            var adss = brnchkeys[1]
                                            val database = FirebaseDatabase.getInstance()
                                            val myRef = database.getReference(ddstr)
                                            myRef.root

                                            val messageListener = object : ValueEventListener {
                                                override fun onCancelled(p0: DatabaseError?) {
                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                }


                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                    datach = "changed"

                                                    if (dataSnapshot.exists()) {


                                                        val docid = dataSnapshot.key

                                                        var ff = docid.removeSuffix("-" + brnchkeys[1])

                                                        println("DOC ID" + docid)
                                                        println("TRIMMED DOC ID" + ff)
                                                        ffstr = ff
                                                        val message = dataSnapshot.value
                                                        val qnty = message.toString()
                                                        var tt = qnty
                                                        qn = tt

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$adss", qn)
                                                        db.collection("product").document(id)
                                                                .update(map)
                                                                .addOnSuccessListener {

                                                                    db.collection("product").document(id)

                                                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                println("e : "+e)
                                                                                if (e==null) {
                                                                                    var doc = task.data

                                                                                    val ids = task.id;//0
                                                                                    idss = ids
                                                                                    val stockonhand = doc.get("$adss").toString();//7
                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                    val price = doc.get("price").toString();//10
                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                    val igst = doc.get("igst").toString();//12
                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                    val currency = doc.get("curency").toString();//18
                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                    val ut = doc.get("ut").toString();//25
                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                    val status = doc.get("status").toString();//27


                                                                                    try {
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37
                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }
                                                                                    } catch (e: Exception) {

                                                                                    }


                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    }




                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                    } else {
                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                    }
                                                                                    if (bcode.isNotEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                    } else if (bcode.isEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                    }
                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                    println(Arrays.toString(disArray))


*//*
                                                                                    progressBar3.visibility=View.GONE
                                                                                    mylist.visibility = View.VISIBLE*//*
                                                                                }
                                                                                progress.visibility = View.GONE
                                                                                alllist.visibility = View.VISIBLE
                                                                                brspinner.visibility = View.VISIBLE

                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                        disArray, primgArray, icohighnmArray, icohighArray)
                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                slist.adapter = whatever


                                                                            })

                                                                }


                                                    }


                                                }


                                            }
                                            myRef!!.addValueEventListener(messageListener)

                                        }
                                    } else {

                                        *//*     mylist.visibility=View.GONE
                                             nores.visibility=View.VISIBLE*//*
                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {

                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                val dd = document.data

                                                                val id = document.id;//0
                                                                idstr = id

                                                                idstrarr = idstrarr.plusElement(idstr)



                                                                lststr = "in"
                                                                var ddstr = id + "_" + brnchkeys[2]
                                                                val database = FirebaseDatabase.getInstance()
                                                                val myRef = database.getReference(ddstr)
                                                                myRef.root

                                                                val messageListener = object : ValueEventListener {
                                                                    override fun onCancelled(p0: DatabaseError?) {
                                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                    }


                                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                        datach = "changed"

                                                                        if (dataSnapshot.exists()) {


                                                                            val docid = dataSnapshot.key

                                                                            var ff = docid.removeSuffix("-" + brnchkeys[2])
                                                                            var adss = brnchkeys[2]
                                                                            println("DOC ID" + docid)
                                                                            println("TRIMMED DOC ID" + ff)
                                                                            ffstr = ff
                                                                            val message = dataSnapshot.value
                                                                            val qnty = message.toString()
                                                                            var tt = qnty
                                                                            qn = tt

                                                                            val map = mutableMapOf<String, Any?>()
                                                                            map.put("$adss", qn)
                                                                            db.collection("product").document(id)
                                                                                    .update(map)
                                                                                    .addOnSuccessListener {

                                                                                        db.collection("product").document(id)
                                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                    println("e : "+e)
                                                                                                    if (e==null) {
                                                                                                        var doc = task.data

                                                                                                        val ids = task.id;//0
                                                                                                        idss = ids
                                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                                        val price = doc.get("price").toString();//10
                                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                                        val igst = doc.get("igst").toString();//12
                                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                                        val currency = doc.get("curency").toString();//18
                                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                                        val ut = doc.get("ut").toString();//25
                                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                                        val status = doc.get("status").toString();//27
                                                                                                        try {
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }
                                                                                                        } catch (e: Exception) {

                                                                                                        }


                                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        }




                                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                        } else {
                                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                        }
                                                                                                        if (bcode.isNotEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                        } else if (bcode.isEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                                        }

                                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                        println(Arrays.toString(disArray))


                                                                                                    }
                                                                                                    progress.visibility = View.GONE

                                                                                                    alllist.visibility = View.VISIBLE
                                                                                                    brspinner.visibility = View.VISIBLE

                                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                            nameArray, mlArray, sunbnmArray, bcArray,
                                                                                                            priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                    slist.adapter = whatever


                                                                                                })

                                                                                    }


                                                                        }


                                                                    }


                                                                }
                                                                myRef!!.addValueEventListener(messageListener)

                                                            }
                                                        } else {
                                                        noresfo.visibility=View.VISIBLE
                                                        progress.visibility=View.GONE
                                                        alllist.visibility=View.GONE
                                                        brspinner.visibility=View.GONE
                                                        }



                                                })


                                    }

                            })
                }


                if ((des.length >= 3)&&(x!==reg)&&(brspinner.selectedItemPosition==3)) {
                    noresfo.visibility = View.GONE

                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    var sunbnmArray = arrayOf<String>() //mfr

                    var bcArray = arrayOf<String>()//bc

                    var sohArray = arrayOf<String>()//stock_hand


                    var mlArray = arrayOf<String>()//wg_vol

                    var mhArray = arrayOf<String>()//mx_stk

                    var priceArray = arrayOf<String>()//price
                    var primgArray = arrayOf<String>()

                    var disArray = arrayOf<String>()//status
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {
                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data

                                            val id = document.id;//0
                                            idstr = id

                                            idstrarr = idstrarr.plusElement(idstr)



                                            lststr = "in"
                                            var ddstr = id + "_" + brnchkeys[3]
                                            var adss = brnchkeys[3]
                                            val database = FirebaseDatabase.getInstance()
                                            val myRef = database.getReference(ddstr)
                                            myRef.root

                                            val messageListener = object : ValueEventListener {
                                                override fun onCancelled(p0: DatabaseError?) {
                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                }


                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                    datach = "changed"

                                                    if (dataSnapshot.exists()) {


                                                        val docid = dataSnapshot.key

                                                        var ff = docid.removeSuffix("-" + brnchkeys[3])

                                                        println("DOC ID" + docid)
                                                        println("TRIMMED DOC ID" + ff)
                                                        ffstr = ff
                                                        val message = dataSnapshot.value
                                                        val qnty = message.toString()
                                                        var tt = qnty
                                                        qn = tt

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$adss", qn)
                                                        db.collection("product").document(id)
                                                                .update(map)
                                                                .addOnSuccessListener {

                                                                    db.collection("product").document(id)
                                                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                println("e : "+e)
                                                                                if (e==null) {
                                                                                    var doc = task.data

                                                                                    val ids = task.id;//0
                                                                                    idss = ids
                                                                                    val stockonhand = doc.get("$adss").toString();//7
                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                    val price = doc.get("price").toString();//10
                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                    val igst = doc.get("igst").toString();//12
                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                    val currency = doc.get("curency").toString();//18
                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                    val ut = doc.get("ut").toString();//25
                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                    val status = doc.get("status").toString();//27
                                                                                    try {
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37
                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }
                                                                                    } catch (e: Exception) {

                                                                                    }


                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    }




                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                    } else {
                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                    }
                                                                                    if (bcode.isNotEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                    } else if (bcode.isEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                    }

                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                    println(Arrays.toString(disArray))


*//*
                                                                                    progressBar3.visibility=View.GONE
                                                                                    mylist.visibility = View.VISIBLE*//*
                                                                                }
                                                                                progress.visibility = View.GONE
                                                                                alllist.visibility = View.VISIBLE
                                                                                brspinner.visibility = View.VISIBLE
                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray,
                                                                                        disArray, primgArray, icohighnmArray, icohighArray)
                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                slist.adapter = whatever


                                                                            })

                                                                }


                                                    }


                                                }


                                            }
                                            myRef!!.addValueEventListener(messageListener)

                                        }
                                    } else {

                                        *//*     mylist.visibility=View.GONE
                                             nores.visibility=View.VISIBLE*//*
                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {
                                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                val dd = document.data

                                                                val id = document.id;//0
                                                                idstr = id

                                                                idstrarr = idstrarr.plusElement(idstr)



                                                                lststr = "in"
                                                                var ddstr = id + "_" + brnchkeys[2]
                                                                val database = FirebaseDatabase.getInstance()
                                                                val myRef = database.getReference(ddstr)
                                                                myRef.root

                                                                val messageListener = object : ValueEventListener {
                                                                    override fun onCancelled(p0: DatabaseError?) {
                                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                    }


                                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                        datach = "changed"

                                                                        if (dataSnapshot.exists()) {


                                                                            val docid = dataSnapshot.key

                                                                            var ff = docid.removeSuffix("-" + brnchkeys[2])
                                                                            var adss = brnchkeys[2]
                                                                            println("DOC ID" + docid)
                                                                            println("TRIMMED DOC ID" + ff)
                                                                            ffstr = ff
                                                                            val message = dataSnapshot.value
                                                                            val qnty = message.toString()
                                                                            var tt = qnty
                                                                            qn = tt

                                                                            val map = mutableMapOf<String, Any?>()
                                                                            map.put("$adss", qn)
                                                                            db.collection("product").document(id)
                                                                                    .update(map)
                                                                                    .addOnSuccessListener {

                                                                                        db.collection("product").document(id)
                                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                    println("e : "+e)
                                                                                                    if (e==null) {
                                                                                                        var doc = task.data

                                                                                                        val ids = task.id;//0
                                                                                                        idss = ids
                                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                                        val price = doc.get("price").toString();//10
                                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                                        val igst = doc.get("igst").toString();//12
                                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                                        val currency = doc.get("curency").toString();//18
                                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                                        val ut = doc.get("ut").toString();//25
                                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                                        val status = doc.get("status").toString();//27
                                                                                                        try {
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }
                                                                                                        } catch (e: Exception) {

                                                                                                        }


                                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        }




                                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                        } else {
                                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                        }
                                                                                                        if (bcode.isNotEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                        } else if (bcode.isEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                                        }

                                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                        println(Arrays.toString(disArray))


                                                                                                    }
                                                                                                    progress.visibility = View.GONE

                                                                                                    alllist.visibility = View.VISIBLE
                                                                                                    brspinner.visibility = View.VISIBLE

                                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                            nameArray, mlArray, sunbnmArray, bcArray,
                                                                                                            priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                    slist.adapter = whatever


                                                                                                })

                                                                                    }


                                                                        }


                                                                    }


                                                                }
                                                                myRef!!.addValueEventListener(messageListener)

                                                            }
                                                        } else {
                                                        noresfo.visibility=View.VISIBLE
                                                        progress.visibility=View.GONE
                                                        alllist.visibility=View.GONE
                                                        brspinner.visibility=View.GONE
                                                        }



                                                })


                                    }

                            })
                }



                if ((des.length >= 3)&&(x!==reg)&&(brspinner.selectedItemPosition==4)) {
                    noresfo.visibility = View.GONE

                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    var sunbnmArray = arrayOf<String>() //mfr

                    var bcArray = arrayOf<String>()//bc

                    var sohArray = arrayOf<String>()//stock_hand


                    var mlArray = arrayOf<String>()//wg_vol

                    var mhArray = arrayOf<String>()//mx_stk

                    var priceArray = arrayOf<String>()//price
                    var primgArray = arrayOf<String>()

                    var disArray = arrayOf<String>()//status
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()


                    db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {
                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data

                                            val id = document.id;//0
                                            idstr = id

                                            idstrarr = idstrarr.plusElement(idstr)



                                            lststr = "in"
                                            var ddstr = id + "_" + brnchkeys[4]
                                            var adss = brnchkeys[4]
                                            val database = FirebaseDatabase.getInstance()
                                            val myRef = database.getReference(ddstr)
                                            myRef.root

                                            val messageListener = object : ValueEventListener {
                                                override fun onCancelled(p0: DatabaseError?) {
                                                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                }


                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                    datach = "changed"

                                                    if (dataSnapshot.exists()) {


                                                        val docid = dataSnapshot.key

                                                        var ff = docid.removeSuffix("-" + brnchkeys[4])

                                                        println("DOC ID" + docid)
                                                        println("TRIMMED DOC ID" + ff)
                                                        ffstr = ff
                                                        val message = dataSnapshot.value
                                                        val qnty = message.toString()
                                                        var tt = qnty
                                                        qn = tt

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$adss", qn)
                                                        db.collection("product").document(id)
                                                                .update(map)
                                                                .addOnSuccessListener {

                                                                    db.collection("product").document(id)
                                                                            .addSnapshotListener(EventListener<DocumentSnapshot> { task, e ->
                                                                                println("e : " + e)
                                                                                if (e == null) {
                                                                                    var doc = task.data

                                                                                    val ids = task.id;//0
                                                                                    idss = ids
                                                                                    val stockonhand = doc.get("$adss").toString();//7
                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                    val price = doc.get("price").toString();//10
                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                    val igst = doc.get("igst").toString();//12
                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                    val currency = doc.get("curency").toString();//18
                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                    val ut = doc.get("ut").toString();//25
                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                    val status = doc.get("status").toString();//27
                                                                                    try {
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37
                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }
                                                                                    } catch (e: Exception) {

                                                                                    }


                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                    } else {
                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                    }




                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                    } else {
                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                    }
                                                                                    if (bcode.isNotEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                    } else if (bcode.isEmpty()) {
                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                    }

                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                    println(Arrays.toString(disArray))


*//*
                                                                                    progressBar3.visibility=View.GONE
                                                                                    mylist.visibility = View.VISIBLE*//*
                                                                                }
                                                                                progress.visibility = View.GONE
                                                                                alllist.visibility = View.VISIBLE
                                                                                brspinner.visibility = View.VISIBLE
                                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray,
                                                                                        primgArray, icohighnmArray, icohighArray)
                                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                slist.adapter = whatever


                                                                            })

                                                                }


                                                    }


                                                }


                                            }
                                            myRef!!.addValueEventListener(messageListener)

                                        }
                                    } else {

                                        *//*     mylist.visibility=View.GONE
                                             nores.visibility=View.VISIBLE*//*
                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {
                                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                val dd = document.data

                                                                val id = document.id;//0
                                                                idstr = id

                                                                idstrarr = idstrarr.plusElement(idstr)



                                                                lststr = "in"
                                                                var ddstr = id + "_" + brnchkeys[2]
                                                                val database = FirebaseDatabase.getInstance()
                                                                val myRef = database.getReference(ddstr)
                                                                myRef.root

                                                                val messageListener = object : ValueEventListener {
                                                                    override fun onCancelled(p0: DatabaseError?) {
                                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                    }


                                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                        datach = "changed"

                                                                        if (dataSnapshot.exists()) {


                                                                            val docid = dataSnapshot.key

                                                                            var ff = docid.removeSuffix("-" + brnchkeys[2])
                                                                            var adss = brnchkeys[2]
                                                                            println("DOC ID" + docid)
                                                                            println("TRIMMED DOC ID" + ff)
                                                                            ffstr = ff
                                                                            val message = dataSnapshot.value
                                                                            val qnty = message.toString()
                                                                            var tt = qnty
                                                                            qn = tt

                                                                            val map = mutableMapOf<String, Any?>()
                                                                            map.put("$adss", qn)
                                                                            db.collection("product").document(id)
                                                                                    .update(map)
                                                                                    .addOnSuccessListener {

                                                                                        db.collection("product").document(id)
                                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                    println("e : "+e)
                                                                                                    if (e==null) {
                                                                                                        var doc = task.data

                                                                                                        val ids = task.id;//0
                                                                                                        idss = ids
                                                                                                        val stockonhand = doc.get("$adss").toString();//7
                                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                                        val price = doc.get("price").toString();//10
                                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                                        val igst = doc.get("igst").toString();//12
                                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                                        val currency = doc.get("curency").toString();//18
                                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                                        val ut = doc.get("ut").toString();//25
                                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                                        val status = doc.get("status").toString();//27
                                                                                                        try {
                                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                                            val img5url = doc.get("img5url").toString();//37

                                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                            if (ur.isNotEmpty()) {
                                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                                            } else {
                                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                            }
                                                                                                        } catch (e: Exception) {

                                                                                                        }


                                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                                        } else {
                                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                                        }




                                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                        } else {
                                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                        }
                                                                                                        if (bcode.isNotEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                        } else if (bcode.isEmpty()) {
                                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                                        }

                                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                        println(Arrays.toString(disArray))


                                                                                                    }
                                                                                                    progress.visibility = View.GONE

                                                                                                    alllist.visibility = View.VISIBLE
                                                                                                    brspinner.visibility = View.VISIBLE

                                                                                                    val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                                                            nameArray, mlArray, sunbnmArray, bcArray,
                                                                                                            priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                    val slist = findViewById<View>(R.id.alllist) as ListView
                                                                                                    slist.adapter = whatever


                                                                                                })

                                                                                    }


                                                                        }


                                                                    }


                                                                }
                                                                myRef!!.addValueEventListener(messageListener)

                                                            }
                                                        } else {
                                                        noresfo.visibility=View.VISIBLE
                                                        progress.visibility=View.GONE
                                                        alllist.visibility=View.GONE
                                                        brspinner.visibility=View.GONE
                                                        }




                                                })


                                    }

                            })
                }*/


                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub
            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(editText.text.toString().isEmpty())//If seach edit is empty load all products
                {
                    progress.visibility=View.VISIBLE
                    selectbr()
                }
            }
        })




    }


    fun getfirst(id: String, bid: String)//Get stock levels from firebase db and update to product db and list out the products.
    {


        progress.visibility=View.VISIBLE


        lststr = "in"
        var ddstr = id + "_" + bid
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference(ddstr)
        myRef.root

        val messageListener = object : ValueEventListener {


            override fun onDataChange(dataSnapshot: DataSnapshot) {
                datach = "changed"

                if (dataSnapshot.exists()) {


                    val docid = dataSnapshot.key

                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value//Get stock levels
                    val qnty = message.toString()
                    var tt = qnty
                    qn1 = tt

                    val map = mutableMapOf<String, Any?>()
                    map.put("$bid", qn1)
                    db.collection("product").document(id)
                            .update(map)//Update to product
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status


                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()


                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)


                                                                val ids = document.id;//0
                                                                idssiv = ids
                                                                val stockonhand = document.get("$bid").toString();//7
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27
                                                                val img1n = document.get("img1n").toString();//28
                                                                val img2n = document.get("img2n").toString();//29
                                                                val img3n = document.get("img3n").toString();//30
                                                                val img4n = document.get("img4n").toString();//31
                                                                val img5n = document.get("img5n").toString();//32
                                                                val img1url = document.get("img1url").toString();//33
                                                                val img2url = document.get("img2url").toString();//34
                                                                val img3url = document.get("img3url").toString();//35
                                                                val img4url = document.get("img4url").toString();//36
                                                                val img5url = document.get("img5url").toString();//37

                                                                val img1nhigh = document.get("img1nhigh").toString();//28

                                                                val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)
                                                                idsArray = idsArray.plusElement(ids)
                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)
                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                } else {
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if (bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                } else if (bcode.isEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                priceArraydup=priceArray

                                                                println(Arrays.toString(disArray))

                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                if (ur.isNotEmpty()) {
                                                                    primgArray = primgArray.plusElement(ur)
                                                                } else {
                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                }

                                                                kknagar = 0
                                                            }
                                                            progress.visibility=View.GONE



                                                            //List out the products
                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray,
                                                                    mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                            slist.adapter = whatever



                                                        })


                                            }
                                        })
                            }


                } else {


                    /*val docid = dataSnapshot.key
                    keylist.add(docid)
                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()*/

                    qn1 = "0"

                    val map = mutableMapOf<String, Any?>()
                    map.put("$bid", qn1)//If stocks doesnt exists,update as 0
                    db.collection("product").document(id)
                            .update(map)
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status


                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()


                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)


                                                                val ids = document.id;//0
                                                                idssiv = ids
                                                                val stockonhand = document.get("$bid").toString();//7
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27
                                                                val img1n = document.get("img1n").toString();//28
                                                                val img2n = document.get("img2n").toString();//29
                                                                val img3n = document.get("img3n").toString();//30
                                                                val img4n = document.get("img4n").toString();//31
                                                                val img5n = document.get("img5n").toString();//32
                                                                val img1url = document.get("img1url").toString();//33
                                                                val img2url = document.get("img2url").toString();//34
                                                                val img3url = document.get("img3url").toString();//35
                                                                val img4url = document.get("img4url").toString();//36
                                                                val img5url = document.get("img5url").toString();//37
                                                                val img1nhigh = document.get("img1nhigh").toString();//28

                                                                val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                idsArray = idsArray.plusElement(ids)
                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)
                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                } else {
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if (bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                } else if (bcode.isEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)


                                                                priceArraydup=priceArray

                                                                println(Arrays.toString(disArray))

                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                if (ur.isNotEmpty()) {
                                                                    primgArray = primgArray.plusElement(ur)
                                                                } else {
                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                }

                                                                kknagar = 0
                                                            }
                                                            progress.visibility=View.GONE


                                                            //list out the products
                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray,
                                                                    sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                            slist.adapter = whatever


                                                        })


                                            }
                                        })
                            }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Failed to read value


            }
        }

        myRef!!.addValueEventListener(messageListener)


    }


    //SECOND FUNCTION

    /*fun getsecond(id: String, bid: String) {



        progress.visibility=View.VISIBLE

        lststr = "in"
        var ddstr = id + "_" + bid
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference(ddstr)
        myRef.root

        val messageListener = object : ValueEventListener {


            override fun onDataChange(dataSnapshot: DataSnapshot) {
                datach = "changed"

                if (dataSnapshot.exists()) {


                    val docid = dataSnapshot.key

                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()
                    var tt = qnty
                    qn1 = tt

                    val map = mutableMapOf<String, Any?>()
                    map.put("$bid", qn1)
                    db.collection("product").document(id)
                            .update(map)
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status

                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()



                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)


                                                                val ids = document.id;//0
                                                                idssiv = ids
                                                                val stockonhand = document.get("$bid").toString();//7
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27
                                                                val img1n = document.get("img1n").toString();//28
                                                                val img2n = document.get("img2n").toString();//29
                                                                val img3n = document.get("img3n").toString();//30
                                                                val img4n = document.get("img4n").toString();//31
                                                                val img5n = document.get("img5n").toString();//32
                                                                val img1url = document.get("img1url").toString();//33
                                                                val img2url = document.get("img2url").toString();//34
                                                                val img3url = document.get("img3url").toString();//35
                                                                val img4url = document.get("img4url").toString();//36
                                                                val img5url = document.get("img5url").toString();//37
                                                                val img1nhigh = document.get("img1nhigh").toString();//28

                                                                val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                idsArray = idsArray.plusElement(ids)
                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)
                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                } else {
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if (bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                } else if (bcode.isEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                priceArraydup=priceArray

                                                                println(Arrays.toString(disArray))

                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                if (ur.isNotEmpty()) {
                                                                    primgArray = primgArray.plusElement(ur)
                                                                } else {
                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                }

                                                                byepassval = 1
                                                            }
                                                            progress.visibility=View.GONE

                                         val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray, mlArray,
                                                 sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                            slist.adapter = whatever



                                                        })


                                            }
                                        })
                            }


                } else {


                    *//*val docid = dataSnapshot.key
                    keylist.add(docid)
                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()*//*

                    qn1 = "0"

                    val map = mutableMapOf<String, Any?>()
                    map.put("$bid", qn1)
                    db.collection("product").document(id)
                            .update(map)
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status


                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()



                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)


                                                                val ids = document.id;//0
                                                                idssiv = ids
                                                                val stockonhand = document.get("$bid").toString();//7
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27
                                                                val img1n = document.get("img1n").toString();//28
                                                                val img2n = document.get("img2n").toString();//29
                                                                val img3n = document.get("img3n").toString();//30
                                                                val img4n = document.get("img4n").toString();//31
                                                                val img5n = document.get("img5n").toString();//32
                                                                val img1url = document.get("img1url").toString();//33
                                                                val img2url = document.get("img2url").toString();//34
                                                                val img3url = document.get("img3url").toString();//35
                                                                val img4url = document.get("img4url").toString();//36
                                                                val img5url = document.get("img5url").toString();//37
                                                                val img1nhigh = document.get("img1nhigh").toString();//28

                                                                val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                idsArray = idsArray.plusElement(ids)
                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)
                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                } else {
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if (bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                } else if (bcode.isEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                priceArraydup=priceArray
                                                                println(Arrays.toString(disArray))

                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                if (ur.isNotEmpty()) {
                                                                    primgArray = primgArray.plusElement(ur)
                                                                } else {
                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                }

                                                                byepassval = 1
                                                            }
                                                            progress.visibility=View.GONE


                                                            val whatever = allbradap(this@AllbranchesActivity, idsArray, nameArray,
                                                                    mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.alllist) as ListView
                                                            slist.adapter = whatever


                                                        })


                                            }
                                        })
                            }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Failed to read value


            }
        }

        myRef!!.addValueEventListener(messageListener)


    }


    //GET THIRD


    fun getthird(id: String, bid: String) {
        progress.visibility=View.VISIBLE


        if (bid.isNotEmpty()) {
            lststr = "in"
            var ddstr = id + "_" + bid
            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference(ddstr)
            myRef.root

            val messageListener = object : ValueEventListener {


                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    datach = "changed"

                    if (dataSnapshot.exists()) {


                        val docid = dataSnapshot.key

                        var ff = docid.removeSuffix("-" + bid)

                        println("DOC ID" + docid)
                        println("TRIMMED DOC ID" + ff)
                        ffstr = ff
                        val message = dataSnapshot.value
                        val qnty = message.toString()
                        var tt = qnty
                        qn1 = tt

                        val map = mutableMapOf<String, Any?>()
                        map.put("$bid", qn1)
                        db.collection("product").document(id)
                                .update(map)
                                .addOnSuccessListener {

                                    db.collection("product").document(id)
                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                println("e : "+e)
                                                if (e==null) {
                                                    var doc = task.data

                                                    val ids = task.id;//0
                                                    Log.d(TAG, "cleared")
                                                    db.collection("product")
                                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                                var idsArray = arrayOf<String>()
                                                                var nameArray = arrayOf<String>()

                                                                var sunbnmArray = arrayOf<String>() //mfr

                                                                var bcArray = arrayOf<String>()//bc

                                                                var sohArray = arrayOf<String>()//stock_hand


                                                                var mlArray = arrayOf<String>()//wg_vol

                                                                var mhArray = arrayOf<String>()//mx_stk

                                                                var priceArray = arrayOf<String>()//price
                                                                var primgArray = arrayOf<String>()

                                                                var disArray = arrayOf<String>()//status


                                                                var icohighArray=arrayOf<String>()
                                                                var icohighnmArray=arrayOf<String>()



                                                                if (e != null) {
                                                                    Log.w("", "Listen failed.", e)
                                                                    return@EventListener
                                                                }

                                                                for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    val ids = document.id;//0
                                                                    idssiv = ids
                                                                    val stockonhand = document.get("$bid").toString();//7
                                                                    val pid = document.get("p_id").toString();//1
                                                                    val pname = document.get("p_nm").toString();//2
                                                                    val bcode = document.get("bc").toString();//3
                                                                    val pdes = document.get("desc").toString();//4
                                                                    val weight = document.get("wg_vol").toString();//5
                                                                    val psac = document.get("hsn").toString();//6
                                                                    val minstock = document.get("min_stk").toString();//8
                                                                    val maxstock = document.get("mx_stk").toString();//9
                                                                    val price = document.get("price").toString();//10
                                                                    val taxable = document.get("taxchk").toString();//11
                                                                    val igst = document.get("igst").toString();//12
                                                                    val cgst = document.get("cgst").toString();//13
                                                                    val sgst = document.get("sgst").toString();//14
                                                                    val cess = document.get("taxchk").toString();//15
                                                                    val taxtotal = document.get("taxtot").toString();//16
                                                                    val cessval = document.get("cesstot").toString();//17
                                                                    val currency = document.get("curency").toString();//18
                                                                    val percentage = document.get("percentage").toString();//19
                                                                    val percentagevalue = document.get("percentageval").toString();//20
                                                                    val product_dec = document.get("product_desc").toString();//21
                                                                    val mrP = document.get("mrp").toString();//22
                                                                    val cate = document.get("ctgy").toString();//23
                                                                    val manufacture = document.get("mfr").toString();//24
                                                                    val ut = document.get("ut").toString();//25
                                                                    val consold = document.get("cn_sold").toString();//26
                                                                    val comm = document.get("emp_com").toString();//27
                                                                    val status = document.get("status").toString();//27
                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37
                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                    idsArray = idsArray.plusElement(ids)
                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    }
                                                                    else{
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    }




                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                    } else {
                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                    }
                                                                    if (bcode.isNotEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                    } else if (bcode.isEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                    }

                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                    priceArraydup=priceArray

                                                                    println(Arrays.toString(disArray))

                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }

                                                                    periyarval = 2
                                                                }
                                                                progress.visibility=View.GONE


                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                        nameArray, mlArray, sunbnmArray, bcArray,
                                                                        priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                slist.adapter = whatever



                                                            })


                                                }
                                            })
                                }


                    } else {


                        *//*val docid = dataSnapshot.key
                    keylist.add(docid)
                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()*//*

                        qn1 = "0"

                        val map = mutableMapOf<String, Any?>()
                        map.put("$bid", qn1)
                        db.collection("product").document(id)
                                .update(map)
                                .addOnSuccessListener {

                                    db.collection("product").document(id)
                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                println("e : "+e)
                                                if (e==null) {
                                                    var doc = task.data

                                                    val ids = task.id;//0
                                                    Log.d(TAG, "cleared")
                                                    db.collection("product")
                                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                                var idsArray = arrayOf<String>()
                                                                var nameArray = arrayOf<String>()

                                                                var sunbnmArray = arrayOf<String>() //mfr

                                                                var bcArray = arrayOf<String>()//bc

                                                                var sohArray = arrayOf<String>()//stock_hand


                                                                var mlArray = arrayOf<String>()//wg_vol

                                                                var mhArray = arrayOf<String>()//mx_stk

                                                                var priceArray = arrayOf<String>()//price
                                                                var primgArray = arrayOf<String>()

                                                                var disArray = arrayOf<String>()//status

                                                                var icohighArray=arrayOf<String>()
                                                                var icohighnmArray=arrayOf<String>()



                                                                if (e != null) {
                                                                    Log.w("", "Listen failed.", e)
                                                                    return@EventListener
                                                                }

                                                                for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    val ids = document.id;//0
                                                                    idssiv = ids
                                                                    val stockonhand = document.get("$bid").toString();//7
                                                                    val pid = document.get("p_id").toString();//1
                                                                    val pname = document.get("p_nm").toString();//2
                                                                    val bcode = document.get("bc").toString();//3
                                                                    val pdes = document.get("desc").toString();//4
                                                                    val weight = document.get("wg_vol").toString();//5
                                                                    val psac = document.get("hsn").toString();//6
                                                                    val minstock = document.get("min_stk").toString();//8
                                                                    val maxstock = document.get("mx_stk").toString();//9
                                                                    val price = document.get("price").toString();//10
                                                                    val taxable = document.get("taxchk").toString();//11
                                                                    val igst = document.get("igst").toString();//12
                                                                    val cgst = document.get("cgst").toString();//13
                                                                    val sgst = document.get("sgst").toString();//14
                                                                    val cess = document.get("taxchk").toString();//15
                                                                    val taxtotal = document.get("taxtot").toString();//16
                                                                    val cessval = document.get("cesstot").toString();//17
                                                                    val currency = document.get("curency").toString();//18
                                                                    val percentage = document.get("percentage").toString();//19
                                                                    val percentagevalue = document.get("percentageval").toString();//20
                                                                    val product_dec = document.get("product_desc").toString();//21
                                                                    val mrP = document.get("mrp").toString();//22
                                                                    val cate = document.get("ctgy").toString();//23
                                                                    val manufacture = document.get("mfr").toString();//24
                                                                    val ut = document.get("ut").toString();//25
                                                                    val consold = document.get("cn_sold").toString();//26
                                                                    val comm = document.get("emp_com").toString();//27
                                                                    val status = document.get("status").toString();//27

                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37
                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                    idsArray = idsArray.plusElement(ids)
                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    }
                                                                    else{
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    }




                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                    } else {
                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                    }
                                                                    if (bcode.isNotEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                    } else if (bcode.isEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                    }

                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                    priceArraydup=priceArray
                                                                    println(Arrays.toString(disArray))

                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }

                                                                    periyarval = 2
                                                                }

                                                                progress.visibility=View.GONE

                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                slist.adapter = whatever


                                                            })


                                                }
                                            })
                                }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Failed to read value


                }
            }

            myRef!!.addValueEventListener(messageListener)

        } else {

        }
    }


    //GET THIRD


    fun getfour(id: String, bid: String) {

        progress.visibility=View.VISIBLE


        if (bid.isNotEmpty()) {
            lststr = "in"
            var ddstr = id + "_" + bid
            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference(ddstr)
            myRef.root

            val messageListener = object : ValueEventListener {


                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    datach = "changed"

                    if (dataSnapshot.exists()) {


                        val docid = dataSnapshot.key

                        var ff = docid.removeSuffix("-" + bid)

                        println("DOC ID" + docid)
                        println("TRIMMED DOC ID" + ff)
                        ffstr = ff
                        val message = dataSnapshot.value
                        val qnty = message.toString()
                        var tt = qnty
                        qn1 = tt

                        val map = mutableMapOf<String, Any?>()
                        map.put("$bid", qn1)
                        db.collection("product").document(id)
                                .update(map)
                                .addOnSuccessListener {

                                    db.collection("product").document(id)
                                            .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                println("e : "+e)
                                                if (e==null) {
                                                    var doc = task.data

                                                    val ids = task.id;//0
                                                    Log.d(TAG, "cleared")
                                                    db.collection("product")
                                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                                var idsArray = arrayOf<String>()
                                                                var nameArray = arrayOf<String>()

                                                                var sunbnmArray = arrayOf<String>() //mfr

                                                                var bcArray = arrayOf<String>()//bc

                                                                var sohArray = arrayOf<String>()//stock_hand


                                                                var mlArray = arrayOf<String>()//wg_vol

                                                                var mhArray = arrayOf<String>()//mx_stk

                                                                var priceArray = arrayOf<String>()//price
                                                                var primgArray = arrayOf<String>()

                                                                var disArray = arrayOf<String>()//status

                                                                var icohighArray=arrayOf<String>()
                                                                var icohighnmArray=arrayOf<String>()



                                                                if (e != null) {
                                                                    Log.w("", "Listen failed.", e)
                                                                    return@EventListener
                                                                }

                                                                for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    val ids = document.id;//0
                                                                    idssiv = ids
                                                                    val stockonhand = document.get("$bid").toString();//7
                                                                    val pid = document.get("p_id").toString();//1
                                                                    val pname = document.get("p_nm").toString();//2
                                                                    val bcode = document.get("bc").toString();//3
                                                                    val pdes = document.get("desc").toString();//4
                                                                    val weight = document.get("wg_vol").toString();//5
                                                                    val psac = document.get("hsn").toString();//6
                                                                    val minstock = document.get("min_stk").toString();//8
                                                                    val maxstock = document.get("mx_stk").toString();//9
                                                                    val price = document.get("price").toString();//10
                                                                    val taxable = document.get("taxchk").toString();//11
                                                                    val igst = document.get("igst").toString();//12
                                                                    val cgst = document.get("cgst").toString();//13
                                                                    val sgst = document.get("sgst").toString();//14
                                                                    val cess = document.get("taxchk").toString();//15
                                                                    val taxtotal = document.get("taxtot").toString();//16
                                                                    val cessval = document.get("cesstot").toString();//17
                                                                    val currency = document.get("curency").toString();//18
                                                                    val percentage = document.get("percentage").toString();//19
                                                                    val percentagevalue = document.get("percentageval").toString();//20
                                                                    val product_dec = document.get("product_desc").toString();//21
                                                                    val mrP = document.get("mrp").toString();//22
                                                                    val cate = document.get("ctgy").toString();//23
                                                                    val manufacture = document.get("mfr").toString();//24
                                                                    val ut = document.get("ut").toString();//25
                                                                    val consold = document.get("cn_sold").toString();//26
                                                                    val comm = document.get("emp_com").toString();//27
                                                                    val status = document.get("status").toString();//27
                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37
                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                    idsArray = idsArray.plusElement(ids)
                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    }
                                                                    else{
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    }




                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                    } else {
                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                    }
                                                                    if (bcode.isNotEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                    } else if (bcode.isEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                    }

                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)




                                                                    priceArraydup=priceArray
                                                                    println(Arrays.toString(disArray))

                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }

                                                                    sivakasival = 3
                                                                }

                                                                progress.visibility=View.GONE

                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                slist.adapter = whatever



                                                            })


                                                }
                                            })
                                }


                    } else {


                        *//*val docid = dataSnapshot.key
                    keylist.add(docid)
                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()*//*

                        qn1 = "0"

                        val map = mutableMapOf<String, Any?>()
                        map.put("$bid", qn1)
                        db.collection("product").document(id)
                                .update(map)
                                .addOnSuccessListener {

                                    db.collection("product").document(id)
                                             .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                        println("e : "+e)
                                        if (e==null) {
                                            var doc = task.data

                                            val ids = task.id;//0
                                                    Log.d(TAG, "cleared")
                                                    db.collection("product")
                                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                                var idsArray = arrayOf<String>()
                                                                var nameArray = arrayOf<String>()

                                                                var sunbnmArray = arrayOf<String>() //mfr

                                                                var bcArray = arrayOf<String>()//bc

                                                                var sohArray = arrayOf<String>()//stock_hand


                                                                var mlArray = arrayOf<String>()//wg_vol

                                                                var mhArray = arrayOf<String>()//mx_stk

                                                                var priceArray = arrayOf<String>()//price
                                                                var primgArray = arrayOf<String>()

                                                                var disArray = arrayOf<String>()//status

                                                                var icohighArray=arrayOf<String>()
                                                                var icohighnmArray=arrayOf<String>()



                                                                if (e != null) {
                                                                    Log.w("", "Listen failed.", e)
                                                                    return@EventListener
                                                                }

                                                                for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    val ids = document.id;//0
                                                                    idssiv = ids
                                                                    val stockonhand = document.get("$bid").toString();//7
                                                                    val pid = document.get("p_id").toString();//1
                                                                    val pname = document.get("p_nm").toString();//2
                                                                    val bcode = document.get("bc").toString();//3
                                                                    val pdes = document.get("desc").toString();//4
                                                                    val weight = document.get("wg_vol").toString();//5
                                                                    val psac = document.get("hsn").toString();//6
                                                                    val minstock = document.get("min_stk").toString();//8
                                                                    val maxstock = document.get("mx_stk").toString();//9
                                                                    val price = document.get("price").toString();//10
                                                                    val taxable = document.get("taxchk").toString();//11
                                                                    val igst = document.get("igst").toString();//12
                                                                    val cgst = document.get("cgst").toString();//13
                                                                    val sgst = document.get("sgst").toString();//14
                                                                    val cess = document.get("taxchk").toString();//15
                                                                    val taxtotal = document.get("taxtot").toString();//16
                                                                    val cessval = document.get("cesstot").toString();//17
                                                                    val currency = document.get("curency").toString();//18
                                                                    val percentage = document.get("percentage").toString();//19
                                                                    val percentagevalue = document.get("percentageval").toString();//20
                                                                    val product_dec = document.get("product_desc").toString();//21
                                                                    val mrP = document.get("mrp").toString();//22
                                                                    val cate = document.get("ctgy").toString();//23
                                                                    val manufacture = document.get("mfr").toString();//24
                                                                    val ut = document.get("ut").toString();//25
                                                                    val consold = document.get("cn_sold").toString();//26
                                                                    val comm = document.get("emp_com").toString();//27
                                                                    val status = document.get("status").toString();//27
                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37

                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)

                                                                    idsArray = idsArray.plusElement(ids)
                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                        nameArray = nameArray.plusElement(pname)

                                                                    }
                                                                    else{
                                                                        nameArray = nameArray.plusElement(pname)
                                                                    }




                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                    } else {
                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                    }
                                                                    if (bcode.isNotEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                    } else if (bcode.isEmpty()) {
                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                    }
                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)



                                                                    priceArraydup=priceArray
                                                                    println(Arrays.toString(disArray))

                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }

                                                                    sivakasival = 3
                                                                }
                                                                progress.visibility=View.GONE

                                                                val whatever = allbradap(this@AllbranchesActivity, idsArray,
                                                                        nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                                val slist = findViewById<View>(R.id.alllist) as ListView
                                                                slist.adapter = whatever


                                                            })


                                                }
                                            })
                                }
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Failed to read value


                }
            }

            myRef!!.addValueEventListener(messageListener)

        } else {

        }
    }*/


    fun selectbr() {
        progress.visibility=View.GONE
        alllist.visibility=View.VISIBLE
        brspinner.visibility=View.VISIBLE


        if(brspinner.selectedItemPosition==0)
        {

            alllist.visibility=View.INVISIBLE
            progress.visibility=View.GONE
            textView51.visibility=View.VISIBLE
        }

        else{
            editText.setHint("Search")
            db.collection("product")
                    .get()
                    .addOnCompleteListener { task ->

                        if (task.isSuccessful) {

                            if (task.result.isEmpty == false) {
                                for (document in task.result) {

                                    val dd = document.data

                                    val id = document.id;//0

                                    try {
                                        var dd=brspinner.selectedItemPosition
                                        getfirst(id, brnchkeys[dd].toString())//
                                    } catch (e: Exception) {

                                    }

                                }


                            }

                        }
                    }


            //Sivakasi


        } /*else if (brspinner.selectedItemPosition == 1) {

            editText.setHint("Search")
            db.collection("product")
                    .get()
                    .addOnCompleteListener { task ->

                        if (task.isSuccessful) {
                            Log.d(TAG, "cleared")
                            if (task.result.isEmpty == false) {
                                for (document in task.result) {
                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                    val dd = document.data

                                    val id = document.id;//0


                                    try {
                                        getsecond(id, brnchkeys[1].toString())
                                    } catch (e: Exception) {

                                    }

                                }


                            }

                        }
                    }


            //Sivakasi


        } else if (brspinner.selectedItemPosition == 3) {
            editText.setHint("Search")
            db.collection("product")
                    .get()
                    .addOnCompleteListener { task ->

                        if (task.isSuccessful) {
                            Log.d(TAG, "cleared")
                            if (task.result.isEmpty == false) {
                                for (document in task.result) {
                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                    val dd = document.data

                                    val id = document.id;//0


                                    try {
                                        getthird(id, brnchkeys[3].toString())
                                    } catch (e: Exception) {

                                    }


                                }


                            }


                        }


                        //Sivakasi


                    }
        } else if (brspinner.selectedItemPosition == 4) {
            editText.setHint("Search")
            db.collection("product")
                    .get()
                    .addOnCompleteListener { task ->

                        if (task.isSuccessful) {
                            Log.d(TAG, "cleared")
                            if (task.result.isEmpty == false) {
                                for (document in task.result) {
                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                    val dd = document.data

                                    val id = document.id;//0


                                    try {
                                        getfour(id, brnchkeys[4].toString())
                                    } catch (e: Exception) {

                                    }


                                }


                            }


                        }


                        //Sivakasi


                    }
        }*/



    }

    override fun onBackPressed() {
        println("BACK PRESSING")
        bpress="press"
        if(card.visibility==View.VISIBLE){//If seach view is visible close it and finish the activity
            card.visibility=View.GONE
            alltitle.visibility=View.VISIBLE
          selectbr()

        }

        else{


            val a= Intent(this@AllbranchesActivity,stocklevelsActivity::class.java)
            a.putExtra("from_stock","main")
            a.putExtra("viewstklvl",viewstklvls)
            a.putExtra("skey",bridssi)
            startActivity(a)
            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        }
    }
    companion object {


        //if net connection is whether on/off,all views becomes enable/disable.

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {
                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

                    fun net_status():Boolean{//Checks internet status.
                        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                        var connected=false
                        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
                            //we are connected to a network
                            connected = true
                        } else {
                            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
                            connected = false
                        }
                        return connected
                    }


    fun dialog(){

    }

}
