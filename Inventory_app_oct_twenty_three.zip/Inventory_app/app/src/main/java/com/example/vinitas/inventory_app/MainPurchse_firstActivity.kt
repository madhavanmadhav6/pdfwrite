package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.*
import com.example.vinitas.inventory_app.R
import kotlinx.android.synthetic.main.activity_main_purchase_first.*
import kotlin.math.PI
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.formats.NativeContentAdView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.formats.NativeContentAd
import com.google.android.gms.ads.MobileAds




class MainPurchasefirstActivity : AppCompatActivity() {


    private var  ADMOB_AD_UNIT_ID = "ca-app-pub-3940256099942544/2247696110";
    private var ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713";






    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()

    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

            var orikey= String()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_purchase_first)



            net_status()  //Check internet status.
        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainPurchasefirstActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view when inetrnet connection is off.
        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)

        purvert.setOnClickListener({ //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@MainPurchasefirstActivity, purvert)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@MainPurchasefirstActivity, "You are logged out" + item.title, Toast.LENGTH_SHORT).show()

                if(item.title=="Logout"){ //Navigate to pin activity
                    if(net_status()==true) {
                        val f=Intent(this@MainPurchasefirstActivity, PinActivity::class.java)
                        startActivity(f)

                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                        finish()
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }

                }

                true

            }

            popup.show()

        })

        val k=intent.getStringExtra("skey")
        orikey=k
        println("ORIGIN KEY"+orikey)







        //Purchase request

        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr


            println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


        }
        if (expr != null) {
            exportpurreq = expr
        }


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        //Supplier Invoice

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }

       purch_request.setOnClickListener {  //Navigate to purchase request details list

           if (viewpurreq == "true") {
               val go = Intent(this, PurchaseRequestActivity::class.java)
               go.putExtra("viewpurord", viewpurord)
               go.putExtra("addpurord", addpurord)
               go.putExtra("deletepurord", deletepurord)
               go.putExtra("editpurord", editepurord)
               go.putExtra("transferpurord", transferpurord)
               go.putExtra("exportpurord", exportpurord)
               go.putExtra("sendpurord", sendpurpo)


               go.putExtra("viewpurreq", viewpurreq)
               go.putExtra("addpurreq", addpurreq)
               go.putExtra("deletepurreq", deletepurreq)
               go.putExtra("editpurreq", editepurreq)
               go.putExtra("transferpurreq", transferpurreq)
               go.putExtra("exportpurreq", exportpurreq)


               go.putExtra("viewsuppin", viewsuppin)
               go.putExtra("addsuppin", addsuppin)
               go.putExtra("deletesuppin", deletesuppin)
               go.putExtra("editsuppin", editesuppin)
               go.putExtra("transfersuppin", transfersuppin)
               go.putExtra("exportsuppin", exportsuppin)




               go.putExtra("from_ver", "main")
               go.putExtra("brkey", orikey)
               startActivity(go)
               overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
           }
           else if(viewpurreq=="false"){
               popup("View")
           }
       }
        pur_req.setOnClickListener{     //Navigate to purchase request details list
            if (viewpurreq == "true") {
            val gor=Intent(this,PurchaseRequestActivity::class.java)
                gor.putExtra("viewpurord", viewpurord)
                gor.putExtra("addpurord", addpurord)
                gor.putExtra("deletepurord", deletepurord)
                gor.putExtra("editpurord", editepurord)
                gor.putExtra("transferpurord", transferpurord)
                gor.putExtra("exportpurord", exportpurord)
                gor.putExtra("sendpurord", sendpurpo)


                gor.putExtra("viewpurreq", viewpurreq)
                gor.putExtra("addpurreq", addpurreq)
                gor.putExtra("deletepurreq", deletepurreq)
                gor.putExtra("editpurreq", editepurreq)
                gor.putExtra("transferpurreq", transferpurreq)
                gor.putExtra("exportpurreq", exportpurreq)


                gor.putExtra("viewsuppin", viewsuppin)
                gor.putExtra("addsuppin", addsuppin)
                gor.putExtra("deletesuppin", deletesuppin)
                gor.putExtra("editsuppin", editesuppin)
                gor.putExtra("transfersuppin", transfersuppin)
                gor.putExtra("exportsuppin", exportsuppin)




                gor.putExtra("from_ver","main")
            gor.putExtra("brkey",orikey)
            startActivity(gor)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
              }
            else if(viewpurreq=="false"){
                popup("View")
            }
        }



        purch_view.setOnClickListener{    //Navigate to purchase order details list
            if (viewpurord == "true") {
            val go=Intent(this,MainPurchaselist_secondActivity::class.java)
            go.putExtra("viewpurord", viewpurord)
            go.putExtra("addpurord", addpurord)
            go.putExtra("deletepurord", deletepurord)
            go.putExtra("editpurord", editepurord)
            go.putExtra("transferpurord", transferpurord)
            go.putExtra("exportpurord", exportpurord)
                go.putExtra("sendpurord", sendpurpo)


            go.putExtra("viewpurreq", viewpurreq)
            go.putExtra("addpurreq", addpurreq)
            go.putExtra("deletepurreq", deletepurreq)
            go.putExtra("editpurreq", editepurreq)
            go.putExtra("transferpurreq", transferpurreq)
            go.putExtra("exportpurreq", exportpurreq)


            go.putExtra("viewsuppin", viewsuppin)
            go.putExtra("addsuppin", addsuppin)
            go.putExtra("deletesuppin", deletesuppin)
            go.putExtra("editsuppin", editesuppin)
            go.putExtra("transfersuppin", transfersuppin)
            go.putExtra("exportsuppin", exportsuppin)






            go.putExtra("from_ver","main")
            go.putExtra("brkey",orikey)
            startActivity(go)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
              }
            else if(viewpurord=="false"){
                popup("View")
            }

        }
        pur_orders.setOnClickListener{   //Navigate to purchase order details list
            if (viewpurord == "true") {
            val gor=Intent(this,MainPurchaselist_secondActivity::class.java)
            gor.putExtra("viewpurord", viewpurord)
            gor.putExtra("addpurord", addpurord)
            gor.putExtra("deletepurord", deletepurord)
            gor.putExtra("editpurord", editepurord)
            gor.putExtra("transferpurord", transferpurord)
            gor.putExtra("exportpurord", exportpurord)
                gor.putExtra("sendpurord", sendpurpo)


            gor.putExtra("viewpurreq", viewpurreq)
            gor.putExtra("addpurreq", addpurreq)
            gor.putExtra("deletepurreq", deletepurreq)
            gor.putExtra("editpurreq", editepurreq)
            gor.putExtra("transferpurreq", transferpurreq)
            gor.putExtra("exportpurreq", exportpurreq)


            gor.putExtra("viewsuppin", viewsuppin)
            gor.putExtra("addsuppin", addsuppin)
            gor.putExtra("deletesuppin", deletesuppin)
            gor.putExtra("editsuppin", editesuppin)
            gor.putExtra("transfersuppin", transfersuppin)
            gor.putExtra("exportsuppin", exportsuppin)




            gor.putExtra("from_ver","main")
            gor.putExtra("brkey",orikey)
            startActivity(gor)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

             }
            else if(viewpurord=="false"){
                popup("View")
            }
        }
        suppli_view.setOnClickListener{ //Navigate to supplier invoice details list
            if (viewsuppin == "true") {
            val go=Intent(this,Supplier_first_MainActivity::class.java)
            go.putExtra("viewsuppin", viewsuppin)
            go.putExtra("addsuppin", addsuppin)
            go.putExtra("deletesuppin", deletesuppin)
            go.putExtra("editsuppin", editesuppin)
            go.putExtra("transfersuppin", transfersuppin)
            go.putExtra("exportsuppin", exportsuppin)


            go.putExtra("viewpurord", viewpurord)
            go.putExtra("addpurord", addpurord)
            go.putExtra("deletepurord", deletepurord)
            go.putExtra("editpurord", editepurord)
            go.putExtra("transferpurord", transferpurord)
            go.putExtra("exportpurord", exportpurord)
            go.putExtra("sendpurord", sendpurpo)



            go.putExtra("viewpurreq", viewpurreq)
            go.putExtra("addpurreq", addpurreq)
            go.putExtra("deletepurreq", deletepurreq)
            go.putExtra("editpurreq", editepurreq)
            go.putExtra("transferpurreq", transferpurreq)
            go.putExtra("exportpurreq", exportpurreq)
             go.putExtra("from_ver","main")
            go.putExtra("brkey",orikey)
            startActivity(go)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
             }
            else if(viewsuppin=="false"){
                popup("View")
            }
        }
        suppl_invoi.setOnClickListener{ //Navigate to supplier invoice details list
            if (viewsuppin == "true") {
            val gor=Intent(this,Supplier_first_MainActivity::class.java)
            gor.putExtra("viewsuppin", viewsuppin)
            gor.putExtra("addsuppin", addsuppin)
            gor.putExtra("deletesuppin", deletesuppin)
            gor.putExtra("editsuppin", editesuppin)
            gor.putExtra("transfersuppin", transfersuppin)
            gor.putExtra("exportsuppin", exportsuppin)



            gor.putExtra("viewpurord", viewpurord)
            gor.putExtra("addpurord", addpurord)
            gor.putExtra("deletepurord", deletepurord)
            gor.putExtra("editpurord", editepurord)
            gor.putExtra("transferpurord", transferpurord)
            gor.putExtra("exportpurord", exportpurord)
           gor.putExtra("sendpurord", sendpurpo)




            gor.putExtra("viewpurreq", viewpurreq)
            gor.putExtra("addpurreq", addpurreq)
            gor.putExtra("deletepurreq", deletepurreq)
            gor.putExtra("editpurreq", editepurreq)
            gor.putExtra("transferpurreq", transferpurreq)
            gor.putExtra("exportpurreq", exportpurreq)





            gor.putExtra("from_ver","main")
            gor.putExtra("brkey",orikey)
            startActivity(gor)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
             }

            else if(viewsuppin=="false"){
                    popup("View")
                }

        }
        userback.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onBackPressed() {   //Back action
        val v=Intent(this@MainPurchasefirstActivity,MainActivity::class.java)




        v.putExtra("bid",orikey)

        startActivity(v)
        finish()
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)


            }
    fun popup(st:String){   //Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
    fun net_status():Boolean{   // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    companion object {

        //Listens inetrnet status whether net is on/off. .

        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable

                constraintLayout3dis!!.visibility= View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

            /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }

}
