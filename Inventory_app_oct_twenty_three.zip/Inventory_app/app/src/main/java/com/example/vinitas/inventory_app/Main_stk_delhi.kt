package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.EventListener
import com.google.firebase.database.MutableData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.firestore.QuerySnapshot
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter
import kotlinx.android.synthetic.main.scroll_stk_delhi.*


import java.io.*

import java.text.SimpleDateFormat
import java.util.*


class Main_stk_delhi : AppCompatActivity() {
    var opri = arrayListOf<String>()
    var dirpath: String? = null
    var other_origiky= String()
    var brids= String()
    var pdfFile= String()
    var TAG="some"
    var descriplistener= String()
    var listListener= String()
    var deletelistener=String()
    var db=FirebaseFirestore.getInstance()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""


    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    private var view=String()
    private var add=String()
    private var delete=String()
    private var edits=String()
    private var import=String()
    private var export=String()

    private var viewpro=String()
    private var addpro=String()
    private var deletepro=String()
    private var editpro=String()
    private var importpro=String()
    private var exportpro=String()
    private var stockin_hand= String()

    private var viewsupp=String()
    private var addsupp=String()
    private var deletesupp=String()
    private var editsupp=String()
    private var importsupp=String()
    private var exportsupp=String()

    private  var viewstklvls=String()

    data class s(

            var otherstkid: String,
            var otherstkdate: Any,
            var otherstk_Desc: Any,
            var otherstk_destination:Any,
            var otherstk_total:Any,
            var otherstk_address:Any,
            var otherstk_brid:Any,
            var otherstk_origin:Any
    )
    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_img: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,

            var otherstk_tally: Any,
            var otherstk_received: Any,
            var stk_key:Any
    )


    var idstk = String()
    var datestk = String()
    var names = String()
    var addressnames= String()
    var  descstk = String()
    var  cgstt = String()
    var  sgstt = String()
    var  cesst = String()
    var  grosstt= String()
    var downstatus= String()
    var grosscheck=String()

    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var  igstArray = arrayListOf<String>()
    var  igsttotArray = arrayListOf<String>()
    var  cesstotalArray = arrayListOf<String>()
    var  tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var keyofbrnch = String()

    var getiddel = ArrayList<String>()
    var ids = arrayOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll_stk_delhi)


        net_status()

        var othernameofbrnch = String()
        var otherlocofbrnch = String()
        var otherdatestk = String()
        var othersmlistids = String()
        var otherdescstk = String()
        var otherstkidstock = String()
        var otherididdb = String()


        var i = arrayListOf<String>()

        var checkcount = arrayListOf<Int>()

        var idsforup = ArrayList<Any>()
        var idsup = arrayOf<String>()

        //ARRAYS FOR TAX VALUES
        var igstedt = arrayListOf<String>()
        var igstedttot = arrayListOf<String>()
        var cestotal = arrayListOf<String>()
        var alltotal = arrayListOf<String>()






        edit.setOnClickListener {

            if (editetransano == "true") {

                othsave.visibility = View.VISIBLE
                edit.visibility = View.GONE

                otstatedescrip.isEnabled = true
                otstatestdate.isEnabled = true

                igst_vi.isEnabled = true


                fab.isEnabled = true
            } else if (editetransano == "false") {
                popup("Edit")
            }

        }


        val bundle = intent.extras
        var frm = bundle!!.get("fromstate").toString()

        otherdatestk = otstatestdate.text.toString()


        if (frm == "oth_state_branch") {
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MM/yyyy")
            val formattedDate = df.format(c.time)

            otstatestdate.setText(formattedDate)


            val a = intent.getStringExtra("otherbrchnm")
            comttname.setText(a)
            othernameofbrnch = comttname.text.toString()
            println(othernameofbrnch)
            val ab = intent.getStringExtra("otherbrchloc")
            comphone.setText(ab)
            val abc = intent.getStringExtra("originky")
            other_origiky = abc
            val brid = intent.getStringExtra("brnchky")
            other_brnchid.setText(brid)
            brids = other_brnchid.text.toString()


            otherlocofbrnch = comphone.text.toString()
            println(otherlocofbrnch)
            keyofbrnch = other_brnchid.text.toString()


            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

        } else if (frm == "sotherlist") {

            val aw = bundle!!.get("sotherthspname") as ArrayList<String>
            val bw = bundle!!.get("sotherpitem") as ArrayList<String>
            val cw = bundle!!.get("sotherphsn") as ArrayList<String>
            val dw = bundle!!.get("sotherporder") as ArrayList<String>
            /*val ew=bundle!!.get("pcomplete") as Array<SListtring>*/
            val fw = bundle!!.get("sotherpprice") as ArrayList<String>
            val hw = bundle!!.get("sotherptot") as ArrayList<String>
            val gw = bundle!!.get("sotherpoarray") as ArrayList<String>
            val lw = bundle!!.get("sothercessarray") as ArrayList<String>
            val mw = bundle!!.get("sotherigstarray") as ArrayList<String>
            val nw = bundle!!.get("sotherigsttotarray") as ArrayList<String>
            val ow = bundle!!.get("sothercesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("tallyarray") as ArrayList<String>
            val rew = bundle!!.get("receivedarray") as ArrayList<String>

            val piddli = bundle!!.get("sotherreiddofli") as ArrayList<String>
            val nms = intent.getStringExtra("sotherbranch")
            val nmsaddrss = intent.getStringExtra("sotheraddress")
            val keybranch = intent.getStringExtra("brkey")
            val imm = bundle!!.get("sotherimi") as ArrayList<String>

            val pdate = intent.getStringExtra("sotherredate")
            val pstkid = intent.getStringExtra("sotherrestkid")
            val pdesc = intent.getStringExtra("sotherredesc")
            val piddb = intent.getStringExtra("sotherreiddb")
            val brnchsid = intent.getStringExtra("brnchid")
            val origid = intent.getStringExtra("origiid")
            val groschk = intent.getStringExtra("groschk")

            grosscheck = groschk

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }




            other_origiky = origid
            brids = brnchsid

            othernameofbrnch = nms
            println("ORIGIN IDDDD" + other_origiky)
            println("BRANCH IDDDD" + other_brnchid.text)
            println(othernameofbrnch)
            otherlocofbrnch = nmsaddrss



            otstatestdate.setText(pdate)
            otstatedescrip.setText(pdesc)
            otstatestno.setText(pstkid)
            listoids.setText(piddb)
            other_brnchid.setText(keybranch)
            comttname.setText(nms)
            comphone.setText(nmsaddrss)
            otherdatestk = otstatestdate.text.toString()

            othernameofbrnch = comttname.text.toString()
            otherlocofbrnch = comphone.text.toString()
            otherididdb = listoids.text.toString()
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MM/yyyy")
            val formattedDate = df.format(c.time)

            otstatestdate.setText(formattedDate)




            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            cessArray = lw
            keyArray = piddli
            igstArray = mw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            imageArray = imm


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            del_st__list.adapter = whatever
            Helper.getListViewSize(del_st__list);
            var total = 0.0F
            var igsttot = 0.0F

            var cesstotals = 0.0F
            var b = 2
            for (i in 0 until priceArray.count()) {
                var c = (priceArray[i])
                var cy = (igsttotArray[i])

                var cyz = (cesstotalArray[i])
                var qyz = (quantityArray[i])

                var cdec = c.toBigDecimal()
                var qyzdec = qyz.toBigDecimal()
                var totquanpri = (cdec * qyzdec)




                total = total.plus(totquanpri.toInt())

                igsttot = igsttot.plus(cy.toFloat())
                cesstotals = cesstotals.plus(cyz.toFloat())

                igst_tot.text = igsttot.toString()
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / b.toBigDecimal()


                cess_tot.text = cesstotals.toString()

                var f = cesstotals
                var g = igsttot

                var op = total
                var m = f.toFloat()
                var n = g.toFloat()

                var yy = m + n + op

                try {
                    otstate_gross_tot.setText(yy.toString())
                } catch (e: Exception) {
                    otstate_gross_tot.text = yy.toString()
                }

                if (grosscheck != otstate_gross_tot.text.toString()) {
                    listListener = "listadded"
                }
            }



            Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)






            ///LOCAL DELETE



        }

        else if(frm=="sotherlist_single"){

        val aw = bundle!!.get("sotherthspname") as ArrayList<String>
        val bw = bundle!!.get("sotherpitem") as ArrayList<String>
        val cw = bundle!!.get("sotherphsn") as ArrayList<String>
        val dw = bundle!!.get("sotherporder") as ArrayList<String>
        /*val ew=bundle!!.get("pcomplete") as Array<SListtring>*/
        val fw = bundle!!.get("sotherpprice") as ArrayList<String>
        val hw = bundle!!.get("sotherptot") as ArrayList<String>
        val gw = bundle!!.get("sotherpoarray") as ArrayList<String>
        val lw = bundle!!.get("sothercessarray") as ArrayList<String>
        val mw = bundle!!.get("sotherigstarray") as ArrayList<String>
        val nw = bundle!!.get("sotherigsttotarray") as ArrayList<String>
        val ow = bundle!!.get("sothercesstotalarray") as ArrayList<String>
        val pw = bundle!!.get("tallyarray") as ArrayList<String>
        val rew = bundle!!.get("receivedarray") as ArrayList<String>

        val piddli = bundle!!.get("sotherreiddofli") as ArrayList<String>
        val nms = intent.getStringExtra("sotherListbranch")
        val nmsaddrss = intent.getStringExtra("sotheraListddress")
        val keybranch = intent.getStringExtra("brkey")
        val imm = bundle!!.get("sotherimi") as ArrayList<String>

        val pdate = intent.getStringExtra("sotherredate")
        val pstkid = intent.getStringExtra("sotherrestkid")
        val pdesc = intent.getStringExtra("sotherredesc")
        val piddb = intent.getStringExtra("sotherreiddb")
        val brnchsid = intent.getStringExtra("brnchid")
        val origid = intent.getStringExtra("origiid")
        val groschk = intent.getStringExtra("groschk")

        grosscheck = groschk

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }



            other_origiky = origid
        brids = brnchsid

        othernameofbrnch = nms
        println("ORIGIN IDDDD" + other_origiky)
        println("BRANCH IDDDD" + other_brnchid.text)
        println(othernameofbrnch)
        otherlocofbrnch = nmsaddrss



        otstatestdate.setText(pdate)
        otstatedescrip.setText(pdesc)
        otstatestno.setText(pstkid)
        listoids.setText(piddb)
        other_brnchid.setText(keybranch)
        comttname.setText(nms)
        comphone.setText(nmsaddrss)
        otherdatestk = otstatestdate.text.toString()

        othernameofbrnch = comttname.text.toString()
        otherlocofbrnch = comphone.text.toString()
        otherididdb = listoids.text.toString()
        val c = Calendar.getInstance()
        System.out.println("Current time =&gt; " + c.time)

        val df = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = df.format(c.time)

        otstatestdate.setText(formattedDate)




        pronameArray = aw
        manufacturerArray = bw
        quantityArray = dw
        priceArray = fw
        hsnArray = cw
        barcodeArray = gw
        totArray = hw
        cessArray = lw
        keyArray = piddli
        igstArray = mw
        igsttotArray = nw
        cesstotalArray = ow
        tallyArray = pw
        receivedArray = rew
        imageArray = imm


        val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
        del_st__list.adapter = whatever
        Helper.getListViewSize(del_st__list);
        var total = 0.0F
        var igsttot = 0.0F

        var cesstotals = 0.0F
        var b = 2
        for (i in 0 until priceArray.count()) {
            var c = (priceArray[i])
            var cy = (igsttotArray[i])

            var cyz = (cesstotalArray[i])
            var qyz = (quantityArray[i])

            var cdec = c.toBigDecimal()
            var qyzdec = qyz.toBigDecimal()
            var totquanpri = (cdec * qyzdec)




            total = total.plus(totquanpri.toInt())

            igsttot = igsttot.plus(cy.toFloat())
            cesstotals = cesstotals.plus(cyz.toFloat())

            igst_tot.text = igsttot.toString()
            var l = igst_tot.text.toString()
            var ss = l.toBigDecimal()
            var tt = ss / b.toBigDecimal()


            cess_tot.text = cesstotals.toString()

            var f = cesstotals
            var g = igsttot

            var op = total
            var m = f.toFloat()
            var n = g.toFloat()

            var yy = m + n + op

            try {
                otstate_gross_tot.setText(yy.toString())
            } catch (e: Exception) {
                otstate_gross_tot.text = yy.toString()
            }

            if (grosscheck != otstate_gross_tot.text.toString()) {
                listListener = "listadded"
            }
        }



        Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)






        ///LOCAL DELETE

    }
        else if (frm == "updateother") {


            othsave.visibility=View.INVISIBLE
            edit.visibility=View.VISIBLE

            fab.isEnabled=false
            otstatedescrip.isEnabled=false
            otstatestdate.isEnabled=false
            igst_vi.isEnabled=false

            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MMM/yyyy")
            val formattedDate = df.format(c.time)

            otstatestdate.setText(formattedDate)
            val av = bundle!!.get("otheruprenm") as ArrayList<String>
            val bv = bundle!!.get("otheruprehsn") as ArrayList<String>
            val mv = bundle!!.get("otherupremanu") as ArrayList<String>
               val dv=bundle!!.get("reprice") as ArrayList<String>
            val ev = bundle!!.get("otheruprequan") as ArrayList<String>
            val fv = bundle!!.get("otheruprebc") as ArrayList<String>
            val hv = bundle!!.get("otherupretotal") as ArrayList<String>
            val gv = bundle!!.get("otheruprecess") as ArrayList<String>
            val iv = bundle!!.get("otherreigst") as ArrayList<String>
            val jv = bundle!!.get("otherreigst_total") as ArrayList<String>
            val kv = bundle!!.get("otherrecesstotal") as ArrayList<String>
            val rekey = bundle!!.get("otheruprekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val n =  intent.getStringExtra("otherupbranch")
            val pp = intent.getStringExtra("otherupaddress")
            val pdate = intent.getStringExtra("otherupredate")
            val pstkid = intent.getStringExtra("otheruprestkid")
            val pdesc = intent.getStringExtra("otherupredesc")
            val piddb = intent.getStringExtra("otherupreiddb")
            val piddli =intent.getStringExtra("otherupreiddofli")
            var smli=intent.getStringExtra("otherupsmlistidss")
            val br = intent.getStringExtra("brnchky")
            var originkeyup=intent.getStringExtra("oribrnky")
            var grss=intent.getStringExtra("groschk")
            other_origiky=originkeyup
            brids=br
            grosscheck=grss

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            /* igstedt.add(igedit)
             igstedttot.add(igtt.toString())
             cestotal.add(cesstotal)
             alltotal.add(overtot)*/

            println("TAX DETAILS SUCCESSSSS"+igstedt)
            println("TAX DETAILS SUCCESSSSS for IGST TOTAl"+igstedttot)


            println("UPDATE IDDDDDD"+Arrays.toString(ids))
            liids.setText(piddli)

            val immv = bundle!!.get("otherupreimmg") as ArrayList<String>
            comttname.setText(n)
            comphone.setText(pp)
            otstatestdate.setText(pdate)
            otstatedescrip.setText(pdesc)
            otstatestno.setText(pstkid)
            listoids.setText(piddb)
            other_brnchid.setText(br)
            otherdescstk=otstatedescrip.text.toString()
            otherdatestk=otstatestdate.text.toString()
            otherstkidstock=otstatestno.text.toString()
            otherididdb=listoids.text.toString()



            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = dv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            cessArray = gv
            keyArray=rekey
            igstArray=iv
            igsttotArray=jv
            cesstotalArray=kv
            tallyArray=ktally
            receivedArray=rereceive
            imageArray = immv


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray,igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,imageArray)
            del_st__list.adapter = whatever
            Helper.getListViewSize(del_st__list);
            var total = 0.0F
            var igsttot = 0.0F

            var cesstotals = 0.0F
            var b = 2
            for (i in 0 until priceArray.count()) {
                var c = (priceArray[i])
                var cy = (igsttotArray[i])

                var cyz = (cesstotalArray[i])
                var qyz = (quantityArray[i])

                var cdec = c.toBigDecimal()
                var qyzdec = qyz.toBigDecimal()
                var totquanpri = (cdec * qyzdec)




                total = total.plus(totquanpri.toInt())

                igsttot = igsttot.plus(cy.toFloat())
                cesstotals = cesstotals.plus(cyz.toFloat())

                igst_tot.text = igsttot.toString()
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / b.toBigDecimal()


                cess_tot.text = cesstotals.toString()

                var f = cesstotals
                var g = igsttot

                var op = total
                var m = f.toFloat()
                var n = g.toFloat()

                var yy = m + n + op

                try {
                    otstate_gross_tot.setText(yy.toString())
                } catch (e: Exception) {
                    otstate_gross_tot.text = yy.toString()
                }

            }
            if(grosscheck==""){

            }
            else if((grosscheck!= otstate_gross_tot.text.toString())&&(grosscheck!="")){
                listListener="listadded"
            }


        }


        else if (frm == "frmotherpdf") {
            othsave.visibility=View.INVISIBLE
            edit.visibility=View.VISIBLE

            fab.isEnabled=false
            otstatedescrip.isEnabled=false
            otstatestdate.isEnabled=false
            igst_vi.isEnabled=false
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MMM/yyyy")
            val formattedDate = df.format(c.time)

            otstatestdate.setText(formattedDate)
            val av = bundle!!.get("otheruprenm") as ArrayList<String>
            val bv = bundle!!.get("otheruprehsn") as ArrayList<String>
            val mv = bundle!!.get("otherupremanu") as ArrayList<String>
            /*   val dv=bundle!!.get("reprice") as Array<SListtring>*/
            val ev = bundle!!.get("otheruprequan") as ArrayList<String>
            val fv = bundle!!.get("otheruprebc") as ArrayList<String>
            val hv = bundle!!.get("otherupretotal") as ArrayList<String>
            val gv = bundle!!.get("otheruprecess") as ArrayList<String>
            val iv = bundle!!.get("otherreigst") as ArrayList<String>
            val jv = bundle!!.get("otherreigst_total") as ArrayList<String>
            val kv = bundle!!.get("otherrecesstotal") as ArrayList<String>
            val rekey = bundle!!.get("otheruprekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val n =  intent.getStringExtra("otherupbranch")
            val pp = intent.getStringExtra("otherupaddress")
            val pdate = intent.getStringExtra("otherupredate")
            val pstkid = intent.getStringExtra("otheruprestkid")
            val pdesc = intent.getStringExtra("otherupredesc")
            val piddb = intent.getStringExtra("otherupreiddb")
            val piddli =intent.getStringExtra("otherupreiddofli")
            var smli=intent.getStringExtra("otherupsmlistidss")
            val br = intent.getStringExtra("brnchky")
            var originkeyup=intent.getStringExtra("oribrnky")
            other_origiky=originkeyup
            brids=br

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            /* igstedt.add(igedit)
             igstedttot.add(igtt.toString())
             cestotal.add(cesstotal)
             alltotal.add(overtot)*/

            println("TAX DETAILS SUCCESSSSS"+igstedt)
            println("TAX DETAILS SUCCESSSSS for IGST TOTAl"+igstedttot)


            println("UPDATE IDDDDDD"+Arrays.toString(ids))
            liids.setText(piddli)

            val immv = bundle!!.get("otherupreimmg") as ArrayList<String>
            comttname.setText(n)
            comphone.setText(pp)
            otstatestdate.setText(pdate)
            otstatedescrip.setText(pdesc)
            otstatestno.setText(pstkid)
            listoids.setText(piddb)
            other_brnchid.setText(br)
            otherdescstk=otstatedescrip.text.toString()
            otherdatestk=otstatestdate.text.toString()
            otherstkidstock=otstatestno.text.toString()
            otherididdb=listoids.text.toString()



            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = hv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            cessArray = gv
            keyArray=rekey
            igstArray=iv
            igsttotArray=jv
            cesstotalArray=kv
            tallyArray=ktally
            receivedArray=rereceive
            imageArray = immv


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray,igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,imageArray)
            del_st__list.adapter = whatever
            Helper.getListViewSize(del_st__list);

            var total = 0.0F
            var igsttot = 0.0F

            var cesstotals = 0.0F
            var b = 2
            for (i in 0 until priceArray.count()) {
                var c = (priceArray[i])
                var cy = (igsttotArray[i])

                var cyz = (cesstotalArray[i])
                var qyz = (quantityArray[i])

                var cdec = c.toBigDecimal()
                var qyzdec = qyz.toBigDecimal()
                var totquanpri = (cdec * qyzdec)




                total = total.plus(totquanpri.toInt())

                igsttot = igsttot.plus(cy.toFloat())
                cesstotals = cesstotals.plus(cyz.toFloat())

                igst_tot.text = igsttot.toString()
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / b.toBigDecimal()


                cess_tot.text = cesstotals.toString()

                var f = cesstotals
                var g = igsttot

                var op = total
                var m = f.toFloat()
                var n = g.toFloat()

                var yy = m + n + op

                try {
                    otstate_gross_tot.setText(yy.toString())
                } catch (e: Exception) {
                    otstate_gross_tot.text = yy.toString()
                }

            }
        }

        else if(frm == "startlist_otherst")

        {

            othsave.visibility=View.INVISIBLE
            edit.visibility=View.VISIBLE

            fab.isEnabled=false
            otstatedescrip.isEnabled=false
            otstatestdate.isEnabled=false
            igst_vi.isEnabled=false

            val name = intent.getStringExtra("otherst_brnm")
            val address = intent.getStringExtra("otherst_braddress")

            val date = intent.getStringExtra("otherst_date")
            val description = intent.getStringExtra("otherst_description")
            val Stockids = intent.getStringExtra("otherst_Stockids")
            val listids = intent.getStringExtra("otherst_listids")
            val soriky = intent.getStringExtra("other_origiid")
            val bridky = intent.getStringExtra("other_brids")


            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            other_origiky=soriky
            comttname.setText(name)
            comphone.setText(address)
            othernameofbrnch=comttname.text.toString()
            otherlocofbrnch=comphone.text.toString()
            otstatestdate.setText(date)
            otstatedescrip.setText(description)
            otstatestno.setText(Stockids)
            listoids.setText(listids)
            other_brnchid.setText(bridky)
            otherdatestk=otstatestdate.text.toString()
            println("DATE DUDEEEE"+otherdatestk)
            otherdescstk=otstatedescrip.text.toString()
            otherstkidstock=otstatestno.text.toString()
            otherididdb=listoids.text.toString()
            keyofbrnch=other_brnchid.text.toString()

            var lista = arrayListOf<String>()
            var d = arrayListOf<String>()
            var dp = arrayListOf<String>()
            var upret = arrayListOf<String>()
            var dpu = arrayListOf<String>()
            var dlt = arrayOf<String>()


            val dl = intent.getStringArrayListExtra("dlt")


            val t = intent.getStringExtra("reid")
            Log.d("gfdgdhd", "RE_   ID OUTTTTT" + t)


            //Save

            db.collection("ST_Another_State/${listoids.text}/Stock_products")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        for (document in value) {

                            Log.d("d", "key --- " + document.id + " => " + document.data)
                            println(document.data)

                            var dt = document.data
                            var id = (document.id)
                            id = id
                            ids = ids.plusElement(id)
                            /*idsforup=ids*/
                            println("Heyyyyyyy" + Arrays.toString(ids))
                            println("HELLOOOOOOOOO" + id)
                            pronameArray .add(dt["stk_name"].toString())

                            manufacturerArray .add(dt["stk_mfr"].toString())
                            hsnArray .add(dt["otherstk_hsn"].toString())

                            quantityArray .add(dt["stk_received"].toString())

                            priceArray .add(dt["stk_price"].toString())
                            totArray .add(dt["stk_total"].toString())
                            barcodeArray .add(dt["stk_barcode"].toString())
                            cessArray .add("0")
                            igstArray.add(dt["otherstk_igst"].toString())
                            igsttotArray.add(dt["otherstk_igsttotal"].toString())
                            cesstotalArray.add(dt["otherstk_cesstotal"].toString())
                            tallyArray.add(dt["otherstk_tally"].toString())
                           receivedArray.add(dt["otherstk_received"].toString())
                            keyArray.add(id)
                            try {
                                var im=(dt["otherstk_img"].toString())
                                if (im.isNotEmpty()) {

                                    imageArray.add(im)
                                } else {
                                    imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                }
                            }
                            catch(e:Exception){

                            }

                        }
                        val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, totArray, totArray, cessArray, keyArray, igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,imageArray)
                        del_st__list.adapter = whatever
                        Helper.getListViewSize(del_st__list);
                        save_progress.visibility = View.GONE
                        var total = 0.0F
                        var igsttot = 0.0F

                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until priceArray.count()) {
                            var c = (priceArray[i])
                            var cy = (igsttotArray[i])

                            var cyz = (cesstotalArray[i])
                            var qyz = (quantityArray[i])

                            var cdec = c.toBigDecimal()
                            var qyzdec = qyz.toBigDecimal()
                            var totquanpri = (cdec * qyzdec)




                            total = total.plus(totquanpri.toInt())

                            igsttot = igsttot.plus(cy.toFloat())
                            cesstotals = cesstotals.plus(cyz.toFloat())

                            igst_tot.text = igsttot.toString()
                            var l = igst_tot.text.toString()
                            var ss = l.toBigDecimal()
                            var tt = ss / b.toBigDecimal()


                            cess_tot.text = cesstotals.toString()

                            var f = cesstotals
                            var g = igsttot

                            var op = total
                            var m = f.toFloat()
                            var n = g.toFloat()

                            var yy = m + n + op

                            try {
                                otstate_gross_tot.setText(yy.toString())
                                grosscheck=otstate_gross_tot.text.toString()
                            } catch (e: Exception) {
                                otstate_gross_tot.text = yy.toString()
                                grosscheck=otstate_gross_tot.text.toString()
                            }

                        }
                        if(grosscheck!=otstate_gross_tot.text.toString()){
                            listListener="listadded"
                        }

                    })




        }
        otstatedescrip.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                descriplistener="descchanged"


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })
        othsave.setOnClickListener { views ->
            if((listoids.text=="")&&(transfertransano=="true")) {
                val pDialog= SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Saving...")
                pDialog.setCancelable(false)
                pDialog.show()
                onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray,igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray,imageArray)

            }


            else if((listoids.text=="")&&(transfertransano=="true")){

                var stkid = (otstatestno.text).toString()
                var stkdate = (otstatestdate.text).toString()
                var stkdesc = (otstatedescrip.text).toString()
                var destination=(comttname.text).toString()
                var address=(comphone.text).toString()
                var stktotals=(otstate_gross_tot.text).toString()
                var brid=(other_brnchid.text).toString()
                var originid=other_origiky

                val data = s(otherstkid = stkid, otherstkdate = stkdate, otherstk_Desc = stkdesc,otherstk_destination = destination,otherstk_address =address,otherstk_total = stktotals,otherstk_brid = brid,otherstk_origin = originid)
                var db = FirebaseFirestore.getInstance()
                println(Arrays.toString(ids))
                db.collection("ST_Another_State").document(listoids.text.toString())
                        .set(data)
                        .addOnSuccessListener {
                            db.collection("Receive Stock").document(listoids.text.toString())
                                    .set(data)


                            var refid=listoids.text.toString()
                            println("WHAT A IDSSSSSSSS"+listoids.text.toString())
                            var path="ST_Another_State/$refid/Stock_products"
                            var receive_path="Receive Stock/$refid/Received stock items"
                            for(i in 0 until priceArray.size) {
                                var stk_name = pronameArray[i]
                                var stk_mfr = manufacturerArray[i]
                                var stk_hsn = hsnArray[i]
                                var stk_bcode = barcodeArray[i]
                                var stk_quan = quantityArray[i]
                                var stk_pri = priceArray[i]
                                var stk_tot = totArray[i]
                                var stk_cess = cessArray[i]
                                var stk_igst = igstArray[i]
                                var stk_igsttot = igsttotArray[i]
                                var stk_cesstot = cesstotalArray[i]
                                var stk_received = receivedArray[i]
                                var stk_tally = tallyArray[i]
                                var img_arr=imageArray[i]
                                var stk_key = keyArray[i]


                                var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess,otherstk_igst=stk_igst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot, stk_key = stk_key,otherstk_tally = stk_tally,otherstk_received = stk_received,otherstk_img = img_arr)
                                if (keyArray[i].equals("")) {
                                    db.collection(path)
                                            .add(d)
                                            .addOnSuccessListener { documentReference ->

                                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                var refid = documentReference.id
                                                db.collection(receive_path).document(refid)
                                                        .set(d)
                                            }
                                }

                                else if(getiddel.isNotEmpty()){
                                    val deleteSize =  getiddel.size
                                    val i = 0
                                    for (i in getiddel) {
                                        db.collection(path).document(i.toString())
                                                .delete()
                                                .addOnSuccessListener {
                                                    getiddel.clear()



                                                }
                                    }
                                }
                                else  {
                                    db.collection(path).document(keyArray[i])
                                            .set(d)
                                            .addOnCompleteListener {
                                                db.collection(receive_path).document(keyArray[i])
                                                        .set(d)

                                                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()
                                                val pDialog= SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                                pDialog.dismiss()
                                                val i=Intent(this@Main_stk_delhi,Anotherstate::class.java)
                                                i.putExtra("frmo_br","brsave")
                                                i.putExtra("viewsuppin", viewsuppin)
                                                i.putExtra("addsuppin", addsuppin)
                                                i.putExtra("deletesuppin", deletesuppin)
                                                i.putExtra("editsuppin", editesuppin)
                                                i.putExtra("transfersuppin", transfersuppin)
                                                i.putExtra("exportsuppin", exportsuppin)


                                                i.putExtra("viewpurord", viewpurord)
                                                i.putExtra("addpurord", addpurord)
                                                i.putExtra("deletepurord", deletepurord)
                                                i.putExtra("editpurord", editepurord)
                                                i.putExtra("transferpurord", transferpurord)
                                                i.putExtra("exportpurord", exportpurord)
                                                i.putExtra("sendpurord", sendpurpo)




                                                i.putExtra("viewpurreq", viewpurreq)
                                                i.putExtra("addpurreq", addpurreq)
                                                i.putExtra("deletepurreq", deletepurreq)
                                                i.putExtra("editpurreq", editepurreq)
                                                i.putExtra("transferpurreq", transferpurreq)
                                                i.putExtra("exportpurreq", exportpurreq)


                                                i.putExtra("viewpro", viewpro)
                                                i.putExtra("addpro", addpro)
                                                i.putExtra("editpro", editpro)
                                                i.putExtra("deletepro", deletepro)
                                                i.putExtra("importpro", importpro)
                                                i.putExtra("exportpro", exportpro)
                                                i.putExtra("changestock", stockin_hand)


                                                i.putExtra("view", view)
                                                i.putExtra("add", add)
                                                i.putExtra("edit", edits)
                                                i.putExtra("delete", delete)
                                                i.putExtra("import", import)
                                                i.putExtra("export", export)


                                                i.putExtra("viewsupp", viewsupp)
                                                i.putExtra("addsupp", addsupp)
                                                i.putExtra("editsupp", editsupp)
                                                i.putExtra("deletesupp", deletesupp)
                                                i.putExtra("importsupp", importsupp)
                                                i.putExtra("exportsupp", exportsupp)



                                                i.putExtra("viewtrans", viewtrans)
                                                i.putExtra("addtrans", addtrans)
                                                i.putExtra("edittrans", editetrans)
                                                i.putExtra("deletetrans", deletetrans)
                                                i.putExtra("transfertrans", transfertrans)
                                                i.putExtra("exporttrans", exporttrans)
                                                i.putExtra("sendtrans", sendtrans)


                                                i.putExtra("viewtransano", viewtransano)
                                                i.putExtra("addtransano", addtransano)
                                                i.putExtra("edittransano", editetransano)
                                                i.putExtra("deletetransano", deletetransano)
                                                i.putExtra("transfertransano", transfertransano)
                                                i.putExtra("exporttransano", exporttransano)
                                                i.putExtra("sendtransano", sendtransano)

                                                i.putExtra("viewrec", viewrec)
                                                i.putExtra("addrec", addrec)
                                                i.putExtra("deleterec", deleterec)
                                                i.putExtra("editrec", editrec)
                                                i.putExtra("transferrec", transferrec)
                                                i.putExtra("exportrec", exportrec)
                                                i.putExtra("sendstrec",sendstrec)


                                                i.putExtra("viewstklvl",viewstklvls)
                                                i.putExtra("brky",keyofbrnch)
                                                i.putExtra("orky",other_origiky)
                                                startActivity(i)
                                                finish()
                                            }
                            }
                            }

                        }

            }
            else if(transfertransano=="false"){
                popup("Transfer")
            }



        }

        del_st__list.setOnItemClickListener { parent, views, position, id ->

            val b = Intent(applicationContext, Main_trans_delhi::class.java)

            b.putExtra("fromstate", "otherstate_updatelist")
            b.putExtra("otherst_pnm", pronameArray)
            b.putExtra("otherst_pmanu", manufacturerArray)
            b.putExtra("otherst_phsn", hsnArray)
            b.putExtra("otherst_barcode", barcodeArray)
            b.putExtra("otherst_price", priceArray)

            b.putExtra("otherst_quan", quantityArray)
            b.putExtra("otherst_tot", totArray)
            b.putExtra("otherst_cessup", cessArray)
            b.putExtra("otherst_igst", igstArray)
            b.putExtra("otherst_igsttotal", igsttotArray)
            b.putExtra("otherst_cesstotarray", cesstotalArray)
            b.putExtra("tallyarray", tallyArray)
            b.putExtra("receivedarray", receivedArray)
            b.putExtra("otherst_image", imageArray)
            b.putExtra("otherst_branch", comttname.text.toString())
            b.putExtra("otherst_address", comphone.text.toString())
            b.putExtra("otherst_sstkdate",otherdatestk)
            b.putExtra("otherst_ssstockid",otherstkidstock)
            b.putExtra("otherst_ssstkdesc",otherdescstk)
            b.putExtra("otherst_idofdb",otherididdb)
            b.putExtra("otherst_idsofli",keyArray)
            b.putExtra("groschk",grosscheck)
            b.putExtra("otherst_smlistids",othersmlistids)
            b.putExtra("keybrnch",keyofbrnch)
            b.putExtra("originkeys",other_origiky)
            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)


            b.putExtra("viewpro", viewpro)
            b.putExtra("addpro", addpro)
            b.putExtra("editpro", editpro)
            b.putExtra("deletepro", deletepro)
            b.putExtra("importpro", importpro)
            b.putExtra("exportpro", exportpro)
            b.putExtra("changestock", stockin_hand)


            b.putExtra("view", view)
            b.putExtra("add", add)
            b.putExtra("edit", edits)
            b.putExtra("delete", delete)
            b.putExtra("import", import)
            b.putExtra("export", export)


            b.putExtra("viewsupp", viewsupp)
            b.putExtra("addsupp", addsupp)
            b.putExtra("editsupp", editsupp)
            b.putExtra("deletesupp", deletesupp)
            b.putExtra("importsupp", importsupp)
            b.putExtra("exportsupp", exportsupp)



            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)


            b.putExtra("viewstklvl",viewstklvls)
            b.putExtra("otherst_pos", position)

            startActivity(b)
            finish()
        }

        var s = opri.add(priceArray.toString())
        Log.v("ghdgkhgfhg", "PRICESSSSSSSS" + s)

        fab.setOnClickListener {
            println(priceArray.size)
            println(pronameArray)
            println(priceArray)
            if ((priceArray.size == 0)&&(addtransano=="true")) {
                val intent = Intent(this, product_list_activity_two::class.java)
                intent.putExtra("fromstate", "emptylist_otstate")
                intent.putExtra("otherst_branch", comttname.text.toString())
                intent.putExtra("otherst_address", comphone.text.toString())
                intent.putExtra("brnchid",keyofbrnch)
                intent.putExtra("origiid",other_origiky)
                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)


                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)




                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)


                intent.putExtra("viewpro", viewpro)
                intent.putExtra("addpro", addpro)
                intent.putExtra("editpro", editpro)
                intent.putExtra("deletepro", deletepro)
                intent.putExtra("importpro", importpro)
                intent.putExtra("exportpro", exportpro)
                intent.putExtra("changestock", stockin_hand)


                intent.putExtra("view", view)
                intent.putExtra("add", add)
                intent.putExtra("edit", edits)
                intent.putExtra("delete", delete)
                intent.putExtra("import", import)
                intent.putExtra("export", export)


                intent.putExtra("viewsupp", viewsupp)
                intent.putExtra("addsupp", addsupp)
                intent.putExtra("editsupp", editsupp)
                intent.putExtra("deletesupp", deletesupp)
                intent.putExtra("importsupp", importsupp)
                intent.putExtra("exportsupp", exportsupp)



                intent.putExtra("viewtrans", viewtrans)
                intent.putExtra("addtrans", addtrans)
                intent.putExtra("edittrans", editetrans)
                intent.putExtra("deletetrans", deletetrans)
                intent.putExtra("transfertrans", transfertrans)
                intent.putExtra("exporttrans", exporttrans)
                intent.putExtra("sendtrans", sendtrans)


                intent.putExtra("viewtransano", viewtransano)
                intent.putExtra("addtransano", addtransano)
                intent.putExtra("edittransano", editetransano)
                intent.putExtra("deletetransano", deletetransano)
                intent.putExtra("transfertransano", transfertransano)
                intent.putExtra("exporttransano", exporttransano)
                intent.putExtra("sendtransano", sendtransano)

                intent.putExtra("viewrec", viewrec)
                intent.putExtra("addrec", addrec)
                intent.putExtra("deleterec", deleterec)
                intent.putExtra("editrec", editrec)
                intent.putExtra("transferrec", transferrec)
                intent.putExtra("exportrec", exportrec)
                intent.putExtra("sendstrec",sendstrec)


                intent.putExtra("viewstklvl",viewstklvls)


                println(othernameofbrnch)

                startActivity(intent)
            } else if((priceArray.size != 0)&&(addtransano=="true")) {
                val intent = Intent(this, product_list_activity_two::class.java)
                intent.putExtra("fromstate", "datalist_otstate")
                intent.putExtra("otherst_namess", pronameArray)
                intent.putExtra("otherst_orderarray", manufacturerArray)
                intent.putExtra("otherst_hsn", hsnArray)
                intent.putExtra("otherst_poarray", barcodeArray)
                intent.putExtra("otherst_complete", quantityArray)
                intent.putExtra("otherst_price", priceArray)
                intent.putExtra("otherst_total", totArray)
                intent.putExtra("otherst_cess", cessArray)
                intent.putExtra("groschk",grosscheck)
                intent.putExtra("otherst_igst", igstArray)
                intent.putExtra("otherst_igsttot", igsttotArray)
                intent.putExtra("otherst_cesstot", cesstotalArray)
                intent.putExtra("tallyarray", tallyArray)
                intent.putExtra("receivedarray", receivedArray)
                intent.putExtra("otherst_im", imageArray)

                intent.putExtra("otherst_sstkdate",otherdatestk)
                intent.putExtra("otherst_ssstockid",otherstkidstock)
                intent.putExtra("otherst_ssstkdesc",otherdescstk)
                intent.putExtra("otherst_idofdb",otherididdb)
                intent.putExtra("brnchid",keyofbrnch)
                intent.putExtra("otherst_idsofli",keyArray)

                intent.putExtra("origiid",other_origiky)
                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)


                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)




                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)


                intent.putExtra("viewpro", viewpro)
                intent.putExtra("addpro", addpro)
                intent.putExtra("editpro", editpro)
                intent.putExtra("deletepro", deletepro)
                intent.putExtra("importpro", importpro)
                intent.putExtra("exportpro", exportpro)
                intent.putExtra("changestock", stockin_hand)


                intent.putExtra("view", view)
                intent.putExtra("add", add)
                intent.putExtra("edit", edits)
                intent.putExtra("delete", delete)
                intent.putExtra("import", import)
                intent.putExtra("export", export)


                intent.putExtra("viewsupp", viewsupp)
                intent.putExtra("addsupp", addsupp)
                intent.putExtra("editsupp", editsupp)
                intent.putExtra("deletesupp", deletesupp)
                intent.putExtra("importsupp", importsupp)
                intent.putExtra("exportsupp", exportsupp)



                intent.putExtra("viewtrans", viewtrans)
                intent.putExtra("addtrans", addtrans)
                intent.putExtra("edittrans", editetrans)
                intent.putExtra("deletetrans", deletetrans)
                intent.putExtra("transfertrans", transfertrans)
                intent.putExtra("exporttrans", exporttrans)
                intent.putExtra("sendtrans", sendtrans)


                intent.putExtra("viewtransano", viewtransano)
                intent.putExtra("addtransano", addtransano)
                intent.putExtra("edittransano", editetransano)
                intent.putExtra("deletetransano", deletetransano)
                intent.putExtra("transfertransano", transfertransano)
                intent.putExtra("exporttransano", exporttransano)
                intent.putExtra("sendtransano", sendtransano)

                intent.putExtra("viewrec", viewrec)
                intent.putExtra("addrec", addrec)
                intent.putExtra("deleterec", deleterec)
                intent.putExtra("editrec", editrec)
                intent.putExtra("transferrec", transferrec)
                intent.putExtra("exportrec", exportrec)
                intent.putExtra("sendstrec",sendstrec)


                intent.putExtra("viewstklvl",viewstklvls)
                intent.putExtra("otherst_branch", comttname.text.toString())
                intent.putExtra("otherst_address", comphone.text.toString())
                startActivity(intent)
                finish()
            }
            else{
            popup("Add")
        }



        }
        userback.setOnClickListener {
            finish()
        }
        mnu.setOnClickListener({


            val popup = PopupMenu(this@Main_stk_delhi, mnu)

            popup.menuInflater.inflate(R.menu.branch_one, popup.menu)

            popup.setOnMenuItemClickListener { item ->
                Toast.makeText(this@Main_stk_delhi, "You Clicked : " + item.title, Toast.LENGTH_SHORT).show()
                if(item.title=="Send this ST"){
                    idstk=otstatestno.text.toString()
                    names=comttname.text.toString()
                    addressnames=comphone.text.toString()
                    cgstt=igst_tot.text.toString()

                    cesst=cess_tot.text.toString()
                    grosstt=otstate_gross_tot.text.toString()
                    createandDisplayPdf(idstk, datestk, names, addressnames,descstk, cgstt,cesst, grosstt)

                    var f = idstk + "_stock Another_state transfer"

                    var y=f+".pdf"


                    val share = Intent(Intent.ACTION_SEND)
                    share.type = "application/pdf"

                    pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer" + "/" + y).toString()


                    try {
                        sendMail(pdfFile)
                    } catch (e: IOException) {
                        Toast.makeText(applicationContext,"Couldn't Send",Toast.LENGTH_SHORT).show()
                    }

                    return@setOnMenuItemClickListener true

                }
                else if(item.title=="Export as pdf"){

                    val b = Intent(applicationContext, MainAnotherBranchPdf::class.java)

                    b.putExtra("fromstate", "mainpdf")
                    b.putExtra("otherst_pnm", pronameArray)
                    b.putExtra("otherst_pmanu", manufacturerArray)
                    b.putExtra("otherst_phsn", hsnArray)
                    b.putExtra("otherst_barcode", barcodeArray)
                    b.putExtra("otherst_price", priceArray)

                    b.putExtra("otherst_quan", quantityArray)
                    b.putExtra("otherst_tot", totArray)
                    b.putExtra("otherst_cessup", cessArray)
                    b.putExtra("otherst_igst", igstArray)
                    b.putExtra("otherst_igsttotal", igsttotArray)
                    b.putExtra("otherst_cesstotarray", cesstotalArray)
                    b.putExtra("tallyarray", tallyArray)
                    b.putExtra("receivedarray", receivedArray)
                    b.putExtra("otherst_image", imageArray)
                    b.putExtra("otherst_branch", othernameofbrnch)
                    b.putExtra("otherst_address", otherlocofbrnch)
                    b.putExtra("otherst_sstkdate",otherdatestk)
                    b.putExtra("otherst_ssstockid",otherstkidstock)
                    b.putExtra("otherst_ssstkdesc",otstatedescrip.text.toString())
                    b.putExtra("otherst_idofdb",otherididdb)
                    b.putExtra("otherst_idsofli",keyArray)
                    b.putExtra("keybrnch",keyofbrnch)

                    b.putExtra("otherst_smlistids",othersmlistids)
                    b.putExtra("gross",otstate_gross_tot.text.toString())
                    b.putExtra("igsttot",igst_tot.text.toString())
                    b.putExtra("cesstot",cess_tot.text.toString())
                    b.putExtra("originkeys",other_origiky)
                    b.putExtra("viewsuppin", viewsuppin)
                    b.putExtra("addsuppin", addsuppin)
                    b.putExtra("deletesuppin", deletesuppin)
                    b.putExtra("editsuppin", editesuppin)
                    b.putExtra("transfersuppin", transfersuppin)
                    b.putExtra("exportsuppin", exportsuppin)


                    b.putExtra("viewpurord", viewpurord)
                    b.putExtra("addpurord", addpurord)
                    b.putExtra("deletepurord", deletepurord)
                    b.putExtra("editpurord", editepurord)
                    b.putExtra("transferpurord", transferpurord)
                    b.putExtra("exportpurord", exportpurord)
                    b.putExtra("sendpurord", sendpurpo)




                    b.putExtra("viewpurreq", viewpurreq)
                    b.putExtra("addpurreq", addpurreq)
                    b.putExtra("deletepurreq", deletepurreq)
                    b.putExtra("editpurreq", editepurreq)
                    b.putExtra("transferpurreq", transferpurreq)
                    b.putExtra("exportpurreq", exportpurreq)


                    b.putExtra("viewpro", viewpro)
                    b.putExtra("addpro", addpro)
                    b.putExtra("editpro", editpro)
                    b.putExtra("deletepro", deletepro)
                    b.putExtra("importpro", importpro)
                    b.putExtra("exportpro", exportpro)
                    b.putExtra("changestock", stockin_hand)


                    b.putExtra("view", view)
                    b.putExtra("add", add)
                    b.putExtra("edit", edits)
                    b.putExtra("delete", delete)
                    b.putExtra("import", import)
                    b.putExtra("export", export)


                    b.putExtra("viewsupp", viewsupp)
                    b.putExtra("addsupp", addsupp)
                    b.putExtra("editsupp", editsupp)
                    b.putExtra("deletesupp", deletesupp)
                    b.putExtra("importsupp", importsupp)
                    b.putExtra("exportsupp", exportsupp)



                    b.putExtra("viewtrans", viewtrans)
                    b.putExtra("addtrans", addtrans)
                    b.putExtra("edittrans", editetrans)
                    b.putExtra("deletetrans", deletetrans)
                    b.putExtra("transfertrans", transfertrans)
                    b.putExtra("exporttrans", exporttrans)
                    b.putExtra("sendtrans", sendtrans)


                    b.putExtra("viewtransano", viewtransano)
                    b.putExtra("addtransano", addtransano)
                    b.putExtra("edittransano", editetransano)
                    b.putExtra("deletetransano", deletetransano)
                    b.putExtra("transfertransano", transfertransano)
                    b.putExtra("exporttransano", exporttransano)
                    b.putExtra("sendtransano", sendtransano)

                    b.putExtra("viewrec", viewrec)
                    b.putExtra("addrec", addrec)
                    b.putExtra("deleterec", deleterec)
                    b.putExtra("editrec", editrec)
                    b.putExtra("transferrec", transferrec)
                    b.putExtra("exportrec", exportrec)
                    b.putExtra("sendstrec",sendstrec)


                    b.putExtra("viewstklvl",viewstklvls)
                    startActivity(b)
                    finish()
                }
                true
            }

            popup.show()

        })


    }


    override fun onBackPressed() {
        if ((listListener == "listadded") || (descriplistener == "descchanged") || (deletelistener == "listdelete")) {

            savepopup()

        }
        else if((listListener.isEmpty())&&(descriplistener.isEmpty())) {
            val i=Intent(this@Main_stk_delhi,Anotherstate::class.java)
            i.putExtra("frmo_br","brsave")
            i.putExtra("viewsuppin", viewsuppin)
            i.putExtra("addsuppin", addsuppin)
            i.putExtra("deletesuppin", deletesuppin)
            i.putExtra("editsuppin", editesuppin)
            i.putExtra("transfersuppin", transfersuppin)
            i.putExtra("exportsuppin", exportsuppin)


          i.putExtra("viewpurord", viewpurord)
          i.putExtra("addpurord", addpurord)
          i.putExtra("deletepurord", deletepurord)
          i.putExtra("editpurord", editepurord)
          i.putExtra("transferpurord", transferpurord)
          i.putExtra("exportpurord", exportpurord)
          i.putExtra("sendpurord", sendpurpo)




          i.putExtra("viewpurreq", viewpurreq)
          i.putExtra("addpurreq", addpurreq)
          i.putExtra("deletepurreq", deletepurreq)
          i.putExtra("editpurreq", editepurreq)
          i.putExtra("transferpurreq", transferpurreq)
          i.putExtra("exportpurreq", exportpurreq)


          i.putExtra("viewpro", viewpro)
          i.putExtra("addpro", addpro)
          i.putExtra("editpro", editpro)
          i.putExtra("deletepro", deletepro)
           i.putExtra("importpro", importpro)
           i.putExtra("exportpro", exportpro)
           i.putExtra("changestock", stockin_hand)


           i.putExtra("view", view)
           i.putExtra("add", add)
           i.putExtra("edit", edits)
           i.putExtra("delete", delete)
           i.putExtra("import", import)
           i.putExtra("export", export)


           i.putExtra("viewsupp", viewsupp)
           i.putExtra("addsupp", addsupp)
           i.putExtra("editsupp", editsupp)
           i.putExtra("deletesupp", deletesupp)
           i.putExtra("importsupp", importsupp)
           i.putExtra("exportsupp", exportsupp)



         i.putExtra("viewtrans", viewtrans)
         i.putExtra("addtrans", addtrans)
         i.putExtra("edittrans", editetrans)
         i.putExtra("deletetrans", deletetrans)
         i.putExtra("transfertrans", transfertrans)
         i.putExtra("exporttrans", exporttrans)
         i.putExtra("sendtrans", sendtrans)


         i.putExtra("viewtransano", viewtransano)
         i.putExtra("addtransano", addtransano)
         i.putExtra("edittransano", editetransano)
         i.putExtra("deletetransano", deletetransano)
         i.putExtra("transfertransano", transfertransano)
         i.putExtra("exporttransano", exporttransano)
         i.putExtra("sendtransano", sendtransano)

         i.putExtra("viewrec", viewrec)
         i.putExtra("addrec", addrec)
         i.putExtra("deleterec", deleterec)
         i.putExtra("editrec", editrec)
         i.putExtra("transferrec", transferrec)
         i.putExtra("exportrec", exportrec)
         i.putExtra("sendstrec",sendstrec)


         i.putExtra("viewstklvl",viewstklvls)
            i.putExtra("brky",keyofbrnch)
            i.putExtra("orky",other_origiky)
            startActivity(i)
            finish()
        }
    }
    fun savepopup(){
        val builder = AlertDialog.Builder(this@Main_stk_delhi)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->
                if ((listoids.text == "") && (transfertransano == "true")) {
                    val pDialog = SweetAlertDialog(this@Main_stk_delhi, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show()
                    onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray,igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray,imageArray)

                }
                else if ((listoids.text != "") && (transfertransano == "true")) {
                    var stkid = (otstatestno.text).toString()
                    var stkdate = (otstatestdate.text).toString()
                    var stkdesc = (otstatedescrip.text).toString()
                    var destination=(comttname.text).toString()
                    var address=(comphone.text).toString()
                    var stktotals=(otstate_gross_tot.text).toString()
                    var brid=(other_brnchid.text).toString()
                    var originid=other_origiky

                    val data = s(otherstkid = stkid, otherstkdate = stkdate, otherstk_Desc = stkdesc,otherstk_destination = destination,otherstk_address =address,otherstk_total = stktotals,otherstk_brid = brid,otherstk_origin = originid)
                    var db = FirebaseFirestore.getInstance()
                    println(Arrays.toString(ids))
                    db.collection("ST_Another_State").document(listoids.text.toString())
                            .set(data)
                            .addOnSuccessListener {
                                db.collection("Receive Stock").document(listoids.text.toString())
                                        .set(data)


                                var refid=listoids.text.toString()
                                println("WHAT A IDSSSSSSSS"+listoids.text.toString())
                                var path="ST_Another_State/$refid/Stock_products"
                                var receive_path="Receive Stock/$refid/Received stock items"
                                for(i in 0 until priceArray.size) {
                                    var stk_name = pronameArray[i]
                                    var stk_mfr = manufacturerArray[i]
                                    var stk_hsn = hsnArray[i]
                                    var stk_bcode = barcodeArray[i]
                                    var stk_quan = quantityArray[i]
                                    var stk_pri = priceArray[i]
                                    var stk_tot = totArray[i]
                                    var stk_cess = cessArray[i]
                                    var stk_igst = igstArray[i]
                                    var stk_igsttot = igsttotArray[i]
                                    var stk_cesstot = cesstotalArray[i]
                                    var stk_received = receivedArray[i]
                                    var stk_tally = tallyArray[i]
                                    var img_arr=imageArray[i]
                                    var stk_key = keyArray[i]


                                    var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess,otherstk_igst=stk_igst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot, stk_key = stk_key,otherstk_tally = stk_tally,otherstk_received = stk_received,otherstk_img = img_arr)
                                    if (keyArray[i].equals("")) {
                                        db.collection(path)
                                                .add(d)
                                                .addOnSuccessListener { documentReference ->

                                                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                    var refid = documentReference.id
                                                    db.collection(receive_path).document(refid)
                                                            .set(d)
                                                }
                                    }

                                    else if(getiddel.isNotEmpty()){
                                        val deleteSize =  getiddel.size
                                        val i = 0
                                        for (i in getiddel) {
                                            db.collection(path).document(i.toString())
                                                    .delete()
                                                    .addOnSuccessListener {
                                                        getiddel.clear()



                                                    }
                                        }
                                    }
                                    else  {
                                        db.collection(path).document(keyArray[i])
                                                .set(d)
                                                .addOnCompleteListener {
                                                    db.collection(receive_path).document(keyArray[i])
                                                            .set(d)

                                                    Toast.makeText(this@Main_stk_delhi, "Your Data is Saved", Toast.LENGTH_LONG).show()
                                                    val pDialog= SweetAlertDialog(this@Main_stk_delhi, SweetAlertDialog.PROGRESS_TYPE)
                                                    pDialog.dismiss()
                                                    val i=Intent(this@Main_stk_delhi,Anotherstate::class.java)
                                                    i.putExtra("frmo_br","brsave")
                                                   i.putExtra("viewsuppin", viewsuppin)
                                                   i.putExtra("addsuppin", addsuppin)
                                                   i.putExtra("deletesuppin", deletesuppin)
                                                   i.putExtra("editsuppin", editesuppin)
                                                   i.putExtra("transfersuppin", transfersuppin)
                                                   i.putExtra("exportsuppin", exportsuppin)


                                                   i.putExtra("viewpurord", viewpurord)
                                                    i.putExtra("addpurord", addpurord)
                                                    i.putExtra("deletepurord", deletepurord)
                                                    i.putExtra("editpurord", editepurord)
                                                    i.putExtra("transferpurord", transferpurord)
                                                    i.putExtra("exportpurord", exportpurord)
                                                    i.putExtra("sendpurord", sendpurpo)




                                                    i.putExtra("viewpurreq", viewpurreq)
                                                    i.putExtra("addpurreq", addpurreq)
                                                    i.putExtra("deletepurreq", deletepurreq)
                                                    i.putExtra("editpurreq", editepurreq)
                                                    i.putExtra("transferpurreq", transferpurreq)
                                                    i.putExtra("exportpurreq", exportpurreq)


                                                    i.putExtra("viewpro", viewpro)
                                                    i.putExtra("addpro", addpro)
                                                    i.putExtra("editpro", editpro)
                                                    i.putExtra("deletepro", deletepro)
                                                    i.putExtra("importpro", importpro)
                                                    i.putExtra("exportpro", exportpro)
                                                    i.putExtra("changestock", stockin_hand)


                                                    i.putExtra("view", view)
                                                    i.putExtra("add", add)
                                                    i.putExtra("edit", edits)
                                                    i.putExtra("delete", delete)
                                                    i.putExtra("import", import)
                                                    i.putExtra("export", export)


                                                    i.putExtra("viewsupp", viewsupp)
                                                    i.putExtra("addsupp", addsupp)
                                                    i.putExtra("editsupp", editsupp)
                                                    i.putExtra("deletesupp", deletesupp)
                                                    i.putExtra("importsupp", importsupp)
                                                    i.putExtra("exportsupp", exportsupp)



                                                    i.putExtra("viewtrans", viewtrans)
                                                    i.putExtra("addtrans", addtrans)
                                                    i.putExtra("edittrans", editetrans)
                                                    i.putExtra("deletetrans", deletetrans)
                                                    i.putExtra("transfertrans", transfertrans)
                                                    i.putExtra("exporttrans", exporttrans)
                                                    i.putExtra("sendtrans", sendtrans)


                                                    i.putExtra("viewtransano", viewtransano)
                                                    i.putExtra("addtransano", addtransano)
                                                    i.putExtra("edittransano", editetransano)
                                                    i.putExtra("deletetransano", deletetransano)
                                                    i.putExtra("transfertransano", transfertransano)
                                                    i.putExtra("exporttransano", exporttransano)
                                                    i.putExtra("sendtransano", sendtransano)

                                                    i.putExtra("viewrec", viewrec)
                                                    i.putExtra("addrec", addrec)
                                                    i.putExtra("deleterec", deleterec)
                                                    i.putExtra("editrec", editrec)
                                                    i.putExtra("transferrec", transferrec)
                                                    i.putExtra("exportrec", exportrec)
                                                    i.putExtra("sendstrec",sendstrec)


                                                    i.putExtra("viewstklvl",viewstklvls)
                                                    i.putExtra("brky",keyofbrnch)
                                                    i.putExtra("orky",other_origiky)
                                                    startActivity(i)
                                                    finish()
                                                }
                                    }
                                }

                            }
                }
                else if (transfertransano == "false") {
                    popup("Transfer")
                }
            }
            setNegativeButton("No") { dialog, whichButton ->

                val i=Intent(this@Main_stk_delhi,Anotherstate::class.java)
                i.putExtra("frmo_br","brsave")
                i.putExtra("viewsuppin", viewsuppin)
                i.putExtra("addsuppin", addsuppin)
                i.putExtra("deletesuppin", deletesuppin)
                i.putExtra("editsuppin", editesuppin)
                i.putExtra("transfersuppin", transfersuppin)
                i.putExtra("exportsuppin", exportsuppin)


                i.putExtra("viewpurord", viewpurord)
                i.putExtra("addpurord", addpurord)
                i.putExtra("deletepurord", deletepurord)
                i.putExtra("editpurord", editepurord)
                i.putExtra("transferpurord", transferpurord)
                i.putExtra("exportpurord", exportpurord)
                i.putExtra("sendpurord", sendpurpo)




                i.putExtra("viewpurreq", viewpurreq)
                i.putExtra("addpurreq", addpurreq)
                i.putExtra("deletepurreq", deletepurreq)
                i.putExtra("editpurreq", editepurreq)
                i.putExtra("transferpurreq", transferpurreq)
                i.putExtra("exportpurreq", exportpurreq)


                i.putExtra("viewpro", viewpro)
                i.putExtra("addpro", addpro)
                i.putExtra("editpro", editpro)
                i.putExtra("deletepro", deletepro)
                i.putExtra("importpro", importpro)
                i.putExtra("exportpro", exportpro)
                i.putExtra("changestock", stockin_hand)


                i.putExtra("view", view)
                i.putExtra("add", add)
                i.putExtra("edit", edits)
                i.putExtra("delete", delete)
                i.putExtra("import", import)
                i.putExtra("export", export)


                i.putExtra("viewsupp", viewsupp)
                i.putExtra("addsupp", addsupp)
                i.putExtra("editsupp", editsupp)
                i.putExtra("deletesupp", deletesupp)
                i.putExtra("importsupp", importsupp)
                i.putExtra("exportsupp", exportsupp)



                i.putExtra("viewtrans", viewtrans)
                i.putExtra("addtrans", addtrans)
                i.putExtra("edittrans", editetrans)
                i.putExtra("deletetrans", deletetrans)
                i.putExtra("transfertrans", transfertrans)
                i.putExtra("exporttrans", exporttrans)
                i.putExtra("sendtrans", sendtrans)


                i.putExtra("viewtransano", viewtransano)
                i.putExtra("addtransano", addtransano)
                i.putExtra("edittransano", editetransano)
                i.putExtra("deletetransano", deletetransano)
                i.putExtra("transfertransano", transfertransano)
                i.putExtra("exporttransano", exporttransano)
                i.putExtra("sendtransano", sendtransano)

                i.putExtra("viewrec", viewrec)
                i.putExtra("addrec", addrec)
                i.putExtra("deleterec", deleterec)
                i.putExtra("editrec", editrec)
                i.putExtra("transferrec", transferrec)
                i.putExtra("exportrec", exportrec)
                i.putExtra("sendstrec",sendstrec)


                i.putExtra("viewstklvl",viewstklvls)
                i.putExtra("brky",keyofbrnch)
                i.putExtra("orky",other_origiky)
                startActivity(i)
                finish()
            }
            val dialog = builder.create()
            dialog.show()
        }
    }
    fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqphone:String,reqestidate:String,cgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Stock Transfer"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f = idstk + "_stock Another_state transfer"

            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Stock Transfer",fontsubheading)

            val a1=  Paragraph("Branch Name:             "+reqname,font)
            val b1=  Paragraph("Branch Address:           "+reqphone,font)
            val c1=  Paragraph("ST No:                        "+id,font)
            val d1=  Paragraph("Date:                          "+requestdt,font)
            val e1=  Paragraph("Description:                    "+reqestidate,font)
            val p13 =  Paragraph("IGST Total:                  "+cgsttotal,font)

            val p15 =  Paragraph("CESS Total:                  "+cesstotal,font)
            val p7 =  Paragraph("Gross Total:                 "+grosstot,font)
            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)





                table.addCell(i.toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(cgstt)

            /*   table.addCell("")
               table.addCell("")
               table.addCell("")
               table.addCell("")
               table.addCell("")
               table.addCell("CGST Total")
               table.addCell(cgstt)*/

            /*    table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("")
                table.addCell("SGST Total")
                table.addCell(sgstt)*/

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)
            /*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*/





            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE );
            doc.add(hs1)
            doc.add( Chunk.NEWLINE );
            doc.add(c1)
            doc.add( Chunk.NEWLINE );
            doc.add(d1)
            doc.add( Chunk.NEWLINE );
            doc.add(a1)
            doc.add( Chunk.NEWLINE );
            doc.add(b1)
            doc.add( Chunk.NEWLINE );
            doc.add(e1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(p8)
            /*   doc.add( Chunk.NEWLINE );
               doc.add(p13)

               doc.add( Chunk.NEWLINE );
               doc.add(p15)
               doc.add( Chunk.NEWLINE );
               doc.add(p7)*/



            doc.add( Chunk.NEWLINE );
            doc.add(table)

            downstatus="success"


        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }

    fun sendMail(path: String) {
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("muthumadhavan.vinitas@gmail.com","it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "ANOTHER STATE STOCK TRANSFER")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Enterprises")
        emailIntent.type = "application/pdf"
        val myUri = Uri.parse("file://" + path)
        emailIntent.putExtra(Intent.EXTRA_STREAM, myUri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        finish()
    }

    private fun onStarClicked1(pronameArray:ArrayList<String>,manufacturerArray:ArrayList<String>,hsnArray:ArrayList<String>,barcodeArray:ArrayList<String>,
                               quantityArray:ArrayList<String>,priceArray:ArrayList<String>,totArray:ArrayList<String>,cessArray:ArrayList<String>,igstArray:ArrayList<String>,
                               igsttotArray:ArrayList<String>,cesstotalArray:ArrayList<String>,tallyArray: ArrayList<String>,receivedArray: ArrayList<String>,
                               keyArray:ArrayList<String>,imageArray:ArrayList<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("Another_State_StockIds")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray,manufacturerArray,hsnArray,barcodeArray,quantityArray,priceArray,totArray,cessArray,igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray,imageArray)


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }

    fun prod_insert(id1: String, pronameArray: ArrayList<String>, manufacturerArray: ArrayList<String>, hsnArray: ArrayList<String>, barcodeArray: ArrayList<String>,
                    quantityArray: ArrayList<String>, priceArray: ArrayList<String>, totArray: ArrayList<String>, cessArray: ArrayList<String>,igstArray:ArrayList<String>,
                    igsttotArray:ArrayList<String>,cesstotalArray:ArrayList<String>,tallyArray: ArrayList<String>,receivedArray: ArrayList<String>,keyArray:ArrayList<String>,
                    imageArray: ArrayList<String>) {

        var stkid = "ST"+id1
        var stkdate = (otstatestdate.text).toString()
        var stkdesc = (otstatedescrip.text).toString()
        var destination=(comttname.text).toString()
        var address=(comphone.text).toString()
        var stktotals=(otstate_gross_tot.text).toString()
        var stkbrid=brids
        println("BRACH IDDDD"+other_brnchid.text)
        var originid=other_origiky

        val data = s(otherstkid = stkid, otherstkdate = stkdate, otherstk_Desc = stkdesc,otherstk_destination = destination,otherstk_address =address,otherstk_total = stktotals,otherstk_brid = stkbrid,otherstk_origin = originid)
        var db = FirebaseFirestore.getInstance()
        db.collection("ST_Another_State")
                .add(data)
                .addOnSuccessListener { documentReference ->

                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var refid=documentReference.id

                    db.collection("Receive Stock").document(refid)
                            .set(data)
                    var path="ST_Another_State/$refid/Stock_products"
                    for(i in 0 until priceArray.size) {

                        var stk_name=pronameArray[i]
                        var stk_mfr=manufacturerArray[i]
                        var stk_hsn=hsnArray[i]
                        var stk_bcode=barcodeArray[i]
                        var stk_quan=quantityArray[i]
                        var stk_pri=  priceArray[i]
                        var stk_tot=totArray[i]
                        var stk_cess=cessArray[i]
                        var stk_igst = igstArray[i]
                        var stk_igsttot = igsttotArray[i]
                        var stk_cesstot = cesstotalArray[i]
                        var stk_received = receivedArray[i]
                        var stk_tally = tallyArray[i]
                        var stk_key= keyArray[i]
                        var imga_arr=imageArray[i]
                        var d=li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess,otherstk_igst=stk_igst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot, stk_key = stk_key,otherstk_tally = stk_tally,otherstk_received = stk_received,otherstk_img = imga_arr)
                        db.collection(path)
                                .add(d)
                                .addOnSuccessListener { documentReference ->
                                    var resid=documentReference.id
                                    db.collection("Receive Stock/$refid/Received stock items").document(resid)
                                            .set(d)
                                    Toast.makeText(applicationContext,"Data saved successfully",Toast.LENGTH_SHORT).show()

                                    val pDialog= SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                    pDialog.dismiss()

                                    val i=Intent(this@Main_stk_delhi,Anotherstate::class.java)
                                    i.putExtra("frmo_br","brsave")
                                    i.putExtra("viewsuppin", viewsuppin)
                                    i.putExtra("addsuppin", addsuppin)
                                    i.putExtra("deletesuppin", deletesuppin)
                                    i.putExtra("editsuppin", editesuppin)
                                    i.putExtra("transfersuppin", transfersuppin)
                                    i.putExtra("exportsuppin", exportsuppin)


                                    i.putExtra("viewpurord", viewpurord)
                                    i.putExtra("addpurord", addpurord)
                                    i.putExtra("deletepurord", deletepurord)
                                    i.putExtra("editpurord", editepurord)
                                    i.putExtra("transferpurord", transferpurord)
                                    i.putExtra("exportpurord", exportpurord)
                                    i.putExtra("sendpurord", sendpurpo)




                                    i.putExtra("viewpurreq", viewpurreq)
                                    i.putExtra("addpurreq", addpurreq)
                                    i.putExtra("deletepurreq", deletepurreq)
                                    i.putExtra("editpurreq", editepurreq)
                                    i.putExtra("transferpurreq", transferpurreq)
                                    i.putExtra("exportpurreq", exportpurreq)


                                    i.putExtra("viewpro", viewpro)
                                    i.putExtra("addpro", addpro)
                                    i.putExtra("editpro", editpro)
                                    i.putExtra("deletepro", deletepro)
                                    i.putExtra("importpro", importpro)
                                    i.putExtra("exportpro", exportpro)
                                    i.putExtra("changestock", stockin_hand)


                                    i.putExtra("view", view)
                                    i.putExtra("add", add)
                                    i.putExtra("edit", edits)
                                    i.putExtra("delete", delete)
                                    i.putExtra("import", import)
                                    i.putExtra("export", export)


                                    i.putExtra("viewsupp", viewsupp)
                                    i.putExtra("addsupp", addsupp)
                                    i.putExtra("editsupp", editsupp)
                                    i.putExtra("deletesupp", deletesupp)
                                    i.putExtra("importsupp", importsupp)
                                    i.putExtra("exportsupp", exportsupp)



                                    i.putExtra("viewtrans", viewtrans)
                                    i.putExtra("addtrans", addtrans)
                                    i.putExtra("edittrans", editetrans)
                                    i.putExtra("deletetrans", deletetrans)
                                    i.putExtra("transfertrans", transfertrans)
                                    i.putExtra("exporttrans", exporttrans)
                                    i.putExtra("sendtrans", sendtrans)


                                    i.putExtra("viewtransano", viewtransano)
                                    i.putExtra("addtransano", addtransano)
                                    i.putExtra("edittransano", editetransano)
                                    i.putExtra("deletetransano", deletetransano)
                                    i.putExtra("transfertransano", transfertransano)
                                    i.putExtra("exporttransano", exporttransano)
                                    i.putExtra("sendtransano", sendtransano)

                                    i.putExtra("viewrec", viewrec)
                                    i.putExtra("addrec", addrec)
                                    i.putExtra("deleterec", deleterec)
                                    i.putExtra("editrec", editrec)
                                    i.putExtra("transferrec", transferrec)
                                    i.putExtra("exportrec", exportrec)
                                    i.putExtra("sendstrec",sendstrec)


                                    i.putExtra("viewstklvl",viewstklvls)
                                    i.putExtra("brky",keyofbrnch)
                                    i.putExtra("orky",other_origiky)
                                    startActivity(i)
                                    finish()
                                }
                    }


                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    /* save_progress.visibility = android.view.View.GONE*/
                }
    }
    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    }
