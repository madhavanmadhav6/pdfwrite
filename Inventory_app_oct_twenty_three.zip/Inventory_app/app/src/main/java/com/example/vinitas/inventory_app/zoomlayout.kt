package com.example.vinitas.inventory_app

import android.content.Context
import android.graphics.*
import android.graphics.Matrix.MSCALE_X
import android.graphics.Matrix.MTRANS_Y
import android.graphics.Matrix.MTRANS_X
import android.graphics.Matrix.MSCALE_Y

import android.text.method.Touch.onTouchEvent

import com.example.vinitas.inventory_app.R.id.save
import android.support.v4.view.GestureDetectorCompat
import android.util.AttributeSet
import android.view.*
import kotlinx.android.synthetic.main.activity_zoom_service.view.*


class ZoomLayout : ViewGroup {

    private var mScaleGestureDetector: ScaleGestureDetector? = null
    private var mGestureDetector: GestureDetectorCompat? = null
    private var scale = 1f
    // Parameters for zooming.
    private val start = PointF()
    private val mid = PointF()
    private var oldDist = 1f
    private var distanceX = 0f
    private var distanceY = 0f


    private var contentSize: RectF? = null


    private val mDispatchTouchEventWorkingArray = FloatArray(2)
    private val mOnTouchEventWorkingArray = FloatArray(2)


    // Matrices used to move and zoom image.
    internal val matrix = Matrix()
    private val matrixInverse = Matrix()
    private val savedMatrix = Matrix()

    /**
     * The scale listener, used for handling multi-finger scale gestures.
     */
    private val mScaleGestureListener = object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        /**
         * This is the active focal point in terms of the viewport. Could be a local
         * variable but kept here to minimize per-frame allocations.
         */

        override fun onScaleBegin(scaleGestureDetector: ScaleGestureDetector): Boolean {

            oldDist = scaleGestureDetector.currentSpan
            if (oldDist > 10f) {
                savedMatrix.set(matrix)
                mid.set(scaleGestureDetector.focusX, scaleGestureDetector.focusY)
            }
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {

        }

        override fun onScale(scaleGestureDetector: ScaleGestureDetector): Boolean {
            scale = scaleGestureDetector.scaleFactor
            return true
        }
    }

    /**
     * The gesture listener, used for handling simple gestures such as double touches, scrolls,
     * and flings.
     */
    private val mGestureListener = object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(event: MotionEvent): Boolean {
            savedMatrix.set(matrix)

            start.set(event.x, event.y)

            return true
        }

        override fun onScroll(e1: MotionEvent, e2: MotionEvent, dX: Float, dY: Float): Boolean {
            setupTranslation(dX, dY)
            matrix.postTranslate(distanceX, distanceY)
            return true
        }

        override fun onFling(e1: MotionEvent, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            //fling((int) -velocityX, (int) -velocityY);
            return true
        }
    }


    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(context)
    }


    private fun init(context: Context) {
        mScaleGestureDetector = ScaleGestureDetector(context, mScaleGestureListener)
        mGestureDetector = GestureDetectorCompat(context, mGestureListener)
    }


    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val childCount = childCount
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility !== View.GONE) {
                child.layout(left, top, left + child.measuredWidth, top + child.measuredHeight)
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        val childCount = childCount
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility !== View.GONE) {
                measureChild(child, widthMeasureSpec, heightMeasureSpec)
            }
        }
    }

    protected override fun dispatchDraw(canvas: Canvas) {
        val values = FloatArray(9)
        matrix.getValues(values)
        canvas.save()
        canvas.translate(values[Matrix.MTRANS_X], values[Matrix.MTRANS_Y])
        canvas.scale(values[Matrix.MSCALE_X], values[Matrix.MSCALE_Y])
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
/*
        userback.visibility=View.VISIBLE
        imageButton.visibility=View.VISIBLE
        comttname.visibility=View.VISIBLE*/

        //mDispatchTouchEventWorkingArray[0] = ev.getX();
        //mDispatchTouchEventWorkingArray[1] = ev.getY();
        //mDispatchTouchEventWorkingArray = screenPointsToScaledPoints(mDispatchTouchEventWorkingArray);
        //ev.setLocation(mDispatchTouchEventWorkingArray[0], mDispatchTouchEventWorkingArray[1]);
        return super.dispatchTouchEvent(ev)
    }



    override fun onTouchEvent(event: MotionEvent): Boolean {



        matrix.set(savedMatrix)
        var gestureDetected = mGestureDetector!!.onTouchEvent(event)
        if (event.pointerCount > 1) {
            gestureDetected = mScaleGestureDetector!!.onTouchEvent(event) or gestureDetected
            if (checkScaleBounds()) {
                matrix.postScale(scale, scale, mid.x, mid.y)
            }

        }
        matrix.invert(matrixInverse)
        savedMatrix.set(matrix)
        invalidate()
        return gestureDetected
    }

    private fun checkScaleBounds(): Boolean {
        val values = FloatArray(9)
        matrix.getValues(values)
        val sx = values[Matrix.MSCALE_X] * scale
        val sy = values[Matrix.MSCALE_Y] * scale
        return if (sx > MIN_ZOOM && sx < MAX_ZOOM && sy > MIN_ZOOM && sy < MAX_ZOOM) {
            true
        } else false
    }

    private fun scaledPointsToScreenPoints(a: FloatArray): FloatArray {
        matrix.mapPoints(a)
        return a
    }

    private fun screenPointsToScaledPoints(a: FloatArray): FloatArray {
        matrixInverse.mapPoints(a)
        return a
    }

    private fun setupTranslation(dX: Float, dY: Float) {
        distanceX = -1 * dX
        distanceY = -1 * dY

        if (contentSize != null) {


               /* userback.visibility=View.GONE
                imageButton.visibility=View.GONE
                comttname.visibility=View.GONE*/



            val values = FloatArray(9)
            matrix.getValues(values)
            val totX = values[Matrix.MTRANS_X] + distanceX
            val totY = values[Matrix.MTRANS_Y] + distanceY
            val sx = values[Matrix.MSCALE_X]

            val viewableRect = Rect()
            this@ZoomLayout.getDrawingRect(viewableRect)
            val offscreenWidth = contentSize!!.width() - (viewableRect.right - viewableRect.left)
            val offscreenHeight = contentSize!!.height() - (viewableRect.bottom - viewableRect.top)
            val maxDx = (contentSize!!.width() - contentSize!!.width() / sx) * sx
            val maxDy = (contentSize!!.height() - contentSize!!.height() / sx) * sx
            if (totX > 0 && distanceX > 0) {
                distanceX = 0f
            }
            if (totY > 0 && distanceY > 0) {
                distanceY = 0f
            }

            if (totX * -1 > offscreenWidth + maxDx && distanceX < 0) {
                distanceX = 0f
            }
            if (totY * -1 > offscreenHeight + maxDy && distanceY < 0) {
                distanceY = 0f
            }

        }

    }

    fun setContentSize(width: Float, height: Float) {
        this.contentSize = RectF(0f, 0f, width, height)
    }

    companion object {
        private val MIN_ZOOM = 1.0f
        private val MAX_ZOOM = 4.0f
    }

}