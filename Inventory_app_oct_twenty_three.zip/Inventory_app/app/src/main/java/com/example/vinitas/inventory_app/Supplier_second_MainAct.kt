package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot



import kotlinx.android.synthetic.main.supplier_second.*


class MainSecondSupplier_secondActivity : AppCompatActivity() {





    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var ids= arrayOf<String>()

    var liids= arrayOf<String>()
    var nameArrayori= arrayOf<String>()
    var phoneArrayori= arrayOf<String>()
    var bridArrayori= arrayOf<String>()
    var dateArrayori= arrayOf<String>()
    var priceArrayori= arrayOf<String>()
    var datearr=arrayOf<String>()
    var datesarr=arrayOf<String>()
    var name=arrayOf<String>()
    var descrip=arrayOf<String>()
    var descriptionss=arrayOf<String>()



    var supnamearr=arrayOf<String>()
    var supphonearr=arrayOf<String>()

    var broriky = String()
    var brorival = String()

    var s = String()

    var cancelsta=String()


    var sd = String()
    var x = String()
    var reg = String()
    var esc = String()
    var upstr = String()
    var numberstr = String()
    var descr = String()
    var regtr = String()
    var nmstr = String()
    var kyval = String()
    var supkyval = String()
    var bsupkyval = String()

    var origisearch = arrayOf<String>()


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplier_second)


        net_status()    //Check internet status


//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()
        if (NetworkUtil.getConnectivityStatus(this@MainSecondSupplier_secondActivity) > 0)
        {
        }
        else{
        }

        val i=intent.extras
        var frm=i!!.get("from_ver")



        //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.seccont)


        search.setOnClickListener { //Image button search  action
            cardsearch.visibility = View.VISIBLE
            search.visibility=View.GONE
            textView.visibility=View.GONE
            imageButtonmnu.visibility=View.GONE
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }


        imageButtonmnu.setOnClickListener({    //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@MainSecondSupplier_secondActivity, imageButtonmnu)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {   //Navigate to pin activity
                    if(net_status()==true) {
                        Toast.makeText(this@MainSecondSupplier_secondActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                        val f = Intent(this@MainSecondSupplier_secondActivity, PinActivity::class.java)
                        startActivity(f)
                        finish()
                    }
                    else{
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()

                    }
                }
                true
            }

            popup.show()
        })







       /* swipeContainer.setOnRefreshListener {
            puract()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/


        if (frm == "main")

        {








            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }


            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }

            val p = intent.getStringExtra("brky")
            broriky = p
            println("LOGINN KEYYYY" + broriky)
            puract()

        }

        //------------------------------SEARCH---------------------------//


        searchedit.addTextChangedListener(object : TextWatcher {


            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar9.visibility=View.VISIBLE

                supplier_list_second.visibility=View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"

                val ps = "^[a-zA-Z ]+$"
                val datev= "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"
                println("TYPED VALUED" + x)





                fun dateget() {
                    if ((s.length>=3)||(s.length>=3)) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var urlArray1 = arrayOf<String>()

                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()

                        db.collection("${broriky}_Purchase Orders").orderBy("req_date").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var brids = (dt["branch_id"]).toString()




                                                if (brorival == brids) {
                                                    var id = (document.id)
                                                    var kk = dt["supp_invoice"].toString()
                                                    if (kk.isEmpty()) {
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)


                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var recsta = (dt["recstatus"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    var descripss = (dt["description"]).toString()
                                                    descriptionss = descriptionss.plusElement(descripss)
                                                    try {
                                                        urlArray1 = urlArray1.plusElement("")
                                                        var sta = (dt["postatus"]).toString()
                                                        if (sta.isNotEmpty()) {
                                                            if ((sta == "Complete") || (sta == "complete")) {


                                                                descr = "Complete"
                                                                statusArray1 = statusArray1.plusElement(descr)
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")


                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                descr = "Incomplete"
                                                                statusArray = statusArray.plusElement(descr)
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss
                                                            } else if (sta == "Partially Complete") {
                                                                descr = "Partially Incomplete"
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement(descr)
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                            }
                                                        } else {
                                                            descr = "Incomplete"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Incomplete"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                        var manufacturer = (dt["ponumber"]).toString()
                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                        nameArray = nameArray.plusElement(name)
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                        if (recsta.isNotEmpty()) {
                                                            priceArray = priceArray.plusElement(tot)
                                                        } else if (recsta.isEmpty()) {
                                                            priceArray = priceArray.plusElement("0.00")

                                                        }
                                                        nameArrayori = text
                                                        dateArrayori = dateArray
                                                        priceArrayori = priceArray
                                                        datearr = datearr.plusElement(date)
                                                        datesarr = datesarr.plusElement(dates)
                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                        descrip = descriptionArray
                                                        ids = idss
                                                        liids = idss
                                                    }
                                                    progressBar9.visibility = View.GONE

                                                    supplier_list_second.visibility = View.VISIBLE
                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                    wlist.adapter = whatever
                                                }
                                                } else {
                                                    progressBar9.visibility = View.GONE

                                                    supplier_list_second.visibility = View.VISIBLE
                                                    noresfo.visibility = View.VISIBLE
                                                }


                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            db.collection("${broriky}_Purchase Orders").orderBy("req_estimated").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)

                                                                    var dt = document.data
                                                                    var brids = (dt["branch_id"]).toString()




                                                                    if (brorival == brids) {


                                                                        var id = (document.id)
                                                                        var kk = dt["supp_invoice"].toString()
                                                                        if (kk.isEmpty()) {
                                                                        idss = idss.plusElement(id)
                                                                        iddd.setText(idss.toString())
                                                                        println(idss)


                                                                        var name = (dt["prod_nms"]).toString()
                                                                        var phone = (dt["supplier_Phone"]).toString()
                                                                        var date = (dt["req_date"]).toString()
                                                                        var tot = (dt["gross_tot"]).toString()
                                                                        var recsta = (dt["recstatus"]).toString()
                                                                        var dates = (dt["req_estimated"]).toString()
                                                                        var descripss = (dt["description"]).toString()
                                                                        descriptionss = descriptionss.plusElement(descripss)
                                                                        try {
                                                                            urlArray1 = urlArray1.plusElement("")
                                                                            var sta = (dt["postatus"]).toString()
                                                                            if (sta.isNotEmpty()) {
                                                                                if ((sta == "Complete") || (sta == "complete")) {


                                                                                    descr = "Complete"
                                                                                    statusArray1 = statusArray1.plusElement(descr)
                                                                                    statusArray = statusArray.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss


                                                                                } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                                    descr = "Incomplete"
                                                                                    statusArray = statusArray.plusElement(descr)
                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss
                                                                                } else if (sta == "Partially Complete") {
                                                                                    descr = "Partially Incomplete"
                                                                                    statusArray = statusArray.plusElement("")
                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement(descr)
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss


                                                                                } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                                                }
                                                                            } else {
                                                                                descr = "Incomplete"
                                                                                statusArray = statusArray.plusElement(descr)
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                                nameArray = nameArray.plusElement(name)
                                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                                if (recsta.isNotEmpty()) {
                                                                                    priceArray = priceArray.plusElement(tot)
                                                                                } else if (recsta.isEmpty()) {
                                                                                    priceArray = priceArray.plusElement("0.00")

                                                                                }
                                                                                nameArrayori = text
                                                                                dateArrayori = dateArray
                                                                                priceArrayori = priceArray
                                                                                datearr = datearr.plusElement(date)
                                                                                datesarr = datesarr.plusElement(dates)
                                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                descrip = descriptionArray
                                                                                ids = idss
                                                                                liids = idss
                                                                            }
                                                                        } catch (e: Exception) {
                                                                            descr = "Incomplete"
                                                                            statusArray = statusArray.plusElement(descr)
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                                            var manufacturer = (dt["ponumber"]).toString()
                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                            if (recsta.isNotEmpty()) {
                                                                                priceArray = priceArray.plusElement(tot)
                                                                            } else if (recsta.isEmpty()) {
                                                                                priceArray = priceArray.plusElement("0.00")

                                                                            }
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(date)
                                                                            datesarr = datesarr.plusElement(dates)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                            descrip = descriptionArray
                                                                            ids = idss
                                                                            liids = idss
                                                                        }


                                                                        progressBar9.visibility = View.GONE

                                                                        supplier_list_second.visibility = View.VISIBLE
                                                                        noresfo.visibility = View.GONE
                                                                        println("If SAVE KEYYYY" + brorival)
                                                                        val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                        val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                                        wlist.adapter = whatever
                                                                    }
                                                                    } else {
                                                                        progressBar9.visibility = View.GONE

                                                                        supplier_list_second.visibility = View.VISIBLE
                                                                        noresfo.visibility = View.VISIBLE
                                                                    }


                                                                }


                                                            } else {
                                                                progressBar9.visibility = View.GONE

                                                                supplier_list_second.visibility = View.VISIBLE
                                                                noresfo.visibility = View.VISIBLE
                                                            }


                                                    })

                                        }



                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                    else{

                        noresfo.visibility = View.VISIBLE
                        supplier_list_second.visibility = View.GONE
                        progressBar9.visibility=View.GONE

                    }
                }


                fun priget() {
                    if (s.length >= 2) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var urlArray1 = arrayOf<String>()
                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Purchase Orders").orderBy("gross_tot").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data

                                                var brids = (dt["branch_id"]).toString()




                                                if (brorival == brids) {


                                                    var id = (document.id)
                                                    var kk = dt["supp_invoice"].toString()
                                                    if (kk.isEmpty()) {
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)


                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var recsta = (dt["recstatus"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    var descripss = (dt["description"]).toString()
                                                    descriptionss = descriptionss.plusElement(descripss)
                                                    try {
                                                        urlArray1 = urlArray1.plusElement("")
                                                        var sta = (dt["postatus"]).toString()
                                                        if (sta.isNotEmpty()) {
                                                            if ((sta == "Complete") || (sta == "complete")) {
                                                                descr = "Complete"
                                                                statusArray1 = statusArray1.plusElement(descr)
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                descr = "Incomplete"
                                                                statusArray = statusArray.plusElement(descr)
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss
                                                            } else if (sta == "Partially Complete") {
                                                                descr = "Partially Incomplete"
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement(descr)
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss
                                                            } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                            }
                                                        } else {
                                                            descr = "Incomplete"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Incomplete"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                        var manufacturer = (dt["ponumber"]).toString()
                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                        nameArray = nameArray.plusElement(name)
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                        if (recsta.isNotEmpty()) {
                                                            priceArray = priceArray.plusElement(tot)
                                                        } else if (recsta.isEmpty()) {
                                                            priceArray = priceArray.plusElement("0.00")

                                                        }
                                                        nameArrayori = text
                                                        dateArrayori = dateArray
                                                        priceArrayori = priceArray
                                                        datearr = datearr.plusElement(date)
                                                        datesarr = datesarr.plusElement(dates)
                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                        descrip = descriptionArray
                                                        ids = idss
                                                        liids = idss
                                                    }


                                                    progressBar9.visibility = View.GONE

                                                    supplier_list_second.visibility = View.VISIBLE

                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                    wlist.adapter = whatever
                                                }
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    supplier_list_second.visibility = View.GONE
                                                    progressBar9.visibility=View.GONE

                                                }


                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            dateget()
                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }



                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    priget()

                    //write code here for success
                }


                if ((x !== reg)&&(!s.contains("/"))) {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                }
                else if(s.contains("/")){
                    dateget()
                }

                if (x.trim().matches(datev.toRegex()))
                {
                    upstr = x
                    println("CAME INTO DATE NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    dateget()

                    //write code here for success
                }







                //_____________________________NAME SEARCH__________________________________//


                fun nameget() {


                    if ((s.length >= 3) && (x !== reg)) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var urlArray1 = arrayOf<String>()
                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Purchase Orders").orderBy("supplier_name").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)


                                                var dt = document.data
                                                var brids = (dt["branch_id"]).toString()




                                                if (brorival == brids) {


                                                    var id = (document.id)
                                                    var kk = dt["supp_invoice"].toString()
                                                    if (kk.isEmpty()) {
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)


                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var recsta = (dt["recstatus"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    var descripss = (dt["description"]).toString()
                                                    descriptionss = descriptionss.plusElement(descripss)
                                                    try {
                                                        urlArray1 = urlArray1.plusElement("")
                                                        var sta = (dt["postatus"]).toString()
                                                        if (sta.isNotEmpty()) {
                                                            if ((sta == "Complete") || (sta == "complete")) {
                                                                descr = "Complete"
                                                                statusArray1 = statusArray1.plusElement(descr)
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")


                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                descr = "Incomplete"
                                                                statusArray = statusArray.plusElement(descr)
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if (sta == "Partially Complete") {
                                                                descr = "Partially Incomplete"
                                                                statusArray = statusArray.plusElement("")
                                                                statusArray1 = statusArray1.plusElement("")
                                                                statusArray2pr = statusArray2pr.plusElement(descr)
                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                nameArray = nameArray.plusElement(name)
                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                if (recsta.isNotEmpty()) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (recsta.isEmpty()) {
                                                                    priceArray = priceArray.plusElement("0.00")

                                                                }
                                                                nameArrayori = text
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                descrip = descriptionArray
                                                                ids = idss
                                                                liids = idss


                                                            } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                            }
                                                        } else {
                                                            descr = "Incomplete"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Incomplete"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                        var manufacturer = (dt["ponumber"]).toString()
                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                        nameArray = nameArray.plusElement(name)
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                        if (recsta.isNotEmpty()) {
                                                            priceArray = priceArray.plusElement(tot)
                                                        } else if (recsta.isEmpty()) {
                                                            priceArray = priceArray.plusElement("0.00")

                                                        }
                                                        nameArrayori = text
                                                        dateArrayori = dateArray
                                                        priceArrayori = priceArray
                                                        datearr = datearr.plusElement(date)
                                                        datesarr = datesarr.plusElement(dates)
                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                        descrip = descriptionArray
                                                        ids = idss
                                                        liids = idss
                                                    }


                                                    progressBar9.visibility = View.GONE

                                                    supplier_list_second.visibility = View.VISIBLE
                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                    wlist.adapter = whatever
                                                }
                                                } else {
                                                    progressBar9.visibility=View.GONE

                                                    supplier_list_second.visibility = View.GONE
                                                    noresfo.visibility=View.VISIBLE
                                                }

                                            }


                                        } else {
                                            db.collection("${broriky}_Purchase Orders").orderBy("prod_nms").startAt(upstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    var dt = document.data
                                                                    var brids = (dt["branch_id"]).toString()




                                                                    if (brorival == brids) {


                                                                        var id = (document.id)
                                                                        var kk = dt["supp_invoice"].toString()
                                                                        if (kk.isEmpty()) {
                                                                        idss = idss.plusElement(id)
                                                                        iddd.setText(idss.toString())
                                                                        println(idss)


                                                                        var name = (dt["prod_nms"]).toString()
                                                                        var phone = (dt["supplier_Phone"]).toString()
                                                                        var date = (dt["req_date"]).toString()
                                                                        var tot = (dt["gross_tot"]).toString()
                                                                        var recsta = (dt["recstatus"]).toString()
                                                                        var dates = (dt["req_estimated"]).toString()
                                                                        var descripss = (dt["description"]).toString()
                                                                        descriptionss = descriptionss.plusElement(descripss)
                                                                        try {
                                                                            urlArray1 = urlArray1.plusElement("")
                                                                            var sta = (dt["postatus"]).toString()
                                                                            if (sta.isNotEmpty()) {
                                                                                if ((sta == "Complete") || (sta == "complete")) {
                                                                                    descr = "Complete"
                                                                                    statusArray1 = statusArray1.plusElement(descr)
                                                                                    statusArray = statusArray.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss


                                                                                } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                                    descr = "Incomplete"
                                                                                    statusArray = statusArray.plusElement(descr)
                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss


                                                                                } else if (sta == "Partially Complete") {
                                                                                    descr = "Partially Incomplete"
                                                                                    statusArray = statusArray.plusElement("")
                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                    statusArray2pr = statusArray2pr.plusElement(descr)
                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                    nameArray = nameArray.plusElement(name)
                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                    if (recsta.isNotEmpty()) {
                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                    } else if (recsta.isEmpty()) {
                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                    }
                                                                                    nameArrayori = text
                                                                                    dateArrayori = dateArray
                                                                                    priceArrayori = priceArray
                                                                                    datearr = datearr.plusElement(date)
                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                    descrip = descriptionArray
                                                                                    ids = idss
                                                                                    liids = idss


                                                                                } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                                                }
                                                                            } else {
                                                                                descr = "Incomplete"
                                                                                statusArray = statusArray.plusElement(descr)
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                                nameArray = nameArray.plusElement(name)
                                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                if (recsta.isNotEmpty()) {
                                                                                    priceArray = priceArray.plusElement(tot)
                                                                                } else if (recsta.isEmpty()) {
                                                                                    priceArray = priceArray.plusElement("0.00")

                                                                                }
                                                                                nameArrayori = text
                                                                                dateArrayori = dateArray
                                                                                priceArrayori = priceArray
                                                                                datearr = datearr.plusElement(date)
                                                                                datesarr = datesarr.plusElement(dates)
                                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                descrip = descriptionArray
                                                                                ids = idss
                                                                                liids = idss
                                                                            }
                                                                        } catch (e: Exception) {
                                                                            descr = "Incomplete"
                                                                            statusArray = statusArray.plusElement(descr)
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                                            var manufacturer = (dt["ponumber"]).toString()
                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                            if (recsta.isNotEmpty()) {
                                                                                priceArray = priceArray.plusElement(tot)
                                                                            } else if (recsta.isEmpty()) {
                                                                                priceArray = priceArray.plusElement("0.00")

                                                                            }
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(date)
                                                                            datesarr = datesarr.plusElement(dates)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                            descrip = descriptionArray
                                                                            ids = idss
                                                                            liids = idss
                                                                        }




                                                                        progressBar9.visibility = View.GONE

                                                                        supplier_list_second.visibility = View.VISIBLE
                                                                        noresfo.visibility = View.GONE
                                                                        println("If SAVE KEYYYY" + brorival)
                                                                        val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                        val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                                        wlist.adapter = whatever
                                                                    }
                                                                    } else {
                                                                        progressBar9.visibility = View.GONE

                                                                        supplier_list_second.visibility = View.GONE
                                                                        noresfo.visibility = View.VISIBLE
                                                                    }

                                                                }


                                                            }
                                                            else {
                                                                db.collection("${broriky}_Purchase Orders").orderBy("postatus").startAt(upstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {

                                                                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                                        println(document.data)


                                                                                        var dt = document.data
                                                                                        var brids = (dt["branch_id"]).toString()




                                                                                        if (brorival == brids) {


                                                                                            var id = (document.id)
                                                                                            var kk = dt["supp_invoice"].toString()
                                                                                            if (kk.isEmpty()) {
                                                                                            idss = idss.plusElement(id)
                                                                                            iddd.setText(idss.toString())
                                                                                            println(idss)


                                                                                            var name = (dt["prod_nms"]).toString()
                                                                                            var phone = (dt["supplier_Phone"]).toString()
                                                                                            var date = (dt["req_date"]).toString()
                                                                                            var tot = (dt["gross_tot"]).toString()
                                                                                            var recsta = (dt["recstatus"]).toString()
                                                                                            var dates = (dt["req_estimated"]).toString()
                                                                                            var descripss = (dt["description"]).toString()
                                                                                            descriptionss = descriptionss.plusElement(descripss)
                                                                                            try {
                                                                                                urlArray1 = urlArray1.plusElement("")
                                                                                                var sta = (dt["postatus"]).toString()
                                                                                                if (sta.isNotEmpty()) {
                                                                                                    if ((sta == "Complete") || (sta == "complete")) {
                                                                                                        descr = "Complete"
                                                                                                        statusArray1 = statusArray1.plusElement(descr)
                                                                                                        statusArray = statusArray.plusElement("")
                                                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                                                        statusArray3cncl = statusArray3cncl.plusElement("")


                                                                                                        var manufacturer = (dt["ponumber"]).toString()
                                                                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                        nameArray = nameArray.plusElement(name)
                                                                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                                        if (recsta.isNotEmpty()) {
                                                                                                            priceArray = priceArray.plusElement(tot)
                                                                                                        } else if (recsta.isEmpty()) {
                                                                                                            priceArray = priceArray.plusElement("0.00")

                                                                                                        }
                                                                                                        nameArrayori = text
                                                                                                        dateArrayori = dateArray
                                                                                                        priceArrayori = priceArray
                                                                                                        datearr = datearr.plusElement(date)
                                                                                                        datesarr = datesarr.plusElement(dates)
                                                                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                                        descrip = descriptionArray
                                                                                                        ids = idss
                                                                                                        liids = idss


                                                                                                    } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                                                        descr = "Incomplete"
                                                                                                        statusArray = statusArray.plusElement(descr)
                                                                                                        statusArray1 = statusArray1.plusElement("")
                                                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                        var manufacturer = (dt["ponumber"]).toString()
                                                                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                        nameArray = nameArray.plusElement(name)
                                                                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                                        if (recsta.isNotEmpty()) {
                                                                                                            priceArray = priceArray.plusElement(tot)
                                                                                                        } else if (recsta.isEmpty()) {
                                                                                                            priceArray = priceArray.plusElement("0.00")

                                                                                                        }
                                                                                                        nameArrayori = text
                                                                                                        dateArrayori = dateArray
                                                                                                        priceArrayori = priceArray
                                                                                                        datearr = datearr.plusElement(date)
                                                                                                        datesarr = datesarr.plusElement(dates)
                                                                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                                        descrip = descriptionArray
                                                                                                        ids = idss
                                                                                                        liids = idss


                                                                                                    } else if (sta == "Partially Complete") {
                                                                                                        descr = "Partially Incomplete"
                                                                                                        statusArray = statusArray.plusElement("")
                                                                                                        statusArray1 = statusArray1.plusElement("")
                                                                                                        statusArray2pr = statusArray2pr.plusElement(descr)
                                                                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                        var manufacturer = (dt["ponumber"]).toString()
                                                                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                        nameArray = nameArray.plusElement(name)
                                                                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                                        if (recsta.isNotEmpty()) {
                                                                                                            priceArray = priceArray.plusElement(tot)
                                                                                                        } else if (recsta.isEmpty()) {
                                                                                                            priceArray = priceArray.plusElement("0.00")

                                                                                                        }
                                                                                                        nameArrayori = text
                                                                                                        dateArrayori = dateArray
                                                                                                        priceArrayori = priceArray
                                                                                                        datearr = datearr.plusElement(date)
                                                                                                        datesarr = datesarr.plusElement(dates)
                                                                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                                        descrip = descriptionArray
                                                                                                        ids = idss
                                                                                                        liids = idss


                                                                                                    } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                                                                    }
                                                                                                } else {
                                                                                                    descr = "Incomplete"
                                                                                                    statusArray = statusArray.plusElement(descr)
                                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                    nameArray = nameArray.plusElement(name)
                                                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                                    if (recsta.isNotEmpty()) {
                                                                                                        priceArray = priceArray.plusElement(tot)
                                                                                                    } else if (recsta.isEmpty()) {
                                                                                                        priceArray = priceArray.plusElement("0.00")

                                                                                                    }
                                                                                                    nameArrayori = text
                                                                                                    dateArrayori = dateArray
                                                                                                    priceArrayori = priceArray
                                                                                                    datearr = datearr.plusElement(date)
                                                                                                    datesarr = datesarr.plusElement(dates)
                                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                                    descrip = descriptionArray
                                                                                                    ids = idss
                                                                                                    liids = idss
                                                                                                }
                                                                                            } catch (e: Exception) {
                                                                                                descr = "Incomplete"
                                                                                                statusArray = statusArray.plusElement(descr)
                                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                var manufacturer = (dt["ponumber"]).toString()
                                                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                nameArray = nameArray.plusElement(name)
                                                                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                                                                if (recsta.isNotEmpty()) {
                                                                                                    priceArray = priceArray.plusElement(tot)
                                                                                                } else if (recsta.isEmpty()) {
                                                                                                    priceArray = priceArray.plusElement("0.00")

                                                                                                }
                                                                                                nameArrayori = text
                                                                                                dateArrayori = dateArray
                                                                                                priceArrayori = priceArray
                                                                                                datearr = datearr.plusElement(date)
                                                                                                datesarr = datesarr.plusElement(dates)
                                                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                bridArrayori = bridArrayori.plusElement(brids)

                                                                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                                                descrip = descriptionArray
                                                                                                ids = idss
                                                                                                liids = idss
                                                                                            }


                                                                                            progressBar9.visibility = View.GONE

                                                                                            supplier_list_second.visibility = View.VISIBLE
                                                                                            noresfo.visibility = View.GONE
                                                                                            println("If SAVE KEYYYY" + brorival)
                                                                                            val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                                            val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                                                            wlist.adapter = whatever
                                                                                        }
                                                                                        } else {
                                                                                            progressBar9.visibility = View.GONE

                                                                                            supplier_list_second.visibility = View.GONE
                                                                                            noresfo.visibility = View.VISIBLE
                                                                                        }

                                                                                    }


                                                                                }
                                                                                else{
                                                                                    progressBar9.visibility = View.GONE

                                                                                    supplier_list_second.visibility = View.GONE
                                                                                    noresfo.visibility = View.VISIBLE
                                                                            }

                                                            })
                                                        }

                                        })




                                        }


                                  /*  } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }

                }

                if ((x.trim().matches(ps.toRegex())) && (x !== reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }
                if ((s.length >= 3) && (x != reg)&&((!s.contains("/")))) {
                    noresfo.visibility = View.GONE

                    var text = arrayOf<String>()
                    var idss = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var descriptionArray = arrayOf<String>()
                    var statusArray = arrayOf<String>()
                    var statusArray1 = arrayOf<String>()
                    var urlArray1 = arrayOf<String>()
                    var statusArray2pr = arrayOf<String>()
                    var statusArray3cncl = arrayOf<String>()


                    db.collection("${broriky}_Purchase Orders").orderBy("ponumber").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)



                                            var dt = document.data
                                            var brids = (dt["branch_id"]).toString()




                                            if (brorival == brids) {

                                                var id = (document.id)
                                                var kk = dt["supp_invoice"].toString()
                                                if (kk.isEmpty()) {
                                                idss = idss.plusElement(id)

                                                iddd.setText(idss.toString())
                                                println(idss)


                                                var name = (dt["prod_nms"]).toString()
                                                var phone = (dt["supplier_Phone"]).toString()
                                                var date = (dt["req_date"]).toString()
                                                var tot = (dt["gross_tot"]).toString()
                                                var recsta = (dt["recstatus"]).toString()
                                                var dates = (dt["req_estimated"]).toString()
                                                var descripss = (dt["description"]).toString()
                                                descriptionss = descriptionss.plusElement(descripss)
                                                try {
                                                    urlArray1 = urlArray1.plusElement("")
                                                    var sta = (dt["postatus"]).toString()
                                                    if (sta.isNotEmpty()) {
                                                        if ((sta == "Complete") || (sta == "complete")) {
                                                            descr = "Complete"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")


                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                            println("Original KEYYYY" + brids)
                                                            println("LOGIINNNN KEYYYY" + brorival)
                                                            brorival = broriky


                                                        } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                            descr = "Incomplete"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                            println("Original KEYYYY" + brids)
                                                            println("LOGIINNNN KEYYYY" + brorival)
                                                            brorival = broriky


                                                        } else if (sta == "Partially Complete") {
                                                            descr = "Partially Incomplete"
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement(descr)
                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                            var manufacturer = (dt["ponumber"]).toString()
                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                            nameArray = nameArray.plusElement(name)
                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                            if (recsta.isNotEmpty()) {
                                                                priceArray = priceArray.plusElement(tot)
                                                            } else if (recsta.isEmpty()) {
                                                                priceArray = priceArray.plusElement("0.00")

                                                            }
                                                            nameArrayori = text
                                                            dateArrayori = dateArray
                                                            priceArrayori = priceArray
                                                            datearr = datearr.plusElement(date)
                                                            datesarr = datesarr.plusElement(dates)
                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                            descrip = descriptionArray
                                                            ids = idss
                                                            liids = idss
                                                            println("Original KEYYYY" + brids)
                                                            println("LOGIINNNN KEYYYY" + brorival)
                                                            brorival = broriky
                                                        } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                        }
                                                    } else {
                                                        descr = "Incomplete"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                        var manufacturer = (dt["ponumber"]).toString()
                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                        nameArray = nameArray.plusElement(name)
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                        if (recsta.isNotEmpty()) {
                                                            priceArray = priceArray.plusElement(tot)
                                                        } else if (recsta.isEmpty()) {
                                                            priceArray = priceArray.plusElement("0.00")

                                                        }
                                                        nameArrayori = text
                                                        dateArrayori = dateArray
                                                        priceArrayori = priceArray
                                                        datearr = datearr.plusElement(date)
                                                        datesarr = datesarr.plusElement(dates)
                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                        descrip = descriptionArray
                                                        ids = idss
                                                        liids = idss
                                                        println("Original KEYYYY" + brids)
                                                        println("LOGIINNNN KEYYYY" + brorival)
                                                        brorival = broriky
                                                    }
                                                } catch (e: Exception) {
                                                    descr = "Incomplete"
                                                    statusArray = statusArray.plusElement(descr)
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brids)
                                                    println("LOGIINNNN KEYYYY" + brorival)
                                                    brorival = broriky
                                                }


                                                progressBar9.visibility = View.GONE

                                                supplier_list_second.visibility = View.VISIBLE
                                                noresfo.visibility = View.GONE
                                                println("If SAVE KEYYYY" + brorival)
                                                val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                                wlist.adapter = whatever
                                            }
                                            } else {
                                                progressBar9.visibility=View.GONE

                                                supplier_list_second.visibility = View.GONE
                                                noresfo.visibility=View.VISIBLE
                                            }

                                        }


                                    } else {

                                        nameget()


                                    }


                                /*} else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }*/
                            })

                }
                else if(s.contains("/")){
                    dateget()
                }








                return
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }

            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if (searchedit.text.toString().isEmpty()) {
                    noresfo.visibility=View.GONE
                    progressBar9.visibility=View.GONE

                    supplier_list_second.visibility = View.VISIBLE


                    puract()
                }
            }
        })



        searback1.setOnClickListener {  //Image button search back action

            searchedit.setText("")
            cardsearch.visibility = View.GONE
            search.visibility=View.VISIBLE
            textView.visibility=View.VISIBLE
            imageButtonmnu.visibility=View.VISIBLE
            noresfo.visibility = View.GONE
            progressBar9.visibility=View.GONE

            supplier_list_second.visibility = View.VISIBLE
            puract()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }





        //Navigate to purchase order details  activity (Supplier_thirdMainActivity) for making supplier invoice.

supplier_list_second.setOnItemClickListener { parent, views, position, id ->

        val i=Intent(this,Supplier_thirdMainActivity::class.java)

        i.putExtra("id",liids[position])
    i.putExtra("brid",bridArrayori[position])
    i.putExtra("supname",supnamearr[position])
    i.putExtra("supmob",supphonearr[position])

    i.putExtra("viewsuppin", viewsuppin)
    i.putExtra("addsuppin", addsuppin)
    i.putExtra("deletesuppin", deletesuppin)
    i.putExtra("editsuppin", editesuppin)
    i.putExtra("transfersuppin", transfersuppin)
    i.putExtra("exportsuppin", exportsuppin)




    i.putExtra("viewpurord", viewpurord)
    i.putExtra("addpurord", addpurord)
    i.putExtra("deletepurord", deletepurord)
    i.putExtra("editpurord", editepurord)
    i.putExtra("transferpurord", transferpurord)
    i.putExtra("exportpurord", exportpurord)
    i.putExtra("sendpurord", sendpurpo)



    i.putExtra("viewpurreq", viewpurreq)
    i.putExtra("addpurreq", addpurreq)
    i.putExtra("deletepurreq", deletepurreq)
    i.putExtra("editpurreq", editepurreq)
    i.putExtra("transferpurreq", transferpurreq)
    i.putExtra("exportpurreq", exportpurreq)









        i.putExtra("from_suppin","supp_invoice")
        startActivity(i)
    overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
    finish()

}
        userback.setOnClickListener {
           onBackPressed()
        }
    }



    //----------------------DATE GET------------------------------//


    fun dateget() {
        if ((s.length>=3)||(s.length>=3)) {
            noresfo.visibility = View.GONE

            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var urlArray1 = arrayOf<String>()
            var statusArray2pr = arrayOf<String>()
            var statusArray3cncl = arrayOf<String>()



            db.collection("${broriky}_Purchase Orders").orderBy("req_date").startAt(numberstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)

                                    var dt = document.data
                                    var brids = (dt["branch_id"]).toString()




                                    if (brorival == brids) {


                                        var id = (document.id)
                                        var kk = dt["supp_invoice"].toString()
                                        if (kk.isEmpty()) {
                                        idss = idss.plusElement(id)
                                        iddd.setText(idss.toString())
                                        println(idss)


                                        var name = (dt["prod_nms"]).toString()
                                        var phone = (dt["supplier_Phone"]).toString()
                                        var date = (dt["req_date"]).toString()
                                        var tot = (dt["gross_tot"]).toString()
                                        var recsta = (dt["recstatus"]).toString()
                                        var dates = (dt["req_estimated"]).toString()
                                        var descripss = (dt["description"]).toString()
                                        descriptionss = descriptionss.plusElement(descripss)
                                        try {
                                            urlArray1 = urlArray1.plusElement("")
                                            var sta = (dt["postatus"]).toString()
                                            if (sta.isNotEmpty()) {
                                                if ((sta == "Complete") || (sta == "complete")) {
                                                    descr = "Complete"
                                                    statusArray1 = statusArray1.plusElement(descr)
                                                    statusArray = statusArray.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss


                                                } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                    descr = "Incomplete"
                                                    statusArray = statusArray.plusElement(descr)
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss


                                                } else if (sta == "Partially Complete") {
                                                    descr = "Partially Incomplete"
                                                    statusArray = statusArray.plusElement("")
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement(descr)
                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss


                                                } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                }
                                            } else {
                                                descr = "Incomplete"
                                                statusArray = statusArray.plusElement(descr)
                                                statusArray1 = statusArray1.plusElement("")
                                                statusArray2pr = statusArray2pr.plusElement("")
                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                var manufacturer = (dt["ponumber"]).toString()
                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                nameArray = nameArray.plusElement(name)
                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                if (recsta.isNotEmpty()) {
                                                    priceArray = priceArray.plusElement(tot)
                                                } else if (recsta.isEmpty()) {
                                                    priceArray = priceArray.plusElement("0.00")

                                                }
                                                nameArrayori = text
                                                dateArrayori = dateArray
                                                priceArrayori = priceArray
                                                datearr = datearr.plusElement(date)
                                                datesarr = datesarr.plusElement(dates)
                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                bridArrayori = bridArrayori.plusElement(brids)

                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                descrip = descriptionArray
                                                ids = idss
                                                liids = idss


                                            }
                                        } catch (e: Exception) {
                                            descr = "Incomplete"
                                            statusArray = statusArray.plusElement(descr)
                                            statusArray1 = statusArray1.plusElement("")
                                            statusArray2pr = statusArray2pr.plusElement("")
                                            statusArray3cncl = statusArray3cncl.plusElement("")


                                            var manufacturer = (dt["ponumber"]).toString()
                                            text = text.plusElement((dt["supplier_name"]).toString())
                                            nameArray = nameArray.plusElement(name)
                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                            if (recsta.isNotEmpty()) {
                                                priceArray = priceArray.plusElement(tot)
                                            } else if (recsta.isEmpty()) {
                                                priceArray = priceArray.plusElement("0.00")

                                            }
                                            nameArrayori = text
                                            dateArrayori = dateArray
                                            priceArrayori = priceArray
                                            datearr = datearr.plusElement(date)
                                            datesarr = datesarr.plusElement(dates)
                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                            bridArrayori = bridArrayori.plusElement(brids)

                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                            descrip = descriptionArray
                                            ids = idss
                                            liids = idss

                                        }


                                        progressBar9.visibility = View.GONE

                                        supplier_list_second.visibility = View.VISIBLE
                                        noresfo.visibility = View.GONE
                                        println("If SAVE KEYYYY" + brorival)
                                        val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                        val wlist = findViewById<ListView>(R.id.purchase_list) as ListView
                                        wlist.adapter = whatever
                                    }
                                    } else {

                                        progressBar9.visibility=View.GONE

                                        supplier_list_second.visibility = View.GONE
                                        noresfo.visibility=View.VISIBLE
                                    }


                                }


                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                db.collection("${broriky}_Purchase Orders").orderBy("req_estimated").startAt(numberstr).endAt(esc)
                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                            if (e != null) {
                                            }
                                            if (value.isEmpty == false) {
                                                for (document in value) {

                                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                                        println(document.data)

                                                        var dt = document.data
                                                        var brids = (dt["branch_id"]).toString()




                                                        if (brorival == brids) {



                                                            var id = (document.id)
                                                            var kk = dt["supp_invoice"].toString()
                                                            if (kk.isEmpty()) {
                                                                idss = idss.plusElement(id)
                                                                iddd.setText(idss.toString())
                                                                println(idss)


                                                                var name = (dt["prod_nms"]).toString()
                                                                var phone = (dt["supplier_Phone"]).toString()
                                                                var date = (dt["req_date"]).toString()
                                                                var tot = (dt["gross_tot"]).toString()
                                                                var recsta = (dt["recstatus"]).toString()
                                                                var dates = (dt["req_estimated"]).toString()
                                                                var descripss = (dt["description"]).toString()
                                                                descriptionss = descriptionss.plusElement(descripss)
                                                                try {
                                                                    urlArray1 = urlArray1.plusElement("")
                                                                    var sta = (dt["postatus"]).toString()
                                                                    if (sta.isNotEmpty()) {
                                                                        if ((sta == "Complete") || (sta == "complete")) {
                                                                            descr = "Complete"
                                                                            statusArray1 = statusArray1.plusElement(descr)
                                                                            statusArray = statusArray.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")


                                                                            var manufacturer = (dt["ponumber"]).toString()
                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                            if (recsta.isNotEmpty()) {
                                                                                priceArray = priceArray.plusElement(tot)
                                                                            } else if (recsta.isEmpty()) {
                                                                                priceArray = priceArray.plusElement("0.00")

                                                                            }
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(date)
                                                                            datesarr = datesarr.plusElement(dates)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                            descrip = descriptionArray
                                                                            ids = idss
                                                                            liids = idss


                                                                        } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                                            descr = "Incomplete"
                                                                            statusArray = statusArray.plusElement(descr)
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                                            var manufacturer = (dt["ponumber"]).toString()
                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                            if (recsta.isNotEmpty()) {
                                                                                priceArray = priceArray.plusElement(tot)
                                                                            } else if (recsta.isEmpty()) {
                                                                                priceArray = priceArray.plusElement("0.00")

                                                                            }
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(date)
                                                                            datesarr = datesarr.plusElement(dates)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                            descrip = descriptionArray
                                                                            ids = idss
                                                                            liids = idss


                                                                        } else if (sta == "Partially Complete") {
                                                                            descr = "Partially Incomplete"
                                                                            statusArray = statusArray.plusElement("")
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement(descr)
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                                                            var manufacturer = (dt["ponumber"]).toString()
                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                            if (recsta.isNotEmpty()) {
                                                                                priceArray = priceArray.plusElement(tot)
                                                                            } else if (recsta.isEmpty()) {
                                                                                priceArray = priceArray.plusElement("0.00")

                                                                            }
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(date)
                                                                            datesarr = datesarr.plusElement(dates)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArrayori.plusElement(brids)

                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                            descrip = descriptionArray
                                                                            ids = idss
                                                                            liids = idss


                                                                        } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                                        }
                                                                    } else {
                                                                        descr = "Incomplete"
                                                                        statusArray = statusArray.plusElement(descr)
                                                                        statusArray1 = statusArray1.plusElement("")
                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                                        var manufacturer = (dt["ponumber"]).toString()
                                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                                        nameArray = nameArray.plusElement(name)
                                                                        dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                        if (recsta.isNotEmpty()) {
                                                                            priceArray = priceArray.plusElement(tot)
                                                                        } else if (recsta.isEmpty()) {
                                                                            priceArray = priceArray.plusElement("0.00")

                                                                        }
                                                                        nameArrayori = text
                                                                        dateArrayori = dateArray
                                                                        priceArrayori = priceArray
                                                                        datearr = datearr.plusElement(date)
                                                                        datesarr = datesarr.plusElement(dates)
                                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                                        bridArrayori = bridArrayori.plusElement(brids)

                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                        descrip = descriptionArray
                                                                        ids = idss
                                                                        liids = idss


                                                                    }
                                                                } catch (e: Exception) {
                                                                    descr = "Incomplete"
                                                                    statusArray = statusArray.plusElement(descr)
                                                                    statusArray1 = statusArray1.plusElement("")
                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                                    var manufacturer = (dt["ponumber"]).toString()
                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                    nameArray = nameArray.plusElement(name)
                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)
                                                                    if (recsta.isNotEmpty()) {
                                                                        priceArray = priceArray.plusElement(tot)
                                                                    } else if (recsta.isEmpty()) {
                                                                        priceArray = priceArray.plusElement("0.00")

                                                                    }
                                                                    nameArrayori = text
                                                                    dateArrayori = dateArray
                                                                    priceArrayori = priceArray
                                                                    datearr = datearr.plusElement(date)
                                                                    datesarr = datesarr.plusElement(dates)
                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                                    descrip = descriptionArray
                                                                    ids = idss
                                                                    liids = idss


                                                                }


                                                                progressBar9.visibility = View.GONE

                                                                supplier_list_second.visibility = View.VISIBLE
                                                                noresfo.visibility = View.GONE
                                                                println("If SAVE KEYYYY" + brorival)
                                                                val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                val wlist = findViewById<ListView>(R.id.purchase_list) as ListView
                                                                wlist.adapter = whatever
                                                            }
                                                        } else {

                                                            progressBar9.visibility = View.GONE

                                                            supplier_list_second.visibility = View.GONE
                                                            noresfo.visibility = View.VISIBLE
                                                        }


                                                    }


                                                }
                                                else{
                                                    progressBar9.visibility = View.GONE

                                                    supplier_list_second.visibility = View.GONE
                                                    noresfo.visibility = View.VISIBLE
                                            }

                            })
                            }


                        /*} else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })

        }
        else{
            noresfo.visibility = View.VISIBLE
            supplier_list_second.visibility = View.GONE
            progressBar9.visibility=View.GONE

        }
    }








    fun idget() {
        if ((s.length >= 4) && (x !== reg)) {
            noresfo.visibility = View.GONE

            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var urlArray1 = arrayOf<String>()
            var statusArray2pr = arrayOf<String>()
            var statusArray3cncl = arrayOf<String>()


            db.collection("${broriky}_Purchase Orders").orderBy("ponumber").startAt(upstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)


                                    var dt = document.data
                                    var id = (document.id)
                                    var kk = dt["supp_invoice"].toString()
                                    if (kk.isEmpty()) {
                                        idss = idss.plusElement(id)
                                        iddd.setText(idss.toString())
                                        println(idss)


                                        var name = (dt["prod_nms"]).toString()
                                        var brids = (dt["branch_id"]).toString()
                                        var phone = (dt["supplier_Phone"]).toString()
                                        var date = (dt["req_date"]).toString()
                                        var tot = (dt["gross_tot"]).toString()
                                        var recsta = (dt["recstatus"]).toString()
                                        var dates = (dt["req_estimated"]).toString()
                                        var descripss = (dt["description"]).toString()
                                        descriptionss = descriptionss.plusElement(descripss)
                                        try {
                                            urlArray1 = urlArray1.plusElement("")
                                            var sta = (dt["postatus"]).toString()
                                            if (sta.isNotEmpty()) {
                                                if ((sta == "Complete") || (sta == "complete")) {
                                                    descr = "Complete"
                                                    statusArray1 = statusArray1.plusElement(descr)
                                                    statusArray = statusArray.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brids)
                                                    println("LOGIINNNN KEYYYY" + brorival)
                                                    brorival = broriky


                                                } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                    descr = "Incomplete"
                                                    statusArray = statusArray.plusElement(descr)
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")

                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brids)
                                                    println("LOGIINNNN KEYYYY" + brorival)
                                                    brorival = broriky


                                                } else if (sta == "Partially Complete") {
                                                    descr = "Partially Incomplete"
                                                    statusArray = statusArray.plusElement("")
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement(descr)
                                                    statusArray3cncl = statusArray3cncl.plusElement("")


                                                    var manufacturer = (dt["ponumber"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                    if (recsta.isNotEmpty()) {
                                                        priceArray = priceArray.plusElement(tot)
                                                    } else if (recsta.isEmpty()) {
                                                        priceArray = priceArray.plusElement("0.00")

                                                    }
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArrayori.plusElement(brids)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)


                                                    descrip = descriptionArray
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brids)
                                                    println("LOGIINNNN KEYYYY" + brorival)
                                                    brorival = broriky


                                                } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {


                                                }
                                            } else {
                                                descr = "Incomplete"
                                                statusArray = statusArray.plusElement(descr)
                                                statusArray1 = statusArray1.plusElement("")
                                                statusArray2pr = statusArray2pr.plusElement("")
                                                statusArray3cncl = statusArray3cncl.plusElement("")

                                                var manufacturer = (dt["ponumber"]).toString()
                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                nameArray = nameArray.plusElement(name)
                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                                if (recsta.isNotEmpty()) {
                                                    priceArray = priceArray.plusElement(tot)
                                                } else if (recsta.isEmpty()) {
                                                    priceArray = priceArray.plusElement("0.00")

                                                }
                                                nameArrayori = text
                                                dateArrayori = dateArray
                                                priceArrayori = priceArray
                                                datearr = datearr.plusElement(date)
                                                datesarr = datesarr.plusElement(dates)
                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                bridArrayori = bridArrayori.plusElement(brids)

                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                descrip = descriptionArray
                                                ids = idss
                                                liids = idss
                                                println("Original KEYYYY" + brids)
                                                println("LOGIINNNN KEYYYY" + brorival)
                                                brorival = broriky


                                            }
                                        } catch (e: Exception) {
                                            descr = "Incomplete"
                                            statusArray = statusArray.plusElement(descr)
                                            statusArray1 = statusArray1.plusElement("")
                                            statusArray2pr = statusArray2pr.plusElement("")
                                            statusArray3cncl = statusArray3cncl.plusElement("")

                                            var manufacturer = (dt["ponumber"]).toString()
                                            text = text.plusElement((dt["supplier_name"]).toString())
                                            nameArray = nameArray.plusElement(name)
                                            dateArray = dateArray.plusElement("Ordered on " + date + ".Required on" + dates)
                                            if (recsta.isNotEmpty()) {
                                                priceArray = priceArray.plusElement(tot)
                                            } else if (recsta.isEmpty()) {
                                                priceArray = priceArray.plusElement("0.00")

                                            }
                                            nameArrayori = text
                                            dateArrayori = dateArray
                                            priceArrayori = priceArray
                                            datearr = datearr.plusElement(date)
                                            datesarr = datesarr.plusElement(dates)
                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                            bridArrayori = bridArrayori.plusElement(brids)

                                            descriptionArray = descriptionArray.plusElement(manufacturer)


                                            descrip = descriptionArray
                                            ids = idss
                                            liids = idss
                                            println("Original KEYYYY" + brids)
                                            println("LOGIINNNN KEYYYY" + brorival)
                                            brorival = broriky


                                        }


                                        if (brorival == brids) {
                                            progressBar9.visibility = View.GONE

                                            supplier_list_second.visibility = View.VISIBLE
                                            noresfo.visibility = View.GONE
                                            println("If SAVE KEYYYY" + brorival)
                                            val whatever = req_search_adap(this@MainSecondSupplier_secondActivity, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                            val wlist = findViewById<ListView>(R.id.purchase_list) as ListView
                                            wlist.adapter = whatever
                                        } else {

                                            progressBar9.visibility = View.GONE

                                            supplier_list_second.visibility = View.GONE
                                            noresfo.visibility = View.VISIBLE
                                        }
                                    }
                                    else if(kk.isNotEmpty()){

                                    }

                                }


                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                dateget()
                                noresfo.visibility = View.VISIBLE
                                supplier_list_second.visibility = View.GONE
                                progressBar9.visibility=View.GONE
                            }


                        /*} else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })
        }
        else{
            noresfo.visibility=View.VISIBLE
            supplier_list_second.visibility=View.GONE
            progressBar9.visibility= View.GONE
        }
    }
    override fun onBackPressed()

    {

        if(cardsearch.visibility==View.VISIBLE){
            cardsearch.visibility=View.GONE
            noresfo.visibility=View.GONE
            searchedit.setText("")
            search.visibility=View.VISIBLE
            textView.visibility=View.VISIBLE
            imageButtonmnu.visibility=View.VISIBLE
            puract()
        }
        else{
            val k=Intent(this,Supplier_first_MainActivity::class.java)
            k.putExtra("from_ver", "main")
            k.putExtra("brkey", broriky)
            k.putExtra("viewsuppin", viewsuppin)
            k.putExtra("addsuppin", addsuppin)
            k.putExtra("deletesuppin", deletesuppin)
            k.putExtra("editsuppin", editesuppin)
            k.putExtra("transfersuppin", transfersuppin)
            k.putExtra("exportsuppin", exportsuppin)


            k.putExtra("viewpurord", viewpurord)
            k.putExtra("addpurord", addpurord)
            k.putExtra("deletepurord", deletepurord)
            k.putExtra("editpurord", editepurord)
            k.putExtra("transferpurord", transferpurord)
            k.putExtra("exportpurord", exportpurord)




            k.putExtra("viewpurreq", viewpurreq)
            k.putExtra("addpurreq", addpurreq)
            k.putExtra("deletepurreq", deletepurreq)
            k.putExtra("editpurreq", editepurreq)
            k.putExtra("transferpurreq", transferpurreq)
            k.putExtra("exportpurreq", exportpurreq)






            k.putExtra("sendpurord", sendpurpo)







            startActivity(k)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }




    //------------------------------Get purchase orders from online db and list out.------------------------//
    fun puract() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(true)
        pDialog.show();
        brorival = broriky

        db.collection("${broriky}_Purchase Orders")
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }

                    if (value.isEmpty == false) {
                        imageView10.visibility=View.GONE
                        db.collection("${broriky}_Purchase Orders").orderBy("ponumber", Query.Direction.DESCENDING).whereEqualTo("branch_id", brorival).limit(15)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                    var text = arrayOf<String>()
                                    var idss = arrayOf<String>()
                                    var bridss = arrayOf<String>()
                                    var nameArray = arrayOf<String>()
                                    var dateArray = arrayOf<String>()
                                    var priceArray = arrayOf<String>()
                                    var descriptionArray = arrayOf<String>()
                                    var statusArray = arrayOf<String>()
                                    var statusArray1 = arrayOf<String>()
                                    var urlArray1 = arrayOf<String>()



                                    var statusArray2pr = arrayOf<String>()
                                    var statusArray3cncl = arrayOf<String>()

                                    if (e != null) {
                                        Log.w("", "Listen failed.", e)
                                        return@EventListener
                                    }

                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)

                                            var dt = document.data
                                            var id = (document.id)

                                            var kk = dt["supp_invoice"].toString()
                                            if (kk.isEmpty()) {
                                                idss = idss.plusElement(id)
                                                iddd.setText(idss.toString())
                                                println(idss)


                                                var name = (dt["prod_nms"]).toString()
                                                var brids = (dt["branch_id"]).toString()
                                                var phone = (dt["supplier_Phone"]).toString()
                                                var date = (dt["req_date"]).toString()
                                                var tot = (dt["gross_tot"]).toString()
                                                var recsta = (dt["recstatus"]).toString()

                                                var dates = (dt["req_estimated"]).toString()
                                                var descripss = (dt["description"]).toString()
                                                descriptionss = descriptionss.plusElement(descripss)
                                                try {

                                                    var sta = (dt["postatus"]).toString()
                                                    if (sta.isNotEmpty()) {
                                                        urlArray1 = urlArray1.plusElement("")

                                                        if ((sta == "Complete") || (sta == "complete")) {
                                                            descr = "Complete"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")


                                                        } else if ((sta == "InComplete") || (sta == "Incomplete")) {
                                                            descr = "Incomplete"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                        } else if (sta == "Partially Complete") {
                                                            descr = "Partially Complete"
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement(descr)
                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                        } else if ((sta == "cancel") || (sta == "Cancel") || (sta == "cancelled") || (sta == "Cancelled")) {
                                                            descr = "Cancelled"
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement(descr)

                                                        }
                                                    } else {
                                                        descr = "Incomplete"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                    }
                                                } catch (e: Exception) {
                                                    descr = "InComplete"
                                                    statusArray = statusArray.plusElement(descr)
                                                    statusArray1 = statusArray1.plusElement("")
                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                }
                                                var manufacturer = (dt["ponumber"]).toString()
                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                nameArray = nameArray.plusElement(name)
                                                dateArray = dateArray.plusElement("Ordered on " + date + ".Required by " + dates)

                                                if (recsta.isNotEmpty()) {
                                                    priceArray = priceArray.plusElement(tot)
                                                } else if (recsta.isEmpty()) {
                                                    priceArray = priceArray.plusElement("0.00")

                                                }



                                                nameArrayori = text
                                                dateArrayori = dateArray
                                                priceArrayori = priceArray
                                                datearr = datearr.plusElement(date)
                                                datesarr = datesarr.plusElement(dates)
                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                bridArrayori = bridArrayori.plusElement(brids)


                                                supnamearr = text
                                                supphonearr = phoneArrayori

                                                descriptionArray = descriptionArray.plusElement(manufacturer)


                                                descrip = descriptionArray
                                                ids = idss
                                                liids = idss
                                                /*      swipeContainer.setRefreshing(false);*/

                                            }
                                            else if(kk.isNotEmpty()){

                                            }
                                        }

                                        text = text.plusElement("")
                                        idss = idss.plusElement("")
                                        nameArray = nameArray.plusElement("")
                                        dateArray = dateArray.plusElement("")
                                        priceArray = priceArray.plusElement("NA")
                                        descriptionArray = descriptionArray.plusElement("")
                                        statusArray = statusArray.plusElement("")
                                        statusArray1 = statusArray1.plusElement("")
                                        urlArray1 = urlArray1.plusElement("")
                                        statusArray2pr = statusArray2pr.plusElement("")
                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                        val whatever = purchase_list_adap(this, urlArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray,
                                                statusArray, statusArray1, statusArray2pr, statusArray3cncl)

                                        val wlist = findViewById<ListView>(R.id.supplier_list_second) as ListView
                                        wlist.adapter = whatever
                                        pDialog.dismiss()


                                    } else {
                                        pDialog.dismiss()
                                    }
                                })
                    }

                    else {
                        pDialog.dismiss()
                        imageView10.visibility=View.VISIBLE
                    }
                })


    }
    companion object {
        //Listens inetrnet status whether net is on/off. .


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                /// if connection is off then all views becomes disable


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                /// if connection is off then all views becomes enabled

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }
    fun net_status():Boolean{  // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
