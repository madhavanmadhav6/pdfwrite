package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AbsListView
import android.widget.ListView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.serv_sub_category_list.*
import java.net.URL

class serv_sub_category_list : AppCompatActivity() {
    var db = FirebaseFirestore.getInstance()
    var TAG = "tag"
    lateinit var di : String

    data class s(var cat: String)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.serv_sub_category_list)


        net_status()

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        //getting key from serv_cate_add activity
        val key = intent.getStringExtra("key").toString()
        val sub = key+"_subcategory"
fun gets() {
    db.collection(sub)
            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Loading...")
                pDialog.setCancelable(false)
                pDialog.show();
                var category = arrayListOf<String>()//all list category name
                var ico = arrayListOf<String>()//all list image url
                var img_name = arrayListOf<String>()//all list image name
                var d = arrayListOf<String>()//all list id's
                var dlt = arrayListOf<String>()//delete id's
                var dltimagname = arrayListOf<String>()//delete image name's
                val list_item = ArrayList<String>()//temp
                if (e != null) {
                    Log.w("", "Listen failed.", e)
                    return@EventListener
                }
                if(value.isEmpty==false) {
                    for (doc in value) {
                        //if (doc.get("nm") != null) {
                        //cities.add(doc.getString("name"))
                        //var dt = document.data
                        var cate = doc.getString("cat")
                        var ur = doc.getString("ur")
                        var name = doc.getString("imgname")
                        var dis = doc.getString("disc")
                        d.add(doc.id)
                        category.add(cate)

                        ico.add(ur.toString())
                        img_name.add(name)
                        pDialog.dismiss()
                        swipeContainer.setRefreshing(false);
                        //}
                    }
                }
                else{
                    pDialog.dismiss()
                }
                val list = listAdapter_serv(this,ico,category,img_name,d)
                val lists = findViewById<ListView>(R.id.serv_sub_cate_list) as ListView
                lists.adapter = list


                serv_sub_cate_list.setOnItemClickListener { adapterView, view, i, l ->
                    val b = Intent(this, serv_sub_cate_add::class.java)
                    b.putExtra("id", d[i])
                    b.putExtra("key", key)
                    startActivity(b)
                }
                serv_sub_cate_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
                serv_sub_cate_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                    override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                        //capture total checked items
                        var checkedCount = serv_sub_cate_list.getCheckedItemCount()
                        val l = d.get(position)
                        val imgname = img_name.get(position)
                        Log.i(TAG, " " + l)
                        //setting CAB title
                        mode.setTitle("" + checkedCount + " Selected")
                        Log.d(TAG, " " + id)
                        //list_item.add(id);
                        if (checked) {
                            list_item.add(id.toString()) // Add to list when checked ==  true
                            dlt.add(l)
                            dltimagname.add(imgname)
                            Log.i(TAG, "itm " + dlt.size)
                            //Log.i(TAG,"itm "+dlt.get(position))
                        } else {
                            list_item.remove(id.toString())
                            dlt.remove(l)
                            dltimagname.remove(imgname)
                            Log.i(TAG, "itm " + dlt.size)
                            Log.d(TAG, "id  " + id)
                        }

                    }

                    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                        //Inflate the CAB
                        serv_sub_cate_toolbar.visibility = View.GONE
                        mode.getMenuInflater().inflate(R.menu.list, menu);
                        return true;
                    }

                    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                        return false
                    }

                    override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                        val builder = AlertDialog.Builder(this@serv_sub_category_list)
                        with(builder) {
                            setTitle("Delete from category?")
                            setMessage("Are you sure want to delete?")
                            setPositiveButton("Yes") { dialog, whichButton ->
                                val deleteSize = dlt.size
                                Log.i("tsdfs", "  " + dlt.size)

                                val itemId = item.getItemId()
                                if (itemId == R.id.delete) {
                                    for (a in dlt) {
                                        db.collection(sub).document(a)
                                                .delete()
                                                .addOnSuccessListener {
                                                    for (i in dltimagname) {
                                                        val storage = FirebaseStorage.getInstance()
                                                        val storageRef = storage.getReference()
                                                        val imagesRef = storageRef.child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    dltimagname.clear()
                                                                }
                                                    }
                                                    dlt.clear()
                                                    Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                                    // save_progress.visibility = android.view.View.GONE

                                                }
                                                .addOnFailureListener {
                                                    Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                                    //save_progress.visibility = android.view.View.GONE
                                                }
                                    }
                                }
                                /* checkedCount = 0*/
                                list_item.clear()
                                mode.finish()


                            }
                            setNegativeButton("No") { dialog, whichButton ->
                                list_item.clear()
                                mode.finish()
                                dialog.dismiss()
                            }
                            val dialog = builder.create()
                            dialog.show()
                        }


                        return true
                    }

                    override fun onDestroyActionMode(mode: ActionMode) {
                        // refresh list after deletion
                        dlt.clear()
                        serv_sub_cate_toolbar.visibility = View.VISIBLE
                    }
                })
            })
}

        gets()



        swipeContainer.setOnRefreshListener {
            gets()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)

        serv_sub_cate_back.setOnClickListener {
            finish()
        }
        sc_sub_add.setOnClickListener {
            val intent = Intent(applicationContext,serv_sub_cate_add::class.java)
            intent.putExtra("key",key)
            startActivity(intent)

        }
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
