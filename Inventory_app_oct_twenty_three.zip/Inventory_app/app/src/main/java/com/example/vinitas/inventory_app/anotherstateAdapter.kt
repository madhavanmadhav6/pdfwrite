package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/**
 * Created by vinitas stock on 04-01-2018.
 */
class anotherstateAdapter(
        private val context: Activity,
        private val ori: Array<String>,
        private val tex: Array<String>,
        private val pl1: Array<String>,
        private val desti: Array<String>,
        private val text: Array<String>,
        private val pl2: Array<String>,
        private val descrip: Array<String>,
        private val amo: Array<String>) : ArrayAdapter<Any>(context, R.layout.anotherstate_list, ori) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.anotherstate_list, null, true)

        //this code gets references to objects in the listview_row.xml file
        val origin = rowView.findViewById<TextView>(R.id.origin1) as TextView
        val text1 = rowView.findViewById<TextView>(R.id.textView2) as TextView
        val place = rowView.findViewById<TextView>(R.id.place1) as TextView
        val destination = rowView.findViewById<TextView>(R.id.desti1) as TextView
        val text2 = rowView.findViewById<TextView>(R.id.textView5) as TextView
        val place2 = rowView.findViewById<TextView>(R.id.place2) as TextView
        val desc = rowView.findViewById<TextView>(R.id.desc1) as TextView
        val amount = rowView.findViewById<TextView>(R.id.textView8) as TextView

        //this code sets the values of the objects to values from the arrays
        origin.text = ori[position]
        text1.text = tex[position]
        place.text = pl1[position]
        destination.text = desti[position]
        text2.text = text[position]
        place2.text = pl2[position]
        desc.text = descrip[position]
        amount.text = amo[position]
        //infoTextField.text = infoArray[position]
        //imageView.setImageResource(imageIDarray[position])

        return rowView

    }
}