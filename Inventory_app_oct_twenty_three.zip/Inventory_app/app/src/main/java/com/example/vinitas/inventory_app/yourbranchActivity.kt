package com.example.vinitas.inventory_app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.util.Log
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.android.gms.vision.barcode.Barcode
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_yourbranch.*

class yourbranchActivity : AppCompatActivity() {
    // Session Manager Class

    var db = FirebaseFirestore.getInstance()
    internal lateinit var session: SessionManagement
    var a = String()
    var state= String()
    var pincd= String()
    var brnchname= String()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yourbranch)

        net_status()  //Check net status

        //BAck to scan activity
        back4.setOnClickListener {
            val a=Intent(this@yourbranchActivity,ScanActivity::class.java)
            startActivity(a)
            finish()
        }

        button2.setOnClickListener {
            val a=Intent(this@yourbranchActivity,ScanActivity::class.java)
            startActivity(a)
            finish()
        }


        try {
        val al = intent.getStringExtra("barcode")
        bid.setText(al)
        a = bid.text.toString()
    } catch (e: Exception) {

    }




        //---------------------------------Get branch name which is relevent to the result of scanned barcode----------------------//
        try {
            if (net_status() == true) {
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Processing...")
                pDialog.setCancelable(false);
                pDialog.show();
                db.collection("branch").document(bid.text.toString())
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.result.exists()) {

                                if (task.result != null) {
                                    Log.d("data", "is" + task.result.data)
                                    branch4.setText(task.result.get("nm").toString())
                                    brnchname=task.result.get("nm").toString()
                                    pDialog.dismiss()
                                    state = task.result.get("st").toString()
                                    pincd = task.result.get("pcd").toString()

                                    Continue.isEnabled = true

                                } else {
                                    Log.d("data", "is not here")
                                }
                            } else {
                                pDialog.dismiss()
                                println("Invalid branch")

                                val builder = AlertDialog.Builder(this)
                                with(builder) {
                                    setTitle("Invalid branch")
                                    setMessage("Scanned branch doesn't exist.")
                                    setPositiveButton("Try again") { dialog, whichButton ->


                                        val a = Intent(this@yourbranchActivity, ScanActivity::class.java)
                                        startActivity(a)
                                        finish()
                                        dialog.dismiss()

                                    }
                                    setNegativeButton("cancel") { dialog, whichButton ->
                                        dialog.dismiss()
                                        Continue.isEnabled = false
                                    }
                                    val dialog = builder.create()

                                    dialog.show()
                                }

                            }


                            // Session Manager
                            session = SessionManagement(applicationContext)

                            /* Toast.makeText(applicationContext, "User Login Status: " + session.isLoggedIn, Toast.LENGTH_LONG).show()
        if (session.isLoggedIn==true){
            val b= Intent(this,PinActivity::class.java)
            b.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(b)
            finish()
        }*/



                            //--------------------------Navigate to pinACtivity-------------------------//

                            Continue.setOnClickListener {
                                /* val b = Intent(applicationContext,PinActivity::class.java)
            startActivity(b)*/

                                // Creating user login session
                                // For testing i am stroing name, email as follow
                                // Use user real data

                                if (bid.text.isNotEmpty()) {
                                    session.createLoginSession(a, pincd, state,brnchname)

                                    // Staring MainActivity
                                    val i = Intent(applicationContext, PinActivity::class.java)
                                    i.putExtra("brid", bid.text.toString())

                                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(i)
                                    finish()

                                }

                            }
                        }
            }
            else {
                Toast.makeText(this, "No internet connection", Toast.LENGTH_LONG).show()
                val buider = AlertDialog.Builder(this)
                with(buider){


                setTitle("Connection Failed")
               setMessage("Unable to set branch.please try again later.")
               setCancelable(false)
               setPositiveButton("Ok") { dialog, whichButton ->
                    dialog.dismiss()
                    val a = Intent(this@yourbranchActivity, ScanActivity::class.java)
                    startActivity(a)
                    finish()

                }
                val dialog = buider.create()
                dialog.show()

                }
            }
        }
            catch(e:Exception){


            }


    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
