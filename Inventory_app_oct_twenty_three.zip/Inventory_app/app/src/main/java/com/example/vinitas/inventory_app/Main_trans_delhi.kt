package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore



import kotlinx.android.synthetic.main.stk_trans_delhi.*

class Main_trans_delhi : AppCompatActivity() {

    var groschk= String()
    var names = String()
    var namesphones = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var orikys= String()
    var brky= String()
    var smlistidss= String()
    var idli= String()
    var tallyar= String()
    var receivear= String()

    var pzsave:Int = 0
    var asave=arrayOf<String>()
    var dsysave=arrayOf<String>()
    var fysave=arrayOf<String>()
    var gysave=arrayOf<String>()
    var hysave=arrayOf<String>()
    var kysave=arrayOf<String>()
    var mysave=arrayOf<String>()
    var nysave=arrayOf<String>()
    var oysave=arrayOf<String>()
    var pysave=arrayOf<String>()
    var tallysave=arrayOf<String>()
    var receivedsave=arrayOf<String>()
    var idddsave= arrayOf<String>()
    var lysave= arrayOf<String>()
    var immysave= arrayOf<String>()
    var editchange= String()

    var db = FirebaseFirestore.getInstance()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""





    var igsted=String()
    var igtot=String()
    var cestot=String()
    var grosstot=String()
    var halfpr:Float=0.0F

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.stk_trans_delhi)


        net_status()

        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }





        //VALUES FOR TAX DETAILS



        val bundle = intent.extras
        var frm = bundle!!.get("fromstate").toString()

        ots_update.visibility= View.GONE
        edit.visibility=View.VISIBLE


        otherbcd_pid.isEnabled=false
        otherhsc.isEnabled=false
        other_prd_nm.isEnabled=false
        other_price.isEnabled=false
        oth_br_quant.isEnabled=false
        other_total.isEnabled=false
        cess_edt_trans.isEnabled=false
        other_igst_vi.isEnabled=false

        edit.setOnClickListener{
            println("EDT PERMISSION"+editetransano)
            if(editetransano=="true"){

                edit.visibility=View.GONE
                ots_update.visibility=View.VISIBLE

                otherbcd_pid.isEnabled=true
                otherhsc.isEnabled=true
                other_prd_nm.isEnabled=true
                other_price.isEnabled=true
                oth_br_quant.isEnabled=true
                other_total.isEnabled=true
                cess_edt_trans.isEnabled=true
                other_igst_vi.isEnabled=true

            }
            else if(editetransano=="false"){
                popup("Update")
            }
        }



        var a= bundle.get("otherst_pnm") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy=bundle.get("otherst_phsn") as Array<String>
        val ly=bundle.get("otherst_pmanu")    as Array<String>
        val fy=bundle.get("otherst_barcode") as Array<String>
        val gy=bundle.get("otherst_quan")    as Array<String>
        val hy=bundle.get("otherst_price")   as Array<String>
        val ky=bundle.get("otherst_tot")     as Array<String>
        val my=bundle.get("otherst_cessup")  as Array<String>
        val ny=bundle.get("otherst_igst") as Array<String>
        val oy=bundle.get("otherst_igsttotal") as Array<String>
        val py=bundle.get("otherst_cesstotarray") as Array<String>
        val idtally=bundle.get("tallyarray") as Array<String>
        val idrec=bundle.get("receivedarray") as Array<String>
        val iddd=bundle.get("otherst_idsofli") as Array<String>
        val immy=bundle.get("otherst_image") as Array<String>


        asave=a
        dsysave=dsy
        fysave=fy
        gysave=gy
        hysave=hy
        kysave=ky
        mysave=my
        nysave=ny
        oysave=oy
        pysave=py
        tallysave=idtally
        receivedsave=idrec
        idddsave=iddd
        immysave=immy
        lysave=ly


        val namebr=intent.getStringExtra("otherst_branch")
        val datest=bundle.get("otherst_sstkdate")
        val kybrnch=intent.getStringExtra("keybrnch")
        val oribrnky=intent.getStringExtra("originkeys")

        val smlistid=intent.getStringExtra("otherst_smlistids")
        val locbr=intent.getStringExtra("otherst_address")
        val stockid=intent.getStringExtra("otherst_ssstockid")
        val stockdesc=intent.getStringExtra("otherst_ssstkdesc")
        val iddb=intent.getStringExtra("otherst_idofdb")

        val grochk=intent.getStringExtra("groschk")
        groschk=grochk

        other_idoflist.setText(smlistid)
        smlistidss=other_idoflist.text.toString()

        othbky.setText(kybrnch)
        other_idofre.setText(iddb)
        other_desc.setText(stockdesc)
        other_stkid.setText(stockid)
        other_date.setText(datest.toString())
        println("PRINT THE   DATEEEE  "+datest)
        comttname.setText(namebr)
        comphone.setText(locbr)
        names=comttname.text.toString()
        orikys=oribrnky
        brky=othbky.text.toString()
        datestk=other_date.text.toString()
        println("YOYO OO DATEEEE"+datestk)
        descstk=other_desc.text.toString()
        idstk=other_stkid.text.toString()
        iddbs=other_idofre.text.toString()
        println(iddbs)


        namesphones=comphone.text.toString()
        /*    val i=bundle.get("imageArray") as Array<String>*/

        /*   d.add(b.toString())*/
        val pz=bundle.get("otherst_pos") as Int
        pzsave=pz


        //name edt text
        var prname=a[pz]
        other_prd_nm.setText(prname)

        //total
        var totalof=ky[pz]
        other_total.setText(totalof)
        try {
            var halfpri = totalof.toInt()
            halfpr=halfpri.toFloat()

        }
        catch(e:Exception){
            var halfpri = totalof.toFloat()
            halfpr=halfpri
        }

        other_gross_tot.setText(totalof)
        var f=other_gross_tot.text.toString()
        var fgr=f.toFloat()


        //quantity
        var quant=gy[pz]
        var qu:Int
        qu=quant.toInt()
        oth_br_quant.setText(quant)
        //hsn code


        var prord=dsy[pz]
        otherhsc.setText(prord)
        //price
        var price=hy[pz]
        try {

            var pr: Int
             var hh=halfpr.toInt()
            pr=hh/qu
            var prdiv = pr
            other_price.setText(prdiv.toString())
        }
        catch(e:Exception){
            var pr: Float
            var halfpri=totalof.toFloat()
            pr=halfpri/qu
            var prdiv = pr

            other_price.setText(prdiv.toString())
        }



        //barcode
        var bar=fy[pz]
        otherbcd_pid.setText(bar)



        //cess
        var cssof=my[pz]
        cess_edt_trans.setText(cssof)

        ///IGST
        var igstof=ny[pz]
       other_igst_vi.setText(igstof)

        //IGST TOTAL
        var igsttotof=oy[pz]
        other_igst_tot.setText(igsttotof)
        var h=other_igst_tot.text.toString()
        var ss=h.toFloat()


        //CESS TTAL
        var cesstotof=py[pz]
       other_cess_tot.setText(cesstotof)
        var t= other_cess_tot.text.toString()
        var hd=t.toFloat()

        var ls=ss+hd+fgr
        other_gross_tot.setText(ls.toString())


        var idof=iddd[pz]
        othernew_id.setText(idof)
        idli=othernew_id.text.toString()


        var tally=idtally[pz]
        tal.setText(tally)
        tallyar=tal.text.toString()

        var receive=idrec[pz]
        rec.setText(receive)
        receivear=rec.text.toString()



        var upnm= arrayListOf<String>()
        val p=intent.getStringArrayListExtra("liids")



        val b = intent.getStringExtra("id")
        other_idofre.setText(b)



        otherbcd_pid.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                editchange="change"
                groschk="edited"
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {

            }
        })




        other_prd_nm.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                editchange="change"
                groschk="edited"
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {

            }
        })



        oth_br_quant.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var prq : Float; var igst : Float; var ces : Float;
                var pri : Int;
                if (pr.isEmpty()){
                    pri = 1
                }else{
                    pri=pr.toString().toInt()
                }
                if (other_igst_vi.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=other_igst_vi.text.toString().toFloat()
                }
                if (other_price.text.isEmpty()){
                    prq = 0.0F
                }else{
                    prq=other_price.text.toString().toFloat()
                }
                if (cess_edt_trans.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt_trans.text.toString().replace("%","").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq*pri)*(igst/100)
                other_igst_tot.setText("$ttot")

                //CESS TOTAL
                val cesstot = (prq*pri)*(ces/100)
                other_cess_tot.setText("$cesstot")

                val fitot = ttot + cesstot +(prq*pri)
                other_gross_tot.setText("$fitot")

                var k = other_price.text.toString()
                var l = k.toBigInteger()
                val o = pri.toBigInteger()
                val f = l.times(o)
                other_total.setText(f.toString())


                editchange="change"


                groschk="edited"


            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })




        other_price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var prq : Float; var igst : Float; var ces : Float;var qty:Float;
                other_total.setText("")
                other_gross_tot.setText("")
                var pri : Int;
                if (pr.isEmpty()){
                    pri = 0

                }else{
                    pri=pr.toString().toInt()
                }
                if (other_igst_vi.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=other_igst_vi.text.toString().toFloat()
                }

                if (oth_br_quant.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=oth_br_quant.text.toString().toFloat()
                }

                if (cess_edt_trans.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt_trans.text.toString().replace("%","").toFloat()
                }


                var k =   oth_br_quant.text.toString()
                var l = pri.toBigInteger()
                val oi = k.toBigInteger()
                val f = l.times(oi)
                other_total.setText(f.toString())
                other_gross_tot.setText(f.toString())

                //IGST TOTAL
                val ttot = (pri*qty)*(igst/100)
                other_igst_tot.setText("$ttot")

                //CESS TOTAL
                val cesstot = (pri*qty)*(ces/100)
                other_cess_tot.setText("$cesstot")

                val fitot = ttot + cesstot +(pri*qty)
                other_gross_tot.setText("$fitot")

                editchange="change"

                groschk="edited"

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })

        other_total.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                editchange="change"

                groschk="edited"
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {

            }
        })


        otherhsc.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                editchange="change"

                groschk="edited"
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {

            }
        })



        cess_edt_trans.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {
                var pri : Float; var igst : Float; var ces : Float;var qty:Float;
                if (other_price.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=other_price.text.toString().toFloat()
                }
                if (oth_br_quant.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=oth_br_quant.text.toString().toFloat()
                }
                if (other_igst_vi.text.isEmpty()){
                    igst=0.0F
                }else{
                    igst =other_igst_vi.text.toString().replace("%","").toFloat()
                }
                if (cess.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess.toString().replace("%","").toFloat()
                }

                //cgst & sgst
                val ans =igst/2
                other_cgst_vi.setText("$ans"+"%")
                other_sgst_vi.setText("$ans"+"%")

                //tax total
                val ttot = (pri*qty)*(igst/100)
                other_igst_tot.setText("$ttot")

                //cess total
                val cesstot = (pri*qty)*(ces/100)
                other_cess_tot.setText("$cesstot")

                //gross total
                val fitot = ttot  + cesstot + (pri*qty)
                other_gross_tot.setText("$fitot")

                editchange="change"

                groschk="edited"

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })
        other_igst_vi.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                var pri : Float; var igst : Float; var ces : Float;var qty:Float;
                if (other_price.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=other_price.text.toString().toFloat()
                }
                if (oth_br_quant.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=oth_br_quant.text.toString().toFloat()
                }
                if (ig.isEmpty()){
                    igst=0.0F
                }else{
                    igst =ig.toString().replace("%","").toFloat()
                }
                if (cess_edt_trans.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt_trans.text.toString().replace("%","").toFloat()
                }

                //cgst & sgst
                val ans =igst/2
                other_cgst_vi.setText("$ans"+"%")
                other_sgst_vi.setText("$ans"+"%")

                //tax total
                val ttot = (pri*qty)*(igst/100)
                other_igst_tot.setText("$ttot")

                 //cess total
                val cesstot = (pri*qty)*(ces/100)
                other_cess_tot.setText("$cesstot")

                 //gross total
                val fitot = ttot  + cesstot + (pri*qty)
                other_gross_tot.setText("$fitot")

                editchange="change"

                groschk="edited"

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })

        ots_update.setOnClickListener {
            val o= Intent(this@Main_trans_delhi,Main_stk_delhi::class.java)

            var dx=  other_prd_nm.text
            var ex=  otherhsc.text
            var fx= other_price.text.toString()
            var gx=oth_br_quant.text
            var hx=otherbcd_pid.text
            var ix=other_gross_tot.text
            var jx=cess_edt_trans.text
            var kx=other_igst_vi.text
            var lx=other_igst_tot.text
            var mx=other_cess_tot.text
            var tallx=tal.text
            var receivex=rec.text

            //ASSIGNING TAXES VALUES FOR PUTEXTR
            igsted=other_igst_vi.text.toString()
            igtot=other_igst_tot.text.toString()
            cestot=other_cess_tot.text.toString()
            grosstot=other_gross_tot.text.toString()


            a[pz]=dx.toString()
            dsy[pz]=ex.toString()

            fy[pz]=hx.toString()
            gy[pz]=gx.toString()
            hy[pz]=fx.toString()
            ky[pz]=ix.toString()
            my[pz]=jx.toString()
            ny[pz]=kx.toString()
            oy[pz]=lx.toString()
            py[pz]=mx.toString()
            idtally[pz]=tallx.toString()
            idrec[pz]=receivex.toString()


            o.putExtra("otheruprenm",a)
            o.putExtra("fromstate","updateother")
            o.putExtra("otherupremanu",ly)
            o.putExtra("otheruprekey",iddd)
            o.putExtra("otheruprehsn",dsy)
            o.putExtra("otherupreprice",hy)
            o.putExtra("otheruprequan",gy)
            o.putExtra("otheruprebc",fy)
            o.putExtra("otherupretotal",ky)
            o.putExtra("otheruprecess",my)
            o.putExtra("otherupreimmg",immy)
            o.putExtra("otherupbranch",comttname.text.toString())
            o.putExtra("otherupaddress",comphone.text.toString())
            o.putExtra("otherupredate",datestk)
            o.putExtra("otherupredesc",descstk)
            o.putExtra("otheruprestkid",idstk)
            o.putExtra("otherupreiddb",iddbs)
            o.putExtra("otherupsmlistidss",smlistidss)
            o.putExtra("otherupreiddofli",idli)
            o.putExtra("retally",idtally)
            o.putExtra("rereceived",idrec)
            o.putExtra("otherreigst",ny)
            o.putExtra("otherreigst_total",oy)
            o.putExtra("otherrecesstotal",py)
            o.putExtra("brnchky",brky)
            o.putExtra("oribrnky",orikys)




            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


            o.putExtra("viewtransano", viewtransano)
            o.putExtra("addtransano", addtransano)
            o.putExtra("edittransano", editetransano)
            o.putExtra("deletetransano", deletetransano)
            o.putExtra("transfertransano", transfertransano)
            o.putExtra("exporttransano", exporttransano)
            o.putExtra("sendtransano", sendtransano)

            o.putExtra("viewrec", viewrec)
            o.putExtra("addrec", addrec)
            o.putExtra("deleterec", deleterec)
            o.putExtra("editrec", editrec)
            o.putExtra("transferrec", transferrec)
            o.putExtra("exportrec", exportrec)
            o.putExtra("sendstrec",sendstrec)



            o.putExtra("groschk",groschk)

            startActivity(o)
            finish()
        }


        userback.setOnClickListener {
            if (editchange.isEmpty()) {

                val o = Intent(this@Main_trans_delhi, Main_stk_delhi::class.java)

               /* var dx = other_prd_nm.text
                var ex = otherhsc.text
                var fx = other_price.text.toString()
                var gx = oth_br_quant.text
                var hx = otherbcd_pid.text
                var ix = other_gross_tot.text
                var jx = cess_edt_trans.text
                var kx = other_igst_vi.text
                var lx = other_igst_tot.text
                var mx = other_cess_tot.text
                var tallx = tal.text
                var receivex = rec.text

                //ASSIGNING TAXES VALUES FOR PUTEXTR
                igsted = other_igst_vi.text.toString()
                igtot = other_igst_tot.text.toString()
                cestot = other_cess_tot.text.toString()
                grosstot = other_gross_tot.text.toString()


                a[pz] = dx.toString()
                dsy[pz] = ex.toString()

                fy[pz] = hx.toString()
                gy[pz] = gx.toString()
                hy[pz] = fx.toString()
                ky[pz] = ix.toString()
                my[pz] = jx.toString()
                ny[pz] = kx.toString()
                oy[pz] = lx.toString()
                py[pz] = mx.toString()
                idtally[pz] = tallx.toString()
                idrec[pz] = receivex.toString()*/


                o.putExtra("otheruprenm", a)
                o.putExtra("fromstate", "updateother")
                o.putExtra("otherupremanu", ly)
                o.putExtra("otheruprekey", iddd)
                o.putExtra("otheruprehsn", dsy)
                o.putExtra("otherupreprice", hy)
                o.putExtra("otheruprequan", gy)
                o.putExtra("otheruprebc", fy)
                o.putExtra("otherupretotal", ky)
                o.putExtra("otheruprecess", my)
                o.putExtra("otherupreimmg", immy)
                o.putExtra("otherupbranch", comttname.text.toString())
                o.putExtra("otherupaddress", comphone.text.toString())
                o.putExtra("otherupredate", datestk)
                o.putExtra("otherupredesc", descstk)
                o.putExtra("otheruprestkid", idstk)
                o.putExtra("otherupreiddb", iddbs)
                o.putExtra("otherupsmlistidss", smlistidss)
                o.putExtra("otherupreiddofli", idli)
                o.putExtra("retally", idtally)
                o.putExtra("rereceived", idrec)
                o.putExtra("otherreigst", ny)
                o.putExtra("otherreigst_total", oy)
                o.putExtra("otherrecesstotal", py)
                o.putExtra("brnchky", brky)
                o.putExtra("oribrnky", orikys)




                o.putExtra("viewtrans", viewtrans)
                o.putExtra("addtrans", addtrans)
                o.putExtra("edittrans", editetrans)
                o.putExtra("deletetrans", deletetrans)
                o.putExtra("transfertrans", transfertrans)
                o.putExtra("exporttrans", exporttrans)
                o.putExtra("sendtrans", sendtrans)


                o.putExtra("viewtransano", viewtransano)
                o.putExtra("addtransano", addtransano)
                o.putExtra("edittransano", editetransano)
                o.putExtra("deletetransano", deletetransano)
                o.putExtra("transfertransano", transfertransano)
                o.putExtra("exporttransano", exporttransano)
                o.putExtra("sendtransano", sendtransano)

                o.putExtra("viewrec", viewrec)
                o.putExtra("addrec", addrec)
                o.putExtra("deleterec", deleterec)
                o.putExtra("editrec", editrec)
                o.putExtra("transferrec", transferrec)
                o.putExtra("exportrec", exportrec)
                o.putExtra("sendstrec",sendstrec)



                o.putExtra("groschk",groschk)

                startActivity(o)
                finish()
            }
            else if (editchange == "change") {
                savepopup()

            }
        }
    }

    override fun onBackPressed() {

        if (editchange.isEmpty()) {

            val ad = intent.getStringExtra("addtransano")
            val ed = intent.getStringExtra("edittransano")
            val del = intent.getStringExtra("deletetransano")
            val vi=intent.getStringExtra("viewtransano")
            val tran=intent.getStringExtra("transfertransano")
            val ex=intent.getStringExtra("exporttransano")

            if (ad != null) {
                addtransano = ad
            }
            if (ed != null) {
                editetransano = ed
            }
            if (del != null) {
                deletetransano = del
            }
            if (vi != null) {
                viewtransano = vi
            }
            if (tran != null) {
                transfertransano = tran
            }
            if (ex != null) {
                exporttransano = ex
            }


            //VALUES FOR TAX DETAILS

            var igsted=String()
            var igtot=String()
            var cestot=String()
            var grosstot=String()


            val bundle = intent.extras
            var frm = bundle!!.get("fromstate").toString()




            otherbcd_pid.isEnabled=false
            otherhsc.isEnabled=false
            other_prd_nm.isEnabled=false
            other_price.isEnabled=false
            oth_br_quant.isEnabled=false
            other_total.isEnabled=false
            cess_edt_trans.isEnabled=false
            other_igst_vi.isEnabled=false





            var a= bundle.get("otherst_pnm") as Array<String>
            println(a)
            /*     val b=bundle.get("id") as Array<String>*/

            val dsy=bundle.get("otherst_phsn") as Array<String>
            val ly=bundle.get("otherst_pmanu")    as Array<String>
            val fy=bundle.get("otherst_barcode") as Array<String>
            val gy=bundle.get("otherst_quan")    as Array<String>
            val hy=bundle.get("otherst_price")   as Array<String>
            val ky=bundle.get("otherst_tot")     as Array<String>
            val my=bundle.get("otherst_cessup")  as Array<String>
            val ny=bundle.get("otherst_igst") as Array<String>
            val oy=bundle.get("otherst_igsttotal") as Array<String>
            val py=bundle.get("otherst_cesstotarray") as Array<String>
            val idtally=bundle.get("tallyarray") as Array<String>
            val idrec=bundle.get("receivedarray") as Array<String>
            val iddd=bundle.get("otherst_idsofli") as Array<String>
            val immy=bundle.get("otherst_image") as Array<String>


            asave=a
            dsysave=dsy
            fysave=fy
            gysave=gy
            hysave=hy
            kysave=ky
            mysave=my
            nysave=ny
            oysave=oy
            pysave=py
            tallysave=idtally
            receivedsave=idrec
            idddsave=iddd
            immysave=immy
            lysave=ly


            val namebr=intent.getStringExtra("otherst_branch")
            val datest=bundle.get("otherst_sstkdate")
            val kybrnch=intent.getStringExtra("keybrnch")
            val oribrnky=intent.getStringExtra("originkeys")

            val smlistid=intent.getStringExtra("otherst_smlistids")
            val locbr=intent.getStringExtra("otherst_address")
            val stockid=intent.getStringExtra("otherst_ssstockid")
            val stockdesc=intent.getStringExtra("otherst_ssstkdesc")
            val iddb=intent.getStringExtra("otherst_idofdb")

            val grochk=intent.getStringExtra("groschk")
            groschk=grochk

            other_idoflist.setText(smlistid)
            smlistidss=other_idoflist.text.toString()

            othbky.setText(kybrnch)
            other_idofre.setText(iddb)
            other_desc.setText(stockdesc)
            other_stkid.setText(stockid)
            other_date.setText(datest.toString())
            println("PRINT THE   DATEEEE  "+datest)
            comttname.setText(namebr)
            comphone.setText(locbr)
            names=comttname.text.toString()
            orikys=oribrnky
            brky=othbky.text.toString()
            datestk=other_date.text.toString()
            println("YOYO OO DATEEEE"+datestk)
            descstk=other_desc.text.toString()
            idstk=other_stkid.text.toString()
            iddbs=other_idofre.text.toString()
            println(iddbs)


            namesphones=comphone.text.toString()
            /*    val i=bundle.get("imageArray") as Array<String>*/

            /*   d.add(b.toString())*/
            val pz=bundle.get("otherst_pos") as Int
            pzsave=pz


            //name edt text
            var prname=a[pz]
            other_prd_nm.setText(prname)

            //total
            var totalof=ky[pz]
            other_total.setText(totalof)
            try {
                var halfpri = totalof.toInt()
                halfpr=halfpri.toFloat()

            }
            catch(e:Exception){
                var halfpri = totalof.toFloat()
                halfpr=halfpri
            }



            //quantity
            var quant=gy[pz]
            var qu:Int
            qu=quant.toInt()
            oth_br_quant.setText(quant)
            //hsn code


            var prord=dsy[pz]
            otherhsc.setText(prord)
            //price
            var price=hy[pz]
            try {

                var pr: Int
                var hh=halfpr.toInt()
                pr=hh/qu
                var prdiv = pr
                other_price.setText(prdiv.toString())
            }
            catch(e:Exception){
                var pr: Float
                var halfpri=totalof.toFloat()
                pr=halfpri/qu
                var prdiv = pr

                other_price.setText(prdiv.toString())
            }
            other_gross_tot.setText(totalof)
            var f=other_gross_tot.text.toString()
            var fgr=f.toFloat()



            //barcode
            var bar=fy[pz]
            otherbcd_pid.setText(bar)



            //cess
            var cssof=my[pz]
            cess_edt_trans.setText(cssof)

            ///IGST
            var igstof=ny[pz]
            other_igst_vi.setText(igstof)

            //IGST TOTAL
            var igsttotof=oy[pz]
            other_igst_tot.setText(igsttotof)
            var h=other_igst_tot.text.toString()
            var ss=h.toFloat()


            //CESS TTAL
            var cesstotof=py[pz]
            other_cess_tot.setText(cesstotof)
            var t= other_cess_tot.text.toString()
            var hd=t.toFloat()

            var ls=ss+hd+fgr
            other_gross_tot.setText(ls.toString())


            var idof=iddd[pz]
            othernew_id.setText(idof)
            idli=othernew_id.text.toString()


            var tally=idtally[pz]
            tal.setText(tally)
            tallyar=tal.text.toString()

            var receive=idrec[pz]
            rec.setText(receive)
            receivear=rec.text.toString()



            var upnm= arrayListOf<String>()
            val p=intent.getStringArrayListExtra("liids")



            val b = intent.getStringExtra("id")
            other_idofre.setText(b)



            val o = Intent(this@Main_trans_delhi, Main_stk_delhi::class.java)

            /* var dx = other_prd_nm.text
             var ex = otherhsc.text
             var fx = other_price.text.toString()
             var gx = oth_br_quant.text
             var hx = otherbcd_pid.text
             var ix = other_gross_tot.text
             var jx = cess_edt_trans.text
             var kx = other_igst_vi.text
             var lx = other_igst_tot.text
             var mx = other_cess_tot.text
             var tallx = tal.text
             var receivex = rec.text

             //ASSIGNING TAXES VALUES FOR PUTEXTR
             igsted = other_igst_vi.text.toString()
             igtot = other_igst_tot.text.toString()
             cestot = other_cess_tot.text.toString()
             grosstot = other_gross_tot.text.toString()


             a[pz] = dx.toString()
             dsy[pz] = ex.toString()

             fy[pz] = hx.toString()
             gy[pz] = gx.toString()
             hy[pz] = fx.toString()
             ky[pz] = ix.toString()
             my[pz] = jx.toString()
             ny[pz] = kx.toString()
             oy[pz] = lx.toString()
             py[pz] = mx.toString()
             idtally[pz] = tallx.toString()
             idrec[pz] = receivex.toString()*/


            o.putExtra("otheruprenm", a)
            o.putExtra("fromstate", "updateother")
            o.putExtra("otherupremanu", ly)
            o.putExtra("otheruprekey", iddd)
            o.putExtra("otheruprehsn", dsy)
            o.putExtra("otherupreprice", hy)
            o.putExtra("otheruprequan", gy)
            o.putExtra("otheruprebc", fy)
            o.putExtra("otherupretotal", ky)
            o.putExtra("otheruprecess", my)
            o.putExtra("otherupreimmg", immy)
            o.putExtra("otherupbranch", comttname.text.toString())
            o.putExtra("otherupaddress", comphone.text.toString())
            o.putExtra("otherupredate", datestk)
            o.putExtra("otherupredesc", descstk)
            o.putExtra("otheruprestkid", idstk)
            o.putExtra("otherupreiddb", iddbs)
            o.putExtra("otherupsmlistidss", smlistidss)
            o.putExtra("otherupreiddofli", idli)
            o.putExtra("retally", idtally)
            o.putExtra("rereceived", idrec)
            o.putExtra("otherreigst", ny)
            o.putExtra("otherreigst_total", oy)
            o.putExtra("otherrecesstotal", py)
            o.putExtra("brnchky", brky)
            o.putExtra("oribrnky", orikys)




            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


            o.putExtra("viewtransano", viewtransano)
            o.putExtra("addtransano", addtransano)
            o.putExtra("edittransano", editetransano)
            o.putExtra("deletetransano", deletetransano)
            o.putExtra("transfertransano", transfertransano)
            o.putExtra("exporttransano", exporttransano)
            o.putExtra("sendtransano", sendtransano)

            o.putExtra("viewrec", viewrec)
            o.putExtra("addrec", addrec)
            o.putExtra("deleterec", deleterec)
            o.putExtra("editrec", editrec)
            o.putExtra("transferrec", transferrec)
            o.putExtra("exportrec", exportrec)
            o.putExtra("sendstrec",sendstrec)



            o.putExtra("groschk",groschk)

            startActivity(o)
            finish()

        }
        else if (editchange == "change") {
            savepopup()

        }

        }

    fun savepopup() {

        val ad = intent.getStringExtra("addtransano")
        val ed = intent.getStringExtra("edittransano")
        val del = intent.getStringExtra("deletetransano")
        val vi=intent.getStringExtra("viewtransano")
        val tran=intent.getStringExtra("transfertransano")
        val ex=intent.getStringExtra("exporttransano")

        if (ad != null) {
            addtransano = ad
        }
        if (ed != null) {
            editetransano = ed
        }
        if (del != null) {
            deletetransano = del
        }
        if (vi != null) {
            viewtransano = vi
        }
        if (tran != null) {
            transfertransano = tran
        }
        if (ex != null) {
            exporttransano = ex
        }

        val builder = AlertDialog.Builder(this@Main_trans_delhi)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")

            setPositiveButton("Yes") { dialog, whichButton ->
                println("YES")

                val o= Intent(this@Main_trans_delhi,Main_stk_delhi::class.java)

                var dx=  other_prd_nm.text
                var exs=  otherhsc.text
                var fx= other_price.text.toString()
                var gx=oth_br_quant.text
                var hx=otherbcd_pid.text
                var ix=other_gross_tot.text
                var jx=cess_edt_trans.text
                var kx=other_igst_vi.text
                var lx=other_igst_tot.text
                var mx=other_cess_tot.text
                var tallx=tal.text
                var receivex=rec.text

                asave[pzsave] = dx.toString()
                dsysave[pzsave] = exs.toString()
                fysave[pzsave] = hx.toString()
                gysave[pzsave] = gx.toString()
                hysave[pzsave] = fx.toString()
                kysave[pzsave] = ix.toString()
                mysave[pzsave] = jx.toString()
                nysave[pzsave] = kx.toString()
                oysave[pzsave] = lx.toString()
                pysave[pzsave] = mx.toString()
                tallysave[pzsave] = tallx.toString()
                receivedsave[pzsave] = receivex.toString()

                //ASSIGNING TAXES VALUES FOR PUTEXTR
                igsted=other_igst_vi.text.toString()
                igtot=other_igst_tot.text.toString()
                cestot=other_cess_tot.text.toString()
                grosstot=other_gross_tot.text.toString()

                o.putExtra("otheruprenm",asave)
                o.putExtra("fromstate","updateother")
                o.putExtra("otherupremanu",lysave)
                o.putExtra("otheruprekey",idddsave)
                o.putExtra("otheruprehsn",dsysave)
                o.putExtra("otherupreprice",hysave)
                o.putExtra("otheruprequan",gysave)
                o.putExtra("otheruprebc",fysave)
                o.putExtra("otherupretotal",kysave)
                o.putExtra("otheruprecess",mysave)
                o.putExtra("otherupreimmg",immysave)
                o.putExtra("otherupbranch",comttname.text.toString())
                o.putExtra("otherupaddress",comphone.text.toString())
                o.putExtra("otherupredate",datestk)
                o.putExtra("otherupredesc",descstk)
                o.putExtra("otheruprestkid",idstk)
                o.putExtra("otherupreiddb",iddbs)
                o.putExtra("otherupsmlistidss",smlistidss)
                o.putExtra("otherupreiddofli",idli)
                o.putExtra("retally",tallysave)
                o.putExtra("rereceived",receivedsave)
                o.putExtra("otherreigst",nysave)
                o.putExtra("otherreigst_total",oysave)
                o.putExtra("otherrecesstotal",pysave)
                o.putExtra("brnchky",brky)
                o.putExtra("oribrnky",orikys)




                o.putExtra("viewtrans", viewtrans)
                o.putExtra("addtrans", addtrans)
                o.putExtra("edittrans", editetrans)
                o.putExtra("deletetrans", deletetrans)
                o.putExtra("transfertrans", transfertrans)
                o.putExtra("exporttrans", exporttrans)
                o.putExtra("sendtrans", sendtrans)


                o.putExtra("viewtransano", viewtransano)
                o.putExtra("addtransano", addtransano)
                o.putExtra("edittransano", editetransano)
                o.putExtra("deletetransano", deletetransano)
                o.putExtra("transfertransano", transfertransano)
                o.putExtra("exporttransano", exporttransano)
                o.putExtra("sendtransano", sendtransano)

                o.putExtra("viewrec", viewrec)
                o.putExtra("addrec", addrec)
                o.putExtra("deleterec", deleterec)
                o.putExtra("editrec", editrec)
                o.putExtra("transferrec", transferrec)
                o.putExtra("exportrec", exportrec)
                o.putExtra("sendstrec",sendstrec)



                o.putExtra("groschk",groschk)
                startActivity(o)
                finish()
            }
            setNegativeButton("No") { dialog, whichButton ->
                groschk=""
                val o= Intent(this@Main_trans_delhi,Main_stk_delhi::class.java)
                o.putExtra("otheruprenm",asave)
                o.putExtra("fromstate","updateother")
                o.putExtra("otherupremanu",lysave)
                o.putExtra("otheruprekey",idddsave)
                o.putExtra("otheruprehsn",dsysave)
                o.putExtra("otherupreprice",hysave)
                o.putExtra("otheruprequan",gysave)
                o.putExtra("otheruprebc",fysave)
                o.putExtra("otherupretotal",kysave)
                o.putExtra("otheruprecess",mysave)
                o.putExtra("otherupreimmg",immysave)
                o.putExtra("otherupbranch",comttname.text.toString())
                o.putExtra("otherupaddress",comphone.text.toString())
                o.putExtra("otherupredate",datestk)
                o.putExtra("otherupredesc",descstk)
                o.putExtra("otheruprestkid",idstk)
                o.putExtra("otherupreiddb",iddbs)
                o.putExtra("otherupsmlistidss",smlistidss)
                o.putExtra("otherupreiddofli",idli)
                o.putExtra("retally",tallysave)
                o.putExtra("rereceived",receivedsave)
                o.putExtra("otherreigst",nysave)
                o.putExtra("otherreigst_total",oysave)
                o.putExtra("otherrecesstotal",pysave)
                o.putExtra("brnchky",brky)
                o.putExtra("oribrnky",orikys)




             o.putExtra("viewtrans", viewtrans)
             o.putExtra("addtrans", addtrans)
             o.putExtra("edittrans", editetrans)
             o.putExtra("deletetrans", deletetrans)
             o.putExtra("transfertrans", transfertrans)
             o.putExtra("exporttrans", exporttrans)
             o.putExtra("sendtrans", sendtrans)


             o.putExtra("viewtransano", viewtransano)
             o.putExtra("addtransano", addtransano)
             o.putExtra("edittransano", editetransano)
             o.putExtra("deletetransano", deletetransano)
             o.putExtra("transfertransano", transfertransano)
             o.putExtra("exporttransano", exporttransano)
             o.putExtra("sendtransano", sendtransano)

             o.putExtra("viewrec", viewrec)
             o.putExtra("addrec", addrec)
             o.putExtra("deleterec", deleterec)
             o.putExtra("editrec", editrec)
             o.putExtra("transferrec", transferrec)
             o.putExtra("exportrec", exportrec)
             o.putExtra("sendstrec",sendstrec)



                o.putExtra("groschk",groschk)
                startActivity(o)
                finish()

                dialog.dismiss()
            }
            // Dialog
            val dialog = builder.create()
            dialog.show()
        }
        }






    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}