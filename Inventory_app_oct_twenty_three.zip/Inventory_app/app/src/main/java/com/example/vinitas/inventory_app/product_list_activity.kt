package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.product_list_activity.*
import android.widget.LinearLayout
import de.hdodenhof.circleimageview.CircleImageView
import android.view.Gravity
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.EventListener

import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.act_stock_first_items.*
import kotlinx.android.synthetic.main.activity_main_pdf.*
import java.util.*


class product_list_activity : AppCompatActivity() {
    var db = FirebaseFirestore.getInstance()
    var TAG="some"
var grosschk= String()

    var regexstr=String()

    var sd = String()
    var x = String()
    var reg = String()
    var esc = String()
    var upstr = String()
    var numberstr = String()
    var regtr = String()
    var nmstr = String()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""


    var descripdup=String()
    var stdatedup=String()





    var ids=arrayOf<String>()


    var pronameArraycpy     = arrayListOf<String>()
    var hsnArraycpy          = arrayListOf<String>()

    var manufacturerArraycpy = arrayListOf<String>()
    var barcodeArraycpy     = arrayListOf<String>()
    var quantityArraycpy     = arrayListOf<String>()
    var priceArraycpy       = arrayListOf<String>()
    var totArraycpy         = arrayListOf<String>()
    var cessArraycpy         = arrayListOf<String>()
    var igstArraycpy= arrayListOf<String>()
    var igsttotArraycpy = arrayListOf<String>()
    var cesstotalArraycpy = arrayListOf<String>()
    var tallyArraycpy = arrayListOf<String>()
    var receivedArraycpy = arrayListOf<String>()
    var imageArraycpy        = arrayListOf<String>()
    var idupArraycpy=arrayListOf<String>()
    var quantityArraycopycpy     = arrayListOf<String>()

    var proidupArraycpy=arrayListOf<String>()
    var proidcopyupArraycpy=arrayListOf<String>()

    var proiddelete= arrayListOf<String>()
    var quantitydelete= arrayListOf<String>()
/*
       val a=intent.getStringExtra("namess")
       names.plusElement(a)
       val ab=intent.getStringExtra("brnchnamess")
       namesphones.plusElement(ab)*/

    //ARRAYS OF LISTS



    var  pronameArrayori     = arrayListOf<String>()
    var  hsnArrayori         = arrayListOf<String>()
    var  manufacturerArrayori= arrayListOf<String>()
    var  barcodeArrayori      = arrayListOf<String>()
    var  quantityArrayori     = arrayListOf<String>()
    var  priceArrayori        = arrayListOf<String>()
    var  totArrayori         = arrayListOf<String>()
    var  cessArrayori        = arrayListOf<String>()
    var igstArrayori =arrayListOf<String>()
    var igsttotArrayori =arrayListOf<String>()
    var cesstotalArrayori =arrayListOf<String>()
    var tallyArrayori =arrayListOf<String>()
    var receivedArrayori =arrayListOf<String>()
    var  imageArrayori        = arrayListOf<String>()
    var keyArrayori=arrayListOf<String>()
    var proidupArrayori=arrayListOf<String>()
    var proidupcopyArrayori=arrayListOf<String>()
    var  quantityArraycopyori     = arrayListOf<String>()

    var d = arrayListOf<String>()

    var dlt = arrayListOf<String>()

    var bcd= String()

var orignm=String()

    var names = String()
    var namesori = String()
    var namesphones = String()
    var keybrnch=String()
    var namesphonesori = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var oriky= String()
    var idli= arrayListOf<String>()
    var image= String()
var deletelistener= String()

    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var proidArray = arrayListOf<String>()
    var proidcopyArray = arrayListOf<String>()
    var quantityArraycopy = arrayListOf<String>()
    var soharray= arrayListOf<String>()
    var maxarray= arrayListOf<String>()

   /* var compnameArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
    var itemnmArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
    var orderArray = arrayOf<String>("BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273")
    var poArray = arrayOf<String>("60/100 Received","20/100 Received","30/100 Received","40/100 Received","50/100 Received")
    var completeArray = arrayOf<String>("200ml","300ml","400ml","500ml","600ml")
    var priceArray = arrayOf<String>("3000.00","4000.00","4500.00","5000.00","6000.00")
    var imageArray = arrayOf<Int>(R.drawable.promen,R.drawable.loreal_bottl,R.drawable.loreal_bottl,R.drawable.promen,R.drawable.loreal_bottl)
    var d = arrayListOf<String>("fireboost","loreal","fireboost","professional","pantine")*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.product_list_activity)

       net_status()     //Check internet status.




       search.setOnClickListener {           //Image button search  action
           cardsearch.visibility = View.VISIBLE
           cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity, R.anim.slide_to_right))
           searchedit.requestFocus()
           val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
           imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
       }

       searback1.setOnClickListener {           //Image button search back action
           searchedit.setText("")
           cardsearch.visibility = View.GONE

           cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity, R.anim.slide_to_left))
           nores.visibility = View.GONE
           product_list.visibility = View.VISIBLE
           progressBar3.visibility = View.GONE
           get()
           /* nores.visibility=View.INVISIBLE
            clilist1.visibility=View.VISIBLE
            searchedit.setText("")*/
           /* get()*/
       }


       //Get stock transfer details from (Mainstk_branch_one)


       val bundle = intent.extras
       var frm = bundle!!.get("from").toString()
       if(frm=="datalist")
       {

           var a= bundle.get("namess") as ArrayList<String>
           println(a)
      /*     val b=bundle.get("id") as Array<String>*/
           val c=bundle.get("orderarray") as ArrayList<String>
           val ds=bundle.get("hsn") as ArrayList<String>
       /*    val l=bundle.get("item") as Array<String>*/
           val f=bundle.get("poarray") as ArrayList<String>
           val g=bundle.get("complete") as ArrayList<String>
           val h=bundle.get("price") as ArrayList<String>
           val i=bundle.get("total") as ArrayList<String>
           val j=bundle.get("cess") as ArrayList<String>
           val r=bundle.get("igst") as ArrayList<String>
           val s=bundle.get("igsttotal") as ArrayList<String>
           val q=bundle.get("cesstotarray") as ArrayList<String>
           val qtall=bundle.get("tallyarray") as ArrayList<String>
           val rec=bundle.get("receivedarray") as ArrayList<String>
           val iddd=bundle.get("idsofli") as ArrayList<String>
           val proidarr=bundle.get("proidarray") as ArrayList<String>
           val proidcpyarr=bundle.get("proidarraycpy") as ArrayList<String>
           val quanarrcpy=bundle.get("quancpy") as ArrayList<String>




           val prodel= bundle.get("proiddelete") as ArrayList<String>

           if(prodel.isNotEmpty()==true){
               proiddelete=prodel
           }
           else{

           }

           val quandel=bundle.get("quantitydelete") as ArrayList<String>

           if(quandel.isNotEmpty()==true){
               quantitydelete=prodel
           }
           else{

           }



           try {
               orignm = intent.getStringExtra("orignm")

           }
           catch (e:Exception){

           }





           val brkey=intent.getStringExtra("brnchid")
           val originky=intent.getStringExtra("origiid")

           val k=bundle.get("im") as ArrayList<String>

           ids=bundle.get("ids") as Array<String>

           val datest=intent.getStringExtra("sstkdate")
           val stockid=intent.getStringExtra("ssstockid")
           val stockdesc=intent.getStringExtra("ssstkdesc")
           val iddb=intent.getStringExtra("idofdb")
           val grochk=intent.getStringExtra("grosschk")

           grosschk=grochk

           deletelistener=intent.getStringExtra("deletelistner")

           val ad = intent.getStringExtra("addtrans")
           val ed = intent.getStringExtra("edittrans")
           val del = intent.getStringExtra("deletetrans")
           val vi=intent.getStringExtra("viewtrans")
           val tran=intent.getStringExtra("transfertrans")
           val ex=intent.getStringExtra("exporttrans")
           sendtrans=intent.getStringExtra("sendtrans")

           if (ad != null) {
               addtrans = ad
           }
           if (ed != null) {
               editetrans = ed
           }
           if (del != null) {
               deletetrans = del
           }
           if (vi != null) {
               viewtrans = vi
           }
           if (tran != null) {
               transfertrans = tran
           }
           if (ex != null) {
               exporttrans = ex
           }

           println("ADD TRANSFER"+addtrans)


           val adano = intent.getStringExtra("addtransano")
           val edano = intent.getStringExtra("edittransano")
           val delano = intent.getStringExtra("deletetransano")
           val viano=intent.getStringExtra("viewtransano")
           val tranano=intent.getStringExtra("transfertransano")
           val exano=intent.getStringExtra("exporttransano")
           sendtransano=intent.getStringExtra("sendtransano")
           if (adano != null) {
               addtransano = adano
           }
           if (edano != null) {
               editetransano = edano
           }
           if (delano != null) {
               deletetransano = delano
           }
           if (viano != null) {
               viewtransano = viano
           }
           if (tranano != null) {
               transfertransano = tranano
           }
           if (exano != null) {
               exporttransano = exano
           }


           val adrec = intent.getStringExtra("addrec")
           val edrec = intent.getStringExtra("editrec")
           val delrec = intent.getStringExtra("deleterec")
           val virec=intent.getStringExtra("viewrec")
           val tranrec=intent.getStringExtra("transferrec")
           val exrec=intent.getStringExtra("exportrec")
           val sendrec=intent.getStringExtra("sendstrec")

           if (adrec != null) {
               addrec = adrec
           }
           if (edrec != null) {
               editrec = edrec
           }
           if (delrec != null) {
               deleterec = delrec
           }
           if (virec != null) {
               viewrec = virec
           }
           if (tranrec != null) {
               transferrec = tranrec
           }
           if (exrec != null) {
               exportrec = exrec
           }
           if (sendrec != null) {
               sendstrec = sendrec
           }





try {
    descripdup = intent.getStringExtra("descripdup")
    stdatedup = intent.getStringExtra("stdatedup")
}
catch (e:Exception){

}

           idli=iddd
           datestk=datest
           descstk=stockdesc
           idstk=stockid
           iddbs=iddb
           brnchkey.setText(brkey)
           oriky=originky
           keybrnch=brnchkey.text.toString()
           val namebr=intent.getStringExtra("branch")
           val locbr=intent.getStringExtra("address")
           nm.setText(namebr)
           loc.setText(locbr)
           names=nm.text.toString()
           namesphones=loc.text.toString()
       /*    val i=bundle.get("imageArray") as Array<String>*/
           pronameArrayori      = a
           hsnArrayori          = ds
           manufacturerArrayori =c
           barcodeArrayori      =f
           quantityArrayori     =g
           priceArrayori        =h
           totArrayori          =i
           receivedArrayori     =rec
           cessArrayori         =j
           igstArrayori         =r
           igsttotArrayori      =s
           cesstotalArrayori    =q
           tallyArrayori        =qtall
           imageArrayori        =k
           keyArrayori          =iddd
           proidupArrayori=proidarr
           proidupcopyArrayori=proidcpyarr
           quantityArraycopyori=quanarrcpy




      /*     var n=nm.setText(namebr)
           println(nm.text)
           names=names.plusElement(n.toString())
           println(names)


          var ah=loc.setText(locbr)
           namesphones=namesphones.plusElement(ah.toString())
           println(namesphones)*/



        /*   d.add(b.toString())*/





       }
       else if(frm=="emptylist")
       {
           val namebr=intent.getStringExtra("branch")
           val locbr=intent.getStringExtra("address")
           val brkey=intent.getStringExtra("brnchid")
           val originky=intent.getStringExtra("origiid")
           val dates=intent.getStringExtra("date")
           val grochk=intent.getStringExtra("grosschk")
           val stockid=intent.getStringExtra("ssstockid")
           val stockdesc=intent.getStringExtra("ssstkdesc")

try {
    grosschk = grochk
}
catch (e:Exception){

}
           nm.setText(namebr)
           loc.setText(locbr)
           brnchkey.setText(brkey)
           keybrnch=brnchkey.text.toString()
           names=nm.text.toString()
           namesphones=loc.text.toString()
           oriky=originky
           datestk=dates
           descstk=stockdesc
           idstk=stockid

           deletelistener=intent.getStringExtra("deletelistner")

           try {
               orignm = intent.getStringExtra("orignm")

           }
           catch (e:Exception){

           }


           try {
               val prodel = bundle.get("proiddelete") as ArrayList<String>

               if (prodel.isNotEmpty() == true) {
                   proiddelete = prodel
               } else {

               }

               val quandel = bundle.get("quantitydelete") as ArrayList<String>

               if (quandel.isNotEmpty() == true) {
                   quantitydelete = prodel
               } else {

               }
           }
           catch (e:Exception){

           }

           try {
               descripdup = intent.getStringExtra("descripdup")
               stdatedup = intent.getStringExtra("stdatedup")
           }
           catch (e:Exception){

           }



           val ad = intent.getStringExtra("addtrans")
           val ed = intent.getStringExtra("edittrans")
           val del = intent.getStringExtra("deletetrans")
           val vi=intent.getStringExtra("viewtrans")
           val tran=intent.getStringExtra("transfertrans")
           val ex=intent.getStringExtra("exporttrans")
           sendtrans=intent.getStringExtra("sendtrans")

           if (ad != null) {
               addtrans = ad
           }
           if (ed != null) {
               editetrans = ed
           }
           if (del != null) {
               deletetrans = del
           }
           if (vi != null) {
               viewtrans = vi
           }
           if (tran != null) {
               transfertrans = tran
           }
           if (ex != null) {
               exporttrans = ex
           }

           println("ADD TRANSFER"+addtrans)


           val adano = intent.getStringExtra("addtransano")
           val edano = intent.getStringExtra("edittransano")
           val delano = intent.getStringExtra("deletetransano")
           val viano=intent.getStringExtra("viewtransano")
           val tranano=intent.getStringExtra("transfertransano")
           val exano=intent.getStringExtra("exporttransano")
           sendtransano=intent.getStringExtra("sendtransano")
           if (adano != null) {
               addtransano = adano
           }
           if (edano != null) {
               editetransano = edano
           }
           if (delano != null) {
               deletetransano = delano
           }
           if (viano != null) {
               viewtransano = viano
           }
           if (tranano != null) {
               transfertransano = tranano
           }
           if (exano != null) {
               exporttransano = exano
           }


           val adrec = intent.getStringExtra("addrec")
           val edrec = intent.getStringExtra("editrec")
           val delrec = intent.getStringExtra("deleterec")
           val virec=intent.getStringExtra("viewrec")
           val tranrec=intent.getStringExtra("transferrec")
           val exrec=intent.getStringExtra("exportrec")
           val sendrec=intent.getStringExtra("sendstrec")

           if (adrec != null) {
               addrec = adrec
           }
           if (edrec != null) {
               editrec = edrec
           }
           if (delrec != null) {
               deleterec = delrec
           }
           if (virec != null) {
               viewrec = virec
           }
           if (tranrec != null) {
               transferrec = tranrec
           }
           if (exrec != null) {
               exportrec = exrec
           }
           if (sendrec != null) {
               sendstrec = sendrec
           }


           //Purchase order

       }
        val db = FirebaseFirestore.getInstance()
        val TAG = "some"


       get()



       //-----------------------------SEARCH ACTION-----------------------------//

       searchedit.addTextChangedListener(object : TextWatcher {
           override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {


               progressBar3.visibility = View.VISIBLE
               product_list.visibility = View.GONE

               if(searchedit.length()==1){
                   product_list.visibility=View.VISIBLE

               }
               nores.visibility = View.GONE
               if(searchedit.length()==0){
                   nores.visibility = View.GONE
               }
               sd = des.toString()
               x = sd
               val ps = "^[a-zA-Z ]+$"
               val regexStr = "^[0-9]*$"
               val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
               fun priget() {




                   if ((des.length >= 1)) {

                       var pronameArraydup = arrayListOf<String>()
                       var hsnArraydup = arrayListOf<String>()
                       var manufacturerArraydup = arrayListOf<String>()
                       var barcodeArraydup = arrayListOf<String>()
                       var quantityArraydup = arrayListOf<String>()
                       var priceArraydup = arrayListOf<String>()
                       var totArraydup = arrayListOf<String>()
                       var cessArraydup = arrayListOf<String>()
                       var imageArraydup = arrayListOf<String>()
                       var igstArraydup = arrayListOf<String>()
                       var igsttotArraydup = arrayListOf<String>()
                       var cesstotalArraydup = arrayListOf<String>()
                       var receivedArraydup = arrayListOf<String>()
                       var tallyArraydup = arrayListOf<String>()
                       var maxarraydup = arrayListOf<String>()
                       var soharraydup = arrayListOf<String>()
                       var keyArraydup = arrayListOf<String>()
                       var proidArraydup = arrayListOf<String>()
                       var proidArraycpydup = arrayListOf<String>()

                       var highnmarray = arrayOf<String>()
                       var highurlarray = arrayOf<String>()

                       var quantityArraycopydup = arrayListOf<String>()


                       nores.visibility = View.GONE


                       db.collection("product").orderBy("price").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {
                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)

                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                           val dd = document.data


                                           var statuss = dd["status"].toString()
                                           var bstkhnd = dd["$oriky"].toString()
                                           var kk = document.id.toString()
                                           println("STATUS" + statuss)

                                           if (!proidupArrayori.contains(kk)) {
                                               nores.visibility = View.GONE

                                               product_list.visibility = View.VISIBLE
                                               progressBar3.visibility = View.GONE
                                               already.visibility = View.GONE
                                               if ((statuss == "Active") && (bstkhnd != "0")) {

                                                   var idofpr = document.id.toString()




                                                   if (idofpr.isNotEmpty()) {

                                                       proidArraydup.add(idofpr)
                                                   } else {
                                                       proidArraydup.add("-")
                                                   }

                                                   var prnm = (dd["p_nm"].toString())

                                                   var wgvols = (dd["wg_vol"].toString())
                                                   var uts = (dd["ut"].toString())

                                                   if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                       prnm = prnm + " - " + wgvols + " " + uts
                                                   } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                       prnm = prnm
                                                   } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                       prnm = prnm
                                                   } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                       prnm = prnm
                                                   } else {
                                                       prnm = prnm
                                                   }

                                                   if (prnm.isNotEmpty()) {

                                                       pronameArraydup.add(prnm)
                                                   } else {
                                                       pronameArraydup.add("No title")
                                                   }

                                                   highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                   highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                   var soharr = (dd["$oriky"].toString())
                                                   var maxstkarr = (dd["mx_stk"].toString())

                                                   if (soharr.isNotEmpty()) {
                                                       soharraydup.add("SOH - " + soharr)
                                                   }
                                                   if (maxstkarr.isNotEmpty()) {
                                                       maxarraydup.add(maxstkarr)
                                                   } else {
                                                       maxarraydup.add("0")

                                                   }

                                                   var manu = (dd["mfr"].toString())

                                                   if (manu.isNotEmpty() && manu != "Select") {
                                                       manufacturerArraydup.add(manu)

                                                   } else {
                                                       manufacturerArraydup.add("MFR - Not Available")
                                                   }

                                                   var hsn = (dd["hsn"].toString())

                                                   if (hsn.isNotEmpty()) {
                                                       hsnArraydup.add(hsn)

                                                   } else {
                                                       hsnArraydup.add("0")
                                                   }

                                                   quantityArraydup.add("1")




                                                   priceArraydup.add(dd["price"].toString())

                                                   var tot = (dd["price"].toString())


                                                   if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                       totArraydup.add(tot)

                                                   } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                       totArraydup.add(tot + ".00")
                                                   } else {
                                                       totArraydup.add("0.0")
                                                   }


                                                   var bc = (dd["bc"].toString())

                                                   if (bc.isNotEmpty()) {
                                                       barcodeArraydup.add(bc)

                                                   } else {
                                                       barcodeArraydup.add("Not Available")
                                                   }


                                                   quantityArraydup.add("1")

                                                   cessArraydup.add("0.0")
                                                   igstArraydup.add("0.0")
                                                   igsttotArraydup.add("0.0")
                                                   cesstotalArraydup.add("0.0")
                                                   tallyArraydup.add("Not tallied")
                                                   receivedArraydup.add("0")
                                                   quantityArraycopydup.add("0")

                                                   proidArraycpydup.add("")

                                                   tallyArraydup.add("Not tallied")



                                                   try {
                                                       var im = dd["img1url"].toString()
                                                       image = im
                                                       if (im.isNotEmpty()) {

                                                           imageArraydup.add(im)
                                                       } else {
                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                       }
                                                   } catch (e: Exception) {

                                                   }
                                                   keyArraydup.add("")

















                                                   d.add(document.id.toString())
                                                   pronameArray = pronameArraydup
                                                   hsnArray = hsnArraydup
                                                   manufacturerArray = manufacturerArraydup
                                                   barcodeArray = barcodeArraydup
                                                   quantityArray = quantityArraydup
                                                   priceArray = priceArraydup
                                                   totArray = totArraydup
                                                   cessArray = cessArraydup
                                                   imageArray = imageArraydup
                                                   igstArray = igstArraydup
                                                   igsttotArray = igsttotArraydup
                                                   cesstotalArray = cesstotalArraydup
                                                   receivedArray = receivedArraydup
                                                   tallyArray = tallyArraydup
                                                   keyArray = keyArraydup
                                                   proidArray = proidArraydup
                                                   proidcopyArray = proidArraycpydup

                                                   quantityArraycopy = quantityArraycopydup
                                                   nores.visibility = View.GONE

                                                   val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, maxarraydup,
                                                           priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, igsttotArraydup, cesstotalArraydup,
                                                           tallyArraydup, soharraydup, imageArraydup, highnmarray, highurlarray)

                                                   product_list.adapter = whatever

                                                   /*   swipeContainer.setRefreshing(false);*/


                                               }
                                           } else if (proidupArrayori.contains(kk) && proidArraydup.isEmpty()) {

                                               /* product_list.visibility = View.GONE
                                               already.setText("You have already added this product")
                                                already.visibility=View.VISIBLE
                                                progressBar3.visibility = View.GONE*/
                                           } else {
                                               //swipeContainer.setRefreshing(false);


                                           }



                                           progressBar3.visibility = View.GONE


                                           progressBar3.visibility = View.GONE

                                       }
                                   }
                                   else {
                                       db.collection("product").orderBy("$oriky").startAt(numberstr).endAt(esc)
                                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                   if (e != null) {
                                                   }
                                                   if (value.isEmpty == false) {
                                                       for (document in value) {
                                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)

                                                           Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                           val dd = document.data


                                                           var statuss = dd["status"].toString()
                                                           var bstkhnd = dd["$oriky"].toString()
                                                           var kk = document.id.toString()
                                                           println("STATUS" + statuss)

                                                           if (!proidupArrayori.contains(kk)) {
                                                               nores.visibility = View.GONE

                                                               product_list.visibility = View.VISIBLE
                                                               progressBar3.visibility = View.GONE
                                                               already.visibility = View.GONE
                                                               if ((statuss == "Active") && (bstkhnd != "0")) {

                                                                   var idofpr = document.id.toString()




                                                                   if (idofpr.isNotEmpty()) {

                                                                       proidArraydup.add(idofpr)
                                                                   } else {
                                                                       proidArraydup.add("-")
                                                                   }

                                                                   var prnm = (dd["p_nm"].toString())

                                                                   var wgvols = (dd["wg_vol"].toString())
                                                                   var uts = (dd["ut"].toString())

                                                                   if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                       prnm = prnm + " - " + wgvols + " " + uts
                                                                   } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                       prnm = prnm
                                                                   } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                       prnm = prnm
                                                                   } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                       prnm = prnm
                                                                   } else {
                                                                       prnm = prnm
                                                                   }

                                                                   if (prnm.isNotEmpty()) {

                                                                       pronameArraydup.add(prnm)
                                                                   } else {
                                                                       pronameArraydup.add("No title")
                                                                   }

                                                                   highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                                   highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                                   var soharr = (dd["$oriky"].toString())
                                                                   var maxstkarr = (dd["mx_stk"].toString())

                                                                   if (soharr.isNotEmpty()) {
                                                                       soharraydup.add("SOH - " + soharr)
                                                                   }
                                                                   if (maxstkarr.isNotEmpty()) {
                                                                       maxarraydup.add(maxstkarr)
                                                                   } else {
                                                                       maxarraydup.add("0")

                                                                   }

                                                                   var manu = (dd["mfr"].toString())

                                                                   if (manu.isNotEmpty() && manu != "Select") {
                                                                       manufacturerArraydup.add(manu)

                                                                   } else {
                                                                       manufacturerArraydup.add("MFR - Not Available")
                                                                   }

                                                                   var hsn = (dd["hsn"].toString())

                                                                   if (hsn.isNotEmpty()) {
                                                                       hsnArraydup.add(hsn)

                                                                   } else {
                                                                       hsnArraydup.add("0")
                                                                   }

                                                                   quantityArraydup.add("1")




                                                                   priceArraydup.add(dd["price"].toString())

                                                                   var tot = (dd["price"].toString())


                                                                   if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                                       totArraydup.add(tot)

                                                                   } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                                       totArraydup.add(tot + ".00")
                                                                   } else {
                                                                       totArraydup.add("0.0")
                                                                   }


                                                                   var bc = (dd["bc"].toString())

                                                                   if (bc.isNotEmpty()) {
                                                                       barcodeArraydup.add(bc)

                                                                   } else {
                                                                       barcodeArraydup.add("Not Available")
                                                                   }


                                                                   quantityArraydup.add("1")

                                                                   cessArraydup.add("0.0")
                                                                   igstArraydup.add("0.0")
                                                                   igsttotArraydup.add("0.0")
                                                                   cesstotalArraydup.add("0.0")
                                                                   tallyArraydup.add("Not tallied")
                                                                   receivedArraydup.add("0")
                                                                   quantityArraycopydup.add("0")

                                                                   proidArraycpydup.add("")

                                                                   tallyArraydup.add("Not tallied")



                                                                   try {
                                                                       var im = dd["img1url"].toString()
                                                                       image = im
                                                                       if (im.isNotEmpty()) {

                                                                           imageArraydup.add(im)
                                                                       } else {
                                                                           imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                                       }
                                                                   } catch (e: Exception) {

                                                                   }
                                                                   keyArraydup.add("")

















                                                                   d.add(document.id.toString())
                                                                   pronameArray = pronameArraydup
                                                                   hsnArray = hsnArraydup
                                                                   manufacturerArray = manufacturerArraydup
                                                                   barcodeArray = barcodeArraydup
                                                                   quantityArray = quantityArraydup
                                                                   priceArray = priceArraydup
                                                                   totArray = totArraydup
                                                                   cessArray = cessArraydup
                                                                   imageArray = imageArraydup
                                                                   igstArray = igstArraydup
                                                                   igsttotArray = igsttotArraydup
                                                                   cesstotalArray = cesstotalArraydup
                                                                   receivedArray = receivedArraydup
                                                                   tallyArray = tallyArraydup
                                                                   keyArray = keyArraydup
                                                                   proidArray = proidArraydup
                                                                   proidcopyArray = proidArraycpydup


                                                                   quantityArraycopy = quantityArraycopydup
                                                                   nores.visibility = View.GONE

                                                                   val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArray, manufacturerArray, hsnArray, barcodeArray, maxarraydup,
                                                                           priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray,
                                                                           tallyArray, soharraydup, imageArray, highnmarray, highurlarray)

                                                                   product_list.adapter = whatever

                                                                   /*   swipeContainer.setRefreshing(false);*/


                                                               }
                                                           } else if (proidupArrayori.contains(kk) && proidArraydup.isEmpty()) {

                                                               /*product_list.visibility = View.GONE
                                                               already.setText("You have already added this product")
                                                               already.visibility=View.VISIBLE

                                                               progressBar3.visibility = View.GONE*/
                                                           } else {
                                                               //swipeContainer.setRefreshing(false);


                                                           }



                                                           progressBar3.visibility = View.GONE


                                                           progressBar3.visibility = View.GONE

                                                       }
                                                   } else {
                                                       if(searchedit.text.toString().isNotEmpty()){
                                                           nores.visibility=View.VISIBLE
                                                       }
                                                       progressBar3.visibility = View.GONE


                                                   }


                                                   /* } else {
                                                        Log.w(TAG, "Error getting documents.", task.exception)
                                                    }*/


                                               })
                                   }

                                   /*} else {
                                       Log.w(TAG, "Error getting documents.", task.exception)
                                   }*/
                               })


                   }

               }
               fun bcodeget() {

                   nores.visibility = View.GONE

                   if ((des.length >= 1) && (bcd == "bcode")) {



                       println("BARCODE")

                       var pronameArraydup = arrayListOf<String>()
                       var hsnArraydup = arrayListOf<String>()
                       var manufacturerArraydup = arrayListOf<String>()
                       var barcodeArraydup = arrayListOf<String>()
                       var quantityArraydup = arrayListOf<String>()
                       var priceArraydup = arrayListOf<String>()
                       var totArraydup = arrayListOf<String>()
                       var cessArraydup = arrayListOf<String>()
                       var imageArraydup = arrayListOf<String>()
                       var igstArraydup = arrayListOf<String>()
                       var igsttotArraydup = arrayListOf<String>()
                       var cesstotalArraydup = arrayListOf<String>()
                       var receivedArraydup = arrayListOf<String>()
                       var tallyArraydup = arrayListOf<String>()
                       var maxarraydup = arrayListOf<String>()

                       var soharraydup = arrayListOf<String>()

                       var keyArraydup = arrayListOf<String>()
                       var proidArraydup = arrayListOf<String>()
                       var proidArraycpydup = arrayListOf<String>()

                       var highnmarray = arrayOf<String>()
                       var highurlarray = arrayOf<String>()

                       var quantityArraycopydup = arrayListOf<String>()




                       db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {
                                               Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                               val dd = document.data


                                               var statuss = dd["status"].toString()
                                               var bstkhnd = dd["$oriky"].toString()
                                               var kk = document.id.toString()
                                               println("STATUS" + statuss)

                                               if (!proidupArrayori.contains(kk)) {

                                                   product_list.visibility = View.VISIBLE
                                                   progressBar3.visibility = View.GONE
                                                   already.visibility = View.GONE
                                                   if ((statuss == "Active") && (bstkhnd != "0")) {

                                                       var idofpr = document.id.toString()




                                                       if (idofpr.isNotEmpty()) {

                                                           proidArraydup.add(idofpr)

                                                       } else {
                                                           proidArraydup.add("-")
                                                       }

                                                       var prnm = (dd["p_nm"].toString())



                                                       var wgvols = (dd["wg_vol"].toString())
                                                       var uts = (dd["ut"].toString())

                                                       if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                           prnm = prnm + " - " + wgvols + " " + uts
                                                       } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                           prnm = prnm
                                                       } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                           prnm = prnm
                                                       } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                           prnm = prnm
                                                       } else {
                                                           prnm = prnm
                                                       }

                                                       if (prnm.isNotEmpty()) {

                                                           pronameArraydup.add(prnm)
                                                       } else {
                                                           pronameArraydup.add("No title")
                                                       }

                                                       highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                       highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                       var soharr = (dd["$oriky"].toString())
                                                       var maxstkarr = (dd["mx_stk"].toString())

                                                       if (soharr.isNotEmpty()) {
                                                           soharraydup.add("SOH - " + soharr)
                                                       }
                                                       if (maxstkarr.isNotEmpty()) {
                                                           maxarraydup.add(maxstkarr)
                                                       } else {
                                                           maxarraydup.add("0")

                                                       }

                                                       var manu = (dd["mfr"].toString())

                                                       if (manu.isNotEmpty() && manu != "Select") {
                                                           manufacturerArraydup.add(manu)

                                                       } else {
                                                           manufacturerArraydup.add("MFR - Not Available")
                                                       }

                                                       var hsn = (dd["hsn"].toString())

                                                       if (hsn.isNotEmpty()) {
                                                           hsnArraydup.add(hsn)

                                                       } else {
                                                           hsnArraydup.add("0")
                                                       }

                                                       quantityArraydup.add("1")




                                                       priceArraydup.add(dd["price"].toString())

                                                       var tot = (dd["price"].toString())


                                                       if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                           totArraydup.add(tot)

                                                       } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                           totArraydup.add(tot + ".00")
                                                       } else {
                                                           totArraydup.add("0.0")
                                                       }


                                                       var bc = (dd["bc"].toString())

                                                       if (bc.isNotEmpty()) {
                                                           barcodeArraydup.add(bc)

                                                       } else {
                                                           barcodeArraydup.add("Not Available")
                                                       }


                                                       quantityArray.add("1")

                                                       cessArraydup.add("0.0")
                                                       igstArraydup.add("0.0")
                                                       igsttotArraydup.add("0.0")
                                                       cesstotalArraydup.add("0.0")
                                                       tallyArraydup.add("Not tallied")
                                                       receivedArraydup.add("0")
                                                       quantityArraycopydup.add("0")

                                                       proidArraycpydup.add("")

                                                       tallyArraydup.add("Not tallied")



                                                       try {
                                                           var im = dd["img1url"].toString()
                                                           image = im
                                                           if (im.isNotEmpty()) {

                                                               imageArraydup.add(im)
                                                           } else {
                                                               imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                           }
                                                       } catch (e: Exception) {

                                                       }
                                                       keyArraydup.add("")










                                                       pronameArray = pronameArraydup
                                                       hsnArray = hsnArraydup
                                                       manufacturerArray = manufacturerArraydup
                                                       barcodeArray = barcodeArraydup
                                                       quantityArray = quantityArraydup
                                                       priceArray = priceArraydup
                                                       totArray = totArraydup
                                                       cessArray = cessArraydup
                                                       imageArray = imageArraydup
                                                       igstArray = igstArraydup
                                                       igsttotArray = igsttotArraydup
                                                       cesstotalArray = cesstotalArraydup
                                                       receivedArray = receivedArraydup
                                                       tallyArray = tallyArraydup
                                                       keyArray = keyArraydup
                                                       proidArray = proidArraydup
                                                       proidcopyArray = proidArraycpydup


                                                       quantityArraycopy = quantityArraycopydup

                                                       nores.visibility = View.GONE

                                                       val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, maxarraydup,
                                                               priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, igsttotArraydup, cesstotalArraydup,
                                                               tallyArraydup, soharraydup, imageArray, highnmarray, highurlarray)
                                                       product_list.adapter = whatever



                                                       d.add(document.id.toString())

                                                       /*   swipeContainer.setRefreshing(false);*/


                                                   }
                                               } else if (proidupArrayori.contains(kk) && proidArraydup.isEmpty()) {

                                              /*     product_list.visibility = View.GONE
                                                   already.setText("You have already added this product")
                                                   already.visibility=View.VISIBLE

                                                   progressBar3.visibility = View.GONE*/
                                               } else {
                                                   //swipeContainer.setRefreshing(false);


                                               }




                                               progressBar3.visibility = View.GONE


                                               progressBar3.visibility = View.GONE

                                           }
                                       } else {
                                           db.collection("product").orderBy("$oriky").startAt(numberstr).endAt(esc)

                                                   .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                       if (e != null) {
                                                       }
                                                       if (value.isEmpty == false) {
                                                           for (document in value) {
                                                                   Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                   val dd = document.data


                                                                   var statuss = dd["status"].toString()
                                                                   var bstkhnd = dd["$oriky"].toString()
                                                                   var kk = document.id.toString()
                                                                   println("STATUS" + statuss)

                                                                   if (!proidupArrayori.contains(kk)) {

                                                                       product_list.visibility = View.VISIBLE
                                                                       progressBar3.visibility = View.GONE
                                                                       already.visibility = View.GONE
                                                                       if ((statuss == "Active") && (bstkhnd != "0")) {

                                                                           var idofpr = document.id.toString()




                                                                           if (idofpr.isNotEmpty()) {

                                                                               proidArraydup.add(idofpr)
                                                                           } else {
                                                                               proidArraydup.add("-")
                                                                           }

                                                                           var prnm = (dd["p_nm"].toString())

                                                                           var wgvols = (dd["wg_vol"].toString())
                                                                           var uts = (dd["ut"].toString())

                                                                           if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                               prnm = prnm + " - " + wgvols + " " + uts
                                                                           } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                               prnm = prnm
                                                                           } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                               prnm = prnm
                                                                           } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                               prnm = prnm
                                                                           } else {
                                                                               prnm = prnm
                                                                           }

                                                                           if (prnm.isNotEmpty()) {

                                                                               pronameArraydup.add(prnm)
                                                                           } else {
                                                                               pronameArraydup.add("No title")
                                                                           }

                                                                           highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                                           highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                                           var soharr = (dd["$oriky"].toString())
                                                                           var maxstkarr = (dd["mx_stk"].toString())

                                                                           if (soharr.isNotEmpty()) {
                                                                               soharraydup.add("SOH - " + soharr)
                                                                           }
                                                                           if (maxstkarr.isNotEmpty()) {
                                                                               maxarraydup.add(maxstkarr)
                                                                           } else {
                                                                               maxarraydup.add("0")

                                                                           }

                                                                           var manu = (dd["mfr"].toString())

                                                                           if (manu.isNotEmpty() && manu != "Select") {
                                                                               manufacturerArraydup.add(manu)

                                                                           } else {
                                                                               manufacturerArraydup.add("MFR - Not Available")
                                                                           }

                                                                           var hsn = (dd["hsn"].toString())

                                                                           if (hsn.isNotEmpty()) {
                                                                               hsnArraydup.add(hsn)

                                                                           } else {
                                                                               hsnArraydup.add("0")
                                                                           }

                                                                           quantityArraydup.add("1")




                                                                           priceArraydup.add(dd["price"].toString())

                                                                           var tot = (dd["price"].toString())


                                                                           if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                                               totArraydup.add(tot)

                                                                           } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                                               totArraydup.add(tot + ".00")
                                                                           } else {
                                                                               totArraydup.add("0.0")
                                                                           }


                                                                           var bc = (dd["bc"].toString())

                                                                           if (bc.isNotEmpty()) {
                                                                               barcodeArraydup.add(bc)

                                                                           } else {
                                                                               barcodeArraydup.add("Not Available")
                                                                           }


                                                                           quantityArraydup.add("1")

                                                                           cessArraydup.add("0.0")
                                                                           igstArraydup.add("0.0")
                                                                           igsttotArraydup.add("0.0")
                                                                           cesstotalArraydup.add("0.0")
                                                                           tallyArraydup.add("Not tallied")
                                                                           receivedArraydup.add("0")
                                                                           quantityArraycopydup.add("0")

                                                                           proidArraycpydup.add("")

                                                                           tallyArraydup.add("Not tallied")



                                                                           try {
                                                                               var im = dd["img1url"].toString()
                                                                               image = im
                                                                               if (im.isNotEmpty()) {

                                                                                   imageArraydup.add(im)
                                                                               } else {
                                                                                   imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                                               }
                                                                           } catch (e: Exception) {

                                                                           }
                                                                           keyArraydup.add("")

















                                                                           d.add(document.id.toString())
                                                                           pronameArray = pronameArraydup
                                                                           hsnArray = hsnArraydup
                                                                           manufacturerArray = manufacturerArraydup
                                                                           barcodeArray = barcodeArraydup
                                                                           quantityArray = quantityArraydup
                                                                           priceArray = priceArraydup
                                                                           totArray = totArraydup
                                                                           cessArray = cessArraydup
                                                                           imageArray = imageArraydup
                                                                           igstArray = igstArraydup
                                                                           igsttotArray = igsttotArraydup
                                                                           cesstotalArray = cesstotalArraydup
                                                                           receivedArray = receivedArraydup
                                                                           tallyArray = tallyArraydup
                                                                           keyArray = keyArraydup
                                                                           proidArray = proidArraydup
                                                                           proidcopyArray = proidArraycpydup


                                                                           quantityArraycopy = quantityArraycopydup

                                                                           nores.visibility = View.GONE

                                                                           val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, maxarraydup,
                                                                                   priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, igsttotArraydup, cesstotalArraydup,
                                                                                   tallyArraydup, soharraydup, imageArray, highnmarray, highurlarray)
                                                                           product_list.adapter = whatever


                                                                           /*   swipeContainer.setRefreshing(false);*/


                                                                       }
                                                                   } else if (proidupArrayori.contains(kk) && proidArraydup.isEmpty()) {

                                                                       product_list.visibility = View.GONE
                                                                       nores.visibility = View.VISIBLE

                                                                       progressBar3.visibility = View.GONE
                                                                   } else {
                                                                       //swipeContainer.setRefreshing(false);


                                                                   }





                                                                   progressBar3.visibility = View.GONE


                                                                   progressBar3.visibility = View.GONE

                                                               }
                                                           }
                                                           else{
                                                           priget()
                                                               /*product_list.visibility = View.GONE
                                                               already.setText("You have already added this product")
                                                               already.visibility=View.VISIBLE
                                                               progressBar3.visibility=View.GONE*/
                                                           }


                                                      /* } else {
                                                           Log.w(TAG, "Error getting documents.", task.exception)
                                                       }*/
                                                   })


                                       }

                               })
                   }
               }















               if (x.trim().matches(regexStr.toRegex())) {
                   upstr = x
                   println("CAME INTO NUMBER" + upstr)
                   var escp = x + '\uf8ff'
                   esc = escp
                   reg = upstr
                   numberstr = upstr
                   bcd = "bcode"
                   bcodeget()
                   //write code here for success
               }
               fun nameget() {
                   if ((des.length >= 3) && (x != reg)) {

                       nores.visibility = View.GONE

                       var pronameArraydup = arrayListOf<String>()
                       var hsnArraydup = arrayListOf<String>()
                       var manufacturerArraydup = arrayListOf<String>()
                       var barcodeArraydup = arrayListOf<String>()
                       var quantityArraydup = arrayListOf<String>()
                       var priceArraydup = arrayListOf<String>()
                       var totArraydup = arrayListOf<String>()
                       var cessArraydup = arrayListOf<String>()
                       var imageArraydup = arrayListOf<String>()
                       var igstArraydup = arrayListOf<String>()
                       var igsttotArraydup = arrayListOf<String>()
                       var cesstotalArraydup = arrayListOf<String>()
                       var receivedArraydup = arrayListOf<String>()
                       var tallyArraydup = arrayListOf<String>()
                       var maxarraydup = arrayListOf<String>()

                       var soharraydup = arrayListOf<String>()

                       var keyArraydup = arrayListOf<String>()
                       var proidArraydup = arrayListOf<String>()
                       var proidArraycpydup = arrayListOf<String>()

                       var highnmarray = arrayOf<String>()
                       var highurlarray = arrayOf<String>()

                       var quantityArraycopydup = arrayListOf<String>()




                       db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                               .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                   if (e != null) {
                                   }
                                   if (value.isEmpty == false) {
                                       for (document in value) {
                                               Log.d(TAG, "dapet" + document.id + " => " + document.data)

                                               val dd = document.data


                                               var statuss = dd["status"].toString()
                                               var bstkhnd = dd["$oriky"].toString()
                                               var kk = document.id.toString()
                                               println("STATUS" + statuss)

                                               if (!proidupArrayori.contains(kk)) {

                                                   product_list.visibility = View.VISIBLE
                                                   progressBar3.visibility = View.GONE
                                                   already.visibility = View.GONE
                                                   if ((statuss == "Active")&&(bstkhnd!="0")) {

                                                       var idofpr = document.id.toString()




                                                       if (idofpr.isNotEmpty()) {

                                                           proidArraydup.add(idofpr)
                                                       } else {
                                                           proidArraydup.add("-")
                                                       }

                                                       var prnm = (dd["p_nm"].toString())

                                                       println("P_NM" + prnm)

                                                       var wgvols = (dd["wg_vol"].toString())
                                                       var uts = (dd["ut"].toString())

                                                       if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                           prnm = prnm + " - " + wgvols + " " + uts
                                                       } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                           prnm = prnm
                                                       } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                           prnm = prnm
                                                       } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                           prnm = prnm
                                                       } else {
                                                           prnm = prnm
                                                       }

                                                       if (prnm.isNotEmpty()) {

                                                           pronameArraydup.add(prnm)
                                                       } else {
                                                           pronameArraydup.add("No title")
                                                       }

                                                       highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                       highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                       var soharr = (dd["$oriky"].toString())
                                                       var maxstkarr = (dd["mx_stk"].toString())

                                                       if (soharr.isNotEmpty()) {
                                                           soharraydup.add("SOH - " + soharr)
                                                       }
                                                       if (maxstkarr.isNotEmpty()) {
                                                           maxarraydup.add(maxstkarr)
                                                       } else {
                                                           maxarraydup.add("0")

                                                       }

                                                       var manu = (dd["mfr"].toString())

                                                       if (manu.isNotEmpty() && manu != "Select") {
                                                           manufacturerArraydup.add(manu)

                                                       } else {
                                                           manufacturerArraydup.add("MFR - Not Available")
                                                       }

                                                       var hsn = (dd["hsn"].toString())

                                                       if (hsn.isNotEmpty()) {
                                                           hsnArraydup.add(hsn)

                                                       } else {
                                                           hsnArraydup.add("0")
                                                       }

                                                       quantityArraydup.add("1")



                                                       println("NAMES" + pronameArray)
                                                       println("SOH ARRAY" + soharraydup)



                                                       priceArraydup.add(dd["price"].toString())

                                                       var tot = (dd["price"].toString())


                                                       if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                           totArraydup.add(tot)

                                                       } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                           totArraydup.add(tot + ".00")
                                                       } else {
                                                           totArraydup.add("0.0")
                                                       }


                                                       var bc = (dd["bc"].toString())

                                                       if (bc.isNotEmpty()) {
                                                           barcodeArraydup.add(bc)

                                                       } else {
                                                           barcodeArraydup.add("Not Available")
                                                       }


                                                       quantityArraydup.add("1")

                                                       cessArraydup.add("0.0")
                                                       igstArraydup.add("0.0")
                                                       igsttotArraydup.add("0.0")
                                                       cesstotalArraydup.add("0.0")
                                                       tallyArraydup.add("Not tallied")
                                                       receivedArraydup.add("0")
                                                       quantityArraycopydup.add("0")

                                                       proidArraycpydup.add("")

                                                       tallyArraydup.add("Not tallied")



                                                       try {
                                                           var im = dd["img1url"].toString()
                                                           image = im
                                                           if (im.isNotEmpty()) {

                                                               imageArraydup.add(im)
                                                           } else {
                                                               imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                           }
                                                       } catch (e: Exception) {

                                                       }
                                                       keyArraydup.add("")

















                                                       d.add(document.id.toString())
                                                       pronameArray = pronameArraydup
                                                       hsnArray = hsnArraydup
                                                       manufacturerArray = manufacturerArraydup
                                                       barcodeArray = barcodeArraydup
                                                       quantityArray = quantityArraydup
                                                       priceArray = priceArraydup
                                                       totArray = totArraydup
                                                       cessArray = cessArraydup
                                                       imageArray = imageArraydup
                                                       igstArray = igstArraydup
                                                       igsttotArray = igsttotArraydup
                                                       cesstotalArray = cesstotalArraydup
                                                       receivedArray = receivedArraydup
                                                       tallyArray = tallyArraydup
                                                       keyArray = keyArraydup
                                                       proidArray = proidArraydup
                                                       proidcopyArray = proidArraycpydup
                                                       quantityArraycopy = quantityArraycopydup
                                                       /*   swipeContainer.setRefreshing(false);*/
                                                       nores.visibility = View.GONE

                                                       val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, maxarraydup,
                                                               priceArraydup, totArraydup, cessArraydup, keyArraydup, igstArraydup, igsttotArraydup, cesstotalArraydup,
                                                               tallyArraydup, soharraydup, imageArraydup, highnmarray, highurlarray)
                                                       product_list.adapter = whatever
                                                   }
                                               } else if (proidupArrayori.contains(kk)) {

                                                   /*product_list.visibility = View.GONE
                                                   already.setText("You have already added this product")
                                                   already.visibility=View.VISIBLE

                                                   progressBar3.visibility = View.GONE*/
                                               } else {
                                                   //swipeContainer.setRefreshing(false);


                                               }





                                               progressBar3.visibility = View.GONE





                                           }
                                       } else {
                                           db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                   .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                       if (e != null) {
                                                       }
                                                       if (value.isEmpty == false) {
                                                           for (document in value) {
                                                                   Log.d(TAG, "dapet" + document.id + " => " + document.data)

                                                                   Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                   val dd = document.data


                                                                   var statuss = dd["status"].toString()
                                                                   var bstkhnd = dd["$oriky"].toString()
                                                                   var kk = document.id.toString()
                                                                   println("STATUS" + statuss)

                                                                   if (!proidupArrayori.contains(kk)) {

                                                                       product_list.visibility = View.VISIBLE
                                                                       progressBar3.visibility = View.GONE
                                                                       already.visibility = View.GONE
                                                                       if ((statuss == "Active") && (bstkhnd != "0")) {

                                                                           var idofpr = document.id.toString()




                                                                           if (idofpr.isNotEmpty()) {

                                                                               proidArraydup.add(idofpr)
                                                                           } else {
                                                                               proidArraydup.add("-")
                                                                           }

                                                                           var prnm = (dd["p_nm"].toString())

                                                                           var wgvols = (dd["wg_vol"].toString())
                                                                           var uts = (dd["ut"].toString())

                                                                           if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                               prnm = prnm + " - " + wgvols + " " + uts
                                                                           } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts != "Select")) {
                                                                               prnm = prnm
                                                                           } else if ((wgvols.isNotEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                               prnm = prnm
                                                                           } else if ((wgvols.isEmpty()) && (uts.isNotEmpty() && uts == "Select")) {
                                                                               prnm = prnm
                                                                           } else {
                                                                               prnm = prnm
                                                                           }

                                                                           if (prnm.isNotEmpty()) {

                                                                               pronameArraydup.add(prnm)
                                                                           } else {
                                                                               pronameArraydup.add("No title")
                                                                           }

                                                                           highnmarray = highnmarray.plusElement(dd["img1nhigh"].toString())
                                                                           highurlarray = highurlarray.plusElement(dd["img1urlhigh"].toString())

                                                                           var soharr = (dd["$oriky"].toString())
                                                                           var maxstkarr = (dd["mx_stk"].toString())

                                                                           if (soharr.isNotEmpty()) {
                                                                               soharraydup.add("SOH - " + soharr)
                                                                           }
                                                                           if (maxstkarr.isNotEmpty()) {
                                                                               maxarraydup.add(maxstkarr)
                                                                           } else {
                                                                               maxarraydup.add("0")

                                                                           }

                                                                           var manu = (dd["mfr"].toString())

                                                                           if (manu.isNotEmpty() && manu != "Select") {
                                                                               manufacturerArraydup.add(manu)

                                                                           } else {
                                                                               manufacturerArraydup.add("MFR - Not Available")
                                                                           }

                                                                           var hsn = (dd["hsn"].toString())

                                                                           if (hsn.isNotEmpty()) {
                                                                               hsnArraydup.add(hsn)

                                                                           } else {
                                                                               hsnArraydup.add("0")
                                                                           }

                                                                           quantityArraydup.add("1")




                                                                           priceArraydup.add(dd["price"].toString())

                                                                           var tot = (dd["price"].toString())


                                                                           if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                                               totArraydup.add(tot)

                                                                           } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                                               totArraydup.add(tot + ".00")
                                                                           } else {
                                                                               totArraydup.add("0.0")
                                                                           }


                                                                           var bc = (dd["bc"].toString())

                                                                           if (bc.isNotEmpty()) {
                                                                               barcodeArraydup.add(bc)

                                                                           } else {
                                                                               barcodeArraydup.add("Not Available")
                                                                           }


                                                                           quantityArraydup.add("1")

                                                                           cessArraydup.add("0.0")
                                                                           igstArraydup.add("0.0")
                                                                           igsttotArraydup.add("0.0")
                                                                           cesstotalArraydup.add("0.0")
                                                                           tallyArraydup.add("Not tallied")
                                                                           receivedArraydup.add("0")
                                                                           quantityArraycopydup.add("0")

                                                                           proidArraycpydup.add("")

                                                                           tallyArraydup.add("Not tallied")



                                                                           try {
                                                                               var im = dd["img1url"].toString()
                                                                               image = im
                                                                               if (im.isNotEmpty()) {

                                                                                   imageArraydup.add(im)
                                                                               } else {
                                                                                   imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                                                               }
                                                                           } catch (e: Exception) {

                                                                           }
                                                                           keyArraydup.add("")













                                                                           println("NAMES CATEGORY" + pronameArray)



                                                                           d.add(document.id.toString())
                                                                           pronameArray = pronameArraydup
                                                                           hsnArray = hsnArraydup
                                                                           manufacturerArray = manufacturerArraydup
                                                                           barcodeArray = barcodeArraydup
                                                                           quantityArray = quantityArraydup
                                                                           priceArray = priceArraydup
                                                                           totArray = totArraydup
                                                                           cessArray = cessArraydup
                                                                           imageArray = imageArraydup
                                                                           igstArray = igstArraydup
                                                                           igsttotArray = igsttotArraydup
                                                                           cesstotalArray = cesstotalArraydup
                                                                           receivedArray = receivedArraydup
                                                                           tallyArray = tallyArraydup
                                                                           keyArray = keyArraydup
                                                                           proidArray = proidArraydup
                                                                           proidcopyArray = proidArraycpydup
                                                                           quantityArraycopy = quantityArraycopydup

                                                                           /*   swipeContainer.setRefreshing(false);*/
                                                                           nores.visibility = View.GONE

                                                                           val whatever = scroll_stock_one_adap(this@product_list_activity, pronameArray, manufacturerArray, hsnArray, barcodeArray, maxarraydup,
                                                                                   priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray,
                                                                                   tallyArray, soharraydup, imageArray, highnmarray, highurlarray)

                                                                           product_list.adapter = whatever

                                                                       }
                                                                   } else if (proidupArrayori.contains(kk) && proidArraydup.isEmpty()) {
                                                                       /*product_list.visibility = View.GONE
                                                                       already.setText("You have already added this product")
                                                                       already.visibility=View.VISIBLE

                                                                       progressBar3.visibility = View.GONE*/

                                                                   } else {
                                                                       //swipeContainer.setRefreshing(false);


                                                                   }



                                                                   progressBar3.visibility = View.GONE


                                                                   progressBar3.visibility = View.GONE
                                                               }
                                                           } else {

                                                           if(searchedit.text.toString().isNotEmpty()){
                                                               product_list.visibility = View.GONE
                                                               nores.visibility=View.VISIBLE
                                                           }
                                                               progressBar3.visibility=View.GONE
                                                           }



                                                   })


                                       }

                                   /*} else {


                                   }*/
                               })
                   }


               }

               if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                   val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                   upstr = upperString
                   /*nmstr = upstr*/
                   var escp = upperString + '\uf8ff'
                   esc = escp
                   println("CAPPPSSSS" + upperString)
                   println("CAME INTO NUMBER upper names" + upstr)
                   println("STRINGSSSS" + upstr)
                   nameget()
               }




















               return
           }
           override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                          arg3: Int) {
               // TODO Auto-generated method stub


           }
           override fun afterTextChanged(arg0: Editable) {
               // TODO Auto-generated method stub
               if(searchedit.length()==0)
               {
                   product_list.visibility = View.VISIBLE

                   progressBar3.visibility=View.GONE
                   nores.visibility=View.GONE

                   get()
               }
           }
       })

      /* swipeContainer.setOnRefreshListener {




           get()



           // Your code to refresh the list here.
           // Make sure you call swipeContainer.setRefreshing(false)
           // once the network request has completed successfully.

       }
       // Configure the refreshing colors
       swipeContainer.setColorSchemeResources(R.color.tool,
               android.R.color.holo_green_light,
               android.R.color.holo_orange_light,
               android.R.color.holo_red_light)*/
        /*private fun addImageView(layout: LinearLayout) {
            val imageView = ImageView(this)
            imageView.setImageResource(R.drawable.ic_launcher)
            layout.addView(imageView)
        }*/

    }
    fun get() {


        //-------------------------Get all products from db and single/multi select product to (Mainstk_branch_one) ---------------------//

        product_list.setOnItemClickListener { parent, views, position, id ->




            ///--------------------------Single select on product lis------------------------------//


            var checkedCount = product_list.getCheckedItemCount()

            val az = pronameArray.get(position)
            val bz = hsnArray.get(position)
            val t = manufacturerArray.get(position)
            val cz = quantityArray.get(position)
            val mz = barcodeArray.get(position)
            val fz = priceArray.get(position)
            val oz = totArray.get(position)
            val qz = cessArray.get(position)
            val qigz = igstArray.get(position)
            val qigtotz = igsttotArray.get(position)
            val qcesstotz = cesstotalArray.get(position)
            val qtallyz = tallyArray.get(position)
            val rece = receivedArray.get(position)
            val imz = imageArray.get(position)
            val li = keyArray.get(position)
            var pid=proidArray.get(position)
            var pidcpy=proidcopyArray.get(position)


            var quancpy=quantityArraycopy.get(position)


            pronameArraycpy.add(az)
            manufacturerArraycpy.add(t)
            hsnArraycpy.add(bz)
            quantityArraycpy.add(cz)
            barcodeArraycpy.add(mz)
            priceArraycpy.add(fz)
            totArraycpy.add(oz)
            cessArraycpy.add(qz)
            igstArraycpy.add(qigz)
            igsttotArraycpy.add(qigtotz)
            cesstotalArraycpy.add(qcesstotz)
            tallyArraycpy.add(qtallyz)
            receivedArraycpy.add(rece)
            imageArraycpy.add(imz.toString())
            idupArraycpy.add(li)
            proidupArraycpy.add(pid)
            proidcopyupArraycpy.add(pidcpy)
            quantityArraycopycpy.add(quancpy)


            imageArray.add(image)


            grosschk="list"

            var a=pronameArraycpy.toString()
            var atr=a.removeSurrounding("[","]")

            var bs=manufacturerArraycpy.toString()
            var btr=bs.removeSurrounding("[","]")

            var cs=hsnArraycpy.toString()
            var cstr=cs.removeSurrounding("[","]")

            var ds=quantityArraycpy.toString()
            var dstr=ds.removeSurrounding("[","]")

            var es=barcodeArraycpy.toString()
            var estr=es.removeSurrounding("[","]")

            var fs=priceArraycpy.toString()
            var fstr=fs.removeSurrounding("[","]")

            var gs=totArraycpy.toString()
            var gstr=gs.removeSurrounding("[","]")

            var hs=cessArraycpy.toString()
            var hstr=hs.removeSurrounding("[","]")


            var ijs=igstArraycpy.toString()
            var ijsstr=ijs.removeSurrounding("[","]")


            var jjs=igsttotArraycpy.toString()
            var jjsstr=jjs.removeSurrounding("[","]")

            var kjs=cesstotalArraycpy.toString()
            var kjsstr=kjs.removeSurrounding("[","]")

            var ljs=tallyArraycpy.toString()
            var ljsstr=ljs.removeSurrounding("[","]")

            var mjs=receivedArraycpy.toString()
            var mjsstr=mjs.removeSurrounding("[","]")

            var njs=imageArraycpy.toString()
            var njsstr=njs.removeSurrounding("[","]")

            var njspid=proidupArraycpy.toString()
            var njspidstr=njspid.removeSurrounding("[","]")


            var njspidcpy=proidcopyupArraycpy.toString()
            var njspidcpystr=njspidcpy.removeSurrounding("[","]")

            var njsquancpy=quantityArraycopycpy.toString()
            var njsquancpystr=njsquancpy.removeSurrounding("[","]")

            pronameArrayori.add(atr.toString())
            manufacturerArrayori.add(btr.toString())
            hsnArrayori.add(cstr.toString())
            quantityArrayori.add(dstr.toString())
            barcodeArrayori.add(estr.toString())
            priceArrayori.add(fstr.toString())
            totArrayori.add(gstr.toString())
            cessArrayori.add(hstr.toString())
            igstArrayori.add(ijsstr.toString())
            igsttotArrayori.add(jjsstr.toString())
            cesstotalArrayori.add(kjsstr.toString())
            tallyArrayori.add(ljsstr.toString())
            receivedArrayori.add(mjsstr.toString())
            imageArrayori.add(njsstr.toString())
            proidupArrayori.add(njspidstr.toString())
            proidupcopyArrayori.add(njspidcpystr.toString())
            quantityArraycopyori.add(njsquancpystr.toString())
            keyArrayori.add("")

            namesori = names
            namesphonesori = namesphones
            println(pronameArraycpy.lastIndex)


            val b = Intent(applicationContext, Mainstk_branch_one::class.java)
                    .putStringArrayListExtra("dlt", dlt)
            println((pronameArrayori))
            println((priceArrayori))

            b.putExtra("from", "list_single")


            val apr=pronameArrayori.toString()
            val apsn=apr.removeSurrounding("[","]")


            b.putExtra("pname", pronameArrayori)
            b.putExtra("pitem", manufacturerArrayori)
            b.putExtra("phsn", hsnArrayori)
            b.putExtra("porder", quantityArrayori)

            b.putExtra("pprice", priceArrayori)
            b.putExtra("ptot", totArrayori)
            b.putExtra("poarray", barcodeArrayori)
            b.putExtra("cessarray", cessArrayori)
            b.putExtra("igstarray", igstArrayori)
            b.putExtra("igsttotarray", igsttotArrayori)
            b.putExtra("cesstotalarray", cesstotalArrayori)
            b.putExtra("tallyarray", tallyArrayori)
            b.putExtra("receivedarray", receivedArrayori)
            b.putExtra("proidarray",proidupArrayori)
            b.putExtra("proidarrayscpy",proidupcopyArrayori)

            b.putExtra("proiddelete",proiddelete)
            b.putExtra("quantitydelete",quantitydelete)

            b.putExtra("requancpy",quantityArraycopyori)
            b.putExtra("branch", namesori)
            b.putExtra("address", namesphonesori)
            b.putExtra("brkey", keybrnch)
            b.putExtra("redate", datestk)
            b.putExtra("redesc", descstk)
            b.putExtra("restkid", idstk)
            b.putExtra("reiddb", iddbs)
            b.putExtra("reiddofli", keyArrayori)
            b.putExtra("originkey", oriky)
            b.putExtra("groschk", grosschk)

            b.putExtra("orignm",orignm)


            b.putExtra("stdatedup", stdatedup)
            b.putExtra("descripdup", descripdup)



            b.putExtra("deletelistener",deletelistener)


            b.putExtra("ids",ids)



            b.putExtra("proiddelete",proiddelete)
            b.putExtra("quantitydelete",quantitydelete)

            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)




            b.putExtra("imi", imageArrayori)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()


        }

        progressBar3.visibility=View.VISIBLE


        //--------------------------Get and list out the products from db.--------------------------------------//

        db.collection("product")

                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    var pronameArraydup = arrayListOf<String>()
                    var hsnArraydup = arrayListOf<String>()
                    var manufacturerArraydup = arrayListOf<String>()
                    var barcodeArraydup = arrayListOf<String>()
                    var quantityArraydup = arrayListOf<String>()
                    var priceArraydup = arrayListOf<String>()
                    var totArraydup = arrayListOf<String>()
                    var cessArraydup = arrayListOf<String>()
                    var imageArraydup = arrayListOf<String>()
                    var igstArraydup = arrayListOf<String>()
                    var igsttotArraydup = arrayListOf<String>()
                    var cesstotalArraydup = arrayListOf<String>()
                    var receivedArraydup = arrayListOf<String>()
                    var tallyArraydup = arrayListOf<String>()
                    var maxarraydup = arrayListOf<String>()

                    var soharraydup = arrayListOf<String>()

                    var keyArraydup = arrayListOf<String>()
                    var proidArraydup= arrayListOf<String>()
                    var proidArraycpydup= arrayListOf<String>()

                    var highnmarray=arrayOf<String>()
                    var highurlarray=arrayOf<String>()

                    var quantityArraycopydup=arrayListOf<String>()

                    pronameArray=pronameArraydup
                    hsnArray=hsnArraydup
                    manufacturerArray=manufacturerArraydup
                    barcodeArray=barcodeArraydup
                    quantityArray=quantityArraydup
                    priceArray=priceArraydup
                    totArray=totArraydup
                    cessArray=cessArraydup
                    imageArray=imageArraydup
                    igstArray=igstArraydup
                    igsttotArray=igsttotArraydup
                    cesstotalArray=cesstotalArraydup
                    receivedArray=receivedArraydup
                    tallyArray=tallyArraydup
                    keyArray=keyArraydup
                    proidArray=proidArraydup
                    proidcopyArray=proidArraycpydup

                    quantityArraycopy=quantityArraycopydup


                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {

                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data


                                var statuss = dd["status"].toString()
                                var bstkhnd=dd["$oriky"].toString()
                                var kk = document.id.toString()
                                println("STATUS" + statuss)

                                if (!proidupArrayori.contains(kk)) {

                                    product_list.visibility = View.VISIBLE
                                    progressBar3.visibility = View.GONE
                                    already.visibility = View.GONE
                                    if ((statuss == "Active")&&(bstkhnd!="0")) {

                                        var idofpr = document.id.toString()




                                        if (idofpr.isNotEmpty()) {

                                            proidArray.add(idofpr)
                                        } else {
                                            proidArray.add("-")
                                        }

                                        var prnm = (dd["p_nm"].toString())

                                        var wgvols=(dd["wg_vol"].toString())
                                        var uts=(dd["ut"].toString())

                                        if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                            prnm=prnm+" - "+wgvols+" "+uts
                                        }

                                        else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                            prnm=prnm
                                        }
                                        else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                            prnm=prnm
                                        }
                                        else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                            prnm=prnm
                                        }
                                        else{
                                            prnm=prnm
                                        }

                                        if (prnm.isNotEmpty()) {

                                            pronameArray.add(prnm)
                                        } else {
                                            pronameArray.add("No title")
                                        }

                                        highnmarray=highnmarray.plusElement(dd["img1nhigh"].toString())
                                        highurlarray=highurlarray.plusElement(dd["img1urlhigh"].toString())

                                        var soharr=(dd["$oriky"].toString())
                                        var maxstkarr=(dd["mx_stk"].toString())

                                        if(soharr.isNotEmpty()){
                                            soharraydup.add("SOH - "+soharr)
                                        }
                                        if(maxstkarr.isNotEmpty()){
                                            maxarraydup.add(maxstkarr)
                                        }
                                        else{
                                            maxarraydup.add("0")

                                        }

                                        var manu = (dd["mfr"].toString())

                                        if (manu.isNotEmpty()&&manu!="Select") {
                                            manufacturerArray.add(manu)

                                        } else {
                                            manufacturerArray.add("MFR - Not Available")
                                        }

                                        var hsn = (dd["hsn"].toString())

                                        if (hsn.isNotEmpty()) {
                                            hsnArray.add(hsn)

                                        } else {
                                            hsnArray.add("0")
                                        }

                                        quantityArray.add("1")




                                        priceArray.add(dd["price"].toString())

                                        var tot = (dd["price"].toString())


                                        if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                            totArray.add(tot)

                                        }
                                        else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                            totArray.add(tot+".00")
                                        }
                                        else {
                                            totArray.add("0.0")
                                        }


                                        var bc = (dd["bc"].toString())

                                        if (bc.isNotEmpty()) {
                                            barcodeArray.add(bc)

                                        } else {
                                            barcodeArray.add("Not Available")
                                        }


                                        quantityArray.add("1")

                                        cessArray.add("0.0")
                                        igstArray.add("0.0")
                                        igsttotArray.add("0.0")
                                        cesstotalArray.add("0.0")
                                        tallyArray.add("Not tallied")
                                        receivedArray.add("0")
                                        quantityArraycopy.add("0")

                                        proidcopyArray.add("")

                                        tallyArray.add("Not tallied")



                                        try {
                                            var im = dd["img1url"].toString()
                                            image = im
                                            if (im.isNotEmpty()) {

                                                imageArray.add(im)
                                            } else {
                                                imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=ec35c2b8-84e7-4e4b-83b6-81017e97a615")
                                            }
                                        } catch (e: Exception) {

                                        }
                                        keyArray.add("")

















                                        d.add(document.id.toString())

                                        /*   swipeContainer.setRefreshing(false);*/

                                        progressBar3.visibility=View.GONE


                                    }
                                } else if (proidupArrayori.contains(kk) && proidArray.isEmpty()) {
                                    progressBar3.visibility=View.GONE
                                    product_list.visibility = View.GONE
                                    progressBar3.visibility = View.GONE
                                    already.setText("You have already added all products")
                                    already.visibility=View.VISIBLE
                                } else {
                                    //swipeContainer.setRefreshing(false);

                                    progressBar3.visibility=View.GONE

                                }


                                val whatever = scroll_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,maxarraydup,
                                        priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray,
                                        tallyArray, soharraydup, imageArray,highnmarray,highurlarray)

                                product_list.adapter = whatever
                                progressBar3.visibility = View.GONE


                                progressBar3.visibility = View.GONE

                            }
                        }
                        else{

                        }
                   /* }else {
                        Log.w(TAG, "Error getting documents.", task.exception)
                    }*/
                })



        ///------------------------ Multi select the products to (Mainst_branch_one)----------------------------------------///

        product_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        product_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = product_list.getCheckedItemCount()
                val l = d.get(position)
                val az=pronameArray.get(position)
                val bz=hsnArray.get(position)
                val t = manufacturerArray.get(position)
                val cz=quantityArray.get(position)
                val mz=barcodeArray.get(position)
                val fz=priceArray.get(position)
                val oz=totArray.get(position)
                val qz=cessArray.get(position)
                val qigz=igstArray.get(position)
                val qigtotz=igsttotArray.get(position)
                val qcesstotz=cesstotalArray.get(position)
                val qtallyz=tallyArray.get(position)
                val rece=receivedArray.get(position)
                val imz=imageArray.get(position)
                val li=keyArray.get(position)
                val proidli=proidArray.get(position)
                val quancpy=quantityArraycopy.get(position)
                val proidlicpy=proidcopyArray.get(position)
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                val tex =CircleImageView(this@product_list_activity)
                val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                textLayoutParams.setMargins(20, 0, 0, 0)
                textLayoutParams.height=100
                textLayoutParams.width=100
                tex.setBorderColor(Color.BLACK)
                tex.setBorderWidth(1)
                tex.setPadding(4,4,4,4)
                tex.setLayoutParams(textLayoutParams)
                try {
                    Picasso.with(this@product_list_activity)
                            .load(imageArray[position])
                            .into(tex);
                }
                catch (e:Exception){

                }
                tex.setTag(l)
                linearlayout.setGravity(Gravity.CENTER)
                tex.setOnClickListener {
                    val r = linearlayout.findViewWithTag<View>(l)
                    linearlayout.removeView(r)
                    Log.d("list","    "+product_list.setItemChecked(position,false))
                }
                if (checked) {
                    // list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    pronameArraycpy.add(az)
                    manufacturerArraycpy.add(t)
                    hsnArraycpy.add(bz)
                    quantityArraycpy.add(cz)
                    barcodeArraycpy.add(mz)
                    priceArraycpy.add(fz)
                    totArraycpy.add(oz)
                    cessArraycpy.add(qz)
                    igstArraycpy.add(qigz)
                    igsttotArraycpy.add(qigtotz)
                    cesstotalArraycpy.add(qcesstotz)
                    tallyArraycpy.add(qtallyz)
                    receivedArraycpy.add(rece)
                    imageArraycpy.add(imz.toString())
                    idupArraycpy.add(li)
                    proidupArraycpy.add(proidli)
                    proidcopyupArraycpy.add(proidlicpy)

                    quantityArraycopycpy.add(quancpy)

                    imageArray.add(image)
                    Log.i(TAG,"itm "+dlt.size)
                    // val tex = TextView(this@product_list_activity)
                    //tex.setBackgroundResource(R.drawable.crcle)
                    Log.d("list","    "+product_list.getCheckedItemPositions())
                    linearlayout.addView(tex)

                    horizontalScrollView.visibility=View.VISIBLE
                } else {
                    val r = linearlayout.findViewWithTag<View>(l)
                    dlt.remove(l)
                    pronameArraycpy.remove(az)
                    manufacturerArraycpy.remove(t)
                    hsnArraycpy.remove(bz)
                    quantityArraycpy.remove(cz)
                    barcodeArraycpy.remove(mz)
                    priceArraycpy.remove(fz)
                    totArraycpy.remove(oz)
                    cessArraycpy.remove(qz)
                    igstArraycpy.remove(qigz)
                    igsttotArraycpy.remove(qigtotz)
                    cesstotalArraycpy.remove(qcesstotz)
                    tallyArraycpy.remove(qtallyz)
                    receivedArraycpy.remove(rece)
                    imageArraycpy.remove(imz.toString())
                    idupArraycpy.remove(li)
                    proidupArraycpy.remove(proidli)
                    proidcopyupArraycpy.remove(proidlicpy)
                    quantityArraycopycpy.remove(quancpy)
                    /*       imageArray=imageArray.plusElement(R.drawable.loreal_bottl)*/


                    Log.d("tag","   "+r)
                    linearlayout.removeView(r)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                    Log.d(TAG,"id  "+position)
                }


            }


            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                product_list_toolbar.visibility = View.GONE
                product_list_back_btn.visibility=View.GONE
                product_page_title.visibility=View.GONE
                search.visibility=View.GONE
                if(cardsearch.visibility==View.VISIBLE) {
                    searchedit.setText("")
                    cardsearch.visibility = View.GONE

                    cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_list_activity, R.anim.slide_to_left))
                }
                mode.getMenuInflater().inflate(R.menu.product_select, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val deleteSize =dlt.size
                Log.i("tsdfs","  "+dlt.size)
                /*val cate = null
                val data = s(cat = cate)*/
                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                val itemId = item.getItemId()

                grosschk="list"
                if (itemId == R.id.ok) {
                    println(pronameArraycpy.size)
                    //if (this@product_list_activity.equals("product_list_activity"))
                    for(i in 0 until pronameArraycpy.size)
                    {
                        pronameArrayori.add(pronameArraycpy.get(i))
                        manufacturerArrayori.add(manufacturerArraycpy.get(i))
                        hsnArrayori.add(hsnArraycpy.get(i))
                        quantityArrayori.add(quantityArraycpy.get(i))
                        barcodeArrayori.add(barcodeArraycpy.get(i))
                        priceArrayori.add(priceArraycpy.get(i))
                        totArrayori.add(totArraycpy.get(i))
                        cessArrayori.add(cessArraycpy.get(i))
                        igstArrayori.add(igstArraycpy.get(i))
                        igsttotArrayori.add(igsttotArraycpy.get(i))
                        cesstotalArrayori.add(cesstotalArraycpy.get(i))
                        tallyArrayori.add(tallyArraycpy.get(i))
                        receivedArrayori.add(receivedArraycpy.get(i))
                        imageArrayori.add(imageArraycpy.get(i))
                        proidupArrayori.add(proidupArraycpy.get(i))
                        proidupcopyArrayori.add(proidcopyupArraycpy.get(i))
                        quantityArraycopyori.add(quantityArraycopycpy.get(i))
                        keyArrayori.add("")

                        namesori=names
                        namesphonesori=namesphones
                        println(pronameArraycpy.lastIndex)
                        if(pronameArraycpy.lastIndex == i)
                        {
                            Log.d("fdgshgtgh","NAMESSSSSSSSSSSSSSSSS             "   +(pronameArrayori))
                        }
                    }
                    val b = Intent(applicationContext,Mainstk_branch_one::class.java)
                            .putStringArrayListExtra("dlt",dlt)
                    println((pronameArrayori))
                    println((priceArrayori))

                    b.putExtra("from","list")
                    b.putExtra("pname",pronameArrayori)
                    b.putExtra("pitem",manufacturerArrayori)
                    b.putExtra("phsn",hsnArrayori)
                    b.putExtra("porder",quantityArrayori)

                    b.putExtra("pprice",priceArrayori)
                    b.putExtra("ptot",totArrayori)
                    b.putExtra("poarray",barcodeArrayori)
                    b.putExtra("cessarray",cessArrayori)
                    b.putExtra("igstarray",igstArrayori)
                    b.putExtra("igsttotarray",igsttotArrayori)
                    b.putExtra("cesstotalarray",cesstotalArrayori)
                    b.putExtra("tallyarray",tallyArrayori)
                    b.putExtra("receivedarray",receivedArrayori)
                    b.putExtra("proidarrays",proidupArrayori)
                    b.putExtra("proidarrayscpy",proidupcopyArrayori)
                    b.putExtra("requancpy",quantityArraycopyori)

                    b.putExtra("stdatedup", stdatedup)
                    b.putExtra("descripdup", descripdup)
                    b.putExtra("branch",names)
                    b.putExtra("address",namesphones)
                    b.putExtra("brkey",keybrnch)
                    b.putExtra("redate",datestk)
                    b.putExtra("redesc",descstk)
                    b.putExtra("restkid",idstk)
                    b.putExtra("reiddb",iddbs)
                    b.putExtra("reiddofli",keyArrayori)
                    b.putExtra("originkey",oriky)
                    b.putExtra("groschk",grosschk)
                    b.putExtra("deletelistener",deletelistener)

                    b.putExtra("orignm",orignm)

                    b.putExtra("proiddelete",proiddelete)
                    b.putExtra("quantitydelete",quantitydelete)







                    b.putExtra("ids",ids)




                    b.putExtra("viewtrans", viewtrans)
                    b.putExtra("addtrans", addtrans)
                    b.putExtra("edittrans", editetrans)
                    b.putExtra("deletetrans", deletetrans)
                    b.putExtra("transfertrans", transfertrans)
                    b.putExtra("exporttrans", exporttrans)
                    b.putExtra("sendtrans", sendtrans)


                    b.putExtra("viewtransano", viewtransano)
                    b.putExtra("addtransano", addtransano)
                    b.putExtra("edittransano", editetransano)
                    b.putExtra("deletetransano", deletetransano)
                    b.putExtra("transfertransano", transfertransano)
                    b.putExtra("exporttransano", exporttransano)
                    b.putExtra("sendtransano", sendtransano)

                    b.putExtra("viewrec", viewrec)
                    b.putExtra("addrec", addrec)
                    b.putExtra("deleterec", deleterec)
                    b.putExtra("editrec", editrec)
                    b.putExtra("transferrec", transferrec)
                    b.putExtra("exportrec", exportrec)
                    b.putExtra("sendstrec",sendstrec)




                    b.putExtra("imi",imageArrayori)


                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()


                    /*for (i in dlt) {
                        Log.d("dlt","  "+i)
                    }*/
                }
                /* checkedCount = 0*/
                // list_item.clear()


                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                linearlayout.removeAllViews()
                horizontalScrollView.visibility=View.GONE
                product_list_toolbar.visibility =View.VISIBLE
                product_list_back_btn.visibility=View.VISIBLE
                product_page_title.visibility=View.VISIBLE
                search.visibility=View.VISIBLE
            }
        })


        product_list_back_btn.setOnClickListener {

            //back action

            val b = Intent(applicationContext,Mainstk_branch_one::class.java)
                    .putStringArrayListExtra("dlt",dlt)
            println((pronameArrayori))
            println((priceArrayori))

            b.putExtra("from","list")
            b.putExtra("pname",pronameArrayori)
            b.putExtra("pitem",manufacturerArrayori)
            b.putExtra("phsn",hsnArrayori)
            b.putExtra("porder",quantityArrayori)

            b.putExtra("pprice",priceArrayori)
            b.putExtra("ptot",totArrayori)
            b.putExtra("poarray",barcodeArrayori)
            b.putExtra("cessarray",cessArrayori)
            b.putExtra("igstarray",igstArrayori)
            b.putExtra("igsttotarray",igsttotArrayori)
            b.putExtra("cesstotalarray",cesstotalArrayori)
            b.putExtra("tallyarray",tallyArrayori)
            b.putExtra("receivedarray",receivedArrayori)
            b.putExtra("proidarrays",proidupArrayori)
            b.putExtra("proidarrayscpy",proidupcopyArrayori)
            b.putExtra("requancpy",quantityArraycopyori)

            b.putExtra("branch",names)
            b.putExtra("address",namesphones)
            b.putExtra("brkey",keybrnch)
            b.putExtra("redate",datestk)
            b.putExtra("redesc",descstk)
            b.putExtra("restkid",idstk)
            b.putExtra("reiddb",iddbs)
            b.putExtra("reiddofli",keyArrayori)
            b.putExtra("originkey",oriky)
            b.putExtra("groschk",grosschk)
            b.putExtra("deletelistener",deletelistener)

            b.putExtra("ids",ids)

            b.putExtra("stdatedup", stdatedup)
            b.putExtra("descripdup", descripdup)


            b.putExtra("proiddelete",proiddelete)
            b.putExtra("quantitydelete",quantitydelete)



            b.putExtra("orignm",orignm)



            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)




            b.putExtra("imi",imageArrayori)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }

    override fun onBackPressed() {
        if (cardsearch.visibility == View.VISIBLE) {

            cardsearch.visibility = View.GONE
            nores.visibility=View.INVISIBLE
            product_list.visibility=View.VISIBLE
            progressBar3.visibility=View.GONE
            searchedit.setText("")
           get()


        }
        else {


            //Back action

            val b = Intent(applicationContext, Mainstk_branch_one::class.java)
                    .putStringArrayListExtra("dlt", dlt)
            println((pronameArrayori))
            println((priceArrayori))

            b.putExtra("from", "list")
            b.putExtra("pname", pronameArrayori)
            b.putExtra("pitem", manufacturerArrayori)
            b.putExtra("phsn", hsnArrayori)
            b.putExtra("porder", quantityArrayori)

            b.putExtra("pprice", priceArrayori)
            b.putExtra("ptot", totArrayori)
            b.putExtra("poarray", barcodeArrayori)
            b.putExtra("cessarray", cessArrayori)
            b.putExtra("igstarray", igstArrayori)
            b.putExtra("igsttotarray", igsttotArrayori)
            b.putExtra("cesstotalarray", cesstotalArrayori)
            b.putExtra("tallyarray", tallyArrayori)
            b.putExtra("receivedarray", receivedArrayori)
            b.putExtra("proidarrays", proidupArrayori)
            b.putExtra("proidarrayscpy", proidupcopyArrayori)
            b.putExtra("requancpy", quantityArraycopyori)
            b.putExtra("deletelistener", deletelistener)
            b.putExtra("branch", names)
            b.putExtra("address", namesphones)
            b.putExtra("brkey", keybrnch)
            b.putExtra("redate", datestk)
            b.putExtra("redesc", descstk)
            b.putExtra("restkid", idstk)
            b.putExtra("reiddb", iddbs)
            b.putExtra("reiddofli", keyArrayori)
            b.putExtra("originkey", oriky)
            b.putExtra("groschk", grosschk)
            b.putExtra("proiddelete", proiddelete)
            b.putExtra("quantitydelete", quantitydelete)
            b.putExtra("stdatedup", stdatedup)
            b.putExtra("descripdup", descripdup)
            b.putExtra("orignm", orignm)
            b.putExtra("ids", ids)
            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec", sendstrec)




            b.putExtra("imi", imageArrayori)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
            finish()
        }
    }
    fun net_status():Boolean{  //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
