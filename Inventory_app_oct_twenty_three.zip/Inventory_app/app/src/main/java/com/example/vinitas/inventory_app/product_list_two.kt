package com.example.vinitas.inventory_app

/**
 * Created by Vinitas on 05-02-2018.
 */
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.product_list_activity.*
import android.widget.LinearLayout
import de.hdodenhof.circleimageview.CircleImageView
import android.view.Gravity
import cn.pedant.SweetAlert.SweetAlertDialog
import com.squareup.picasso.Picasso
import java.util.*


class product_list_activity_two : AppCompatActivity() {
    var TAG="some"
    var grosschk= String()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""


    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    private var view=String()
    private var add=String()
    private var delete=String()
    private var edits=String()
    private var import=String()
    private var export=String()

    private var viewpro=String()
    private var addpro=String()
    private var deletepro=String()
    private var editpro=String()
    private var importpro=String()
    private var exportpro=String()
    private var stockin_hand= String()

    private var viewsupp=String()
    private var addsupp=String()
    private var deletesupp=String()
    private var editsupp=String()
    private var importsupp=String()
    private var exportsupp=String()

    private  var viewstklvls=String()


    var names = String()
    var namesori = String()
    var namesphones = String()
    var namesphonesori = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var brid= String()
    var oriid= String()
    var idli= arrayListOf<String>()
    var image= String()




    var pronameArraycpy     = arrayListOf<String>()
    var hsnArraycpy          = arrayListOf<String>()

    var manufacturerArraycpy = arrayListOf<String>()
    var barcodeArraycpy     = arrayListOf<String>()
    var quantityArraycpy     = arrayListOf<String>()
    var priceArraycpy       = arrayListOf<String>()
    var totArraycpy         = arrayListOf<String>()
    var cessArraycpy         = arrayListOf<String>()
    var igstArraycpy= arrayListOf<String>()
    var igsttotArraycpy = arrayListOf<String>()
    var cesstotalArraycpy = arrayListOf<String>()
    var tallyArraycpy = arrayListOf<String>()
    var receivedArraycpy = arrayListOf<String>()
    var imageArraycpy        = arrayListOf<String>()
    var idupArraycpy=arrayListOf<String>()

/*
       val a=intent.getStringExtra("namess")
       names.plusElement(a)
       val ab=intent.getStringExtra("brnchnamess")
       namesphones.plusElement(ab)*/

    //ARRAYS OF LISTS

    var  pronameArray       = arrayListOf<String>()
    var  hsnArray           = arrayListOf<String>()
    var  manufacturerArray  = arrayListOf<String>()
    var  barcodeArray       = arrayListOf<String>()
    var  quantityArray      = arrayListOf<String>()
    var  priceArray         = arrayListOf<String>()
    var  totArray           = arrayListOf<String>()
    var  cessArray          = arrayListOf<String>()
    var  imageArray         = arrayListOf<String>()
    var  igstArray         = arrayListOf<String>()
    var  igsttotArray         = arrayListOf<String>()
    var  cesstotalArray         = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var keyArray=arrayListOf<String>()

    var  pronameArrayori     = arrayListOf<String>()
    var  hsnArrayori         = arrayListOf<String>()
    var  manufacturerArrayori= arrayListOf<String>()
    var  barcodeArrayori      = arrayListOf<String>()
    var  quantityArrayori     = arrayListOf<String>()
    var  priceArrayori        = arrayListOf<String>()
    var  totArrayori         = arrayListOf<String>()
    var  cessArrayori        = arrayListOf<String>()
    var igstArrayori =arrayListOf<String>()
    var igsttotArrayori =arrayListOf<String>()
    var cesstotalArrayori =arrayListOf<String>()
    var tallyArrayori =arrayListOf<String>()
    var receivedArrayori =arrayListOf<String>()
    var  imageArrayori        = arrayListOf<String>()
    var keyArrayori=arrayListOf<String>()
    var d = arrayListOf<String>()

    var dlt = arrayListOf<String>()


    /* var compnameArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
     var itemnmArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
     var orderArray = arrayOf<String>("BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273")
     var poArray = arrayOf<String>("60/100 Received","20/100 Received","30/100 Received","40/100 Received","50/100 Received")
     var completeArray = arrayOf<String>("200ml","300ml","400ml","500ml","600ml")
     var priceArray = arrayOf<String>("3000.00","4000.00","4500.00","5000.00","6000.00")
     var imageArray = arrayOf<Int>(R.drawable.promen,R.drawable.loreal_bottl,R.drawable.loreal_bottl,R.drawable.promen,R.drawable.loreal_bottl)
     var d = arrayListOf<String>("fireboost","loreal","fireboost","professional","pantine")*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.product_list_activity)




        net_status()

        val bundle = intent.extras
        var frm = bundle!!.get("fromstate").toString()
        if(frm=="datalist_otstate")
        {

            var a= bundle.get("otherst_namess") as ArrayList<String>
            println(a)
            /*     val b=bundle.get("id") as Array<String>*/
            val c=bundle.get("otherst_orderarray") as ArrayList<String>
            val ds=bundle.get("otherst_hsn") as ArrayList<String>
            /*    val l=bundle.get("item") as Array<String>*/
            val f=bundle.get("otherst_poarray") as ArrayList<String>
            val g=bundle.get("otherst_complete") as ArrayList<String>
            val h=bundle.get("otherst_price") as ArrayList<String>
            val i=bundle.get("otherst_total") as ArrayList<String>
            val j=bundle.get("otherst_cess") as ArrayList<String>
            val r=bundle.get("otherst_igst") as ArrayList<String>
            val s=bundle.get("otherst_igsttot") as ArrayList<String>
            val q=bundle.get("otherst_cesstot") as ArrayList<String>
            val qtall=bundle.get("tallyarray") as ArrayList<String>
            val rec=bundle.get("receivedarray") as ArrayList<String>
            val iddd=bundle.get("otherst_idsofli") as ArrayList<String>
            val k=bundle.get("otherst_im") as ArrayList<String>
try {
    val grochk = intent.getStringExtra("grosschk")
    grosschk = grochk
}
catch (e:Exception){
    var aa=0
    grosschk=aa.toString()
}
            val datest=intent.getStringExtra("otherst_sstkdate")
            val stockid=intent.getStringExtra("otherst_ssstockid")
            val stockdesc=intent.getStringExtra("otherst_ssstkdesc")
            val iddb=intent.getStringExtra("otherst_idofdb")
            val brnchid=intent.getStringExtra("brnchid")
            val oriids=intent.getStringExtra("origiid")

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            brid=brnchid
            oriid=oriids

            idli=iddd
            datestk=datest
            descstk=stockdesc
            idstk=stockid
            iddbs=iddb

            val namebr=intent.getStringExtra("otherst_branch")
            val locbr=intent.getStringExtra("otherst_address")
            nm.setText(namebr)
            loc.setText(locbr)
            names=nm.text.toString()
            namesphones=loc.text.toString()


            /*    val i=bundle.get("imageArray") as Array<String>*/
            pronameArrayori      = a
            hsnArrayori          = ds
            manufacturerArrayori =c
            barcodeArrayori      =f
            quantityArrayori     =g
            priceArrayori        =h
            totArrayori          =i
            cessArrayori         =j
            igstArrayori =r
            igsttotArrayori=s
            cesstotalArrayori=q
            tallyArrayori=qtall
            receivedArrayori=rec
            imageArrayori         =k
            keyArrayori=iddd


            /*     var n=nm.setText(namebr)
                 println(nm.text)
                 names=names.plusElement(n.toString())
                 println(names)


                var ah=loc.setText(locbr)
                 namesphones=namesphones.plusElement(ah.toString())
                 println(namesphones)*/



            /*   d.add(b.toString())*/





        }
        else if(frm=="emptylist_otstate")
        {
            val namebr=intent.getStringExtra("otherst_branch")
            val locbr=intent.getStringExtra("otherst_address")
            val brnchid=intent.getStringExtra("brnchid")
            val oriids=intent.getStringExtra("origiid")
            brid=brnchid
            oriid=oriids
            nm.setText(namebr)
            loc.setText(locbr)
            names=nm.text.toString()
            namesphones=loc.text.toString()
            println("NAMESSS"+names)
            println("NAMESSS ADDRESSS"+namesphones)
            try {
                val grochk = intent.getStringExtra("grosschk")
                grosschk = grochk
            }
            catch(e:Exception){
                var a=0
                grosschk = a.toString()

            }
            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)
            view=intent.getStringExtra("view")
            add=intent.getStringExtra("add")
            delete=intent.getStringExtra("delete")
            edits=intent.getStringExtra("edit")
            import=intent.getStringExtra("import")
            export=intent.getStringExtra("export")


            //Product

            viewpro=intent.getStringExtra("viewpro")
            addpro=intent.getStringExtra("addpro")
            deletepro=intent.getStringExtra("deletepro")
            editpro=intent.getStringExtra("editpro")
            importpro=intent.getStringExtra("importpro")
            exportpro=intent.getStringExtra("exportpro")
            stockin_hand=intent.getStringExtra("changestock")


            //supplier
            viewsupp=intent.getStringExtra("viewsupp")
            addsupp=intent.getStringExtra("addsupp")
            deletesupp=intent.getStringExtra("deletesupp")
            editsupp=intent.getStringExtra("editsupp")
            importsupp=intent.getStringExtra("importsupp")
            exportsupp=intent.getStringExtra("exportsupp")

            viewstklvls=intent.getStringExtra("viewstklvl")

            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order
            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }
            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")
            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

        }
             fun get() {

                 product_list.setOnItemClickListener { parent, views, position, id ->


                     val az=pronameArray.get(position)
                     val bz=hsnArray.get(position)
                     val t = manufacturerArray.get(position)
                     val cz=quantityArray.get(position)
                     val mz=barcodeArray.get(position)
                     val fz=priceArray.get(position)
                     val oz=totArray.get(position)
                     val qz=cessArray.get(position)
                     val qigz=igstArray.get(position)
                     val qigtotz=igsttotArray.get(position)
                     val qcesstotz=cesstotalArray.get(position)
                     val qtallyz=tallyArray.get(position)
                     val rece=receivedArray.get(position)
                     val imz=imageArray.get(position)
                     val li=keyArray.get(position)



                     pronameArraycpy.add(az)
                     manufacturerArraycpy.add(t)
                     hsnArraycpy.add(bz)
                     quantityArraycpy.add(cz)
                     barcodeArraycpy.add(mz)
                     priceArraycpy.add(fz)
                     totArraycpy.add(oz)
                     cessArraycpy.add(qz)
                     igstArraycpy.add(qigz)
                     igsttotArraycpy.add(qigtotz)
                     cesstotalArraycpy.add(qcesstotz)
                     tallyArraycpy.add(qtallyz)
                     receivedArraycpy.add(rece)
                     imageArraycpy.add(imz.toString())
                     idupArraycpy.add(li)
                     imageArray.add(image)



                     var a=pronameArraycpy.toString()
                     var atr=a.removeSurrounding("[","]")

                     var bs=manufacturerArraycpy.toString()
                     var btr=bs.removeSurrounding("[","]")

                     var cs=hsnArraycpy.toString()
                     var cstr=cs.removeSurrounding("[","]")

                     var ds=quantityArraycpy.toString()
                     var dstr=ds.removeSurrounding("[","]")

                     var es=barcodeArraycpy.toString()
                     var estr=es.removeSurrounding("[","]")

                     var fs=priceArraycpy.toString()
                     var fstr=fs.removeSurrounding("[","]")

                     var gs=totArraycpy.toString()
                     var gstr=gs.removeSurrounding("[","]")

                     var hs=cessArraycpy.toString()
                     var hstr=hs.removeSurrounding("[","]")


                     var ijs=igstArraycpy.toString()
                     var ijsstr=ijs.removeSurrounding("[","]")


                     var jjs=igsttotArraycpy.toString()
                     var jjsstr=jjs.removeSurrounding("[","]")

                     var kjs=cesstotalArraycpy.toString()
                     var kjsstr=kjs.removeSurrounding("[","]")

                     var ljs=tallyArraycpy.toString()
                     var ljsstr=ljs.removeSurrounding("[","]")

                     var mjs=receivedArraycpy.toString()
                     var mjsstr=mjs.removeSurrounding("[","]")

                     var njs=imageArraycpy.toString()
                     var njsstr=njs.removeSurrounding("[","]")

                     pronameArrayori.add(atr)
                     manufacturerArrayori.add(btr)
                     hsnArrayori.add(cstr)
                     quantityArrayori.add(dstr)
                     barcodeArrayori.add(estr)
                     priceArrayori.add(fstr)
                     totArrayori.add(gstr)
                     cessArrayori.add(hstr)
                     igstArrayori.add(ijsstr)
                     igsttotArrayori.add(jjsstr)
                     cesstotalArrayori.add(kjsstr)
                     tallyArrayori.add(ljsstr)
                     receivedArrayori.add(mjsstr)
                     imageArrayori.add(njsstr)
                     keyArrayori.add("")

                     namesori=names
                     namesphonesori=namesphones
                     println(pronameArraycpy.lastIndex)

                 val b = Intent(applicationContext,Main_stk_delhi::class.java)
                         .putStringArrayListExtra("dlt",dlt)
                 println((pronameArrayori))
                 println((priceArrayori))

                 b.putExtra("fromstate","sotherlist_single")
                 b.putExtra("sotherthspname",pronameArrayori)
                 b.putExtra("sotherpitem",manufacturerArrayori)
                 b.putExtra("sotherphsn",hsnArrayori)
                 b.putExtra("sotherporder",quantityArrayori)
                 b.putExtra("sotherpprice",priceArrayori)
                 b.putExtra("sotherptot",totArrayori)
                 b.putExtra("sotherpoarray",barcodeArrayori)
                 b.putExtra("sothercessarray",cessArrayori)
                 b.putExtra("sotherigstarray",igstArrayori)
                 b.putExtra("sotherigsttotarray",igsttotArrayori)
                 b.putExtra("sothercesstotalarray",cesstotalArrayori)
                 b.putExtra("tallyarray",tallyArrayori)
                 b.putExtra("receivedarray",receivedArrayori)
                 b.putExtra("sotherredate",datestk)
                 b.putExtra("sotherredesc",descstk)
                 b.putExtra("sotherrestkid",idstk)
                 b.putExtra("sotherreiddb",iddbs)
                 b.putExtra("sotherreiddofli",keyArrayori)

                 b.putExtra("sotherbranch",names)
                 b.putExtra("brnchid",brid)
                 b.putExtra("origiid",oriid)
                 b.putExtra("sotheraddress",namesphones)
                 b.putExtra("groschk",grosschk)

                     b.putExtra("viewsuppin", viewsuppin)
                     b.putExtra("addsuppin", addsuppin)
                     b.putExtra("deletesuppin", deletesuppin)
                     b.putExtra("editsuppin", editesuppin)
                     b.putExtra("transfersuppin", transfersuppin)
                     b.putExtra("exportsuppin", exportsuppin)


                     b.putExtra("viewpurord", viewpurord)
                     b.putExtra("addpurord", addpurord)
                     b.putExtra("deletepurord", deletepurord)
                     b.putExtra("editpurord", editepurord)
                     b.putExtra("transferpurord", transferpurord)
                     b.putExtra("exportpurord", exportpurord)
                     b.putExtra("sendpurord", sendpurpo)




                     b.putExtra("viewpurreq", viewpurreq)
                     b.putExtra("addpurreq", addpurreq)
                     b.putExtra("deletepurreq", deletepurreq)
                     b.putExtra("editpurreq", editepurreq)
                     b.putExtra("transferpurreq", transferpurreq)
                     b.putExtra("exportpurreq", exportpurreq)


                     b.putExtra("viewpro", viewpro)
                     b.putExtra("addpro", addpro)
                     b.putExtra("editpro", editpro)
                     b.putExtra("deletepro", deletepro)
                     b.putExtra("importpro", importpro)
                     b.putExtra("exportpro", exportpro)
                     b.putExtra("changestock", stockin_hand)


                     b.putExtra("view", view)
                     b.putExtra("add", add)
                     b.putExtra("edit", edits)
                     b.putExtra("delete", delete)
                     b.putExtra("import", import)
                     b.putExtra("export", export)


                     b.putExtra("viewsupp", viewsupp)
                     b.putExtra("addsupp", addsupp)
                     b.putExtra("editsupp", editsupp)
                     b.putExtra("deletesupp", deletesupp)
                     b.putExtra("importsupp", importsupp)
                     b.putExtra("exportsupp", exportsupp)



                     b.putExtra("viewtrans", viewtrans)
                     b.putExtra("addtrans", addtrans)
                     b.putExtra("edittrans", editetrans)
                     b.putExtra("deletetrans", deletetrans)
                     b.putExtra("transfertrans", transfertrans)
                     b.putExtra("exporttrans", exporttrans)
                     b.putExtra("sendtrans", sendtrans)


                     b.putExtra("viewtransano", viewtransano)
                     b.putExtra("addtransano", addtransano)
                     b.putExtra("edittransano", editetransano)
                     b.putExtra("deletetransano", deletetransano)
                     b.putExtra("transfertransano", transfertransano)
                     b.putExtra("exporttransano", exporttransano)
                     b.putExtra("sendtransano", sendtransano)

                     b.putExtra("viewrec", viewrec)
                     b.putExtra("addrec", addrec)
                     b.putExtra("deleterec", deleterec)
                     b.putExtra("editrec", editrec)
                     b.putExtra("transferrec", transferrec)
                     b.putExtra("exportrec", exportrec)
                     b.putExtra("sendstrec",sendstrec)


                     b.putExtra("viewstklvl",viewstklvls)


                 b.putExtra("sotherimi",imageArrayori)


                 startActivity(b)
                 finish()


                 }










                 val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                 pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                 pDialog.setTitleText("Loading...")
                 pDialog.setCancelable(false)
                 pDialog.show();
                 val db = FirebaseFirestore.getInstance()
                 val TAG = "some"
                 progressBar3.visibility = View.VISIBLE
                 db.collection("product")
                         .get()
                         .addOnCompleteListener { task ->
                              var pronameArraydup       = arrayListOf<String>()
                              var hsnArraydup           = arrayListOf<String>()
                              var manufacturerArraydup  = arrayListOf<String>()
                              var barcodeArraydup       = arrayListOf<String>()
                              var quantityArraydup      = arrayListOf<String>()
                              var priceArraydup         = arrayListOf<String>()
                              var totArraydup           = arrayListOf<String>()
                              var cessArraydup          = arrayListOf<String>()
                              var imageArraydup         = arrayListOf<String>()
                              var igstArraydup         = arrayListOf<String>()
                              var igsttotArraydup         = arrayListOf<String>()
                              var cesstotalArraydup         = arrayListOf<String>()
                             var tallyArraydup = arrayListOf<String>()
                             var receivedArraydup = arrayListOf<String>()
                             var keyArraydup=arrayListOf<String>()


                             pronameArray=pronameArraydup
                             hsnArray=hsnArraydup
                             manufacturerArray=manufacturerArraydup
                             barcodeArray=barcodeArraydup
                             quantityArray=quantityArraydup
                             priceArray=priceArraydup
                             totArray=totArraydup
                             cessArray=cessArraydup
                             imageArray=imageArraydup
                             igstArray=igstArraydup
                             igsttotArray=igsttotArraydup
                             cesstotalArray=cesstotalArraydup
                             tallyArray=tallyArraydup
                             receivedArray=receivedArraydup
                             keyArray=keyArraydup

                             if (task.isSuccessful) {
                                 Log.d(TAG, "cleared")
                                 if(task.result.isEmpty==false) {
                                     for (document in task.result) {
                                         Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                         val dd = document.data


                                         var prnm = (dd["p_nm"].toString() + " - " + dd["wg_vol"].toString() + "ml")

                                         if (prnm.isNotEmpty()) {

                                             pronameArray.add(prnm)
                                         } else {
                                             pronameArray.add("No title")
                                         }

                                         var manu = (dd["mfr"].toString())

                                         if (manu.isNotEmpty()) {
                                             manufacturerArray.add(manu)

                                         } else {
                                             manufacturerArray.add("No title")
                                         }

                                         var hsn = (dd["hsn"].toString())

                                         if (hsn.isNotEmpty()) {
                                             hsnArray.add(hsn)

                                         } else {
                                             hsnArray.add("0")
                                         }

                                         quantityArray.add("1")




                                         priceArray.add(dd["price"].toString())

                                         var tot = (dd["price"].toString())

                                         if (tot.isNotEmpty()) {
                                             totArray.add(tot)

                                         } else {
                                             totArray.add("0.0")
                                         }


                                         var bc = (dd["bc"].toString())

                                         if (bc.isNotEmpty()) {
                                             barcodeArray.add(bc)

                                         } else {
                                             barcodeArray.add(" - ")
                                         }


                                         quantityArray.add("1")

                                         cessArray.add("0.0")
                                         igstArray.add("0.0")
                                         igsttotArray.add("0.0")
                                         cesstotalArray.add("0.0")
                                         tallyArray.add("Not tallied")
                                         receivedArray.add("0")


                                         tallyArray.add("Not tallied")



                                         try {
                                             var im = dd["img1url"].toString()
                                             image = im
                                             if (im.isNotEmpty()) {

                                                 imageArray.add(im)
                                             } else {
                                                 imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                             }
                                         } catch (e: Exception) {

                                         }
                                         keyArray.add("")

















                                         d.add(document.id.toString())

                                      /*   swipeContainer.setRefreshing(false);*/

                                         pDialog.dismiss()
                                         val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                                         product_list.adapter = whatever
                                         progressBar3.visibility = View.GONE
                                     }
                                 }
                                 else{

                                 }
                             } else {
                                 Log.w(TAG, "Error getting documents.", task.exception)
                             }
                         }
             }
             get()

        /*swipeContainer.setOnRefreshListener {


            get()
        }
            // Configure the refreshing colors

            swipeContainer.setColorSchemeResources(R.color.tool,

                    android.R.color.holo_green_light,

                    android.R.color.holo_orange_light,

                    android.R.color.holo_red_light)*/
        /*private fun addImageView(layout: LinearLayout) {
            val imageView = ImageView(this)
            imageView.setImageResource(R.drawable.ic_launcher)
            layout.addView(imageView)
        }*/
        product_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        product_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = product_list.getCheckedItemCount()
                val l = d.get(position)
                val az=pronameArray.get(position)
                val bz=hsnArray.get(position)
                val t = manufacturerArray.get(position)
                val cz=quantityArray.get(position)
                val mz=barcodeArray.get(position)
                val fz=priceArray.get(position)
                val oz=totArray.get(position)
                val qz=cessArray.get(position)
                val qigz=igstArray.get(position)
                val qigtotz=igsttotArray.get(position)
                val qcesstotz=cesstotalArray.get(position)
                val qtallyz=tallyArray.get(position)
                val rece=receivedArray.get(position)
                val imz=imageArray.get(position)
                val li=keyArray.get(position)
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                val tex =CircleImageView(this@product_list_activity_two)
                val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                textLayoutParams.setMargins(20, 0, 0, 0)
                textLayoutParams.height=100
                textLayoutParams.width=100
                tex.setBorderColor(Color.BLACK)
                tex.setBorderWidth(1)
                tex.setPadding(4,4,4,4)
                tex.setLayoutParams(textLayoutParams)
                try {
                    Picasso.with(this@product_list_activity_two)
                            .load(imageArray[position])
                            .into(tex);
                }
                catch (e:Exception){

                }
                tex.setTag(l)
                linearlayout.setGravity(Gravity.CENTER)
                tex.setOnClickListener {
                    val r = linearlayout.findViewWithTag<View>(l)
                    linearlayout.removeView(r)
                    Log.d("list","    "+product_list.setItemChecked(position,false))
                }
                if (checked) {
                    // list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    pronameArraycpy.add(az)
                    manufacturerArraycpy.add(t)
                    hsnArraycpy.add(bz)
                    quantityArraycpy.add(cz)
                    barcodeArraycpy.add(mz)
                    priceArraycpy.add(fz)
                    totArraycpy.add(oz)
                    cessArraycpy.add(qz)
                    igstArraycpy.add(qigz)
                    igsttotArraycpy.add(qigtotz)
                    cesstotalArraycpy.add(qcesstotz)
                    tallyArraycpy.add(qtallyz)
                   receivedArraycpy.add(rece)
                    imageArraycpy.add(imz.toString())
                    idupArraycpy.add(li)
                    imageArray.add(image)

                    Log.i(TAG,"itm "+dlt.size)
                    // val tex = TextView(this@product_list_activity)
                    //tex.setBackgroundResource(R.drawable.crcle)
                    Log.d("list","    "+product_list.getCheckedItemPositions())
                    linearlayout.addView(tex)
                    horizontalScrollView.visibility=View.VISIBLE
                } else {
                    val r = linearlayout.findViewWithTag<View>(l)
                    dlt.remove(l)
                    pronameArraycpy.remove(az)
                    manufacturerArraycpy.remove(t)
                    hsnArraycpy.remove(bz)
                    quantityArraycpy.remove(cz)
                    barcodeArraycpy.remove(mz)
                    priceArraycpy.remove(fz)
                    totArraycpy.remove(oz)
                    cessArraycpy.remove(qz)
                    igstArraycpy.remove(qigz)
                    igsttotArraycpy.remove(qigtotz)
                    cesstotalArraycpy.remove(qcesstotz)
                    tallyArraycpy.remove(qtallyz)
                    receivedArraycpy.remove(rece)
                    imageArraycpy.remove(imz.toString())
                    idupArraycpy.remove(li)
                    /*       imageArray=imageArray.plusElement(R.drawable.loreal_bottl)*/


                    Log.d("tag","   "+r)
                    linearlayout.removeView(r)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                    Log.d(TAG,"id  "+position)
                }


            }


            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                product_list_toolbar.visibility = View.GONE
                mode.getMenuInflater().inflate(R.menu.product_select, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val deleteSize =dlt.size
                Log.i("tsdfs","  "+dlt.size)
                /*val cate = null
                val data = s(cat = cate)*/
                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                val itemId = item.getItemId()
                if (itemId == R.id.ok) {
                    println(pronameArraycpy.size)
                    //if (this@product_list_activity.equals("product_list_activity"))
                    for(i in 0 until pronameArraycpy.size)
                    {
                        pronameArrayori.add(pronameArraycpy.get(i))
                        manufacturerArrayori.add(manufacturerArraycpy.get(i))
                        hsnArrayori.add(hsnArraycpy.get(i))
                        quantityArrayori.add(quantityArraycpy.get(i))
                        barcodeArrayori.add(barcodeArraycpy.get(i))
                        priceArrayori.add(priceArraycpy.get(i))
                        totArrayori.add(totArraycpy.get(i))
                        cessArrayori.add(cessArraycpy.get(i))
                        igstArrayori.add(igstArraycpy.get(i))
                        igsttotArrayori.add(igsttotArraycpy.get(i))
                        cesstotalArrayori.add(cesstotalArraycpy.get(i))
                        tallyArrayori.add(tallyArraycpy.get(i))
                       receivedArrayori.add(receivedArraycpy.get(i))
                        imageArrayori.add(imageArraycpy.get(i))
                        keyArrayori.add("")

                        namesori=names
                        namesphonesori=namesphones
                        println(pronameArraycpy.lastIndex)
                        if(pronameArraycpy.lastIndex == i)
                        {
                            Log.d("fdgshgtgh","NAMESSSSSSSSSSSSSSSSS             "   + (pronameArrayori))
                        }
                    }
                    val b = Intent(applicationContext,Main_stk_delhi::class.java)
                            .putStringArrayListExtra("dlt",dlt)
                    println((pronameArrayori))
                    println((priceArrayori))

                    b.putExtra("fromstate","sotherlist")
                    b.putExtra("sotherthspname",pronameArrayori)
                    b.putExtra("sotherpitem",manufacturerArrayori)
                    b.putExtra("sotherphsn",hsnArrayori)
                    b.putExtra("sotherporder",quantityArrayori)
                    b.putExtra("sotherpprice",priceArrayori)
                    b.putExtra("sotherptot",totArrayori)
                    b.putExtra("sotherpoarray",barcodeArrayori)
                    b.putExtra("sothercessarray",cessArrayori)
                    b.putExtra("sotherigstarray",igstArrayori)
                    b.putExtra("sotherigsttotarray",igsttotArrayori)
                    b.putExtra("sothercesstotalarray",cesstotalArrayori)
                    b.putExtra("tallyarray",tallyArrayori)
                    b.putExtra("receivedarray",receivedArrayori)
                    b.putExtra("sotherredate",datestk)
                    b.putExtra("sotherredesc",descstk)
                    b.putExtra("sotherrestkid",idstk)
                    b.putExtra("sotherreiddb",iddbs)
                    b.putExtra("sotherreiddofli",keyArrayori)

                    b.putExtra("sotherbranch",names)
                    b.putExtra("brnchid",brid)
                    b.putExtra("origiid",oriid)
                    b.putExtra("sotheraddress",namesphones)
                    b.putExtra("groschk",grosschk)

                    b.putExtra("viewsuppin", viewsuppin)
                    b.putExtra("addsuppin", addsuppin)
                    b.putExtra("deletesuppin", deletesuppin)
                    b.putExtra("editsuppin", editesuppin)
                    b.putExtra("transfersuppin", transfersuppin)
                    b.putExtra("exportsuppin", exportsuppin)


                    b.putExtra("viewpurord", viewpurord)
                    b.putExtra("addpurord", addpurord)
                    b.putExtra("deletepurord", deletepurord)
                    b.putExtra("editpurord", editepurord)
                    b.putExtra("transferpurord", transferpurord)
                    b.putExtra("exportpurord", exportpurord)
                    b.putExtra("sendpurord", sendpurpo)




                    b.putExtra("viewpurreq", viewpurreq)
                    b.putExtra("addpurreq", addpurreq)
                    b.putExtra("deletepurreq", deletepurreq)
                    b.putExtra("editpurreq", editepurreq)
                    b.putExtra("transferpurreq", transferpurreq)
                    b.putExtra("exportpurreq", exportpurreq)


                    b.putExtra("viewpro", viewpro)
                    b.putExtra("addpro", addpro)
                    b.putExtra("editpro", editpro)
                    b.putExtra("deletepro", deletepro)
                    b.putExtra("importpro", importpro)
                    b.putExtra("exportpro", exportpro)
                    b.putExtra("changestock", stockin_hand)


                    b.putExtra("view", view)
                    b.putExtra("add", add)
                    b.putExtra("edit", edits)
                    b.putExtra("delete", delete)
                    b.putExtra("import", import)
                    b.putExtra("export", export)


                    b.putExtra("viewsupp", viewsupp)
                    b.putExtra("addsupp", addsupp)
                    b.putExtra("editsupp", editsupp)
                    b.putExtra("deletesupp", deletesupp)
                    b.putExtra("importsupp", importsupp)
                    b.putExtra("exportsupp", exportsupp)



                    b.putExtra("viewtrans", viewtrans)
                    b.putExtra("addtrans", addtrans)
                    b.putExtra("edittrans", editetrans)
                    b.putExtra("deletetrans", deletetrans)
                    b.putExtra("transfertrans", transfertrans)
                    b.putExtra("exporttrans", exporttrans)
                    b.putExtra("sendtrans", sendtrans)


                    b.putExtra("viewtransano", viewtransano)
                    b.putExtra("addtransano", addtransano)
                    b.putExtra("edittransano", editetransano)
                    b.putExtra("deletetransano", deletetransano)
                    b.putExtra("transfertransano", transfertransano)
                    b.putExtra("exporttransano", exporttransano)
                    b.putExtra("sendtransano", sendtransano)

                    b.putExtra("viewrec", viewrec)
                    b.putExtra("addrec", addrec)
                    b.putExtra("deleterec", deleterec)
                    b.putExtra("editrec", editrec)
                    b.putExtra("transferrec", transferrec)
                    b.putExtra("exportrec", exportrec)
                    b.putExtra("sendstrec",sendstrec)


                    b.putExtra("viewstklvl",viewstklvls)


                    b.putExtra("sotherimi",imageArrayori)


                    startActivity(b)
                    finish()


                    /*for (i in dlt) {
                        Log.d("dlt","  "+i)
                    }*/
                }
                /* checkedCount = 0*/
                // list_item.clear()


                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                linearlayout.removeAllViews()
                horizontalScrollView.visibility=View.GONE
                product_list_toolbar.visibility =View.VISIBLE
            }
        })


        product_list_back_btn.setOnClickListener {

            val b = Intent(applicationContext,Main_stk_delhi::class.java)
                    .putStringArrayListExtra("dlt",dlt)
            println((pronameArrayori))
            println((priceArrayori))

            b.putExtra("fromstate","sotherlist")
            b.putExtra("sotherthspname",pronameArrayori)
            b.putExtra("sotherpitem",manufacturerArrayori)
            b.putExtra("sotherphsn",hsnArrayori)
            b.putExtra("sotherporder",quantityArrayori)
            b.putExtra("sotherpprice",priceArrayori)
            b.putExtra("sotherptot",totArrayori)
            b.putExtra("sotherpoarray",barcodeArrayori)
            b.putExtra("sothercessarray",cessArrayori)
            b.putExtra("sotherigstarray",igstArrayori)
            b.putExtra("sotherigsttotarray",igsttotArrayori)
            b.putExtra("sothercesstotalarray",cesstotalArrayori)
            b.putExtra("tallyarray",tallyArrayori)
            b.putExtra("receivedarray",receivedArrayori)
            b.putExtra("sotherredate",datestk)
            b.putExtra("sotherredesc",descstk)
            b.putExtra("sotherrestkid",idstk)
            b.putExtra("sotherreiddb",iddbs)
            b.putExtra("sotherreiddofli",keyArrayori)

            b.putExtra("sotherbranch",names)
            b.putExtra("brnchid",brid)
            b.putExtra("origiid",oriid)
            b.putExtra("sotheraddress",namesphones)
            b.putExtra("groschk",grosschk)

            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)


            b.putExtra("viewpro", viewpro)
            b.putExtra("addpro", addpro)
            b.putExtra("editpro", editpro)
            b.putExtra("deletepro", deletepro)
            b.putExtra("importpro", importpro)
            b.putExtra("exportpro", exportpro)
            b.putExtra("changestock", stockin_hand)


            b.putExtra("view", view)
            b.putExtra("add", add)
            b.putExtra("edit", edits)
            b.putExtra("delete", delete)
            b.putExtra("import", import)
            b.putExtra("export", export)


            b.putExtra("viewsupp", viewsupp)
            b.putExtra("addsupp", addsupp)
            b.putExtra("editsupp", editsupp)
            b.putExtra("deletesupp", deletesupp)
            b.putExtra("importsupp", importsupp)
            b.putExtra("exportsupp", exportsupp)



            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)


            b.putExtra("viewstklvl",viewstklvls)


            b.putExtra("sotherimi",imageArrayori)


            startActivity(b)
            finish()

        }


    }


    override fun onBackPressed() {
        val b = Intent(applicationContext,Main_stk_delhi::class.java)
                .putStringArrayListExtra("dlt",dlt)
        println(pronameArrayori)
        println((priceArrayori))

        b.putExtra("fromstate","sotherlist")
        b.putExtra("sotherthspname",pronameArrayori)
        b.putExtra("sotherpitem",manufacturerArrayori)
        b.putExtra("sotherphsn",hsnArrayori)
        b.putExtra("sotherporder",quantityArrayori)
        b.putExtra("sotherpprice",priceArrayori)
        b.putExtra("sotherptot",totArrayori)
        b.putExtra("sotherpoarray",barcodeArrayori)
        b.putExtra("sothercessarray",cessArrayori)
        b.putExtra("sotherigstarray",igstArrayori)
        b.putExtra("sotherigsttotarray",igsttotArrayori)
        b.putExtra("sothercesstotalarray",cesstotalArrayori)
        b.putExtra("tallyarray",tallyArrayori)
        b.putExtra("receivedarray",receivedArrayori)
        b.putExtra("sotherredate",datestk)
        b.putExtra("sotherredesc",descstk)
        b.putExtra("sotherrestkid",idstk)
        b.putExtra("sotherreiddb",iddbs)
        b.putExtra("sotherreiddofli",keyArrayori)

        b.putExtra("sotherbranch",names)
        b.putExtra("brnchid",brid)
        b.putExtra("origiid",oriid)
        b.putExtra("sotheraddress",namesphones)
        b.putExtra("groschk",grosschk)

        b.putExtra("viewsuppin", viewsuppin)
        b.putExtra("addsuppin", addsuppin)
        b.putExtra("deletesuppin", deletesuppin)
        b.putExtra("editsuppin", editesuppin)
        b.putExtra("transfersuppin", transfersuppin)
        b.putExtra("exportsuppin", exportsuppin)


        b.putExtra("viewpurord", viewpurord)
        b.putExtra("addpurord", addpurord)
        b.putExtra("deletepurord", deletepurord)
        b.putExtra("editpurord", editepurord)
        b.putExtra("transferpurord", transferpurord)
        b.putExtra("exportpurord", exportpurord)
        b.putExtra("sendpurord", sendpurpo)




        b.putExtra("viewpurreq", viewpurreq)
        b.putExtra("addpurreq", addpurreq)
        b.putExtra("deletepurreq", deletepurreq)
        b.putExtra("editpurreq", editepurreq)
        b.putExtra("transferpurreq", transferpurreq)
        b.putExtra("exportpurreq", exportpurreq)


        b.putExtra("viewpro", viewpro)
        b.putExtra("addpro", addpro)
        b.putExtra("editpro", editpro)
        b.putExtra("deletepro", deletepro)
        b.putExtra("importpro", importpro)
        b.putExtra("exportpro", exportpro)
        b.putExtra("changestock", stockin_hand)


        b.putExtra("view", view)
        b.putExtra("add", add)
        b.putExtra("edit", edits)
        b.putExtra("delete", delete)
        b.putExtra("import", import)
        b.putExtra("export", export)


        b.putExtra("viewsupp", viewsupp)
        b.putExtra("addsupp", addsupp)
        b.putExtra("editsupp", editsupp)
        b.putExtra("deletesupp", deletesupp)
        b.putExtra("importsupp", importsupp)
        b.putExtra("exportsupp", exportsupp)



        b.putExtra("viewtrans", viewtrans)
        b.putExtra("addtrans", addtrans)
        b.putExtra("edittrans", editetrans)
        b.putExtra("deletetrans", deletetrans)
        b.putExtra("transfertrans", transfertrans)
        b.putExtra("exporttrans", exporttrans)
        b.putExtra("sendtrans", sendtrans)


        b.putExtra("viewtransano", viewtransano)
        b.putExtra("addtransano", addtransano)
        b.putExtra("edittransano", editetransano)
        b.putExtra("deletetransano", deletetransano)
        b.putExtra("transfertransano", transfertransano)
        b.putExtra("exporttransano", exporttransano)
        b.putExtra("sendtransano", sendtransano)

        b.putExtra("viewrec", viewrec)
        b.putExtra("addrec", addrec)
        b.putExtra("deleterec", deleterec)
        b.putExtra("editrec", editrec)
        b.putExtra("transferrec", transferrec)
        b.putExtra("exportrec", exportrec)
        b.putExtra("sendstrec",sendstrec)


        b.putExtra("viewstklvl",viewstklvls)

        b.putExtra("sotherimi",imageArrayori)


        startActivity(b)
        finish()
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}