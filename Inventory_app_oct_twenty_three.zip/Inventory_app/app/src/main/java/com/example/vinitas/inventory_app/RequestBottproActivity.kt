package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.constraint.ConstraintLayout
import android.view.*
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import de.hdodenhof.circleimageview.CircleImageView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_request_bottpro.*
import java.text.SimpleDateFormat
import java.util.*

class RequestBottproActivity : AppCompatActivity() {



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""
    var supplieridfr=String()




    var ids=arrayOf<String>()






    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""




    var editchange= String()
    var groschk= String()

    var reqid = String()
    var reprnms = String()
    var reqdt = String()
    var reqliid = String()
    var restimt = String()
    var reqnm = String()
    var reqmail = String()
    var reqph = String()
    var imagelink = String()

    var supnm = String()
    var supadd1 = String()
    var supadd2 = String()
    var supadd3 = String()
    var supgst = String()
    var supph = String()
    var supcity = String()
    var supstate = String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var receivear= String()
    var status= String()
    var oriky= String()


    var listListener = String()
    var deletelistener = String()


    var incompstr= String()




    var pronamestr= String()
    var hsnstr = String()
    var manustr = String()
    var barcodestr= String()
    var quantitystr= String()
    var pricestr = String()
    var totstr = String()
    var grosstotstr=String()
    var cessstr = String()
    var keystr = String()
    var igststr = String()
    var cgststr = String()
    var sgststr = String()
    var igsttotstr= String()
    var cesstotstr= String()
    var tallystr = String()
    var receivedstr= String()
    var imagestr = String()
    var idofpro = String()



    var editclick= String()
    var d = arrayListOf<String>()

    var nameofbrnch = String()
    var locofbrnch = String()
    var keyofbrnch = String()
    var datestk = String()
    var smlistids = String()
    var descstk = String()
    var stkidstock = String()
    var ididdb = String()

    var downstatus = String()
    var igsttt = String()
    var cgsttt = String()
    var sgsttt = String()
    var cestt = String()
    var grosstt = String()
    var singrosstot = arrayOf<String>()

    var i = arrayListOf<String>()
    var getiddel = ArrayList<String>()
    var checkcount = arrayListOf<Int>()


    var updatestatus= String()

    var idsup = String()

    var befnm= String()
    var request_datedup= String()
    var reqest_datedup= String()
    var supp_namedup= String()
    var supp_gstdup= String()
    var supp_addredup= String()


    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var grosstotArray= arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var cgstArray = arrayListOf<String>()
    var sgstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var idproarray=arrayListOf<String>()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_bottpro)



        net_status()//Check net status


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@RequestBottproActivity) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off.


        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        bottonNavBardis=findViewById(R.id.bottonNavBar)

        cont=findViewById<ConstraintLayout>(R.id.container)

        addLogText(NetworkUtil.getConnectivityStatusString(this@RequestBottproActivity))





        //----------------------------------------------Delete Action--------------------------------------------------///


        var pronameArraydel = arrayListOf<String>()
        var hsnArraydel = arrayListOf<String>()
        var manufacturerArraydel = arrayListOf<String>()
        var barcodeArraydel = arrayListOf<String>()
        var quantityArraydel = arrayListOf<String>()
        var priceArraydel = arrayListOf<String>()
        var totArraydel = arrayListOf<String>()
        var grosstotArraydel = arrayListOf<String>()
        var cessArraydel = arrayListOf<String>()
        var keyArraydel = arrayListOf<String>()
        var igstArraydel = arrayListOf<String>()
        var cgstArraydel = arrayListOf<String>()
        var sgstArraydel = arrayListOf<String>()
        var igsttotArraydel = arrayListOf<String>()
        var cesstotArraydel = arrayListOf<String>()
        var tallyArraydel = arrayListOf<String>()
        var receivedArraydel = arrayListOf<String>()
        var imageArraydel = arrayListOf<String>()
        var idproArraydel = arrayListOf<String>()


        val bundle = intent.extras
        var frm = bundle!!.get("from_req").toString()




            purreq_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
            purreq_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {

                    val l = pronameArray.get(position)
                    if (pronameArray.get(position).isNotEmpty()) {
                        pronamestr = pronameArray.get(position)
                    } else {
                        pronamestr = ""
                    }

                    if (hsnArray.get(position).isNotEmpty()) {
                        hsnstr = hsnArray.get(position)
                    } else {
                        hsnstr = "0"
                    }

                    if (manufacturerArray.get(position).isNotEmpty()) {
                        manustr = manufacturerArray.get(position)
                    } else {
                        manustr = "0"
                    }

                    if (barcodeArray.get(position).isNotEmpty()) {
                        barcodestr = barcodeArray.get(position)
                    } else {
                        barcodestr = "0"
                    }
                    if (quantityArray.get(position).isNotEmpty()) {
                        quantitystr = quantityArray.get(position)
                    } else {
                        quantitystr = "0"
                    }

                    if (priceArray.get(position).isNotEmpty()) {
                        pricestr = priceArray.get(position)
                    } else {
                        pricestr = "0"
                    }
                    if (totArray.get(position).isNotEmpty()) {
                        totstr = totArray.get(position)
                    } else {
                        totstr = "0"
                    }
                    if (grosstotArray.get(position).isNotEmpty()) {
                        grosstotstr = grosstotArray.get(position)
                    } else {
                        grosstotstr = "0"
                    }

                    if (cessArray.get(position).isNotEmpty()) {
                        cessstr = cessArray.get(position)
                    } else {
                        cessstr = "0"
                    }

                    if (keyArray.get(position).isNotEmpty()) {
                        keystr = keyArray.get(position)
                    } else {
                        keystr = "0"
                    }
                    if (igstArray.get(position).isNotEmpty()) {
                        igststr = igstArray.get(position)
                    } else {
                        igststr = "0"
                    }

                    if (cgstArray.get(position).isNotEmpty()) {
                        cgststr = cgstArray.get(position)
                    } else {
                        cgststr = "0"
                    }
                    if (sgstArray.get(position).isNotEmpty()) {
                        sgststr = sgstArray.get(position)
                    } else {
                        sgststr = "0"
                    }
                    if (igsttotArray.get(position).isNotEmpty()) {
                        igsttotstr = igsttotArray.get(position)
                    } else {
                        igsttotstr = "0"
                    }
                    if (cesstotalArray.get(position).isNotEmpty()) {
                        cesstotstr = cesstotalArray.get(position)
                    } else {
                        cesstotstr = "0"
                    }
                    if (tallyArray.get(position).isNotEmpty()) {
                        tallystr = tallyArray.get(position)
                    } else {
                        tallystr = "0"
                    }
                    if (receivedArray.get(position).isNotEmpty()) {
                        receivedstr = receivedArray.get(position)
                    } else {
                        receivedstr = "0"
                    }
                    if (imageArray.get(position).isNotEmpty()) {
                        imagestr = imageArray.get(position)
                    } else {
                        imagestr = "0"
                    }

                    if (idproarray.get(position).isNotEmpty()) {
                        idofpro = idproarray.get(position)
                    } else {
                        idofpro = "0"
                    }

                    val tex = CircleImageView(this@RequestBottproActivity)
                    val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    textLayoutParams.setMargins(20, 0, 0, 0)
                    textLayoutParams.height = 100
                    textLayoutParams.width = 100
                    tex.setBorderColor(Color.BLACK)
                    tex.setBorderWidth(1)
                    tex.setPadding(4, 4, 4, 4)
                    tex.setLayoutParams(textLayoutParams)
                    try {
                        Picasso.with(this@RequestBottproActivity)
                                .load(imageArray[position])
                                .into(tex);
                    } catch (e: Exception) {

                    }
                    /*     tex.setImageResource(imli)*/
                    tex.setTag(l)
                    linearlayout.setGravity(Gravity.CENTER)
                    tex.setOnClickListener {
                        val r = linearlayout.findViewWithTag<View>(l)
                        linearlayout.removeView(r)

                    }


                    //capture total checked items and put the values to array



                    if (checked == true) {

                        pronameArraydel.add(pronamestr)
                        hsnArraydel.add(hsnstr)
                        manufacturerArraydel.add(manustr)
                        barcodeArraydel.add(barcodestr)
                        quantityArraydel.add(quantitystr)
                        priceArraydel.add(pricestr)
                        totArraydel.add(totstr)
                        grosstotArraydel.add(grosstotstr)
                        cessArraydel.add(cessstr)
                        keyArraydel.add(keystr)
                        igstArraydel.add(igststr)
                        cgstArraydel.add(cgststr)
                        sgstArraydel.add(sgststr)
                        igsttotArraydel.add(igsttotstr)
                        cesstotArraydel.add(cesstotstr)
                        tallyArraydel.add(tallystr)
                        receivedArraydel.add(receivedstr)
                        imageArraydel.add(imagestr)
                        idproArraydel.add(idofpro)
                        /* pronameArraydelglo=pronameArraydel
                    hsnArraydelglo=hsnArraydel
                    manufacturerArraydelglo=manufacturerArraydel
                    barcodeArraydelglo=barcodeArraydel
                    quantityArraydelglo=quantityArraydel
                    priceArraydelglo=priceArraydel
                    totArraydelglo=totArraydel
                    cessArraydelglo=cessArraydel
                    keyArraydelglo=keyArraydel
                    igstArraydelglo=igstArraydel
                    cgstArraydelglo=cgstArraydel
                    sgstArraydelglo=sgstArraydel
                    igsttotArraydelglo=igsttotArraydel
                    cesstotalArraydelglo=cesstotArraydel
                    tallyArraydelglo=tallyArraydel
                    receivedArraydelglo=receivedArraydel
                    imageArraydelglo=imageArraydel*/


                        println("pronameArray ARRAY SELECTED DELETE" + pronameArraydel)
                        println("hsnArray ARRAY SELECTED DELETE" + hsnArraydel)
                        println("manufacturerArray ARRAY SELECTED DELETE" + manufacturerArraydel)
                        println("barcodeArray ARRAY SELECTED DELETE" + barcodeArraydel)
                        println("quantityArray ARRAY SELECTED DELETE" + quantityArraydel)
                        println("priceArray ARRAY SELECTED DELETE" + priceArraydel)
                        println("totArray ARRAY SELECTED DELETE" + totArraydel)
                        println("cessArray ARRAY SELECTED DELETE" + cessArraydel)
                        println("keyArray ARRAY SELECTED DELETE" + keyArraydel)
                        println("igstArray ARRAY SELECTED DELETE" + igstArraydel)
                        println("cgstArray ARRAY SELECTED DELETE" + cgstArraydel)
                        println("sgstArray ARRAY SELECTED DELETE" + sgstArraydel)
                        println("igsttotArray ARRAY SELECTED DELETE" + igsttotArraydel)
                        println("cesstotalArray ARRAY SELECTED DELETE" + cesstotArraydel)
                        println("tallyArray ARRAY SELECTED DELETE" + tallyArraydel)
                        println("receivedArray ARRAY SELECTED DELETE" + receivedArraydel)
                        println("imageArray ARRAY SELECTED DELETE" + imageArraydel)
                        linearlayout.addView(tex)
                        horizontalScrollView.visibility = View.VISIBLE

                    } else {
                        val r = linearlayout.findViewWithTag<View>(l)
                        pronameArraydel.remove(pronamestr)
                        hsnArraydel.remove(hsnstr)
                        manufacturerArraydel.remove(manustr)
                        barcodeArraydel.remove(barcodestr)
                        quantityArraydel.remove(quantitystr)
                        priceArraydel.remove(pricestr)
                        totArraydel.remove(totstr)
                        grosstotArraydel.remove(grosstotstr)
                        cessArraydel.remove(cessstr)
                        keyArraydel.remove(keystr)
                        igstArraydel.remove(igststr)
                        cgstArraydel.remove(cgststr)
                        sgstArraydel.remove(sgststr)
                        igsttotArraydel.remove(igsttotstr)
                        cesstotArraydel.remove(cesstotstr)
                        tallyArraydel.remove(tallystr)
                        receivedArraydel.remove(receivedstr)
                        imageArraydel.remove(imagestr)
                        idproArraydel.remove(idofpro)
                        linearlayout.removeView(r)

                        /*pronameArraydelglo=pronameArraydel
                    hsnArraydelglo=hsnArraydel
                    manufacturerArraydelglo=manufacturerArraydel
                    barcodeArraydelglo=barcodeArraydel
                    quantityArraydelglo=quantityArraydel
                    priceArraydelglo=priceArraydel
                    totArraydelglo=totArraydel
                    cessArraydelglo=cessArraydel
                    keyArraydelglo=keyArraydel
                    igstArraydelglo=igstArraydel
                    cgstArraydelglo=cgstArraydel
                    sgstArraydelglo=sgstArraydel
                    igsttotArraydelglo=igsttotArraydel
                    cesstotalArraydelglo=cesstotArraydel
                    tallyArraydelglo=tallyArraydel
                    receivedArraydelglo=receivedArraydel
                    imageArraydelglo=imageArraydel*/


                        println("pronameArray ARRAY UNSELETED DELETE" + pronameArraydel)
                        println("hsnArray ARRAY UNSELETED DELETE" + hsnArraydel)
                        println("manufacturerArray ARRAY UNSELETED DELETE" + manufacturerArraydel)
                        println("barcodeArray ARRAY UNSELETED DELETE" + barcodeArraydel)
                        println("quantityArray ARRAY UNSELETED DELETE" + quantityArraydel)
                        println("priceArray ARRAY UNSELETED DELETE" + priceArraydel)
                        println("totArray ARRAY UNSELETED DELETE" + totArraydel)
                        println("cessArray ARRAY UNSELETED DELETE" + cessArraydel)
                        println("keyArray ARRAY UNSELETED DELETE" + keyArraydel)
                        println("igstArray ARRAY UNSELETED DELETE" + igstArraydel)
                        println("cgstArray ARRAY UNSELETED DELETE" + cgstArraydel)
                        println("sgstArray ARRAY UNSELETED DELETE" + sgstArraydel)
                        println("igsttotArray ARRAY UNSELETED DELETE" + igsttotArraydel)
                        println("cesstotalArray ARRAY UNSELETED DELETE" + cesstotArraydel)
                        println("tallyArray ARRAY UNSELETED DELETE" + tallyArraydel)
                        println("receivedArray ARRAY UNSELETED DELETE" + receivedArraydel)
                        println("imageArray ARRAY UNSELETED DELETE" + imageArraydel)


                    }


                    val checkedCounts = purreq_list.checkedItemCount


                    //setting CAB title
                    mode.setTitle("" + checkedCounts + " Selected")

                }

                override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {

                    //Inflate the CAB and Invisible other views in toolbar

                        toolbar1.visibility = View.GONE

                        userback.visibility = View.INVISIBLE

                        comp_toolimg.visibility = View.INVISIBLE
                        comttname.visibility = View.INVISIBLE
                        comphone.visibility = View.INVISIBLE
                        mode.getMenuInflater().inflate(R.menu.menu_delete, menu);

                    return true;
                }

                override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                    return false
                }

                override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                    println("CREATEDDDD")
                    /*        val deleteSize = dlt.size
                          Log.i("tsdfs", "  " + dlt.size)
                          *//*val cate = null
                    val data = s(cat = cate)*//*
                    val i = 0
                    Log.d("dlt", " " + dlt.get(i))*/
                    val itemId = item.getItemId()

                    //val i = 0
                    var refiddel = reqliid
                    var pathfdel = "Stock_Transfer/$refiddel/Stock_products"
                    if ((itemId == R.id.delete) && (deletepurreq == "true")) {


                        for (i in 0 until pronameArraydel.size) {

                            deletelistener = "listdelete"

                            pronameArray.remove(pronameArraydel.get(i))
                            hsnArray.remove(hsnArraydel.get(i))
                            manufacturerArray.remove(manufacturerArraydel.get(i))
                            barcodeArray.remove(barcodeArraydel.get(i))
                            quantityArray.remove(quantityArraydel.get(i))
                            priceArray.remove(priceArraydel.get(i))
                            totArray.remove(totArraydel.get(i))
                            grosstotArray.remove(grosstotArraydel.get(i))
                            cessArray.remove(cessArraydel.get(i))
                            keyArray.remove(keyArraydel.get(i))
                            igstArray.remove(igstArraydel.get(i))
                            cgstArray.remove(cgstArraydel.get(i))
                            sgstArray.remove(sgstArraydel.get(i))
                            igsttotArray.remove(igsttotArraydel.get(i))
                            cesstotalArray.remove(cesstotArraydel.get(i))
                            tallyArray.remove(tallyArraydel.get(i))
                            receivedArray.remove(receivedArraydel.get(i))
                            imageArray.remove(imageArraydel.get(i))
                            idproarray.remove(idproArraydel.get(i))

                        }



                        println("pronameArray ARRAY AFTER DELETE" + pronameArray)
                        println("pronameArray ARRAY AFTER DELETE" + pronameArray)
                        println("hsnArray ARRAY AFTER DELETE" + hsnArray)
                        println("manufacturerArray ARRAY AFTER DELETE" + manufacturerArray)
                        println("barcodeArray ARRAY AFTER DELETE" + barcodeArray)
                        println("quantityArray ARRAY AFTER DELETE" + quantityArray)
                        println("priceArray ARRAY AFTER DELETE" + priceArray)
                        println("totArray ARRAY AFTER DELETE" + totArray)
                        println("cessArray ARRAY AFTER DELETE" + cessArray)
                        println("keyArray ARRAY AFTER DELETE" + keyArray)
                        println("igstArray ARRAY AFTER DELETE" + igstArray)
                        println("cgstArray ARRAY AFTER DELETE" + cgstArray)
                        println("sgstArray ARRAY AFTER DELETE" + sgstArray)
                        println("igsttotArray ARRAY AFTER DELETE" + igsttotArray)
                        println("cesstotalArray ARRAY AFTER DELETE" + cesstotalArray)
                        println("tallyArray ARRAY AFTER DELETE" + tallyArray)
                        println("receivedArray ARRAY AFTER DELETE" + receivedArray)
                        println("imageArray ARRAY AFTER DELETE" + imageArray)


                        val whatever = purchproduct_list_adap_pur(this@RequestBottproActivity, pronameArray, manufacturerArray, hsnArray,
                                barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray,
                                cesstotalArray, tallyArray, receivedArray, imageArray)
                        purreq_list.adapter = whatever


                    } else {
                        popup("delete")
                    }
                    mode.finish()
                    pronameArraydel.clear()
                    hsnArraydel.clear()
                    manufacturerArraydel.clear()
                    barcodeArraydel.clear()
                    quantityArraydel.clear()
                    priceArraydel.clear()
                    totArraydel.clear()
                    grosstotArraydel.clear()
                    cessArraydel.clear()
                    keyArraydel.clear()
                    igstArraydel.clear()
                    cgstArraydel.clear()
                    sgstArraydel.clear()
                    igsttotArraydel.clear()
                    cesstotArraydel.clear()
                    tallyArraydel.clear()
                    receivedArraydel.clear()
                    imageArraydel.clear()
                    idproArraydel.clear()
                    return true

                }

                override fun onDestroyActionMode(mode: ActionMode) {
                    toolbar1.visibility = View.VISIBLE

                    userback.visibility = View.VISIBLE

                    comp_toolimg.visibility = View.VISIBLE
                    comttname.visibility = View.VISIBLE
                    comphone.visibility = View.VISIBLE
                    linearlayout.removeAllViews()
                    horizontalScrollView.visibility = View.GONE
                }

            })



        userback.setOnClickListener {
            onBackPressed()
        }


        edit.setOnClickListener {
            editclick="clicked"
            edit.visibility=View.GONE
            fab.visibility=View.VISIBLE
            purreq_list.isClickable=true
            purreq_list.isLongClickable=true

            val whatever = purchproduct_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                    priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray,
                    receivedArray, imageArray)

            purreq_list.adapter = whatever
        }


        if (frm == "bott_req") {





            //Purchase request access

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }



            //Purchase order access

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice access

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            //Get all purchase request details from (RequestAddActivity)

            var a = bundle.get("pnm") as ArrayList<String>
            println(a)
            /*     val b=bundle.get("id") as Array<String>*/

            val dsy = bundle.get("phsn") as ArrayList<String>
            val ly = bundle.get("pmanu") as ArrayList<String>
            val fy = bundle.get("barcode") as ArrayList<String>
            val gy = bundle.get("quan") as ArrayList<String>
            val hy = bundle.get("price") as ArrayList<String>
            val ky = bundle.get("tot") as ArrayList<String>
            val kygro = bundle.get("grosstot") as ArrayList<String>
            val my = bundle.get("cessup") as ArrayList<String>
            val ny = bundle.get("igst") as ArrayList<String>
            val cy = bundle.get("cgst") as ArrayList<String>
            val sy = bundle.get("sgst") as ArrayList<String>
            val oy = bundle.get("igsttotal") as ArrayList<String>
            val py = bundle.get("cesstotarray") as ArrayList<String>
            val iddd = bundle.get("idsofli") as ArrayList<String>
            val idtally = bundle.get("tallyarray") as ArrayList<String>
            val idrec = bundle.get("receivedarray") as ArrayList<String>
            val immy = bundle.get("image") as ArrayList<String>
            val idpros = bundle.get("idpro") as ArrayList<String>

            ids = bundle.get("ids") as Array<String>


            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }


            pronameArray = a
            hsnArray = dsy
            cgstArray = cy
            sgstArray = sy
            barcodeArray = fy
            quantityArray = gy
            priceArray = hy
            totArray = ky
            grosstotArray=kygro
            cessArray = my
            igstArray = ny
            igsttotArray = oy
            cesstotalArray = py
            tallyArray = idtally
            receivedArray = idrec
            keyArray = iddd
            imageArray = immy
            manufacturerArray = ly
            idproarray = idpros


            val whatever = purchproduct_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever




            try {
                val a = intent.getStringExtra("reqid")
                reqid = a

                val b = intent.getStringExtra("reqname")
                reqnm = b

                val s = intent.getStringExtra("status")
                status = s
                println("STATUS VALUE INTRY"+status)
                val sky = intent.getStringExtra("brky")
                oriky = sky
                val skyimg = intent.getStringExtra("imlinks")
                imagelink = skyimg
                try {

                    Picasso.with(this)
                            .load(skyimg)
                            .into(comp_toolimg);
                } catch (e: Exception) {

                }

            } catch (e: Exception) {

            }


            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch (e:Exception){

            }

            try {

                updatestatus = intent.getStringExtra("updatestatus")
            }
            catch (e:Exception){

            }

            try {
                editclick = intent.getStringExtra("edclick")
                incompstr=intent.getStringExtra("incompstr")
            }
            catch (e:Exception){

            }

            println("ED CLICK"+editclick)

            println("Update Status"+updatestatus)

            if(editclick=="clicked"){
                edit.visibility=View.GONE

            }
            else if((editclick.isEmpty()==true)&&(reqid!="Auto-generated")){

                edit.visibility=View.VISIBLE
                fab.visibility=View.INVISIBLE
                purreq_list.isClickable=false
                purreq_list.isLongClickable=false


            }
            else if((editclick.isEmpty()==true)&&(reqid=="Auto-generated")){


            }

            try{
                 befnm=intent.getStringExtra("befnm")
                 request_datedup=intent.getStringExtra("request_datedup")
                 reqest_datedup=intent.getStringExtra("reqest_datedup")
                 supp_namedup=intent.getStringExtra("supp_namedup")
                 supp_gstdup=intent.getStringExtra("supp_gstdup")
                 supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }







            val lii = intent.getStringExtra("reqliid")
            reqliid = lii
            val c = intent.getStringExtra("reqdate")
            reqdt = c
            val nm = intent.getStringExtra("reprnms")
            reprnms = nm
            val o = intent.getStringExtra("reqest")
            restimt = o
            val d = intent.getStringExtra("reqmail")
            reqmail = d

            val f = intent.getStringExtra("supnm")
            supnm = f
            println("SUPPPP NNNNNAAAMMME" + supnm)
            val g = intent.getStringExtra("supadd1")
            supadd1 = g
            val h = intent.getStringExtra("supadd2")
            supadd2 = h
            val i = intent.getStringExtra("supadd3")
            supadd3 = i
            val j = intent.getStringExtra("supcity")
            supcity = j
            val k = intent.getStringExtra("supstate")
            supstate = k
            val l = intent.getStringExtra("supph")
            supph = l
            val m = intent.getStringExtra("supgst")
            supgst = m

            val grochk = intent.getStringExtra("groschk")
            groschk = grochk

            println("GROSSCHECK"+groschk)





            comttname.setText(f)
            comphone.setText(l)


            if ((reqliid.isNotEmpty()) && (status== "Approved") && (transferpurreq == "true")) {



                edit.isEnabled = false
                edit.setImageResource(R.drawable.disable_edit)
                edit.visibility=View.GONE
                fab.visibility=View.INVISIBLE
            }






            //--------------------------Here we can add multiple product list items from (product_req_add)-------------------------//

        } else if (frm == "req_list") {


            val aw = bundle!!.get("req_pname") as ArrayList<String>
            val bw = bundle!!.get("req_pitem") as ArrayList<String>
            val cw = bundle!!.get("req_phsn") as ArrayList<String>
            val dw = bundle!!.get("req_porder") as ArrayList<String>
            /*    val ew=bundle!!.greq"pcomplete") as Array<String>*/
            val fw = bundle!!.get("req_pprice") as ArrayList<String>
            val hw = bundle!!.get("req_ptot") as ArrayList<String>
            val hwgro = bundle!!.get("req_pgrosstot") as ArrayList<String>
            val gw = bundle!!.get("req_poarray") as ArrayList<String>
            val lw = bundle!!.get("req_cessarray") as ArrayList<String>
            val mw = bundle!!.get("req_igstarray") as ArrayList<String>
            val cgw = bundle!!.get("req_cgstarray") as ArrayList<String>
            val sgw = bundle!!.get("req_sgstarray") as ArrayList<String>
            val nw = bundle!!.get("req_igsttotarray") as ArrayList<String>
            val ow = bundle!!.get("req_cesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("req_tallyarray") as ArrayList<String>
            val rew = bundle!!.get("req_receivedarray") as ArrayList<String>
            val piddli = bundle!!.get("req_reiddofli") as ArrayList<String>
            val rid = intent.getStringExtra("req_id")
            val rdt = intent.getStringExtra("req_date")
            val rnm = intent.getStringExtra("req_name")
            val imm = bundle!!.get("req_imi") as ArrayList<String>
            val idpr = bundle!!.get("idpro") as ArrayList<String>

            ids = bundle!!.get("ids") as Array<String>

            //Purchase req from access controls list

            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }
            updatestatus="update_req_list"

            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }


            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }




            try {
                val st = intent.getStringExtra("status")
                status = st

            } catch (e: Exception) {

            }

            val rlid = intent.getStringExtra("req_liid")
            val rmail = intent.getStringExtra("req_mail")
            val rprnm = intent.getStringExtra("req_prnms")
            val resti = intent.getStringExtra("req_esti")

            val rsnm = intent.getStringExtra("req_supnm")
            val rsadd1 = intent.getStringExtra("req_supadd1")
            val rsadd2 = intent.getStringExtra("req_supadd2")
            val rsadd3 = intent.getStringExtra("req_supadd3")
            val rsgst = intent.getStringExtra("req_supgst")
            val rscity = intent.getStringExtra("req_supcity")
            val rsstate = intent.getStringExtra("req_supstate")
            val rssuph = intent.getStringExtra("req_supph")
            val brky = intent.getStringExtra("brkys")
            val imgslnk = intent.getStringExtra("imlinks")


            try {
                editclick = intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }


            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch (e:Exception){

            }

            try {
                incompstr = intent.getStringExtra("incompstr")
            }
            catch (e:Exception){

            }

            imagelink = imgslnk
            try {

                Picasso.with(this)
                        .load(imgslnk)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }

            val groschks = intent.getStringExtra("groschk")

            groschk = groschks

            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            grosstotArray = hwgro
            cessArray = lw
            keyArray = piddli
            igstArray = mw
            cgstArray = cgw
            sgstArray = sgw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            imageArray = imm
            idproarray = idpr

            val whatever = purchproduct_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                    quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray,
                    cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever


            println("PRO ADD IDS" + idproarray)



            reqid = rid
            reqliid = rlid
            reprnms = rprnm.toString()
            restimt = resti
            reqnm = rnm
            reqmail = rmail
            reqdt =  rdt
            /*req_phone.setText(rphone)*/
            supnm = rsnm.toString()
            supadd1 = rsadd1
            supadd2 = rsadd2
            supadd3 = rsadd3
            supgst = rsgst
            supcity = rscity
            supstate = rsstate
            supph = rssuph
            comttname.setText(rsnm)
            comphone.setText(rssuph)
            oriky = brky



            //Here we can add single list item from (product_req_add)

        } else if (frm == "req_list_single") {


            val aw = bundle!!.get("req_pname") as ArrayList<String>
            val bw = bundle!!.get("req_pitem") as ArrayList<String>
            val cw = bundle!!.get("req_phsn") as ArrayList<String>
            val dw = bundle!!.get("req_porder") as ArrayList<String>
            /*    val ew=bundle!!.greq"pcomplete") as Array<String>*/
            val fw = bundle!!.get("req_pprice") as ArrayList<String>
            val hw = bundle!!.get("req_ptot") as ArrayList<String>
            val hwgro = bundle!!.get("req_pgrosstot") as ArrayList<String>
            val gw = bundle!!.get("req_poarray") as ArrayList<String>
            val lw = bundle!!.get("req_cessarray") as ArrayList<String>
            val mw = bundle!!.get("req_igstarray") as ArrayList<String>
            val cgw = bundle!!.get("req_cgstarray") as ArrayList<String>
            val sgw = bundle!!.get("req_sgstarray") as ArrayList<String>
            val nw = bundle!!.get("req_igsttotarray") as ArrayList<String>
            val ow = bundle!!.get("req_cesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("req_tallyarray") as ArrayList<String>
            val rew = bundle!!.get("req_receivedarray") as ArrayList<String>
            val piddli = bundle!!.get("req_reiddofli") as ArrayList<String>
            val rid = intent.getStringExtra("req_id")
            val rdt = intent.getStringExtra("req_date")
            val rnm = intent.getStringExtra("req_name")
            val imm = bundle!!.get("req_imi") as ArrayList<String>
            val idpr = bundle!!.get("idpro") as ArrayList<String>

            ids = bundle!!.get("ids") as Array<String>

            //Purchase req from access controls list

            updatestatus="update_req_list"

            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }

            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch (e:Exception){

            }

            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }




            try {
                val st = intent.getStringExtra("status")
                status = st

            } catch (e: Exception) {

            }

            val rlid = intent.getStringExtra("req_liid")
            val rmail = intent.getStringExtra("req_mail")
            val rprnm = intent.getStringExtra("req_prnms")
            val resti = intent.getStringExtra("req_esti")
            val rphone = intent.getStringExtra("req_phone")
            val rsnm = intent.getStringExtra("req_supnm")
            val rsadd1 = intent.getStringExtra("req_supadd1")
            val rsadd2 = intent.getStringExtra("req_supadd2")
            val rsadd3 = intent.getStringExtra("req_supadd3")
            val rsgst = intent.getStringExtra("req_supgst")
            val rscity = intent.getStringExtra("req_supcity")
            val rsstate = intent.getStringExtra("req_supstate")
            val rssuph = intent.getStringExtra("req_supph")
            val brky = intent.getStringExtra("brkys")
            val imgslnk = intent.getStringExtra("imlinks")

            try {
                editclick = intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }

            try {
                incompstr = intent.getStringExtra("incompstr")
            }
            catch (e:Exception){

            }

            imagelink = imgslnk
            try {

                Picasso.with(this)
                        .load(imgslnk)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }

            val groschks = intent.getStringExtra("groschk")

            groschk = groschks

            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            grosstotArray = hwgro
            cessArray = lw
            keyArray = piddli
            igstArray = mw
            cgstArray = cgw
            sgstArray = sgw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            imageArray = imm
            idproarray = idpr

            val whatever = purchproduct_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                    priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray,
                    tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever



            reqid = rid
            reqliid = rlid
            reprnms = rprnm.toString()
            restimt =  resti
            reqnm = rnm
            reqmail = rmail
            reqdt = rdt
            /*req_phone.setText(rphone)*/
            supnm = rsnm.toString()
            supadd1 = rsadd1
            supadd2 = rsadd2
            supadd3 = rsadd3
            supgst = rsgst
            supcity = rscity
            supstate = rsstate
            supph = rssuph
            comttname.setText(rsnm)
            comphone.setText(rssuph)
            oriky = brky





            //From Update Function

        } else if (frm == "update_request") {
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MMM/yyyy")
            val formattedDate = df.format(c.time)
            reqdt = formattedDate
            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            val dv = bundle!!.get("reprice") as ArrayList<String>
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val hvgro = bundle!!.get("regrosstotal") as ArrayList<String>
            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val idv = bundle!!.get("recgst") as ArrayList<String>
            val isv = bundle!!.get("resgst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val immv = bundle!!.get("reimmg") as ArrayList<String>
            val idpr = bundle!!.get("idpro") as ArrayList<String>


            ids = bundle!!.get("ids") as Array<String>


            try{

                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            updatestatus="update_req_upd"

            val rid = intent.getStringExtra("req_id")
            reqid=rid
            val rdt = intent.getStringExtra("req_date")
            val rnm = intent.getStringExtra("req_name")

            println("RID"+rid)

            var grocheck = intent.getStringExtra("groschk")
            groschk = grocheck


            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch (e:Exception){

            }

            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }


            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }



            try {
                val stat = intent.getStringExtra("status")
                status = stat

                val imgli = intent.getStringExtra("images")
                imagelink = imgli
                Picasso.with(this)
                        .load(imgli)
                        .into(comp_toolimg);
            } catch (e: Exception) {

            }


            val rmail = intent.getStringExtra("req_mail")
            val rids = intent.getStringExtra("req_liids")
            val rprnms = intent.getStringExtra("req_prnms")
            val resti = intent.getStringExtra("req_esti")
            val rphone = intent.getStringExtra("req_phone")
            val rsnm = intent.getStringExtra("req_supnm")
            val rsadd1 = intent.getStringExtra("req_supadd1")
            val rsadd2 = intent.getStringExtra("req_supadd2")
            val rsadd3 = intent.getStringExtra("req_supadd3")
            val rsgst = intent.getStringExtra("req_supgst")
            val rscity = intent.getStringExtra("req_supcity")
            val rsstate = intent.getStringExtra("req_supstate")
            val rssuph = intent.getStringExtra("req_supph")
            val orikys = intent.getStringExtra("orikys")

            try {
                editclick = intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }
            if(editclick=="clicked"){
                edit.visibility=View.GONE

            }
            else if((editclick.isEmpty()==true)&&(reqid!="Auto-generated")&&(status!="Approved")){

                edit.visibility=View.VISIBLE
                fab.visibility=View.INVISIBLE
                purreq_list.isClickable=false
                purreq_list.isLongClickable=false


            }
            else if((editclick.isEmpty()==true)&&(reqid=="Auto-generated")){


            }

            try {
                incompstr = intent.getStringExtra("incompstr")
            }
            catch (e:Exception){

            }

            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = dv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            grosstotArray = hvgro
            cessArray = gv
            keyArray = rekey
            igstArray = iv
            cgstArray = idv
            sgstArray = isv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            imageArray = immv
            idproarray = idpr

            val whatever = purchproduct_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                    quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray,
                    cesstotalArray, tallyArray, receivedArray, imageArray)
            purreq_list.adapter = whatever


            var za = priceArray
            var ya = quantityArray






            reqid = rid
            reqliid = rids
            reprnms = rprnms.toString()
            restimt = resti
            reqnm = rnm
            reqmail = rmail
            reqdt =  rdt
            /*req_phone.setText(rphone)*/
            supnm = rsnm.toString()
            supadd1 = rsadd1
            supadd2 = rsadd2
            supadd3 = rsadd3
            supgst = rsgst
            supcity = rscity
            supstate = rsstate
            supph = rssuph
            comttname.setText(rsnm)
            comphone.setText(rssuph)
            oriky = orikys




        }


        //Navigate to add product lists (product_request_add)


        fab.setOnClickListener {
            println(priceArray.size)
            println(pronameArray)
            println(priceArray)
            if ((priceArray.size == 0) && (addpurreq == "true")) {
                val intent = Intent(this, product_request_add::class.java)
                intent.putExtra("from_req", "req_emptylist")
                intent.putExtra("reqid", reqid)
                intent.putExtra("reqname", reqnm)
                intent.putExtra("reqdate", reqdt)
                intent.putExtra("reqest", restimt)
                intent.putExtra("reqmail", reqmail)


                intent.putExtra("supplieridfr",supplieridfr)

                intent.putExtra("supnm", supnm)
                intent.putExtra("supadd1", supadd1)
                intent.putExtra("supadd2", supadd2)
                intent.putExtra("supadd3", supadd3)
                intent.putExtra("supcity", supcity)
                intent.putExtra("supstate", supstate)
                intent.putExtra("supph", supph)
                intent.putExtra("relids", reqliid)
                intent.putExtra("supgst", supgst)
                intent.putExtra("imlinks", imagelink)
                intent.putExtra("status", status)
                intent.putExtra("brky", oriky)
                intent.putExtra("incompstr", incompstr)

                intent.putExtra("request_datedup",request_datedup)
                intent.putExtra("reqest_datedup",reqest_datedup)
                intent.putExtra("supp_namedup",supp_namedup)
                intent.putExtra("supp_gstdup",supp_gstdup)
                intent.putExtra("supp_addredup",supp_addredup)
                intent.putExtra("befnm",befnm)

                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)
                intent.putExtra("deletelistener",deletelistener)
                intent.putExtra("edclick",editclick)
                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)




                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)


                intent.putExtra("groschk", groschk)



                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                finish()
            } else if ((priceArray.size != 0) && (addpurreq == "true")) {
                val intent = Intent(this, product_request_add::class.java)
                intent.putExtra("from_req", "req_datalist")
                intent.putExtra("namess", pronameArray)
                intent.putExtra("orderarray", manufacturerArray)
                intent.putExtra("hsn", hsnArray)
                intent.putExtra("poarray", barcodeArray)
                intent.putExtra("complete", quantityArray)
                intent.putExtra("price", priceArray)
                intent.putExtra("total", totArray)
                intent.putExtra("grosstotal", grosstotArray)
                intent.putExtra("cess", cessArray)
                intent.putExtra("igst", igstArray)
                intent.putExtra("cgst", cgstArray)
                intent.putExtra("sgst", sgstArray)
                intent.putExtra("igsttotal", igsttotArray)
                intent.putExtra("incompstr", incompstr)
                intent.putExtra("cesstotarray", cesstotalArray)
                intent.putExtra("tallyarray", tallyArray)
                intent.putExtra("receivedarray", receivedArray)
                intent.putExtra("im", imageArray)
                intent.putExtra("idpro", idproarray)
                intent.putExtra("branch", comttname.text.toString())
                intent.putExtra("address", comphone.text.toString())
                intent.putExtra("sstkdate", datestk)
                intent.putExtra("ssstockid", stkidstock)
                intent.putExtra("ssstkdesc", descstk)
                intent.putExtra("idofdb", ididdb)
                intent.putExtra("brnchid", keyofbrnch)
                intent.putExtra("idsofli", keyArray)
                intent.putExtra("reprnms", reprnms)
                intent.putExtra("relids", reqliid)
                intent.putExtra("reqid", reqid)
                intent.putExtra("reqname", reqnm)
                intent.putExtra("reqdate", reqdt)
                intent.putExtra("reqest", restimt)
                intent.putExtra("reqmail", reqmail)
                intent.putExtra("edclick",editclick)
                intent.putExtra("supplieridfr",supplieridfr)

                intent.putExtra("request_datedup",request_datedup)
                intent.putExtra("reqest_datedup",reqest_datedup)
                intent.putExtra("supp_namedup",supp_namedup)
                intent.putExtra("supp_gstdup",supp_gstdup)
                intent.putExtra("supp_addredup",supp_addredup)
                intent.putExtra("befnm",befnm)

                intent.putExtra("supnm", supnm)
                intent.putExtra("supadd1", supadd1)
                intent.putExtra("supadd2", supadd2)
                intent.putExtra("supadd3", supadd3)
                intent.putExtra("supcity", supcity)
                intent.putExtra("supstate", supstate)
                intent.putExtra("supph", supph)
                intent.putExtra("supgst", supgst)
                intent.putExtra("status", status)
                intent.putExtra("imlinks", imagelink)
                intent.putExtra("brky", oriky)
                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)

                intent.putExtra("deletelistener",deletelistener)
                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)




                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)


                intent.putExtra("groschk", groschk)
                intent.putExtra("ids", ids)


                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                finish()
            } else {
                popup("Add")
            }
        }


        //Navigate  list items  to edit activity (RequestUpdateActivity)

        purreq_list.setOnItemClickListener { parent, views, position, id ->


            println("STATUS WHEN LIST CLICK" + status)



            val b = Intent(applicationContext, RequestUpdateActivity::class.java)
            b.putExtra("from_req", updatestatus)
            b.putExtra("updstatus", updatestatus)
            b.putExtra("pnm", pronameArray)
            b.putExtra("pmanu", manufacturerArray)
            b.putExtra("phsn", hsnArray)
            b.putExtra("barcode", barcodeArray)
            b.putExtra("price", priceArray)
            b.putExtra("quan", quantityArray)
            b.putExtra("tot", totArray)
                b.putExtra("grosstot", grosstotArray)
            b.putExtra("pos", position)
            b.putExtra("cessup", cessArray)
            b.putExtra("igst", igstArray)
            b.putExtra("cgst", cgstArray)
            b.putExtra("sgst", sgstArray)
            b.putExtra("igsttotal", igsttotArray)
            b.putExtra("cesstotarray", cesstotalArray)
            b.putExtra("tallyarray", tallyArray)
            b.putExtra("receivedarray", receivedArray)
            b.putExtra("idsofli", keyArray)
            b.putExtra("smlistids", smlistids)
            b.putExtra("image", imageArray)
            b.putExtra("idpro", idproarray)
            b.putExtra("reqid", reqid)
            b.putExtra("reqliid", reqliid)
            b.putExtra("reprnms", reprnms)
            b.putExtra("reqname", reqnm)
            b.putExtra("reqdate", reqdt)
            b.putExtra("reqest", restimt)
            b.putExtra("reqmail", reqmail)
            b.putExtra("incompstr", incompstr)
            b.putExtra("edclick", editclick)

                b.putExtra("deletelistener",deletelistener)
               b.putExtra("request_datedup",request_datedup)
               b.putExtra("reqest_datedup",reqest_datedup)
               b.putExtra("supp_namedup",supp_namedup)
               b.putExtra("supp_gstdup",supp_gstdup)
               b.putExtra("supp_addredup",supp_addredup)
               b.putExtra("befnm",befnm)

            b.putExtra("supnm", supnm)
            b.putExtra("supadd1", supadd1)
            b.putExtra("supadd2", supadd1)
            b.putExtra("supadd3", supadd1)
            b.putExtra("supcity", supcity)
            b.putExtra("supstate", supstate)
            b.putExtra("supph", supph)
            b.putExtra("supgst", supgst)
            b.putExtra("status", status)
            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)
                b.putExtra("deletelistener",deletelistener)
                b.putExtra("supplieridfr",supplieridfr)

            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)


            b.putExtra("imlinks", imagelink)
            b.putExtra("brky", oriky)
            b.putExtra("groschk", groschk)

            b.putExtra("ids", ids)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
            finish()


        }



        ///------------------------------------- Bottom navigation to (RequestAddActivity)------------------------------///



        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val `in`: Intent

            when (checkedId) {
                R.id.matching -> {

                    println("RADIO STATUS"+status)


                    val o = Intent(this@RequestBottproActivity, RequestAddActivity::class.java)
                    o.putExtra("from_req", "update_request")
                    o.putExtra("renm", pronameArray)

                    o.putExtra("remanu", manufacturerArray)
                    o.putExtra("rekey", keyArray)
                    o.putExtra("rehsn", hsnArray)
                    o.putExtra("reprice", priceArray)
                    o.putExtra("requan", quantityArray)
                    o.putExtra("rebc", barcodeArray)
                    o.putExtra("retotal", totArray)
                    o.putExtra("regrosstotal", grosstotArray)
                    o.putExtra("recess", cessArray)
                    o.putExtra("reigst", igstArray)
                    o.putExtra("recgst", cgstArray)
                    o.putExtra("resgst", sgstArray)
                    o.putExtra("retally", tallyArray)
                    o.putExtra("rereceived", receivedArray)
                    o.putExtra("reigst_total", igsttotArray)
                    o.putExtra("recesstotal", cesstotalArray)
                    o.putExtra("reimmg", imageArray)
                    o.putExtra("req_id", reqid)
                    o.putExtra("req_liids", reqliid)
                    o.putExtra("req_prnms", reprnms)
                    o.putExtra("req_date", reqdt)
                    o.putExtra("groschk",groschk)
                    o.putExtra("idpro", idproarray)
                    o.putExtra("updatestatus", updatestatus)
                    o.putExtra("supplieridfr",supplieridfr)

                    o.putExtra("request_datedup",request_datedup)
                    o.putExtra("reqest_datedup",reqest_datedup)
                    o.putExtra("supp_namedup",supp_namedup)
                    o.putExtra("supp_gstdup",supp_gstdup)
                    o.putExtra("supp_addredup",supp_addredup)
                    o.putExtra("befnm",befnm)

                    o.putExtra("edclick",editclick)
                    o.putExtra("incompstr",incompstr)
                    o.putExtra("req_name", reqnm)
                    o.putExtra("req_mail", reqmail)
                    o.putExtra("req_esti", restimt)
                    o.putExtra("req_phone", reqph)
                    o.putExtra("req_supnm", supnm)
                    o.putExtra("req_supadd1", supadd1)
                    o.putExtra("req_supadd2", supadd2)
                    o.putExtra("req_supadd3", supadd3)
                    o.putExtra("req_supgst", supgst)
                    o.putExtra("req_supcity", supcity)
                    o.putExtra("req_supstate", supstate)
                    o.putExtra("req_supph", supph)
                    o.putExtra("status", status)
                    o.putExtra("orikys", oriky)
                    o.putExtra("images", imagelink)
                    o.putExtra("viewsuppin", viewsuppin)
                    o.putExtra("addsuppin", addsuppin)
                    o.putExtra("deletesuppin", deletesuppin)
                    o.putExtra("editsuppin", editesuppin)
                    o.putExtra("transfersuppin", transfersuppin)
                    o.putExtra("exportsuppin", exportsuppin)

                    o.putExtra("deletelistener",deletelistener)
                    o.putExtra("viewpurord", viewpurord)
                    o.putExtra("addpurord", addpurord)
                    o.putExtra("deletepurord", deletepurord)
                    o.putExtra("editpurord", editepurord)
                    o.putExtra("transferpurord", transferpurord)
                    o.putExtra("exportpurord", exportpurord)
                    o.putExtra("sendpurord", sendpurpo)




                    o.putExtra("viewpurreq", viewpurreq)
                    o.putExtra("addpurreq", addpurreq)
                    o.putExtra("deletepurreq", deletepurreq)
                    o.putExtra("editpurreq", editepurreq)
                    o.putExtra("transferpurreq", transferpurreq)
                    o.putExtra("exportpurreq", exportpurreq)



                    o.putExtra("ids",ids)





                    startActivity(o)
                    overridePendingTransition(0,0)
                    finish()

                }
                R.id.watchList -> {
                }
                else -> {
                }
            }

        })


    }


    companion object {

        //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively:RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private var bottonNavBardis:LinearLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE

                bottonNavBardis!!.visibility=View.GONE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {
                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                bottonNavBardis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

    override fun onBackPressed() {


        //Back action

        val o = Intent(this@RequestBottproActivity, RequestAddActivity::class.java)
        o.putExtra("from_req", "update_request")
        o.putExtra("renm", pronameArray)

        o.putExtra("remanu", manufacturerArray)
        o.putExtra("rekey", keyArray)
        o.putExtra("rehsn", hsnArray)
        o.putExtra("reprice", priceArray)
        o.putExtra("requan", quantityArray)
        o.putExtra("rebc", barcodeArray)
        o.putExtra("retotal", totArray)
        o.putExtra("regrosstotal", grosstotArray)
        o.putExtra("recess", cessArray)
        o.putExtra("reigst", igstArray)
        o.putExtra("recgst", cgstArray)
        o.putExtra("resgst", sgstArray)
        o.putExtra("retally", tallyArray)
        o.putExtra("rereceived", receivedArray)
        o.putExtra("reigst_total", igsttotArray)
        o.putExtra("recesstotal", cesstotalArray)
        o.putExtra("updatestatus", updatestatus)
        o.putExtra("reimmg", imageArray)
        o.putExtra("req_id", reqid)
        o.putExtra("req_liids", reqliid)
        o.putExtra("req_prnms", reprnms)
        o.putExtra("req_date", reqdt)
        o.putExtra("groschk",groschk)
        o.putExtra("idpro", idproarray)
        o.putExtra("request_datedup",request_datedup)
        o.putExtra("reqest_datedup",reqest_datedup)
        o.putExtra("supp_namedup",supp_namedup)
        o.putExtra("supp_gstdup",supp_gstdup)
        o.putExtra("supp_addredup",supp_addredup)
        o.putExtra("befnm",befnm)
        o.putExtra("edclick",editclick)
        o.putExtra("incompstr",incompstr)
        o.putExtra("req_name", reqnm)
        o.putExtra("req_mail", reqmail)
        o.putExtra("req_esti", restimt)
        o.putExtra("req_phone", reqph)
        o.putExtra("req_supnm", supnm)
        o.putExtra("req_supadd1", supadd1)
        o.putExtra("req_supadd2", supadd2)
        o.putExtra("req_supadd3", supadd3)
        o.putExtra("req_supgst", supgst)
        o.putExtra("req_supcity", supcity)
        o.putExtra("req_supstate", supstate)
        o.putExtra("req_supph", supph)
        o.putExtra("status", status)
        o.putExtra("orikys", oriky)
        o.putExtra("images", imagelink)
        o.putExtra("viewsuppin", viewsuppin)
        o.putExtra("addsuppin", addsuppin)
        o.putExtra("deletesuppin", deletesuppin)
        o.putExtra("editsuppin", editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)


        o.putExtra("deletelistener",deletelistener)
        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)


        o.putExtra("ids",ids)

        o.putExtra("supplieridfr",supplieridfr)

        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)


        startActivity(o)
        overridePendingTransition(0,0)
        finish()
    }

    fun net_status():Boolean{       //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    fun popup(st:String){  //Access Denied popup
        val pop= android.support.v7.app.AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
}
