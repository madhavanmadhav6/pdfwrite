package com.example.vinitas.inventory_app

import android.content.ActivityNotFoundException
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_zoom.*
import android.view.ScaleGestureDetector
import android.widget.ImageView
import com.example.vinitas.inventory_app.R.id.imageView
import android.text.method.Touch.onTouchEvent
import android.view.MotionEvent
import com.example.vinitas.inventory_app.R.id.imageView
import android.text.method.Touch.onTouchEvent
import android.view.View

import android.text.method.Touch.onTouchEvent
import android.widget.RelativeLayout
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.os.AsyncTask.execute
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import java.net.URL
import android.content.ContextWrapper
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.support.v7.app.AlertDialog
import android.widget.Toast
import dmax.dialog.SpotsDialog
import java.io.*
import java.util.*


class ZoomActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zoom)




        var zoomLayout = findViewById<View>(R.id.zoom_layout) as ZoomLayout  //Zoom Layout

        //--------------------------------Zoom layout zommlistner-------------------------------//
        val vto = zoomLayout.getViewTreeObserver()
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                zoomLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this)
                val width = zoomLayout.getMeasuredWidth()
                val height = zoomLayout.getMeasuredHeight()
                zoomLayout.setContentSize(width.toFloat(), height.toFloat())
            }
        })


        val k=intent.getStringExtra("imgurl")
        val extras = intent.extras
        val b = extras!!.getByteArray("drawb")


                //
        val bmp = BitmapFactory.decodeByteArray(b, 0, b!!.size)
        val drawable = BitmapDrawable(resources, bmp)

        imgview.setImageDrawable(drawable)



        imageButton.setOnClickListener {


            if (net_status() == true) {

                var smill=System.currentTimeMillis().toString()
                var y="Bill_$smill"+".jpg"
                val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Invoice Bill"
                val dir =  File(path);
                if(!dir.exists())
                    dir.mkdirs();
                val file = File(dir,y);

                val dialo =  SpotsDialog(this,"Downloading image...");

                dialo.show();

                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {


                        val time = System.currentTimeMillis()
                        val drawable = imgview.drawable
                        val bitmap = (drawable as BitmapDrawable).bitmap


                        try {



                            val fOut =  FileOutputStream(file);

                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                            fOut.flush();
                            fOut.close();
                            dialo.dismiss()
                            val savedImageURI = Uri.parse(file.absolutePath)

                            // Display the saved image to ImageView


                            // Display saved image uri to TextView
                            Toast.makeText(applicationContext, "Image Saved to:\n$savedImageURI", Toast.LENGTH_LONG).show()

                        } catch (e:Exception) {


                        }



                }
                }, 3000)

                val handler = Handler()
                handler.postDelayed({

                    if(file.exists()) {
                        val builder = AlertDialog.Builder(this@ZoomActivity)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->


                                var s = smill

                                var y = "Bill_$s"+".jpg"
                                viewPdf("Invoice Bill", y)

                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }
                    else{

                    }
                }, 4000)
            }
            else{
                Toast.makeText(applicationContext, "Please check your connection", Toast.LENGTH_LONG).show()

            }


        }




        userback.setOnClickListener {
            onBackPressed()
        }

    }



    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }



    fun viewPdf(folder:String,file:String) {

        val pdfFile =  File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+folder,file)
        println("SD CARD URL"+pdfFile)
        val path = Uri.fromFile(pdfFile);

        // Setting the intent for pdf reader
        val pdfIntent = Intent(Intent.ACTION_VIEW)
        pdfIntent.setDataAndType(path, "image/jpeg")
        pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        try {
            startActivity(pdfIntent);
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(applicationContext, "Can't open imge", Toast.LENGTH_SHORT).show();
        }
    }


}








