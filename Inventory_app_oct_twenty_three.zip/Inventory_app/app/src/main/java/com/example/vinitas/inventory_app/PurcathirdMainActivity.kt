package com.example.vinitas.inventory_app

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.Image
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.opengl.Visibility
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.constraint.solver.widgets.Rectangle
import android.support.design.widget.FloatingActionButton
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.firestore.EventListener
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import kotlinx.android.synthetic.main.activity_purcathird_main.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter

import java.io.*
import java.text.DecimalFormat

import java.text.SimpleDateFormat
import java.util.*


class PurcathirdMainActivity : AppCompatActivity() {


    private val datePicker: DatePicker? = null
    private var calendar: Calendar? = null
    private var dateView: TextView? = null

    private var dateView1: TextView? = null

    var supplieridfr=String()

    var suppinv=String()


    var edclick=String()


    private var year: Int = 0
    private var month: Int = 0
    private var day: Int = 0

    private val myDateListener = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day
        showDate(arg1, arg2 + 1, arg3)

    }

    private val myDateListener1 = DatePickerDialog.OnDateSetListener { arg0, arg1, arg2, arg3 ->
        // TODO Auto-generated method stub
        // arg1 = year
        // arg2 = month
        // arg3 = day

        showDate1(arg1, arg2 + 1, arg3)
    }
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""




    var innoempty=String()
    var innoemptystart=String()

    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""

    var savecli=String()

    var dirpath: String? = null
    var pri = arrayListOf<String>()
    var prodnms = arrayListOf<String>()
    var branchids = String()
    var descriplistener= String()
    var listListener= String()
    var deletelistener=String()
    var grosscheck=String()


    var db= FirebaseFirestore.getInstance()
    var TAG="some"
    data class s(

            var ponumber: String,
            var order_date: Any,
            var description: Any,
            var req_estimated: Any,
            var postatus: Any,
            var recstatus: Any,
            var igst_tot : Any,
            var cgst_tot : Any,
            var sgst_tot : Any,
            var cess_tot : Any,
            var gross_tot : Any,
            var stk_brid:Any,
            var supp_invoice:Any

            /*    var stk_wg_vol: Any,
                var stk_name: String,
                var stk_mfr: String,

                var taxchk: Any*/
    )
    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_grosstotal: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_cgst: Any,
            var otherstk_sgst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_received: Any,
            var received_price: Any,
            var received_taxtotal: Any,
            var received_cesstotal: Any,
            var received_grosstotal: Any,
            var received_total: Any,
            var otherstk_img: Any,
            var stk_key:Any,
            var stk_prokey:Any
    )

    var igstto = String()
    var cgstto = String()
    var sgstto = String()
    var cessto = String()

    var nameofbrnch = String()
    var locofbrnch = String()
    var keyofbrnch = String()
    var datestk = String()
    var smlistids = String()
    var descstk = String()
    var stkidstock = String()
    var ididdb = String()
    var i = arrayListOf<String>()
    var getiddel = ArrayList<String>()
    var checkcount = arrayListOf<Int>()
    var ids = arrayOf<String>()
    var ponum = String()
    var reqdt = String()
    var ordate = String()
    var postatus = String()
    var suppname= String()
    var suppphone= String()
    var grossto = String()
    var pdfFile= String()





    var pronamestr= String()
    var hsnstr = String()
    var manustr = String()
    var barcodestr= String()
    var quantitystr= String()
    var pricestr = String()
    var totstr = String()
    var grosstotstr = String()

    var cessstr = String()
    var keystr = String()
    var igststr = String()
    var cgststr = String()
    var sgststr = String()
    var igsttotstr= String()
    var cesstotstr= String()
    var tallystr = String()
    var receivedstr= String()
    var    receivedpricestr = String()
    var    receivedtotalstr = String()
    var  receivedcesstotstr = String()
    var receivedtaxtotalstr = String()
    var receivedgrosstotstr = String()
    var imagestr = String()
    var idofpro = String()


    var orddatedup= String()
    var reqdatedup= String()
    var descripdup= String()


    var recstat=String()


    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var grosstotArray = arrayListOf<String>()

    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var cgstArray = arrayListOf<String>()
    var sgstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var receivedpriceArray = arrayListOf<String>()
    var receivedtotalArray = arrayListOf<String>()
    var receivedcesstotArray = arrayListOf<String>()
    var receivedtaxtotalArray = arrayListOf<String>()
    var receivedgrosstotArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var idproarray=arrayListOf<String>()
    var downstatus= String()



    var compArray= arrayListOf<String>()
    var incomparray= arrayListOf<String>()
    var partcomp= arrayListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_purcathird_main)





//------------------------arrow mark displays when the list items is greater than 4 -------------------------------------//


        img_arrow.setOnClickListener {


            pur_list.setSelection(pur_list.getCount() - 1);


        }




/*pur_list.setOnScrollListener(object:AbsListView.OnScrollListener {

  override fun onScrollStateChanged(view:AbsListView ,scrollState:Int) {

    }


    override fun onScroll(view:AbsListView , firstVisibleItem:Int , visibleItemCount:Int , totalItemCount:Int)
    {
         if (firstVisibleItem < 2) {
             img_arrow.visibility=(View.GONE);
        }else{
            img_arrow.visibility=(View.VISIBLE);
        }
    }
});*/



        net_status()        //Check internet status.



        //Date views
        calendar = Calendar.getInstance()
        year = calendar!!.get(Calendar.YEAR)
        month = calendar!!.get(Calendar.MONTH)
        day = calendar!!.get(Calendar.DAY_OF_MONTH)

        dateView =  findViewById<TextView>(R.id.textView49)
        dateView1=findViewById<TextView>(R.id.textView50)

        showDate(year, month + 1, day)
        showDate1(year, month + 1, day)



        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@PurcathirdMainActivity) > 0)
        {

        }
        else{
            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()

        }


        //Define No connection view and other views when inetrnet connection is off.


        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        pur_savedis=findViewById(R.id.pur_save)
        userbackdis=findViewById(R.id.userback)
        mnudis=findViewById(R.id.mnu)
        ponodis=findViewById(R.id.pono)
        orddatedis=findViewById(R.id.orddate)
        reqdatedis=findViewById(R.id.reqdate)
        descripdis=findViewById(R.id.descrip)
        fabdis=findViewById(R.id.fab)
        pur_listdis=findViewById(R.id.pur_list)
        editdis=findViewById(R.id.edit)

        addLogText(NetworkUtil.getConnectivityStatusString(this@PurcathirdMainActivity))

        var received_price     =String()
        var received_total     =String()
        var received_quantity  =String()
        var received_taxtot    =String()
        var received_cesstot   =String()
        var received_grosstot  =String()


  /*      reqdate.setOnClickListener(View.OnClickListener {
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@PurcathirdMainActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> reqdate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })
*/







        //----------------------------------------------Delete Action--------------------------------------------------///

        var pronameArraydel = arrayListOf<String>()
        var hsnArraydel = arrayListOf<String>()
        var manufacturerArraydel = arrayListOf<String>()
        var barcodeArraydel = arrayListOf<String>()
        var quantityArraydel = arrayListOf<String>()
        var priceArraydel = arrayListOf<String>()
        var totArraydel = arrayListOf<String>()
        var grosstotArraydel = arrayListOf<String>()

        var cessArraydel = arrayListOf<String>()
        var keyArraydel = arrayListOf<String>()
        var igstArraydel = arrayListOf<String>()
        var cgstArraydel = arrayListOf<String>()
        var sgstArraydel = arrayListOf<String>()
        var igsttotArraydel = arrayListOf<String>()
        var cesstotArraydel = arrayListOf<String>()
        var tallyArraydel = arrayListOf<String>()
        var receivedArraydel = arrayListOf<String>()
        var receivedpriceArraydel = arrayListOf<String>()
        var receivedtotalArraydel = arrayListOf<String>()
        var receivedtaxtotalArraydel = arrayListOf<String>()
        var receivedcesstotArraydel = arrayListOf<String>()
        var receivedgrosstotArraydel = arrayListOf<String>()
        var imageArraydel = arrayListOf<String>()
        var idproArraydel=arrayListOf<String>()

        //Delete Action


        pur_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        pur_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {

                prodnms.clear()




                if(pronameArray.get(position).isNotEmpty()){
                    pronamestr = pronameArray.get(position)
                }
                else{
                    pronamestr = ""
                }

                if(hsnArray.get(position).isNotEmpty()){
                    hsnstr = hsnArray.get(position)
                }
                else{
                    hsnstr = "0"
                }

                if(manufacturerArray.get(position).isNotEmpty()){
                    manustr = manufacturerArray.get(position)
                }
                else{
                    manustr = "0"
                }

                if(barcodeArray.get(position).isNotEmpty()){
                    barcodestr = barcodeArray.get(position)
                }
                else{
                    barcodestr = "0"
                }
                if(quantityArray.get(position).isNotEmpty()){
                    quantitystr = quantityArray.get(position)
                }
                else{
                    quantitystr = "0"
                }

                if(priceArray.get(position).isNotEmpty()){
                    pricestr = priceArray.get(position)
                }
                else{
                    pricestr = "0"
                }
                if(totArray.get(position).isNotEmpty()){
                    totstr = totArray.get(position)
                }
                else{
                    totstr = "0"
                }
                if(grosstotArray.get(position).isNotEmpty()){
                    grosstotstr = grosstotArray.get(position)
                }
                else{
                    grosstotstr = "0"
                }

                if(cessArray.get(position).isNotEmpty()){
                    cessstr = cessArray.get(position)
                }
                else{
                    cessstr = "0"
                }

                if(keyArray.get(position).isNotEmpty()){
                    keystr = keyArray.get(position)
                }
                else{
                    keystr = "0"
                }
                if(igstArray.get(position).isNotEmpty()){
                    igststr = igstArray.get(position)
                }
                else{
                    igststr = "0"
                }

                if(cgstArray.get(position).isNotEmpty()){
                    cgststr = cgstArray.get(position)
                }
                else{
                    cgststr = "0"
                }
                if(sgstArray.get(position).isNotEmpty()){
                    sgststr = sgstArray.get(position)
                }
                else{
                    sgststr = "0"
                }
                if(igsttotArray.get(position).isNotEmpty()){
                    igsttotstr = igsttotArray.get(position)
                }
                else{
                    igsttotstr = "0"
                }
                if(cesstotalArray.get(position).isNotEmpty()){
                    cesstotstr = cesstotalArray.get(position)
                }
                else{
                    cesstotstr = "0"
                }
                if(tallyArray.get(position).isNotEmpty()){
                    tallystr = tallyArray.get(position)
                }
                else{
                    tallystr = "0"
                }
                if(receivedArray.get(position).isNotEmpty()){
                    receivedstr = receivedArray.get(position)
                }
                else{
                    receivedstr = "0"
                }


                if(receivedpriceArray.get(position).isNotEmpty()){
                    receivedpricestr = receivedpriceArray.get(position)
                }
                else{
                    receivedpricestr = "0"
                }

                if(receivedtotalArray.get(position).isNotEmpty()){
                    receivedtotalstr = receivedtotalArray.get(position)
                }
                else{
                    receivedtotalstr = "0"
                }

                if(receivedcesstotArray.get(position).isNotEmpty()){
                    receivedcesstotstr = receivedcesstotArray.get(position)
                }
                else{
                    receivedcesstotstr = "0"
                }

                if(receivedtaxtotalArray.get(position).isNotEmpty()){
                    receivedtaxtotalstr = receivedtaxtotalArray.get(position)
                }
                else{
                    receivedtaxtotalstr = "0"
                }

                if(receivedgrosstotArray.get(position).isNotEmpty()){
                    receivedgrosstotstr = receivedgrosstotArray.get(position)
                }
                else{
                    receivedgrosstotstr = "0"
                }


                if(imageArray.get(position).isNotEmpty()){
                    imagestr = imageArray.get(position)
                }
                else{
                    imagestr = "0"
                }

                if(idproarray.get(position).isNotEmpty()){
                    idofpro = idproarray.get(position)
                }
                else{
                    idofpro = "0"
                }




                //capture total checked items and put the values to array


                if (checked == true) {
                    pronameArraydel.add(pronamestr)
                    hsnArraydel.add(hsnstr)
                    manufacturerArraydel.add(manustr)
                    barcodeArraydel.add(barcodestr)
                    quantityArraydel.add(quantitystr)
                    priceArraydel.add(pricestr)
                    totArraydel.add(totstr)
                    grosstotArraydel.add(grosstotstr)

                    cessArraydel.add(cessstr)
                    keyArraydel.add(keystr)
                    igstArraydel.add(igststr)
                    cgstArraydel.add(cgststr)
                    sgstArraydel.add(sgststr)
                    igsttotArraydel.add(igsttotstr)
                    cesstotArraydel.add(cesstotstr)
                    tallyArraydel.add(tallystr)
                    receivedArraydel.add(receivedstr)
                    receivedpriceArraydel.add(receivedpricestr)
                    receivedtotalArraydel.add(receivedtotalstr)
                    receivedtaxtotalArraydel.add(receivedtaxtotalstr)
                    receivedcesstotArraydel.add(receivedcesstotstr)
                    receivedgrosstotArraydel.add(receivedgrosstotstr)
                    imageArraydel.add(imagestr)
                    idproArraydel.add(idofpro)

                    /* pronameArraydelglo=pronameArraydel
                     hsnArraydelglo=hsnArraydel
                     manufacturerArraydelglo=manufacturerArraydel
                     barcodeArraydelglo=barcodeArraydel
                     quantityArraydelglo=quantityArraydel
                     priceArraydelglo=priceArraydel
                     totArraydelglo=totArraydel
                     cessArraydelglo=cessArraydel
                     keyArraydelglo=keyArraydel
                     igstArraydelglo=igstArraydel
                     cgstArraydelglo=cgstArraydel
                     sgstArraydelglo=sgstArraydel
                     igsttotArraydelglo=igsttotArraydel
                     cesstotalArraydelglo=cesstotArraydel
                     tallyArraydelglo=tallyArraydel
                     receivedArraydelglo=receivedArraydel
                     imageArraydelglo=imageArraydel*/


                    println("pronameArray ARRAY SELECTED DELETE"+pronameArraydel)
                    println("hsnArray ARRAY SELECTED DELETE"+hsnArraydel)
                    println("manufacturerArray ARRAY SELECTED DELETE"+manufacturerArraydel)
                    println("barcodeArray ARRAY SELECTED DELETE"+barcodeArraydel)
                    println("quantityArray ARRAY SELECTED DELETE"+quantityArraydel)
                    println("priceArray ARRAY SELECTED DELETE"+priceArraydel)
                    println("totArray ARRAY SELECTED DELETE"+totArraydel)
                    println("cessArray ARRAY SELECTED DELETE"+cessArraydel)
                    println("keyArray ARRAY SELECTED DELETE"+keyArraydel)
                    println("igstArray ARRAY SELECTED DELETE"+igstArraydel)
                    println("cgstArray ARRAY SELECTED DELETE"+cgstArraydel)
                    println("sgstArray ARRAY SELECTED DELETE"+sgstArraydel)
                    println("igsttotArray ARRAY SELECTED DELETE"+igsttotArraydel)
                    println("cesstotalArray ARRAY SELECTED DELETE"+cesstotArraydel)
                    println("tallyArray ARRAY SELECTED DELETE"+tallyArraydel)
                    println("receivedArray ARRAY SELECTED DELETE"+receivedArraydel)
                    println("imageArray ARRAY SELECTED DELETE"+imageArraydel)


                }
                else{
                    pronameArraydel.remove(pronamestr)
                    hsnArraydel.remove(hsnstr)
                    manufacturerArraydel.remove(manustr)
                    barcodeArraydel.remove(barcodestr)
                    quantityArraydel.remove(quantitystr)
                    priceArraydel.remove(pricestr)
                    totArraydel.remove(totstr)
                    grosstotArraydel.remove(grosstotstr)
                    cessArraydel.remove(cessstr)
                    keyArraydel.remove(keystr)
                    igstArraydel.remove(igststr)
                    cgstArraydel.remove(cgststr)
                    sgstArraydel.remove(sgststr)
                    igsttotArraydel.remove(igsttotstr)
                    cesstotArraydel.remove(cesstotstr)
                    tallyArraydel.remove(tallystr)
                    receivedArraydel.remove(receivedstr)
                    receivedpriceArraydel.remove(receivedpricestr)
                    receivedtotalArraydel.remove(receivedtotalstr)
                    receivedtaxtotalArraydel.remove(receivedtaxtotalstr)
                    receivedcesstotArraydel.remove(receivedcesstotstr)
                    receivedgrosstotArraydel.remove(receivedgrosstotstr)
                    imageArraydel.remove(imagestr)
                    idproArraydel.remove(idofpro)

                    /*pronameArraydelglo=pronameArraydel
                    hsnArraydelglo=hsnArraydel
                    manufacturerArraydelglo=manufacturerArraydel
                    barcodeArraydelglo=barcodeArraydel
                    quantityArraydelglo=quantityArraydel
                    priceArraydelglo=priceArraydel
                    totArraydelglo=totArraydel
                    cessArraydelglo=cessArraydel
                    keyArraydelglo=keyArraydel
                    igstArraydelglo=igstArraydel
                    cgstArraydelglo=cgstArraydel
                    sgstArraydelglo=sgstArraydel
                    igsttotArraydelglo=igsttotArraydel
                    cesstotalArraydelglo=cesstotArraydel
                    tallyArraydelglo=tallyArraydel
                    receivedArraydelglo=receivedArraydel
                    imageArraydelglo=imageArraydel*/


                    println("pronameArray ARRAY UNSELETED DELETE"+pronameArraydel)
                    println("hsnArray ARRAY UNSELETED DELETE"+hsnArraydel)
                    println("manufacturerArray ARRAY UNSELETED DELETE"+manufacturerArraydel)
                    println("barcodeArray ARRAY UNSELETED DELETE"+barcodeArraydel)
                    println("quantityArray ARRAY UNSELETED DELETE"+quantityArraydel)
                    println("priceArray ARRAY UNSELETED DELETE"+priceArraydel)
                    println("totArray ARRAY UNSELETED DELETE"+totArraydel)
                    println("cessArray ARRAY UNSELETED DELETE"+cessArraydel)
                    println("keyArray ARRAY UNSELETED DELETE"+keyArraydel)
                    println("igstArray ARRAY UNSELETED DELETE"+igstArraydel)
                    println("cgstArray ARRAY UNSELETED DELETE"+cgstArraydel)
                    println("sgstArray ARRAY UNSELETED DELETE"+sgstArraydel)
                    println("igsttotArray ARRAY UNSELETED DELETE"+igsttotArraydel)
                    println("cesstotalArray ARRAY UNSELETED DELETE"+cesstotArraydel)
                    println("tallyArray ARRAY UNSELETED DELETE"+tallyArraydel)
                    println("receivedArray ARRAY UNSELETED DELETE"+receivedArraydel)
                    println("imageArray ARRAY UNSELETED DELETE"+imageArraydel)


                }


                println("CREATEDDDD out")

                val checkedCounts = pur_list.checkedItemCount




                //setting CAB title
                mode.setTitle("" + checkedCounts + " Selected")
                Log.d(TAG, " " + id)
            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {


                //Inflate the CAB and Invisible other views in toolbar

                toolbar1.visibility = View.INVISIBLE
                pur_save.visibility = View.INVISIBLE
                userback.visibility = View.INVISIBLE
                comttname.visibility=View.INVISIBLE
                comphone.visibility=View.INVISIBLE
                mnu.visibility = View.INVISIBLE
                comp_toolimg.visibility=View.INVISIBLE
                mode.getMenuInflater().inflate(R.menu.menu_delete, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                println("CREATEDDDD")
                /*        val deleteSize = dlt.size
                          Log.i("tsdfs", "  " + dlt.size)
                          *//*val cate = null
                    val data = s(cat = cate)*//*
                    val i = 0
                    Log.d("dlt", " " + dlt.get(i))*/
                val itemId = item.getItemId()

                //val i = 0
                var refiddel = listoids.text.toString()
                var pathfdel = "Stock_Transfer/$refiddel/Stock_products"
                if ((itemId == R.id.delete) && (deletepurord == "true")) {

                    listListener="listadded"

                    for (i in 0 until pronameArraydel.size) {

                        pronameArray.remove(pronameArraydel.get(i))
                        hsnArray.remove(hsnArraydel.get(i))
                        manufacturerArray.remove(manufacturerArraydel.get(i))
                        barcodeArray.remove(barcodeArraydel.get(i))
                        quantityArray.remove(quantityArraydel.get(i))
                        priceArray.remove(priceArraydel.get(i))
                        totArray.remove(totArraydel.get(i))
                        grosstotArray.remove(grosstotArraydel.get(i))

                        cessArray.remove(cessArraydel.get(i))
                        keyArray.remove(keyArraydel.get(i))
                        igstArray.remove(igstArraydel.get(i))
                        cgstArray.remove(cgstArraydel.get(i))
                        sgstArray.remove(sgstArraydel.get(i))
                        igsttotArray.remove(igsttotArraydel.get(i))
                        cesstotalArray.remove(cesstotArraydel.get(i))
                        tallyArray.remove(tallyArraydel.get(i))
                        receivedArray.remove(receivedArraydel.get(i))
                        receivedpriceArray.remove(receivedpriceArraydel.get(i))
                        receivedtaxtotalArray.remove(receivedtaxtotalArraydel.get(i))
                        receivedcesstotArray.remove(receivedcesstotArraydel.get(i))
                        receivedgrosstotArray.remove(receivedgrosstotArraydel.get(i))
                        receivedtotalArray.remove(receivedtotalArraydel.get(i))
                        imageArray.remove(imageArraydel.get(i))
                        idproarray.remove(idproArraydel.get(i))
                    }



                    println("pronameArray ARRAY AFTER DELETE"+pronameArray)
                    println("pronameArray ARRAY AFTER DELETE"+pronameArray)
                    println("hsnArray ARRAY AFTER DELETE"+hsnArray)
                    println("manufacturerArray ARRAY AFTER DELETE"+manufacturerArray)
                    println("barcodeArray ARRAY AFTER DELETE"+barcodeArray)
                    println("quantityArray ARRAY AFTER DELETE"+quantityArray)
                    println("priceArray ARRAY AFTER DELETE"+priceArray)
                    println("totArray ARRAY AFTER DELETE"+totArray)
                    println("cessArray ARRAY AFTER DELETE"+cessArray)
                    println("keyArray ARRAY AFTER DELETE"+keyArray)
                    println("igstArray ARRAY AFTER DELETE"+igstArray)
                    println("cgstArray ARRAY AFTER DELETE"+cgstArray)
                    println("sgstArray ARRAY AFTER DELETE"+sgstArray)
                    println("igsttotArray ARRAY AFTER DELETE"+igsttotArray)
                    println("cesstotalArray ARRAY AFTER DELETE"+cesstotalArray)
                    println("tallyArray ARRAY AFTER DELETE"+tallyArray)
                    println("receivedArray ARRAY AFTER DELETE"+receivedArray)
                    println("imageArray ARRAY AFTER DELETE"+imageArray)







                    val whatever = purchseorder_list_adaps(this@PurcathirdMainActivity, pronameArray, manufacturerArray, hsnArray,
                            barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                            igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                            receivedgrosstotArray,receivedtotalArray,imageArray)
                    pur_list.adapter = whatever

                    val  footer = View.inflate(this@PurcathirdMainActivity,R.layout.footer, null);
                    pur_list.addFooterView(footer,null,false)
                   /* Helper.getListViewSize(pur_list);*/


                    //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.


                    try {



                        if(priceArray.isNotEmpty()==true) {





                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until priceArray.count()) {


                            if(receivedArray[i].isEmpty()) {
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (quantityArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)



                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)


                                println("TRIMED LIST NAMESSS" + (prodnms.toString()))


                                println("COUNT"+pronameArray.size)



                                if(pronameArray.size>4){


                                    img_arrow.visibility=View.VISIBLE

                                }



                            }
                            else if(receivedArray[i].isNotEmpty()) {
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (receivedArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }

                                recstat="Received"

                                println("COUNT" + pronameArray.size)



                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)
                            }

                            }




                        }
                        else{
                            gross_tot.text = DecimalFormat("#.00").format(0.0)
                            grosscheck = gross_tot.text.toString()

                            igst_tot.text = DecimalFormat("##.##").format(0.0)
                            cgst_tot.text = DecimalFormat("##.##").format(0.0)
                            sgst_tot.text = DecimalFormat("##.##").format(0.0)
                            cess_tot.text = DecimalFormat("##.##").format(0.0)
                        }
                    } catch (e: Exception) {
                        Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                    }


                } else {
                    popup("delete")
                }
                mode.finish()
                pronameArraydel.clear()
                hsnArraydel.clear()
                manufacturerArraydel.clear()
                barcodeArraydel.clear()
                quantityArraydel.clear()
                priceArraydel.clear()
                totArraydel.clear()
                grosstotArraydel.clear()

                cessArraydel.clear()
                keyArraydel.clear()
                igstArraydel.clear()
                cgstArraydel.clear()
                sgstArraydel.clear()
                igsttotArraydel.clear()
                cesstotArraydel.clear()
                tallyArraydel.clear()
                receivedArraydel.clear()
                receivedpriceArraydel.clear()
                receivedtotalArraydel.clear()
                receivedtaxtotalArraydel.clear()
                receivedcesstotArraydel.clear()
                receivedgrosstotArraydel.clear()
                idproArraydel.clear()
                return true

            }

            override fun onDestroyActionMode(mode: ActionMode) {
                toolbar1.visibility = View.VISIBLE
                pur_list.visibility = View.VISIBLE
                pur_save.visibility = View.VISIBLE
                comttname.visibility=View.VISIBLE
                comphone.visibility=View.VISIBLE
                userback.visibility = View.VISIBLE
                mnu.visibility = View.VISIBLE
                comp_toolimg.visibility=View.VISIBLE
            }

        })


















        edit.setOnClickListener {

            if(editepurord=="true") {



                pur_list.isClickable=true
                edit.visibility = View.GONE
                pur_save.visibility = View.VISIBLE
                mnu.visibility=View.VISIBLE
                descrip.isEnabled = true
                fab.visibility=View.VISIBLE
                orddate.isEnabled=true
                reqdate.isEnabled=true
                descrip.isEnabled=true

                edclick="click"

                val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                        barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                        igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                        receivedgrosstotArray,receivedtotalArray,imageArray)
                pur_list.adapter = whatever

                /*Helper.getListViewSize(pur_list);*/
            }
            else if(editepurord=="false")
            {
                popup("Edit")
            }

        }



        val c = Calendar.getInstance()
        System.out.println("Current time =&gt; " + c.time)

        val df = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = df.format(c.time)



      /*  orddate.setOnClickListener(View.OnClickListener {
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@PurcathirdMainActivity,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> orddate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })*/





        val bundle = intent.extras
        var frm = bundle!!.get("from_pur").toString()


        var idsforup = ArrayList<Any>()
        var idsup = String()


        val dl = intent.getStringArrayListExtra("dlt")
        Log.d("dlt", "  " + dl)


        //Empty list product add


        if(frm=="newadd_pur") {




        }



            //FROM PRODUCT LIST


            //--------------------------Here we can add multiple product list items from (product_list_activity(purchase))-------------------------//


            else if (frm == "pur_list") {

                val aw = bundle!!.get("pur_pname") as ArrayList<String>
                val bw = bundle!!.get("pur_pitem") as ArrayList<String>
                val cw = bundle!!.get("pur_phsn") as ArrayList<String>
                val dw = bundle!!.get("pur_porder") as ArrayList<String>
                /*    val ew=bundle!!.get("pcomplete") as Array<String>*/
                val fw = bundle!!.get("pur_pprice") as ArrayList<String>
                val hw = bundle!!.get("pur_ptot") as ArrayList<String>
                val hwgro = bundle!!.get("pur_pgrosstot") as ArrayList<String>

                val gw = bundle!!.get("pur_poarray") as ArrayList<String>
                val lw = bundle!!.get("pur_cessarray") as ArrayList<String>
                val mw = bundle!!.get("pur_igstarray") as ArrayList<String>
                val cgw = bundle!!.get("pur_cgstarray") as ArrayList<String>
                val sgw = bundle!!.get("pur_sgstarray") as ArrayList<String>
                val nw = bundle!!.get("pur_igsttotarray") as ArrayList<String>
                val ow = bundle!!.get("pur_cesstotalarray") as ArrayList<String>
                val pw = bundle!!.get("pur_tallyarray") as ArrayList<String>
                val rew = bundle!!.get("pur_receivedarray") as ArrayList<String>
                val rewpri = bundle!!.get("pur_receivedarraypri") as ArrayList<String>
                val rewtot = bundle!!.get("pur_receivedarraytotal") as ArrayList<String>
                val rewtaxtot = bundle!!.get("pur_receivedarraytaxtot") as ArrayList<String>
                val rewgrosstot = bundle!!.get("pur_receivedarraygrosstot") as ArrayList<String>
                val rewcesstot = bundle!!.get("pur_receivedarraycesstot") as ArrayList<String>
                val piddli = bundle!!.get("pur_reiddofli") as ArrayList<String>
                val imm = bundle!!.get("pur_imi") as ArrayList<String>
            val idpr = bundle!!.get("idpro") as ArrayList<String>


            ids=bundle!!.get("ids") as Array<String>

                val uppono = intent.getStringExtra("pono")
                val orddtup = intent.getStringExtra("reorddate")
                val reqdtup = intent.getStringExtra("reestdt")
                val descup = intent.getStringExtra("redesc")
                val postatusup = intent.getStringExtra("restatus")
                val mainidup = intent.getStringExtra("reids")
                val prnmsup = intent.getStringExtra("names")
                val comnmup = intent.getStringExtra("titnm")
                val comphup = intent.getStringExtra("tiphone")
            val bridds = intent.getStringExtra("brid")
            branchids=bridds


try {
    orddatedup = intent.getStringExtra("orddatedup")
    reqdatedup = intent.getStringExtra("reqdatedup")
    descripdup = intent.getStringExtra("descripdup")
}
catch (e:Exception){

}


            try{

                edclick=intent.getStringExtra("edclick")

            }
            catch (e:Exception){

            }


            try{

                suppinv=intent.getStringExtra("suppinv")

            }
            catch (e:Exception){

            }

            try {
                descriplistener = intent.getStringExtra("descriplistener")
                listListener = intent.getStringExtra("listListener")

                println("listListener"+listListener)

            }
            catch (e:Exception){

            }

//Purchase order

            //Purchase order




            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }




            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }






            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            try{
            supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            val groschk=intent.getStringExtra("groschk")

            grosscheck=groschk

            println("GROSSCHECk"+grosscheck)

            pono.setText(uppono)
            orddate.setText(orddtup)
            reqdate.setText(reqdtup)
            descrip.setText(descup)
            listoids.setText(mainidup)
            names.setText(prnmsup)
            comttname.setText(comnmup)
            comphone.setText(comphup)

         /*       val c = Calendar.getInstance()
                System.out.println("Current time =&gt; " + c.time)

                val df = SimpleDateFormat("dd/MM/yyyy")
                val formattedDate = df.format(c.time)

                orddate.setText(formattedDate)*/

                pronameArray = aw
                manufacturerArray = bw
                quantityArray = dw
                priceArray = fw
                hsnArray = cw
                barcodeArray = gw
                totArray = hw
            grosstotArray = hwgro

            cessArray = lw
                keyArray = piddli
                igstArray = mw
                cgstArray = cgw
                sgstArray = sgw
                igsttotArray = nw
                cesstotalArray = ow
                tallyArray = pw
                receivedArray = rew
                receivedpriceArray = rewpri
                receivedtaxtotalArray = rewtaxtot
                receivedcesstotArray = rewcesstot
                receivedgrosstotArray = rewgrosstot
                receivedtotalArray = rewtot
                imageArray = imm
                idproarray=idpr


            println("ID PRO LIST VALS"+idproarray)








                val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                        barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                        igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                        receivedgrosstotArray,receivedtotalArray,imageArray)
                pur_list.adapter = whatever

                val footer = View.inflate(this, R.layout.footer, null);
                pur_list.addFooterView(footer, null, false)
                //Helper.getListViewSize(pur_list);


            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.


            if (savecli != "clicked") {

                    try {
                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until priceArray.count()) {
                            if(receivedArray[i].isEmpty()) {
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (quantityArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)



                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)

                                val asf = tallyArray.contains("InComplete")

                                val asfcomp = tallyArray.contains("Complete")

                                val asfpartcm = tallyArray.contains("Partially Complete")




                                println("TALLIEDDDD" + asf)
                                println("ARRRAY ITEEEMSSSS" + tallyArray)
                                if (asfpartcm) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                } else if (asfcomp && (asfpartcm)) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                } else if (!asf && (!asfpartcm) && asfcomp) {

                                    purc_spinner2.setText("Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                } else if (asf && (asfcomp)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                }


                                println("TRIMED LIST NAMESSS" + (prodnms))

                                if (grosscheck == "") {

                                } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                    listListener = "listadded"
                                }
                            }
                            else if(receivedArray[i].isNotEmpty()){
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (receivedArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)


                                recstat="Received"
                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)

                                val asf = tallyArray.contains("InComplete")

                                val asfcomp = tallyArray.contains("Complete")

                                val asfpartcm = tallyArray.contains("Partially Complete")




                                println("TALLIEDDDD" + asf)
                                println("ARRRAY ITEEEMSSSS" + tallyArray)
                                if (asfpartcm) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                } else if (asfcomp && (asfpartcm)) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                } else if (!asf && (!asfpartcm) && asfcomp) {

                                    purc_spinner2.setText("Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                } else if (asf && (asfcomp)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                }


                                println("TRIMED LIST NAMESSS" + (prodnms))

                                if (grosscheck == "") {

                                } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                    listListener = "listadded"
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                    }
                        }

            }











        else if (frm == "pur_list_single") {    //Here we can add single list item from (product_list_activity(purchase))

            val aw = bundle!!.get("pur_pname") as ArrayList<String>
            val bw = bundle!!.get("pur_pitem") as ArrayList<String>
            val cw = bundle!!.get("pur_phsn") as ArrayList<String>
            val dw = bundle!!.get("pur_porder") as ArrayList<String>
            /*    val ew=bundle!!.get("pcomplete") as Array<String>*/
            val fw = bundle!!.get("pur_pprice") as ArrayList<String>
            val hw = bundle!!.get("pur_ptot") as ArrayList<String>
            val hwgro = bundle!!.get("pur_pgrosstot") as ArrayList<String>

            val gw = bundle!!.get("pur_poarray") as ArrayList<String>
            val lw = bundle!!.get("pur_cessarray") as ArrayList<String>
            val mw = bundle!!.get("pur_igstarray") as ArrayList<String>
            val cgw = bundle!!.get("pur_cgstarray") as ArrayList<String>
            val sgw = bundle!!.get("pur_sgstarray") as ArrayList<String>
            val nw = bundle!!.get("pur_igsttotarray") as ArrayList<String>
            val ow = bundle!!.get("pur_cesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("pur_tallyarray") as ArrayList<String>
            val rew = bundle!!.get("pur_receivedarray") as ArrayList<String>
            val rewpri = bundle!!.get("pur_receivedarraypri") as ArrayList<String>
            val rewtot = bundle!!.get("pur_receivedarraytotal") as ArrayList<String>
            val rewtaxtot = bundle!!.get("pur_receivedarraytaxtot") as ArrayList<String>
            val rewgrosstot = bundle!!.get("pur_receivedarraygrosstot") as ArrayList<String>
            val rewcesstot = bundle!!.get("pur_receivedarraycesstot") as ArrayList<String>
            val piddli = bundle!!.get("pur_reiddofli") as ArrayList<String>
            val imm = bundle!!.get("pur_imi") as ArrayList<String>

             val idpr = bundle!!.get("idpro") as ArrayList<String>

            val uppono = intent.getStringExtra("pono")
            val orddtup = intent.getStringExtra("reorddate")
            val reqdtup = intent.getStringExtra("reestdt")
            val descup = intent.getStringExtra("redesc")
            val postatusup = intent.getStringExtra("restatus")
            val mainidup = intent.getStringExtra("reids")
            val prnmsup = intent.getStringExtra("names")
            val comnmup = intent.getStringExtra("titnm")
            val comphup = intent.getStringExtra("tiphone")
            val bridds = intent.getStringExtra("brid")
            branchids=bridds
            ids=bundle!!.get("ids") as Array<String>
//Purchase order


            try {
                orddatedup = intent.getStringExtra("orddatedup")
                reqdatedup = intent.getStringExtra("reqdatedup")
                descripdup = intent.getStringExtra("descripdup")
            }
            catch (e:Exception){

            }
            try {
                descriplistener = intent.getStringExtra("descriplistener")
                listListener = intent.getStringExtra("listListener")

            }
            catch (e:Exception){

            }

            //Purchase order
            try{

                suppinv=intent.getStringExtra("suppinv")

            }
            catch (e:Exception){

            }



            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }




            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }






            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            val groschk=intent.getStringExtra("groschk")

            grosscheck=groschk

            pono.setText(uppono)
            orddate.setText(orddtup)
            reqdate.setText(reqdtup)
            descrip.setText(descup)
            listoids.setText(mainidup)
            names.setText(prnmsup)
            comttname.setText(comnmup)
            comphone.setText(comphup)



            try{
                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }


            /*       val c = Calendar.getInstance()
                   System.out.println("Current time =&gt; " + c.time)

                   val df = SimpleDateFormat("dd/MM/yyyy")
                   val formattedDate = df.format(c.time)

                   orddate.setText(formattedDate)*/

            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            grosstotArray = hwgro

            cessArray = lw
            keyArray = piddli
            igstArray = mw
            cgstArray = cgw
            sgstArray = sgw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            receivedpriceArray = rewpri
            receivedtaxtotalArray = rewtaxtot
            receivedcesstotArray = rewcesstot
            receivedgrosstotArray = rewgrosstot
            receivedtotalArray = rewtot
            imageArray = imm
            idproarray=idpr

            println("ID PRO LIST VALS"+idproarray)


                val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                        barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                        igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                        receivedgrosstotArray,receivedtotalArray,imageArray)
                pur_list.adapter = whatever

                val footer = View.inflate(this, R.layout.footer, null);
                pur_list.addFooterView(footer, null, false)
                //Helper.getListViewSize(pur_list);


            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.


            if (savecli != "clicked") {

                    try {
                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until priceArray.count()) {

                            if(receivedArray[i].isEmpty()) {
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (quantityArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)



                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)

                                val asf = tallyArray.contains("InComplete")

                                val asfcomp = tallyArray.contains("Complete")

                                val asfpartcm = tallyArray.contains("Partially Complete")




                                println("TALLIEDDDD" + asf)
                                println("ARRRAY ITEEEMSSSS" + tallyArray)
                                if (asfpartcm) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                } else if (asfcomp && (asfpartcm)) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                } else if (!asf && (!asfpartcm) && asfcomp) {

                                    purc_spinner2.setText("Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                } else if (asf && (asfcomp)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                }


                                println("TRIMED LIST NAMESSS" + (prodnms))

                                if (grosscheck == "") {

                                } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                    listListener = "listadded"
                                }
                            }
                            else if(receivedArray[i].isNotEmpty()){
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (receivedArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)

                                recstat="Received"

                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)

                                val asf = tallyArray.contains("InComplete")

                                val asfcomp = tallyArray.contains("Complete")

                                val asfpartcm = tallyArray.contains("Partially Complete")




                                println("TALLIEDDDD" + asf)
                                println("ARRRAY ITEEEMSSSS" + tallyArray)
                                if (asfpartcm) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                } else if (asfcomp && (asfpartcm)) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                } else if (!asf && (!asfpartcm) && asfcomp) {

                                    purc_spinner2.setText("Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                } else if (asf && (asfcomp)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                }


                                println("TRIMED LIST NAMESSS" + (prodnms))

                                if (grosscheck == "") {

                                } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                    listListener = "listadded"
                                }
                            }

                        }
                    } catch (e: Exception) {
                        Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                    }
                }



            //Delete function



        }








            //From Update Function

        else if (frm == "update_purchase") {

            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
               val dv=bundle!!.get("reprice") as ArrayList<String>
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val hvgro = bundle!!.get("regrosstotal") as ArrayList<String>

            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val idv = bundle!!.get("recgst") as ArrayList<String>
            val isv = bundle!!.get("resgst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val rereceivepri = bundle!!.get("rereceived_pri") as ArrayList<String>
            val rereceivetot = bundle!!.get("rereceived_tot") as ArrayList<String>
            val rereceivetaxtot = bundle!!.get("rereceived_taxtot") as ArrayList<String>
            val rereceivecesstot = bundle!!.get("rereceived_cesstot") as ArrayList<String>
            val rereceivegrosstot = bundle!!.get("rereceived_grosstot") as ArrayList<String>
            val immv = bundle!!.get("reimmg") as ArrayList<String>
             val idpr = bundle!!.get("idpro") as ArrayList<String>

            ids=bundle!!.get("ids") as Array<String>
            val uppono = intent.getStringExtra("pono")
            val orddtup = intent.getStringExtra("reorddate")
            val reqdtup = intent.getStringExtra("reestdt")
            val descup = intent.getStringExtra("redesc")
            val postatusup = intent.getStringExtra("restatus")
            val mainidup = intent.getStringExtra("reids")
            val prnmsup = intent.getStringExtra("names")
            val comnmup = intent.getStringExtra("titnm")
            val comphup = intent.getStringExtra("tiphone")
            val brnchidds = intent.getStringExtra("brids")
            branchids=brnchidds
            //Purchase order


            var grocheck=intent.getStringExtra("groschk")
            grosscheck=grocheck

            try {
                orddatedup = intent.getStringExtra("orddatedup")
                reqdatedup = intent.getStringExtra("reqdatedup")
                descripdup = intent.getStringExtra("descripdup")
            }
            catch (e:Exception){

            }

            try {
                descriplistener = intent.getStringExtra("descriplistener")
                listListener = intent.getStringExtra("listListener")

            }
            catch (e:Exception){

            }

            try{

                suppinv=intent.getStringExtra("suppinv")

            }
            catch (e:Exception){

            }

            try{
                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }


            try{
                edclick=intent.getStringExtra("edclick")
            }
            catch (e:Exception){

            }

            if(edclick=="click"||edclick.isNotEmpty()){
                pur_list.isClickable=true
                edit.visibility = View.GONE
                pur_save.visibility = View.VISIBLE
                mnu.visibility=View.VISIBLE
                descrip.isEnabled = true
                fab.visibility=View.VISIBLE
                orddate.isEnabled=true
                reqdate.isEnabled=true
                descrip.isEnabled=true
            }
            else if(edclick.isEmpty()){
                pur_list.isClickable=false
                edit.visibility = View.VISIBLE
                pur_save.visibility = View.GONE
                mnu.visibility=View.GONE
                descrip.isEnabled = false
                fab.visibility=View.GONE
                orddate.isEnabled=false
                reqdate.isEnabled=false
                descrip.isEnabled=false
            }



            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }




            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }






            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }





             pono.setText(uppono)
            orddate.setText(orddtup)
            reqdate.setText(reqdtup)
            descrip.setText(descup)
            listoids.setText(mainidup)
            names.setText(prnmsup)
            comttname.setText(comnmup)
            comphone.setText(comphup)







            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = dv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            grosstotArray = hvgro

            cessArray = gv
            keyArray = rekey
            igstArray = iv
            cgstArray = idv
            sgstArray = isv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            receivedpriceArray=rereceivepri
            receivedtaxtotalArray=rereceivetaxtot
            receivedcesstotArray=rereceivecesstot
            receivedgrosstotArray=rereceivegrosstot
            receivedtotalArray=rereceivetot
            imageArray = immv
            idproarray=idpr

            println("ID PRO LIST VALS"+idproarray)


            println("EMPTY ARRAY "+receivedArray)

               val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                       barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                       igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                       receivedgrosstotArray,receivedtotalArray,imageArray)
               pur_list.adapter = whatever

               val footer = View.inflate(this, R.layout.footer, null);
               pur_list.addFooterView(footer, null, false)
               //Helper.getListViewSize(pur_list);

            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.


            if (savecli != "clicked") {


                   try {
                       var total = 0.0F
                       var igsttot = 0.0F
                       var cesstotals = 0.0F
                       var b = 2


                       for(i in 0 until receivedArray.size){

                           var v=receivedArray[i]
                           if(v.isNotEmpty()){
                               innoempty="inside"
                           }
                           else if(v.isEmpty()){

                           }
                       }


                       for (i in 0 until priceArray.count()) {



                            if(receivedArray[i].isNotEmpty()){

                               var c = (priceArray[i])
                               var cy = (receivedtaxtotalArray[i])
                               var cyz = (receivedcesstotArray[i])
                               var qyz = (receivedArray[i])

                               var cdec = c.toBigDecimal()
                               var qyzdec = qyz.toBigDecimal()
                               var totquanpri = (cdec * qyzdec)




                               total = total.plus(totquanpri.toInt())

                               igsttot = igsttot.plus(cy.toFloat())
                               cesstotals = cesstotals.plus(cyz.toFloat())

                               igst_tot.setText((String.format("%.2f", igsttot)))
                               var l = igst_tot.text.toString()
                               var ss = l.toBigDecimal()
                               var tt = ss / b.toBigDecimal()
                               cgst_tot.setText((String.format("%.2f", tt)))
                               sgst_tot.setText((String.format("%.2f", tt)))

                               cess_tot.setText((String.format("%.2f", cesstotals)))

                               var f = cesstotals
                               var g = igsttot

                               var op = total
                               var m = f.toFloat()
                               var n = g.toFloat()

                               var yy = m + n + op

                               try {
                                   gross_tot.setText((String.format("%.2f", yy)))
                               } catch (e: Exception) {
                                   gross_tot.setText((String.format("%.2f", yy)))
                               }


                               println("COUNT" + pronameArray.size)
                                recstat="Received"


                               if (pronameArray.size > 4) {


                                   img_arrow.visibility = View.VISIBLE

                               }


                               Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                               var d = pronameArray[i]
                               var t = d.removeSuffix("- ml")
                               prodnms.add(t)
                               names.setText((prodnms.toString()))
                               var u = names.text
                               var s = u.removePrefix("[")
                               var y = s.removeSuffix("]")
                               names.setText(y)

                               val asf = tallyArray.contains("InComplete")

                               val asfcomp = tallyArray.contains("Complete")

                               val asfpartcm = tallyArray.contains("Partially Complete")




                               println("TALLIEDDDD" + asf)
                               println("ARRRAY ITEEEMSSSS" + tallyArray)
                               if (asfpartcm) {

                                   purc_spinner2.setText("Partially Complete")
                                   purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                               } else if (asfcomp && (asfpartcm)) {

                                   purc_spinner2.setText("Partially Complete")
                                   purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                               } else if (!asf && (!asfpartcm) && asfcomp) {

                                   purc_spinner2.setText("Complete")
                                   purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                               } else if (asf && (asfcomp)) {
                                   purc_spinner2.setText("InComplete")
                                   purc_spinner2.setTextColor(resources.getColor(R.color.red))
                               } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                   purc_spinner2.setText("InComplete")
                                   purc_spinner2.setTextColor(resources.getColor(R.color.red))
                               }


                               println("TRIMED LIST NAMESSS" + (prodnms))

                               if (grosscheck == "") {

                               } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                   listListener = "listadded"
                               }
                           }
                           else if((receivedArray[i].isEmpty())&&(innoempty!="inside")){

                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (quantityArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }

                                catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f", yy)))
                                }


                                println("COUNT" + pronameArray.size)



                                if (pronameArray.size > 4) {


                                    img_arrow.visibility = View.VISIBLE

                                }


                                Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                var d = pronameArray[i]
                                var t = d.removeSuffix("- ml")
                                prodnms.add(t)
                                names.setText((prodnms.toString()))
                                var u = names.text
                                var s = u.removePrefix("[")
                                var y = s.removeSuffix("]")
                                names.setText(y)

                                val asf = tallyArray.contains("InComplete")

                                val asfcomp = tallyArray.contains("Complete")

                                val asfpartcm = tallyArray.contains("Partially Complete")




                                println("TALLIEDDDD" + asf)
                                println("ARRRAY ITEEEMSSSS" + tallyArray)
                                if (asfpartcm) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                } else if (asfcomp && (asfpartcm)) {

                                    purc_spinner2.setText("Partially Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                } else if (!asf && (!asfpartcm) && asfcomp) {

                                    purc_spinner2.setText("Complete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                } else if (asf && (asfcomp)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                    purc_spinner2.setText("InComplete")
                                    purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                }


                                println("TRIMED LIST NAMESSS" + (prodnms))

                                if (grosscheck == "") {

                                } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                    listListener = "listadded"
                                }

                            }
                       }
                   } catch (e: Exception) {
                       Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                   }
               }


           }




            else if(frm=="from_pdf")             //From pdf activity
        {



            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            /*   val dv=bundle!!.get("reprice") as Array<SListtring>*/
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val hvgro = bundle!!.get("regrosstotal") as ArrayList<String>

            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val idv = bundle!!.get("recgst") as ArrayList<String>
            val isv = bundle!!.get("resgst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            val rereceivepri = bundle!!.get("rereceived_pri") as ArrayList<String>
            val rereceivetot = bundle!!.get("rereceived_tot") as ArrayList<String>
            val rereceivetaxtot = bundle!!.get("rereceived_taxtot") as ArrayList<String>
            val rereceivecesstot = bundle!!.get("rereceived_cesstot") as ArrayList<String>
            val rereceivegrosstot = bundle!!.get("rereceived_grosstot") as ArrayList<String>
            val immv = bundle!!.get("reimmg") as ArrayList<String>
             val idpr = bundle!!.get("idpro") as ArrayList<String>


            ids= bundle!!.get("ids") as Array<String>
            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = hv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            grosstotArray = hvgro

            cessArray = gv
            keyArray = rekey
            igstArray = iv
            cgstArray = idv
            sgstArray = isv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            receivedpriceArray=rereceivepri
            receivedtaxtotalArray=rereceivetaxtot
            receivedcesstotArray=rereceivecesstot
            receivedgrosstotArray=rereceivegrosstot
            receivedtotalArray=rereceivetot
            imageArray = immv
            idproarray=idpr


            val uppono = intent.getStringExtra("pono")
            val orddtup = intent.getStringExtra("reorddate")
            val reqdtup = intent.getStringExtra("reestdt")
            val descup = intent.getStringExtra("redesc")
            val postatusup = intent.getStringExtra("restatus")
            val mainidup = intent.getStringExtra("reids")
            val prnmsup = intent.getStringExtra("names")
            val comnmup = intent.getStringExtra("titnm")
            val comphup = intent.getStringExtra("tiphone")
            val brnchidds = intent.getStringExtra("brids")
            val grosst = intent.getStringExtra("regross")
            val igstt = intent.getStringExtra("reigsts")
            val cgstt = intent.getStringExtra("recgsts")
            val sgstt = intent.getStringExtra("resgsts")
            val cesstt = intent.getStringExtra("recessts")

            //Purchase order
            branchids=brnchidds

            try {
                orddatedup = intent.getStringExtra("orddatedup")
                reqdatedup = intent.getStringExtra("reqdatedup")
                descripdup = intent.getStringExtra("descripdup")
            }
            catch (e:Exception){

            }

            try {
                descriplistener = intent.getStringExtra("descriplistener")
                listListener = intent.getStringExtra("listListener")

            }
            catch (e:Exception){

            }

            try{

                edclick=intent.getStringExtra("edclick")

            }
            catch (e:Exception){

            }
            if(edclick=="click"||edclick.isNotEmpty()){
                pur_list.isClickable=true
                edit.visibility = View.GONE
                pur_save.visibility = View.VISIBLE
                mnu.visibility=View.VISIBLE
                descrip.isEnabled = true
                fab.visibility=View.VISIBLE
                orddate.isEnabled=true
                reqdate.isEnabled=true
                descrip.isEnabled=true
            }
            else if(edclick.isEmpty()){
                pur_list.isClickable=false
                edit.visibility = View.VISIBLE
                pur_save.visibility = View.GONE
                mnu.visibility=View.GONE
                descrip.isEnabled = false
                fab.visibility=View.GONE
                orddate.isEnabled=false
                reqdate.isEnabled=false
                descrip.isEnabled=false
            }

            try{
                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            try{

                suppinv=intent.getStringExtra("suppinv")

            }
            catch (e:Exception){

            }

            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }




            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }






            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }



            pono.setText(uppono)
            orddate.setText(orddtup)
            reqdate.setText(reqdtup)
            descrip.setText(descup)
            listoids.setText(mainidup)
            names.setText(prnmsup)
            comttname.setText(comnmup)
            comphone.setText(comphup)


            igst_tot.setText((String.format("%.2f",igstt.toFloat())))

            cgst_tot.setText((String.format("%.2f",cgstt.toFloat())))

            sgst_tot.setText((String.format("%.2f",sgstt.toFloat())))

            cess_tot.setText((String.format("%.2f",cesstt.toFloat())))

            gross_tot.setText((String.format("%.2f",grosst.toFloat())))



            val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                    barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                    igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                    receivedgrosstotArray,receivedtotalArray,imageArray)
            pur_list.adapter = whatever

            val  footer = View.inflate(this,R.layout.footer, null);
            pur_list.addFooterView(footer,null,false)
            //Helper.getListViewSize(pur_list)






        }






            //FROM START LIST

        else if (frm == "startlist_pur")

        {                                       //Here we can view,edit,save the existing purchase order




            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }




            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }






        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }


            pur_save.visibility=View.INVISIBLE
            edit.visibility=View.VISIBLE
            mnu.visibility=View.GONE

            pur_list.isClickable=false



           fab.visibility=View.INVISIBLE



            pono.isEnabled=false
            orddate.isEnabled=false
            reqdate.isEnabled=false
           descrip.isEnabled=false




            val name = intent.getStringExtra("spnm")
            val sid=intent.getStringExtra("spid")
            val phone = intent.getStringExtra("spph")
            val date = intent.getStringExtra("date")
            val dates = intent.getStringExtra("estidate")
            val Stockids = intent.getStringExtra("reqids")
            val listids = intent.getStringExtra("listids")
            val brids = intent.getStringExtra("branchids")
            val descss = intent.getStringExtra("descss")

            try{
                suppinv=intent.getStringExtra("suppinv")
            }
            catch (e:Exception){

            }

            comttname.setText(name)
            comphone.setText(phone)
            pono.setText(Stockids)
            listoids.setText(listids)
            orddate.setText(date)
            reqdate.setText(dates)
            descrip.setText(descss)
            branchids=brids
            supplieridfr=sid

            orddatedup=date
            reqdatedup=dates
            descripdup=descss

            //Purchase order



            if(orddate.text.toString().equals("")){
                val c = Calendar.getInstance()
                System.out.println("Current time =&gt; " + c.time)

                val df = SimpleDateFormat("dd/MM/yyyy")
                val formattedDate = df.format(c.time)

                orddate.setText(formattedDate)
            }

        /*    db.collection("Purchase Orders").document(listoids.text.toString())
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result != null) {
                                Log.d("data", "is" + task.result.data)
                                received_price   =(task.result.get("received_price").toString())
                                received_total   =(task.result.get("received_total").toString())
                                received_grosstot=(task.result.get("received_grosstot").toString())
                                received_taxtot  =(task.result.get("received_taxtot").toString())
                                received_cesstot =(task.result.get("received_cesstot").toString())





                            } else {
                                Log.d("data", "is not here")
                            }
                        } else {
                            Log.d("task is not success", "full" + task.exception)
                        }

                    }
*/








            db.collection("${branchids}_Purchase Orders/${listoids.text}/purchase_products")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        if(value.isEmpty==false) {
                            for (document in value) {

                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                println(document.data)

                                var dt = document.data
                                var id = (document.id)
                                id = id
                                ids = ids.plusElement(id)
                                /*idsforup=ids*/
                                println("Heyyyyyyy" + Arrays.toString(ids))
                                println("HELLOOOOOOOOO" + id)
                                pronameArray.add(dt["stk_name"].toString())

                                manufacturerArray.add(dt["stk_mfr"].toString())
                                hsnArray.add(dt["stk_hsn"].toString())

                                quantityArray.add(dt["stk_received"].toString())

                                priceArray.add(dt["stk_price"].toString())
                                totArray.add(dt["stk_total"].toString())
                                grosstotArray.add(dt["stk_grosstotal"].toString())

                                barcodeArray.add(dt["stk_barcode"].toString())
                                cessArray.add(dt["stk_cess"].toString())
                                igstArray.add(dt["otherstk_igst"].toString())
                                cgstArray.add(dt["otherstk_cgst"].toString())
                                sgstArray.add(dt["otherstk_sgst"].toString())
                                igsttotArray.add(dt["otherstk_igsttotal"].toString())
                                cesstotalArray.add(dt["otherstk_cesstotal"].toString())
                                tallyArray.add(dt["otherstk_tally"].toString())
                                receivedArray.add(dt["otherstk_received"].toString())

                                receivedpriceArray.add(dt["received_price"].toString())
                               var grrt=(dt["received_taxtotal"].toString())
                                if(grrt=="00.00"){
                                    receivedtaxtotalArray.add("0.00")
                                }
                                else{
                                    receivedtaxtotalArray.add(grrt)
                                }

                                receivedcesstotArray.add(dt["received_cesstotal"].toString())
                                receivedgrosstotArray.add(dt["received_grosstotal"].toString())
                                receivedtotalArray.add(dt["received_total"].toString())
                                idproarray.add(dt["stk_prokey"].toString())
                                try {
                                    var im = (dt["otherstk_img"].toString())
                                    if (im.isNotEmpty()) {

                                        imageArray.add(im)
                                    } else {
                                        imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                    }
                                } catch (e: Exception) {

                                }

                                keyArray.add(id)

                                println("ID PRO LIST VALS"+idproarray)

                            }
                        }
                        else{

                        }

                        /*pronameArray.add("")
                        manufacturerArray.add("")
                        quantityArray.add("")
                        priceArray.add("")
                        hsnArray.add("")
                        barcodeArray.add("")
                        totArray.add("")
                        cessArray.add("")
                        keyArray.add("")
                        igstArray.add("")
                        cgstArray.add("")
                        sgstArray.add("")
                        igsttotArray.add("")
                        cesstotalArray.add("")
                        tallyArray.add("")
                        receivedArray.add("")
                        receivedpriceArray.add("")
                        receivedtaxtotalArray.add("")
                        receivedcesstotArray.add("")
                        receivedgrosstotArray.add("")
                        receivedtotalArray.add("")
                        imageArray.add("")*/

                        println("PRONAME ARRAY"+pronameArray)


                            val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray,
                                    barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, keyArray, igstArray, cgstArray, sgstArray,
                                    igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,
                                    receivedgrosstotArray,receivedtotalArray,imageArray)
                            pur_list.adapter = whatever

                            val footer = View.inflate(this, R.layout.footer, null);
                            pur_list.addFooterView(footer, null, false)
                            //Helper.getListViewSize(pur_list);
                            if (savecli != "clicked") {

                                try {
                                    var total = 0.0F
                                    var igsttot = 0.0F
                                    var cesstotals = 0.0F
                                    var b = 2

                                    for(i in 0 until receivedArray.size){

                                        var v=receivedArray[i]
                                        if(v.isNotEmpty()){
                                            innoemptystart="inside"
                                        }
                                        else if(v.isEmpty()){

                                        }
                                    }


                                    for (i in 0 until priceArray.count()) {

                                         if(receivedArray[i].isNotEmpty()){
                                            var c = (priceArray[i])
                                            var cy = (igsttotArray[i])
                                            var cyz = (cesstotalArray[i])
                                            var qyz = (receivedArray[i])

                                            var cdec = c.toBigDecimal()
                                            var qyzdec = qyz.toBigDecimal()
                                            var totquanpri = (cdec * qyzdec)




                                            total = total.plus(totquanpri.toInt())

                                            igsttot = igsttot.plus(cy.toFloat())
                                            cesstotals = cesstotals.plus(cyz.toFloat())

                                            igst_tot.setText((String.format("%.2f", igsttot)))
                                            var l = igst_tot.text.toString()
                                            var ss = l.toBigDecimal()
                                            var tt = ss / b.toBigDecimal()
                                            cgst_tot.setText((String.format("%.2f", tt)))
                                            sgst_tot.setText((String.format("%.2f", tt)))

                                            cess_tot.setText((String.format("%.2f", cesstotals)))

                                            var f = cesstotals
                                            var g = igsttot

                                            var op = total
                                            var m = f.toFloat()
                                            var n = g.toFloat()

                                            var yy = m + n + op

                                            try {
                                                gross_tot.setText((String.format("%.2f", yy)))
                                            } catch (e: Exception) {
                                                gross_tot.setText((String.format("%.2f", yy)))
                                            }

                                            recstat="Received"
                                            println("COUNT" + pronameArray.size)



                                            if (pronameArray.size > 4) {


                                                img_arrow.visibility = View.VISIBLE

                                            }


                                            Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                            var d = pronameArray[i]
                                            var t = d.removeSuffix("- ml")
                                            prodnms.add(t)
                                            names.setText((prodnms.toString()))
                                            var u = names.text
                                            var s = u.removePrefix("[")
                                            var y = s.removeSuffix("]")
                                            names.setText(y)

                                            val asf = tallyArray.contains("InComplete")

                                            val asfcomp = tallyArray.contains("Complete")

                                            val asfpartcm = tallyArray.contains("Partially Complete")




                                            println("TALLIEDDDD" + asf)
                                            println("ARRRAY ITEEEMSSSS" + tallyArray)
                                            if (asfpartcm) {

                                                purc_spinner2.setText("Partially Complete")
                                                purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                            } else if (asfcomp && (asfpartcm)) {

                                                purc_spinner2.setText("Partially Complete")
                                                purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                            } else if (!asf && (!asfpartcm) && asfcomp) {

                                                purc_spinner2.setText("Complete")
                                                purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                            } else if (asf && (asfcomp)) {
                                                purc_spinner2.setText("InComplete")
                                                purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                            } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                                purc_spinner2.setText("InComplete")
                                                purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                            }


                                            println("TRIMED LIST NAMESSS" + (prodnms))

                                            if (grosscheck == "") {

                                            } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                                listListener = "listadded"
                                            }
                                        }
                                        else if((receivedArray[i].isEmpty())&&(innoemptystart!="inside")) {
                                             var c = (priceArray[i])
                                             var cy = (igsttotArray[i])
                                             var cyz = (cesstotalArray[i])
                                             var qyz = (quantityArray[i])

                                             var cdec = c.toBigDecimal()
                                             var qyzdec = qyz.toBigDecimal()
                                             var totquanpri = (cdec * qyzdec)




                                             total = total.plus(totquanpri.toInt())

                                             igsttot = igsttot.plus(cy.toFloat())
                                             cesstotals = cesstotals.plus(cyz.toFloat())

                                             igst_tot.setText((String.format("%.2f", igsttot)))
                                             var l = igst_tot.text.toString()
                                             var ss = l.toBigDecimal()
                                             var tt = ss / b.toBigDecimal()
                                             cgst_tot.setText((String.format("%.2f", tt)))
                                             sgst_tot.setText((String.format("%.2f", tt)))

                                             cess_tot.setText((String.format("%.2f", cesstotals)))

                                             var f = cesstotals
                                             var g = igsttot

                                             var op = total
                                             var m = f.toFloat()
                                             var n = g.toFloat()

                                             var yy = m + n + op

                                             try {
                                                 gross_tot.setText((String.format("%.2f", yy)))
                                             } catch (e: Exception) {
                                                 gross_tot.setText((String.format("%.2f", yy)))
                                             }


                                             println("COUNT" + pronameArray.size)



                                             if (pronameArray.size > 4) {


                                                 img_arrow.visibility = View.VISIBLE

                                             }


                                             Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                                             var d = pronameArray[i]
                                             var t = d.removeSuffix("- ml")
                                             prodnms.add(t)
                                             names.setText((prodnms.toString()))
                                             var u = names.text
                                             var s = u.removePrefix("[")
                                             var y = s.removeSuffix("]")
                                             names.setText(y)

                                             val asf = tallyArray.contains("InComplete")

                                             val asfcomp = tallyArray.contains("Complete")

                                             val asfpartcm = tallyArray.contains("Partially Complete")




                                             println("TALLIEDDDD" + asf)
                                             println("ARRRAY ITEEEMSSSS" + tallyArray)
                                             if (asfpartcm) {

                                                 purc_spinner2.setText("Partially Complete")
                                                 purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))


                                             } else if (asfcomp && (asfpartcm)) {

                                                 purc_spinner2.setText("Partially Complete")
                                                 purc_spinner2.setTextColor(resources.getColor(R.color.partiallycomp))

                                             } else if (!asf && (!asfpartcm) && asfcomp) {

                                                 purc_spinner2.setText("Complete")
                                                 purc_spinner2.setTextColor(resources.getColor(R.color.ok))

                                             } else if (asf && (asfcomp)) {
                                                 purc_spinner2.setText("InComplete")
                                                 purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                             } else if ((!asfcomp) && (!asfpartcm) && (asf)) {
                                                 purc_spinner2.setText("InComplete")
                                                 purc_spinner2.setTextColor(resources.getColor(R.color.red))
                                             }


                                             println("TRIMED LIST NAMESSS" + (prodnms))

                                             if (grosscheck == "") {

                                             } else if ((grosscheck != gross_tot.text.toString()) && (grosscheck != "")) {
                                                 listListener = "listadded"
                                             }
                                         }
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                                }
                            }






                       /* } catch (e: Exception) {

                        }*/


                    })








        }

descrip.addTextChangedListener(object : TextWatcher {

    override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {




    }

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
    }

    override fun afterTextChanged(s: Editable) {


    }
})

        reqdate.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {



            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })




        //Navigate to add product lists (product_list_activity(purchase))

        fab.setOnClickListener {

            if ((priceArray.size == 0)&&(addpurord=="true")) {

                val intent = Intent(this, product_list_activity_pur::class.java)
                intent.putExtra("from_pur", "emptylist")
                intent.putExtra("branch", nameofbrnch)
                intent.putExtra("address", locofbrnch)
                intent.putExtra("sstkdate",datestk)
                intent.putExtra("ssstockid",stkidstock)
                intent.putExtra("ssstkdesc",descstk)
                intent.putExtra("idofdb",ididdb)
                intent.putExtra("brnchid",keyofbrnch)
                intent.putExtra("supplieridfr",supplieridfr)
                intent.putExtra("reprnms", names.text.toString())
                intent.putExtra("nms", comttname.text.toString())
                intent.putExtra("ph", comphone.text.toString())
                intent.putExtra("pono", pono.text.toString())
                intent.putExtra("orddate", orddate.text.toString())
                intent.putExtra("desc", descrip.text.toString())
                intent.putExtra("reqdate", reqdate.text.toString())
                intent.putExtra("reqliid", listoids.text.toString())
                intent.putExtra("brids",branchids)
                intent.putExtra("edclick",edclick)


                intent.putExtra("suppinv",suppinv)
                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)


                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)




                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)




                intent.putExtra("grosschk",gross_tot.text.toString())
                intent.putExtra("descriplistener",descriplistener)
                intent.putExtra("listListener",listListener)

                intent.putExtra("orddatedup",orddatedup)
                intent.putExtra("reqdatedup",reqdatedup)
                intent.putExtra("descripdup",descripdup)





                println(nameofbrnch)

                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

                finish()
            }
            else if((priceArray.size != 0)&&(addpurord=="true")) {
                println(priceArray.size)
                println(pronameArray)
                println(priceArray)
                val intent = Intent(this, product_list_activity_pur::class.java)
                intent.putExtra("from_pur", "pur_datalist")
                intent.putExtra("namess", pronameArray)
                intent.putExtra("orderarray", manufacturerArray)
                intent.putExtra("hsn", hsnArray)
                intent.putExtra("poarray", barcodeArray)
                intent.putExtra("complete", quantityArray)
                intent.putExtra("price", priceArray)
                intent.putExtra("total", totArray)
                intent.putExtra("grosstotal", grosstotArray)
                intent.putExtra("supplieridfr",supplieridfr)
                intent.putExtra("suppinv",suppinv)
                intent.putExtra("edclick",edclick)

                intent.putExtra("cess", cessArray)
                intent.putExtra("igst", igstArray)
                intent.putExtra("cgst", cgstArray)
                intent.putExtra("sgst", sgstArray)
                intent.putExtra("igsttotal", igsttotArray)
                intent.putExtra("cesstotarray", cesstotalArray)
                intent.putExtra("tallyarray", tallyArray)
                intent.putExtra("receivedarray", receivedArray)
                intent.putExtra("receivedarray_pri", receivedpriceArray)
                intent.putExtra("receivedarray_taxtot", receivedtaxtotalArray)
                intent.putExtra("receivedarray_tot", receivedtotalArray)
                intent.putExtra("receivedarray_cesstot", receivedcesstotArray)
                intent.putExtra("receivedarray_grosstot", receivedgrosstotArray)
                intent.putExtra("im", imageArray)
                intent.putExtra("idpro", idproarray)
                intent.putExtra("branch", nameofbrnch)
                intent.putExtra("address", locofbrnch)
                intent.putExtra("sstkdate", datestk)
                intent.putExtra("ssstockid", stkidstock)
                intent.putExtra("ssstkdesc", descstk)
                intent.putExtra("idofdb", ididdb)
                intent.putExtra("brnchid", keyofbrnch)
                intent.putExtra("idsofli", keyArray)
                intent.putExtra("reprnms", names.text.toString())
                intent.putExtra("nms", comttname.text.toString())
                intent.putExtra("ph", comphone.text.toString())
                intent.putExtra("pono", pono.text.toString())
                intent.putExtra("orddate", orddate.text.toString())
                intent.putExtra("desc", descrip.text.toString())
                intent.putExtra("reqdate", reqdate.text.toString())
                intent.putExtra("reqliid", listoids.text.toString())
                intent.putExtra("brids", branchids)
                intent.putExtra("grosschk",gross_tot.text.toString())

                intent.putExtra("viewsuppin", viewsuppin)
                intent.putExtra("addsuppin", addsuppin)
                intent.putExtra("deletesuppin", deletesuppin)
                intent.putExtra("editsuppin", editesuppin)
                intent.putExtra("transfersuppin", transfersuppin)
                intent.putExtra("exportsuppin", exportsuppin)
                intent.putExtra("descriplistener",descriplistener)
                intent.putExtra("listListener",listListener)

                intent.putExtra("viewpurord", viewpurord)
                intent.putExtra("addpurord", addpurord)
                intent.putExtra("deletepurord", deletepurord)
                intent.putExtra("editpurord", editepurord)
                intent.putExtra("transferpurord", transferpurord)
                intent.putExtra("exportpurord", exportpurord)
                intent.putExtra("sendpurord", sendpurpo)



                intent.putExtra("orddatedup",orddatedup)
                intent.putExtra("reqdatedup",reqdatedup)
                intent.putExtra("descripdup",descripdup)

                intent.putExtra("viewpurreq", viewpurreq)
                intent.putExtra("addpurreq", addpurreq)
                intent.putExtra("deletepurreq", deletepurreq)
                intent.putExtra("editpurreq", editepurreq)
                intent.putExtra("transferpurreq", transferpurreq)
                intent.putExtra("exportpurreq", exportpurreq)



                intent.putExtra("ids",ids)


                /* intent.putExtra("postatus",purc_spinner2.selectedItem.toString())*/
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

                finish()


            }
            else{
                popup("Add")
            }
        }



        //----------------------------------------SAVE ACTION -------------------------//

        pur_save.setOnClickListener { views ->

            if(net_status()==true) {
                savecli="clicked"
                if (transferpurord == "true") {

                    if((orddatedup!=orddate.text.toString())||(reqdatedup!=reqdate.text.toString())||(descripdup!=descrip.text.toString())){

                        descriplistener="descchanged"

                    }

                    /* if(listoids.text=="") {
                pur_save_prgrs.visibility = android.view.View.VISIBLE
                onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray,igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray)

            }*/

                    var db = FirebaseFirestore.getInstance()
                    var refid = listoids.text.toString()
                    println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                    var path = "${branchids}_Purchase Orders/$refid/purchase_products"
                    println(Arrays.toString(ids))


                    if((descriplistener=="descchanged")&&(listListener!="listadded")) {
                        try {
                            pDialogs = SweetAlertDialog(this@PurcathirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();
                        }
                        catch (e:Exception){

                        }
                        val map = mutableMapOf<String, Any?>()
                        map.put("ponumber", (pono.text).toString())
                        map.put("order_date", (orddate.text).toString())
                        map.put("description", (descrip.text).toString())
                        map.put("req_estimated", (reqdate.text).toString())
                        map.put("igst_tot", (igst_tot.text).toString())
                        map.put("cgst_tot", (cgst_tot.text).toString())
                        map.put("sgst_tot", (sgst_tot.text).toString())
                        map.put("cess_tot", (cess_tot.text).toString())
                        map.put("gross_tot", (gross_tot.text).toString())
                        map.put("stk_brid", (listoids.text).toString())
                        map.put("postatus", purc_spinner2.text.toString())
                        map.put("supp_invoice",suppinv)
                        map.put("prod_nms", names.text.toString())
                        map.put("recstatus", recstat)
                        db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                .update(map)
                                .addOnCompleteListener {
                                    try {
                                        pDialogs!!.dismiss()
                                    }
                                    catch (e:Exception){

                                    }

                                    val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                    u.putExtra("from_ver", "main")
                                    u.putExtra("viewsuppin", viewsuppin)
                                    u.putExtra("addsuppin", addsuppin)
                                    u.putExtra("deletesuppin", deletesuppin)
                                    u.putExtra("editsuppin", editesuppin)
                                    u.putExtra("transfersuppin", transfersuppin)
                                    u.putExtra("exportsuppin", exportsuppin)


                                    u.putExtra("viewpurord", viewpurord)
                                    u.putExtra("addpurord", addpurord)
                                    u.putExtra("deletepurord", deletepurord)
                                    u.putExtra("editpurord", editepurord)
                                    u.putExtra("transferpurord", transferpurord)
                                    u.putExtra("exportpurord", exportpurord)
                                    u.putExtra("sendpurord", sendpurpo)




                                    u.putExtra("viewpurreq", viewpurreq)
                                    u.putExtra("addpurreq", addpurreq)
                                    u.putExtra("deletepurreq", deletepurreq)
                                    u.putExtra("editpurreq", editepurreq)
                                    u.putExtra("transferpurreq", transferpurreq)
                                    u.putExtra("exportpurreq", exportpurreq)


                                    u.putExtra("brkey", branchids)
                                    startActivity(u)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                    finish()
                                }
                    }
                    else if((descriplistener!="descchanged")&&(listListener=="listadded")) {

                        val map = mutableMapOf<String, Any?>()
                        map.put("igst_tot", (igst_tot.text).toString())
                        map.put("cgst_tot", (cgst_tot.text).toString())
                        map.put("sgst_tot", (sgst_tot.text).toString())
                        map.put("cess_tot", (cess_tot.text).toString())
                        map.put("gross_tot", (gross_tot.text).toString())
                        map.put("prod_nms", names.text.toString())
                        map.put("supp_invoice",suppinv)

                        map.put("postatus", purc_spinner2.text.toString())
                        map.put("recstatus", recstat)
                        try {
                            pDialogs = SweetAlertDialog(this@PurcathirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();
                        }
                        catch (e:Exception){

                        }

                        for (m in 0 until ids.size) {
                            db.collection(path).document(ids[m].toString())
                                    .delete()
                                    .addOnCompleteListener {

                                    }
                        }

                        /*var receive_path="Receive Stock/$refid/Received stock items"*/
                                        for (i in 0 until priceArray.size) {
                                            var stk_name = pronameArray[i]
                                            var stk_mfr = manufacturerArray[i]
                                            var stk_hsn = hsnArray[i]
                                            var stk_bcode = barcodeArray[i]
                                            var stk_quan = quantityArray[i]
                                            var stk_pri = priceArray[i]
                                            var stk_tot = totArray[i]
                                            var stk_grosstot = grosstotArray[i]

                                            var stk_cess = cessArray[i]
                                            var stk_igst = igstArray[i]
                                            var stk_cgst = cgstArray[i]
                                            var stk_sgst = sgstArray[i]
                                            var stk_igsttot = igsttotArray[i]
                                            var stk_cesstot = cesstotalArray[i]
                                            var stk_tally = tallyArray[i]
                                            var stk_received = receivedArray[i]
                                            var stk_receivedpri = receivedpriceArray[i]
                                            var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                            var stk_receivedcesstot = receivedcesstotArray[i]
                                            var stk_receivedgrosstot = receivedgrosstotArray[i]
                                            var stk_receivedtot = receivedtotalArray[i]
                                            var stk_key = keyArray[i]
                                            var img_ar = imageArray[i]
                                            var idpro_ar = idproarray[i]


                                            var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                                                    stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                                                    otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                                                    otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri,
                                                    received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot,
                                                    received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = img_ar, stk_prokey = idpro_ar)
                                            db.collection(path)
                                                    .add(d)
                                                    .addOnSuccessListener { documentReference ->

                                                        db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                                                .update(map)

                                                        Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                        var refid = documentReference.id

                                                        Toast.makeText(applicationContext, "Saved", Toast.LENGTH_SHORT).show()

                                                        /*db.collection(receive_path).document(refid)
                                                                .set(d)*/
                                                    }
                                        }

                        Handler().postDelayed(Runnable {
                            try{
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception){

                            }

                                        //BAck action

                                        val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                        u.putExtra("from_ver", "main")
                                        u.putExtra("viewsuppin", viewsuppin)
                                        u.putExtra("addsuppin", addsuppin)
                                        u.putExtra("deletesuppin", deletesuppin)
                                        u.putExtra("editsuppin", editesuppin)
                                        u.putExtra("transfersuppin", transfersuppin)
                                        u.putExtra("exportsuppin", exportsuppin)


                                        u.putExtra("viewpurord", viewpurord)
                                        u.putExtra("addpurord", addpurord)
                                        u.putExtra("deletepurord", deletepurord)
                                        u.putExtra("editpurord", editepurord)
                                        u.putExtra("transferpurord", transferpurord)
                                        u.putExtra("exportpurord", exportpurord)
                                        u.putExtra("sendpurord", sendpurpo)




                                        u.putExtra("viewpurreq", viewpurreq)
                                        u.putExtra("addpurreq", addpurreq)
                                        u.putExtra("deletepurreq", deletepurreq)
                                        u.putExtra("editpurreq", editepurreq)
                                        u.putExtra("transferpurreq", transferpurreq)
                                        u.putExtra("exportpurreq", exportpurreq)


                                        u.putExtra("brkey", branchids)
                                        startActivity(u)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()
                             },2000)
                                    }



                    else if((descriplistener=="descchanged")&&(listListener=="listadded")) {
                        try{
                            pDialogs = SweetAlertDialog(this@PurcathirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();
                        }
                        catch (e:Exception){

                        }


                        val map = mutableMapOf<String, Any?>()
                        map.put("ponumber", (pono.text).toString())
                        map.put("order_date", (orddate.text).toString())
                        map.put("description", (descrip.text).toString())
                        map.put("req_estimated", (reqdate.text).toString())
                        map.put("igst_tot", (igst_tot.text).toString())
                        map.put("cgst_tot", (cgst_tot.text).toString())
                        map.put("sgst_tot", (sgst_tot.text).toString())
                        map.put("cess_tot", (cess_tot.text).toString())
                        map.put("gross_tot", (gross_tot.text).toString())
                        map.put("stk_brid", (listoids.text).toString())
                        map.put("postatus", purc_spinner2.text.toString())
                        map.put("recstatus", recstat)
                        map.put("prod_nms", names.text.toString())
                        map.put("supp_invoice",suppinv)

                        db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                .update(map)
                                .addOnCompleteListener {
                                    for (m in 0 until ids.size) {
                                        db.collection(path).document(ids[m].toString())
                                                .delete()
                                                .addOnCompleteListener {

                                                }
                                    }
                                }

                                .addOnSuccessListener {


                                    /*var receive_path="Receive Stock/$refid/Received stock items"*/
                                    for (i in 0 until priceArray.size) {
                                        var stk_name = pronameArray[i]
                                        var stk_mfr = manufacturerArray[i]
                                        var stk_hsn = hsnArray[i]
                                        var stk_bcode = barcodeArray[i]
                                        var stk_quan = quantityArray[i]
                                        var stk_pri = priceArray[i]
                                        var stk_tot = totArray[i]
                                        var stk_grosstot = grosstotArray[i]

                                        var stk_cess = cessArray[i]
                                        var stk_igst = igstArray[i]
                                        var stk_cgst = cgstArray[i]
                                        var stk_sgst = sgstArray[i]
                                        var stk_igsttot = igsttotArray[i]
                                        var stk_cesstot = cesstotalArray[i]
                                        var stk_tally = tallyArray[i]
                                        var stk_received = receivedArray[i]
                                        var stk_receivedpri = receivedpriceArray[i]
                                        var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                        var stk_receivedcesstot = receivedcesstotArray[i]
                                        var stk_receivedgrosstot = receivedgrosstotArray[i]
                                        var stk_receivedtot = receivedtotalArray[i]
                                        var stk_key = keyArray[i]
                                        var img_ar = imageArray[i]
                                        var idpro_ar = idproarray[i]


                                        var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                                                stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                                                otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                                                otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri,
                                                received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot,
                                                received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = img_ar, stk_prokey = idpro_ar)
                                        db.collection(path)
                                                .add(d)
                                                .addOnSuccessListener { documentReference ->

                                                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                    var refid = documentReference.id

                                                    Toast.makeText(applicationContext, "Saved", Toast.LENGTH_SHORT).show()

                                                    /*db.collection(receive_path).document(refid)
                                                            .set(d)*/
                                                }
                                    }
                                    Handler().postDelayed(Runnable {
try {
    pDialogs!!.dismiss()
}
catch (e:Exception){

}

                                        val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                        u.putExtra("from_ver", "main")
                                        u.putExtra("viewsuppin", viewsuppin)
                                        u.putExtra("addsuppin", addsuppin)
                                        u.putExtra("deletesuppin", deletesuppin)
                                        u.putExtra("editsuppin", editesuppin)
                                        u.putExtra("transfersuppin", transfersuppin)
                                        u.putExtra("exportsuppin", exportsuppin)


                                        u.putExtra("viewpurord", viewpurord)
                                        u.putExtra("addpurord", addpurord)
                                        u.putExtra("deletepurord", deletepurord)
                                        u.putExtra("editpurord", editepurord)
                                        u.putExtra("transferpurord", transferpurord)
                                        u.putExtra("exportpurord", exportpurord)
                                        u.putExtra("sendpurord", sendpurpo)




                                        u.putExtra("viewpurreq", viewpurreq)
                                        u.putExtra("addpurreq", addpurreq)
                                        u.putExtra("deletepurreq", deletepurreq)
                                        u.putExtra("editpurreq", editepurreq)
                                        u.putExtra("transferpurreq", transferpurreq)
                                        u.putExtra("exportpurreq", exportpurreq)


                                        u.putExtra("brkey", branchids)
                                        startActivity(u)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()
                                    }, 2000)
                                }
                    }
                    else if((descriplistener.isEmpty())&&(listListener.isEmpty())){

                        Toast.makeText(applicationContext,"No changes happened for save",Toast.LENGTH_SHORT).show()

                    }


                    /*  var pono = (pono.text).toString()
                var order_date = (orddate.text).toString()
                var po_Desc = (descrip.text).toString()
                var poreqby=(reqdate.text).toString()
               var igsttot = (igst_tot.text).toString()
              var cgsttot = (cgst_tot.text).toString()
              var sgsttot = (sgst_tot.text).toString()
              var cesstot = (cess_tot.text).toString()
              var grosstot = (gross_tot.text).toString()
                var brid=(listoids.text).toString()
                var postatus="Incomplete"*/

                    /*val data = s(ponumber = pono, order_date = order_date, description = po_Desc,required_date=poreqby,IGST_tot = igsttot,CGST_tot = cgsttot,SGST_tot = sgsttot,Cess_tot = cesstot,Gross_tot =grosstot,stk_brid = brid,postatus = postatus)*/



                } else if (transferpurord == "false") {
                    popup("Purchase order")
                }
            }
            else{

            }
        }










        //Navigate  list items  to edit activity (Purchase_orderMainActivity)

        pur_list.setOnItemClickListener { parent, views, position, id ->







                val b = Intent(applicationContext, Purchase_orderMainActivity::class.java)

                b.putExtra("from_pur", "update_pur")
                b.putExtra("pnm", pronameArray)
                b.putExtra("pmanu", manufacturerArray)
                b.putExtra("phsn", hsnArray)
                b.putExtra("barcode", barcodeArray)
                b.putExtra("price", priceArray)
                b.putExtra("quan", quantityArray)
                b.putExtra("tot", totArray)
                b.putExtra("grosstot", grosstotArray)
                b.putExtra("suppinv",suppinv)

                b.putExtra("pos", position)
                b.putExtra("supplieridfr",supplieridfr)

                b.putExtra("cessup", cessArray)
                b.putExtra("igst", igstArray)
                b.putExtra("cgst", cgstArray)
                b.putExtra("sgst", sgstArray)
                b.putExtra("igsttotal", igsttotArray)
                b.putExtra("cesstotarray", cesstotalArray)
                b.putExtra("tallyarray", tallyArray)
                b.putExtra("receivedarray", receivedArray)
                b.putExtra("received_price", receivedpriceArray)
                b.putExtra("received_total", receivedtotalArray)
                b.putExtra("received_taxtot", receivedtaxtotalArray)
                b.putExtra("received_cesstot", receivedcesstotArray)
                b.putExtra("received_grosstot", receivedgrosstotArray)
                b.putExtra("idsofli", keyArray)
                b.putExtra("smlistids", smlistids)
                b.putExtra("image", imageArray)
                b.putExtra("idpro", idproarray)
                b.putExtra("reprnms", names.text.toString())
                b.putExtra("reqliid", listoids.text.toString())
                b.putExtra("nms", comttname.text.toString())
                b.putExtra("ph", comphone.text.toString())
                b.putExtra("pono", pono.text.toString())
                b.putExtra("orddate", orddate.text.toString())
                b.putExtra("desc", descrip.text.toString())
                b.putExtra("reqdate", reqdate.text.toString())
                b.putExtra("postatus", purc_spinner2.text.toString())
                b.putExtra("brids", branchids)
                b.putExtra("groschk", grosscheck)

                b.putExtra("viewsuppin", viewsuppin)
                b.putExtra("addsuppin", addsuppin)
                b.putExtra("deletesuppin", deletesuppin)
                b.putExtra("editsuppin", editesuppin)
                b.putExtra("transfersuppin", transfersuppin)
                b.putExtra("exportsuppin", exportsuppin)

                b.putExtra("descriplistener",descriplistener)
                b.putExtra("listListener",listListener)
                b.putExtra("viewpurord", viewpurord)
                b.putExtra("addpurord", addpurord)
                b.putExtra("deletepurord", deletepurord)
                b.putExtra("editpurord", editepurord)
                b.putExtra("transferpurord", transferpurord)
                b.putExtra("exportpurord", exportpurord)
                b.putExtra("sendpurord", sendpurpo)


               b.putExtra("orddatedup",orddatedup)
               b.putExtra("reqdatedup",reqdatedup)
               b.putExtra("descripdup",descripdup)

                b.putExtra("edclick",edclick)

                b.putExtra("viewpurreq", viewpurreq)
                b.putExtra("addpurreq", addpurreq)
                b.putExtra("deletepurreq", deletepurreq)
                b.putExtra("editpurreq", editepurreq)
                b.putExtra("transferpurreq", transferpurreq)
                b.putExtra("exportpurreq", exportpurreq)



                b.putExtra("ids", ids)



                startActivity(b)
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)

                finish()

        }


             /*   val categories = ArrayList<String>()
                categories.add("PO Status")

                val dataAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                purc_spinner2.adapter = dataAdapter*/


                igst.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                        igst.isEnabled == true
                        cgst.isEnabled = true
                        sgst.isEnabled = true
                    }

                    override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                        cgst.isEnabled = false
                        sgst.isEnabled = false
                        cgst.setHintTextColor(Color.parseColor("#99546e7a"))
                        sgst.setHintTextColor(Color.parseColor("#99546e7a"))
                        sgst_tot.setTextColor(Color.parseColor("#994d4d4d"))
                        cgst_tot.setTextColor(Color.parseColor("#994d4d4d"))
                        sgst_tot_te.setTextColor(Color.parseColor("#994d4d4d"))
                        cgst_tot_te.setTextColor(Color.parseColor("#994d4d4d"))
                    }

                    override fun afterTextChanged(s: Editable?) {
                        if (s != null) {
                            if (s.length == 0) {
                                igst.isEnabled == true
                                cgst.isEnabled = true
                                sgst.isEnabled = true
                                cgst.setHintTextColor(Color.parseColor("#546e7a"))
                                sgst.setHintTextColor(Color.parseColor("#546e7a"))
                                sgst_tot.setTextColor(Color.parseColor("#4d4d4d"))
                                cgst_tot.setTextColor(Color.parseColor("#4d4d4d"))
                                sgst_tot_te.setTextColor(Color.parseColor("#4d4d4d"))
                                cgst_tot_te.setTextColor(Color.parseColor("#4d4d4d"))
                            }
                        }
                    }
                })
                sgst.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                        igst.isEnabled == true
                        cgst.isEnabled = true
                        sgst.isEnabled = true
                    }

                    override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                        igst.isEnabled = false
                        igst.setHintTextColor(Color.parseColor("#99546e7a"))
                        igst_tot.setTextColor(Color.parseColor("#994d4d4d"))
                        igst_tot_te.setTextColor(Color.parseColor("#994d4d4d"))
                    }

                    override fun afterTextChanged(s: Editable?) {
                        if (s != null) {
                            if (s.length == 0) {
                                igst.isEnabled = true
                                igst.setHintTextColor(Color.parseColor("#546e7a"))
                                igst_tot.setTextColor(Color.parseColor("#4d4d4d"))
                                igst_tot_te.setTextColor(Color.parseColor("#4d4d4d"))
                            }
                        }
                    }
                })
                cgst.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                        igst.isEnabled == true
                        cgst.isEnabled = true
                        sgst.isEnabled = true
                    }

                    override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                        igst.isEnabled = false
                        igst.setHintTextColor(Color.parseColor("#99546e7a"))
                        igst_tot.setTextColor(Color.parseColor("#994d4d4d"))
                        igst_tot_te.setTextColor(Color.parseColor("#994d4d4d"))
                    }

                    override fun afterTextChanged(s: Editable?) {
                        if (s != null) {
                            if (s.length == 0) {
                                igst.isEnabled = true
                                igst.setHintTextColor(Color.parseColor("#546e7a"))
                                igst_tot.setTextColor(Color.parseColor("#4d4d4d"))
                                igst_tot_te.setTextColor(Color.parseColor("#4d4d4d"))
                            }
                        }
                    }
                })


        userback.setOnClickListener {
            onBackPressed()
        }

        mnu.setOnClickListener({   //Menu contains two options 'Send this PO' , 'Export as Pdf'.


            val popup = PopupMenu(this@PurcathirdMainActivity, mnu)

            popup.menuInflater.inflate(R.menu.purchase_orderpo, popup.menu)

            popup.setOnMenuItemClickListener { item ->

                if(item.title=="Send this PO"){   //Clicked 'Send this PO'

                    if((exportpurord=="true")&&(net_status()==true)) {

                        if(priceArray.isNotEmpty()==true) {





                            var totalpdf = 0.0F
                            var igsttotpdf = 0.0F
                            var cesstotalspdf = 0.0F
                            var bpdf = 2
                            for (i in 0 until priceArray.count()) {


                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (receivedArray[i])

                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                totalpdf = totalpdf.plus(totquanpri.toInt())

                                igsttotpdf = igsttotpdf.plus(cy.toFloat())
                                cesstotalspdf = cesstotalspdf.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f", igsttotpdf)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / bpdf.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f", tt)))
                                sgst_tot.setText((String.format("%.2f", tt)))

                                cess_tot.setText((String.format("%.2f", cesstotalspdf)))

                                var f = cesstotalspdf
                                var g = igsttotpdf

                                var op = totalpdf
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    pdfgross.setText((String.format("%.2f", yy)))
                                } catch (e: Exception) {
                                    pdfgross.setText((String.format("%.2f", yy)))
                                }
                            }
                        }


                        //Make purchase order details to pdf document.

                        createandDisplayPdf(comttname.text.toString(), comphone.text.toString(), pono.text.toString(), orddate.text.toString(), descrip.text.toString(),reqdate.text.toString(),igst_tot.text.toString(),cgst_tot.text.toString(),sgst_tot.text.toString(),cess_tot.text.toString(),pdfgross.text.toString())

                        var fs = pono.text.toString()

                        var c = comttname.text.toString()
                        var y = fs + ".pdf"
                        println("GET URI FROM STORAGE" + y)
                        val share = Intent(Intent.ACTION_SEND)
                        share.type = "application/pdf"

                        pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order" + "/" + y).toString()


                        /* imageToPDF()*/
                        val fz = dirpath + "/NewPDF.pdf"
                        println()
                        val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
                        try {

                            sendMail(pdfFile) //And send that pdf document using this 'ACTION_SEND'


                        } catch (e: IOException) {
                            Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        if(net_status()==false){
                            Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                        }
                        else {
                            popup("Send")
                        }
                    }

                    return@setOnMenuItemClickListener true


                    // View v1 = iv.getRootView(); //even this works
                    // View v1 = findViewById(android.R.id.content); //this works too
                    // but gives only content
                    /*   var myBitmap: Bitmap? = null
                       v1.isDrawingCacheEnabled = true
                       myBitmap = v1.drawingCache
                       saveBitmap(myBitmap)*/

                }
                else if(item.title=="Export as pdf"){           //Navigate  to pdf activity with details. (purchasepdf)

                    if((exportpurord=="true")&&(net_status()==true)) {

                        pdfnav()
                    }
                    else{
                        if(net_status()==false){
                            Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                        }
                        else{
                            popup("Export")

                        }
                    }

                    return@setOnMenuItemClickListener true
                }
                true
            }

            popup.show()

        })
            }

    override fun onBackPressed() {

        println("DSCLISTENER"+descriplistener)
        println("Listlistener"+listListener)
        if((orddatedup!=orddate.text.toString())||(reqdatedup!=reqdate.text.toString())||(descripdup!=descrip.text.toString())){

            descriplistener="descchanged"

        }


        if((listListener=="listadded")||(deletelistener=="listdelete")||(descriplistener=="descchanged")){

            savepopup()

        }
        else if((listListener.isEmpty())&&(descriplistener.isEmpty())){
            val u=Intent(this@PurcathirdMainActivity,MainPurchaselist_secondActivity::class.java)
            u.putExtra("from_ver","main")
          u.putExtra("viewsuppin", viewsuppin)
          u.putExtra("addsuppin", addsuppin)
          u.putExtra("deletesuppin", deletesuppin)
          u.putExtra("editsuppin", editesuppin)
          u.putExtra("transfersuppin", transfersuppin)
          u.putExtra("exportsuppin", exportsuppin)


          u.putExtra("viewpurord", viewpurord)
          u.putExtra("addpurord", addpurord)
          u.putExtra("deletepurord", deletepurord)
           u.putExtra("editpurord", editepurord)
           u.putExtra("transferpurord", transferpurord)
           u.putExtra("exportpurord", exportpurord)
           u.putExtra("sendpurord", sendpurpo)




           u.putExtra("viewpurreq", viewpurreq)
           u.putExtra("addpurreq", addpurreq)
           u.putExtra("deletepurreq", deletepurreq)
           u.putExtra("editpurreq", editepurreq)
           u.putExtra("transferpurreq", transferpurreq)
           u.putExtra("exportpurreq", exportpurreq)


            u.putExtra("brkey",branchids)
            startActivity(u)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
        }
    }



    fun savepopup() {     // save popup

        val builder = AlertDialog.Builder(this@PurcathirdMainActivity)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->

                if(net_status()==true) {
                    savecli="clicked"
                    if (transferpurord == "true") {
try {
    pDialogs = SweetAlertDialog(this@PurcathirdMainActivity, SweetAlertDialog.PROGRESS_TYPE);
    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
    pDialogs!!.setTitleText("Saving...");
    pDialogs!!.setCancelable(false);
    pDialogs!!.show();
}
catch (e:Exception){

}
                        /* if(listoids.text=="") {
                    pur_save_prgrs.visibility = android.view.View.VISIBLE
                    onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray,igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray)

                }*/



                        //Save purchase order

                        var db = FirebaseFirestore.getInstance()
                        var refid = listoids.text.toString()
                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                        var path = "${branchids}_Purchase Orders/$refid/purchase_products"
                        println(Arrays.toString(ids))


                        if((descriplistener=="descchanged")&&(listListener!="listadded")) {
                            val map = mutableMapOf<String, Any?>()
                            map.put("ponumber", (pono.text).toString())
                            map.put("order_date", (orddate.text).toString())
                            map.put("description", (descrip.text).toString())
                            map.put("req_estimated", (reqdate.text).toString())
                            map.put("igst_tot", (igst_tot.text).toString())
                            map.put("cgst_tot", (cgst_tot.text).toString())
                            map.put("sgst_tot", (sgst_tot.text).toString())
                            map.put("cess_tot", (cess_tot.text).toString())
                            map.put("gross_tot", (gross_tot.text).toString())
                            map.put("stk_brid", (listoids.text).toString())
                            map.put("postatus", purc_spinner2.text.toString())
                            map.put("prod_nms", names.text.toString())
                            map.put("supp_invoice",suppinv)

                            map.put("recstatus", recstat)
                            db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                    .update(map)
                                    .addOnCompleteListener {
                                        try {
                                            pDialogs!!.dismiss()
                                        }
                                        catch (e:Exception){

                                        }
                                        val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                        u.putExtra("from_ver", "main")
                                        u.putExtra("viewsuppin", viewsuppin)
                                        u.putExtra("addsuppin", addsuppin)
                                        u.putExtra("deletesuppin", deletesuppin)
                                        u.putExtra("editsuppin", editesuppin)
                                        u.putExtra("transfersuppin", transfersuppin)
                                        u.putExtra("exportsuppin", exportsuppin)


                                        u.putExtra("viewpurord", viewpurord)
                                        u.putExtra("addpurord", addpurord)
                                        u.putExtra("deletepurord", deletepurord)
                                        u.putExtra("editpurord", editepurord)
                                        u.putExtra("transferpurord", transferpurord)
                                        u.putExtra("exportpurord", exportpurord)
                                        u.putExtra("sendpurord", sendpurpo)




                                        u.putExtra("viewpurreq", viewpurreq)
                                        u.putExtra("addpurreq", addpurreq)
                                        u.putExtra("deletepurreq", deletepurreq)
                                        u.putExtra("editpurreq", editepurreq)
                                        u.putExtra("transferpurreq", transferpurreq)
                                        u.putExtra("exportpurreq", exportpurreq)


                                        u.putExtra("brkey", branchids)
                                        startActivity(u)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()
                                    }
                        }
                        else if((descriplistener!="descchanged")&&(listListener=="listadded")) {


                            val map = mutableMapOf<String, Any?>()
                            map.put("igst_tot", (igst_tot.text).toString())
                            map.put("cgst_tot", (cgst_tot.text).toString())
                            map.put("sgst_tot", (sgst_tot.text).toString())
                            map.put("cess_tot", (cess_tot.text).toString())
                            map.put("gross_tot", (gross_tot.text).toString())
                            map.put("prod_nms", names.text.toString())
                            map.put("supp_invoice",suppinv)

                            map.put("postatus", purc_spinner2.text.toString())
                            map.put("recstatus", recstat)

                            for (m in 0 until ids.size) {
                                db.collection(path).document(ids[m].toString())
                                        .delete()
                                        .addOnCompleteListener {

                                        }
                            }



                                            /*var receive_path="Receive Stock/$refid/Received stock items"*/
                                            for (i in 0 until priceArray.size) {
                                                var stk_name = pronameArray[i]
                                                var stk_mfr = manufacturerArray[i]
                                                var stk_hsn = hsnArray[i]
                                                var stk_bcode = barcodeArray[i]
                                                var stk_quan = quantityArray[i]
                                                var stk_pri = priceArray[i]
                                                var stk_tot = totArray[i]
                                                var stk_grosstot = grosstotArray[i]

                                                var stk_cess = cessArray[i]
                                                var stk_igst = igstArray[i]
                                                var stk_cgst = cgstArray[i]
                                                var stk_sgst = sgstArray[i]
                                                var stk_igsttot = igsttotArray[i]
                                                var stk_cesstot = cesstotalArray[i]
                                                var stk_tally = tallyArray[i]
                                                var stk_received = receivedArray[i]
                                                var stk_receivedpri = receivedpriceArray[i]
                                                var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                                var stk_receivedcesstot = receivedcesstotArray[i]
                                                var stk_receivedgrosstot = receivedgrosstotArray[i]
                                                var stk_receivedtot = receivedtotalArray[i]
                                                var stk_key = keyArray[i]
                                                var img_ar = imageArray[i]
                                                var idpro_ar = idproarray[i]


                                                var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                                                        stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                                                        otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                                                        otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri,
                                                        received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot,
                                                        received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = img_ar, stk_prokey = idpro_ar)
                                                db.collection(path)
                                                        .add(d)
                                                        .addOnSuccessListener { documentReference ->
                                                            db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                                                    .update(map)
                                                            Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                            var refid = documentReference.id

                                                            Toast.makeText(applicationContext, "Saved", Toast.LENGTH_SHORT).show()

                                                            /*db.collection(receive_path).document(refid)
                                                                    .set(d)*/
                                                        }
                                            }
                            Handler().postDelayed(Runnable {
                                try {
                                    pDialogs!!.dismiss()
                                }
                                catch (e:Exception){

                                }
                                val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                u.putExtra("from_ver", "main")
                                u.putExtra("viewsuppin", viewsuppin)
                                u.putExtra("addsuppin", addsuppin)
                                u.putExtra("deletesuppin", deletesuppin)
                                u.putExtra("editsuppin", editesuppin)
                                u.putExtra("transfersuppin", transfersuppin)
                                u.putExtra("exportsuppin", exportsuppin)


                                u.putExtra("viewpurord", viewpurord)
                                u.putExtra("addpurord", addpurord)
                                u.putExtra("deletepurord", deletepurord)
                                u.putExtra("editpurord", editepurord)
                                u.putExtra("transferpurord", transferpurord)
                                u.putExtra("exportpurord", exportpurord)
                                u.putExtra("sendpurord", sendpurpo)




                                u.putExtra("viewpurreq", viewpurreq)
                                u.putExtra("addpurreq", addpurreq)
                                u.putExtra("deletepurreq", deletepurreq)
                                u.putExtra("editpurreq", editepurreq)
                                u.putExtra("transferpurreq", transferpurreq)
                                u.putExtra("exportpurreq", exportpurreq)


                                u.putExtra("brkey", branchids)
                                startActivity(u)
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                finish()
                            },2000)


                        }
                        else if((descriplistener=="descchanged")&&(listListener=="listadded")){

                            val map = mutableMapOf<String, Any?>()
                            map.put("ponumber", (pono.text).toString())
                            map.put("order_date", (orddate.text).toString())
                            map.put("description", (descrip.text).toString())
                            map.put("req_estimated", (reqdate.text).toString())
                            map.put("igst_tot", (igst_tot.text).toString())
                            map.put("cgst_tot", (cgst_tot.text).toString())
                            map.put("sgst_tot", (sgst_tot.text).toString())
                            map.put("cess_tot", (cess_tot.text).toString())
                            map.put("gross_tot", (gross_tot.text).toString())
                            map.put("stk_brid", (listoids.text).toString())
                            map.put("postatus", purc_spinner2.text.toString())
                            map.put("prod_nms", names.text.toString())
                            map.put("supp_invoice",suppinv)

                            map.put("recstatus", recstat)
                            db.collection("${branchids}_Purchase Orders").document(listoids.text.toString())
                                    .update(map)
                                    .addOnCompleteListener {
                                        for (m in 0 until ids.size) {
                                            db.collection(path).document(ids[m].toString())
                                                    .delete()
                                                    .addOnCompleteListener {

                                                    }
                                        }
                                    }

                            .addOnSuccessListener {


                                /*var receive_path="Receive Stock/$refid/Received stock items"*/
                                for (i in 0 until priceArray.size) {
                                    var stk_name = pronameArray[i]
                                    var stk_mfr = manufacturerArray[i]
                                    var stk_hsn = hsnArray[i]
                                    var stk_bcode = barcodeArray[i]
                                    var stk_quan = quantityArray[i]
                                    var stk_pri = priceArray[i]
                                    var stk_tot = totArray[i]
                                    var stk_grosstot = grosstotArray[i]

                                    var stk_cess = cessArray[i]
                                    var stk_igst = igstArray[i]
                                    var stk_cgst = cgstArray[i]
                                    var stk_sgst = sgstArray[i]
                                    var stk_igsttot = igsttotArray[i]
                                    var stk_cesstot = cesstotalArray[i]
                                    var stk_tally = tallyArray[i]
                                    var stk_received = receivedArray[i]
                                    var stk_receivedpri = receivedpriceArray[i]
                                    var stk_receivedtaxtot = receivedtaxtotalArray[i]
                                    var stk_receivedcesstot = receivedcesstotArray[i]
                                    var stk_receivedgrosstot = receivedgrosstotArray[i]
                                    var stk_receivedtot = receivedtotalArray[i]
                                    var stk_key = keyArray[i]
                                    var img_ar = imageArray[i]
                                    var idpro_ar = idproarray[i]


                                    var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan,
                                            stk_price = stk_pri, stk_total = stk_tot,stk_grosstotal = stk_grosstot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst,
                                            otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                                            otherstk_tally = stk_tally, otherstk_received = stk_received, received_price = stk_receivedpri,
                                            received_taxtotal = stk_receivedtaxtot, received_cesstotal = stk_receivedcesstot,
                                            received_grosstotal = stk_receivedgrosstot, received_total = stk_receivedtot, otherstk_img = img_ar,stk_prokey = idpro_ar)
                                    db.collection(path)
                                            .add(d)
                                            .addOnSuccessListener { documentReference ->

                                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                var refid = documentReference.id

                                                Toast.makeText(applicationContext,"Saved",Toast.LENGTH_SHORT).show()

                                                /*db.collection(receive_path).document(refid)
                                                        .set(d)*/
                                            }
                                }

                                Handler().postDelayed(Runnable {
                                    try {
                                        pDialogs!!.dismiss()
                                    }
                                    catch (e:Exception){

                                    }
                                    val u = Intent(this@PurcathirdMainActivity, MainPurchaselist_secondActivity::class.java)
                                    u.putExtra("from_ver", "main")
                                    u.putExtra("viewsuppin", viewsuppin)
                                    u.putExtra("addsuppin", addsuppin)
                                    u.putExtra("deletesuppin", deletesuppin)
                                    u.putExtra("editsuppin", editesuppin)
                                    u.putExtra("transfersuppin", transfersuppin)
                                    u.putExtra("exportsuppin", exportsuppin)


                                    u.putExtra("viewpurord", viewpurord)
                                    u.putExtra("addpurord", addpurord)
                                    u.putExtra("deletepurord", deletepurord)
                                    u.putExtra("editpurord", editepurord)
                                    u.putExtra("transferpurord", transferpurord)
                                    u.putExtra("exportpurord", exportpurord)
                                    u.putExtra("sendpurord", sendpurpo)




                                    u.putExtra("viewpurreq", viewpurreq)
                                    u.putExtra("addpurreq", addpurreq)
                                    u.putExtra("deletepurreq", deletepurreq)
                                    u.putExtra("editpurreq", editepurreq)
                                    u.putExtra("transferpurreq", transferpurreq)
                                    u.putExtra("exportpurreq", exportpurreq)


                                    u.putExtra("brkey", branchids)
                                    startActivity(u)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                    finish() },2000)

                            }
                        }


                        /*  var pono = (pono.text).toString()
                    var order_date = (orddate.text).toString()
                    var po_Desc = (descrip.text).toString()
                    var poreqby=(reqdate.text).toString()
                   var igsttot = (igst_tot.text).toString()
                  var cgsttot = (cgst_tot.text).toString()
                  var sgsttot = (sgst_tot.text).toString()
                  var cesstot = (cess_tot.text).toString()
                  var grosstot = (gross_tot.text).toString()
                    var brid=(listoids.text).toString()
                    var postatus="Incomplete"*/

                        /*val data = s(ponumber = pono, order_date = order_date, description = po_Desc,required_date=poreqby,IGST_tot = igsttot,CGST_tot = cgsttot,SGST_tot = sgsttot,Cess_tot = cesstot,Gross_tot =grosstot,stk_brid = brid,postatus = postatus)*/



                    } else if (transferpurord == "false") {
                        popup("Purchase order")
                    }
                }
                else{
                    dialog.dismiss()
                }
            }

            setNegativeButton("No") { dialog, whichButton ->
                val u=Intent(this@PurcathirdMainActivity,MainPurchaselist_secondActivity::class.java)
                u.putExtra("from_ver","main")
                u.putExtra("viewsuppin", viewsuppin)
                u.putExtra("addsuppin", addsuppin)
                u.putExtra("deletesuppin", deletesuppin)
                u.putExtra("editsuppin", editesuppin)
                u.putExtra("transfersuppin", transfersuppin)
                u.putExtra("exportsuppin", exportsuppin)


                u.putExtra("viewpurord", viewpurord)
                u.putExtra("addpurord", addpurord)
                u.putExtra("deletepurord", deletepurord)
                u.putExtra("editpurord", editepurord)
                u.putExtra("transferpurord", transferpurord)
                u.putExtra("exportpurord", exportpurord)
                u.putExtra("sendpurord", sendpurpo)




                u.putExtra("viewpurreq", viewpurreq)
                u.putExtra("addpurreq", addpurreq)
                u.putExtra("deletepurreq", deletepurreq)
                u.putExtra("editpurreq", editepurreq)
                u.putExtra("transferpurreq", transferpurreq)
                u.putExtra("exportpurreq", exportpurreq)


                u.putExtra("brkey",branchids)
                startActivity(u)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                finish()

            }
            val dialog = builder.create()
            dialog.show()
        }
    }


    //Create and write pdf document for 'Send this PO' option.


    fun createandDisplayPdf(nm:String,ph:String,vno:String,date:String,desc:String,ivdt:String,igstt:String,csgtt:String,sgstt:String,cesst:String,grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Purchase Order"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f=vno

            var c=nm
            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)




            PdfWriter.getInstance(doc,fOut)

            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSize1 = 10.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD

            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);

            val font1 = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize1,b);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Purchase Order",fontsubheading)



            val p1 =  Paragraph("Supplier Name:           "+nm,font)

            val p2 =  Paragraph("Supplier Phone:           "+ph,font)
            val p3 =  Paragraph("PO No:                         "+vno,font)
            val p4 =  Paragraph("Order Date:                    "+date,font)
            val p11 =  Paragraph("Description:                    "+desc,font)
            val p5 =  Paragraph("Required By:                  "+ivdt,font)
            val supde= Paragraph("Supplier Details:                  ",fontsubheading)
            val billto= Paragraph("Bill to:                  ",fontsubheading)
            val offaddre= Paragraph("Vinitas Enterprises pvt Ltd," +
                    "No:438,KK Nagar,Opposite Mahatma School," +
                    "Madurai,Tamil Nadu-635020",font)
            /* val p6 =  Paragraph("PO Status:                  "+paydt,font)
             val p12 =  Paragraph("IGST Total:                  "+igstt,font)
             val p13 =  Paragraph("CGST Total:                  "+csgtt,font)
             val p14 =  Paragraph("SGST Total:                  "+sgstt,font)
             val p15 =  Paragraph("CESS Total:                  "+cesst,font)
             val p7 =  Paragraph("Gross Total:                 "+grosstot,font)*/

            val p8=   Paragraph("Product Details",fontsubheading)

            /*    val pnm= Paragraph("Product Name")
                val pri= Paragraph("Price")*/
            val igstpdf= Paragraph("IGST TOTAL",font1)
            val cgstpdf= Paragraph("CGST TOTAL",font1)
            val sgstpdf= Paragraph("SGST TOTAL",font1)
            val cesspdf= Paragraph("Cess TOTAL",font1)
            val grosspdf= Paragraph("Gross TOTAL",font1)



            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ))

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER)

            table.addCell("S.No");

            table.addCell("Product Name");
            table.addCell("HSN/SAC")
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes");
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            for (i in 0 until priceArray.size)
            {
                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)




                /*var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var div=2
                var e=igsttotArray[i]
                var eflo=e.toFloat()
                ee=ee+eflo
                ig= ee
                var csgsts=ig.toFloat()
                var csgttotalss=csgsts/div
                cg=csgttotalss
                sg=csgttotalss




                var f=cesstotalArray[i]
                var fflo=f.toFloat()
                cc=fflo+cc
                ces=cc
                var gg=ig.toFloat()
                var jj=ces.toFloat()
                var grtt=gg+jj+cc
                var grflo=grtt.toFloat()
                var gttt=grflo+(pri*quan)*/



                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(com.itextpdf.text.Rectangle.NO_BORDER);
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(csgtt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstot)


            /*val table1 =  PdfPTable( floatArrayOf(6F))

            table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);

            table1.setHeaderRows(1)
            val cells1 = table.getRow(0).getCells()


                table1.addCell("IGST Total"+igstto)
                table1.addCell("CGST Total"+cgstto)
                table1.addCell("SGST Total"+sgstto)
                table1.addCell( "Cess Total"+cessto)
                table1.addCell( "Gross Total"+grossto)*/


            /*      val table1 =  PdfPTable(2);
                  val  cell = PdfPCell(igstpdf);
                 cell.colspan=2
                 cell.setBorder(PdfPCell.NO_BORDER);
                 cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                  table.addCell(cell);
                  val cellCaveat =  PdfPCell(cgstpdf);
                  cellCaveat.setColspan(1);
                  cellCaveat.setBorder(PdfPCell.NO_BORDER);
                  table1.addCell(cellCaveat);
                 table1.addCell(cellCaveat);*/






            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE );
            doc.add(hs1)
            doc.add( Chunk.NEWLINE );
            doc.add(p3);
            doc.add( Chunk.NEWLINE );
            doc.add(p4);
            doc.add( Chunk.NEWLINE );
            doc.add(p11);
            doc.add( Chunk.NEWLINE );
            doc.add(p5);
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(supde);
            doc.add( Chunk.NEWLINE );
            doc.add(p1);
            doc.add( Chunk.NEWLINE );
            doc.add(p2);
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(billto);
            doc.add( Chunk.NEWLINE );
            doc.add(offaddre);


            /*       doc.add( Chunk.NEWLINE );
                   doc.add(p6);
                   doc.add( Chunk.NEWLINE );
                   doc.add(p12);
                   doc.add( Chunk.NEWLINE );
                   doc.add(p13);
                   doc.add( Chunk.NEWLINE );
                   doc.add(p14);
                   doc.add( Chunk.NEWLINE );
                   doc.add(p15);
                   doc.add( Chunk.NEWLINE );
                   doc.add(p7)*/

            doc.add( Chunk.NEWLINE );
            doc.add(p8);
            doc.add( Chunk.NEWLINE );
            doc.add(table)
            doc.add( Chunk.NEWLINE );

            downstatus="success"

        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }

   /* fun getBitmapFromView(view: View, totalHeight: Int, totalWidth: Int): Bitmap {

        val returnedBitmap = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(returnedBitmap)
        val bgDrawable = view.background
        if (bgDrawable != null)
            bgDrawable.draw(canvas)
        else
            canvas.drawColor(Color.WHITE)
        view.draw(canvas)
        return returnedBitmap
    }
    @Throws(FileNotFoundException::class)*/
 /*   fun imageToPDF() {
        try {
            val img = Image.getInstance(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            val image = Image.getInstance(img)
            val width = image.width
            val height = image.height
            val page = Rectangle(width, height)
            val document = Document(page)
            dirpath = Environment.getExternalStorageDirectory().toString()
            val writer=PdfWriter.getInstance(document, FileOutputStream(dirpath + "/NewPDF.pdf")) //  Change pdf's name.
            document.open()
            val canvas = writer.getDirectContentUnder()
            canvas.addImage(image, width, 0F, 0F, height, 0F, -height / 2);
            document.newPage();
            canvas.addImage(image, width, 0F, 0F, height, 0F, 0F);
            document.newPage();
            canvas.addImage(image, width, 0F, 0F, height, -width / 2, - height / 2);
            document.newPage();
            canvas.addImage(image, width, 0F, 0F, height, -width / 2, 0F);
            document.close()
            Toast.makeText(this, "PDF Generated successfully!..", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {

        }

    }*/



    /*fun saveBitmap(bitmap: Bitmap) {
        val filePath = (Environment.getExternalStorageDirectory().toString()
                + File.separator + "Pictures/screenshot.png")
        val imagePath = File(filePath)
        val fos: FileOutputStream
        try {
            fos = FileOutputStream(imagePath)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()
            sendMail(filePath)
        } catch (e: FileNotFoundException) {
            Log.e("GREC", e.message,e)
        } catch (e: IOException) {
            Log.e("GREC", e.message,e)
        }

    }*/

    fun pdfnav(){
        if(priceArray.isNotEmpty()==true) {





            var totalpdf = 0.0F
            var igsttotpdf = 0.0F
            var cesstotalspdf = 0.0F
            var bpdf = 2
            for (i in 0 until priceArray.count()) {


                var c = (priceArray[i])
                var cy = (igsttotArray[i])
                var cyz = (cesstotalArray[i])
                var qyz = (receivedArray[i])

                var cdec = c.toBigDecimal()
                var qyzdec = qyz.toBigDecimal()
                var totquanpri = (cdec * qyzdec)




                totalpdf = totalpdf.plus(totquanpri.toInt())

                igsttotpdf = igsttotpdf.plus(cy.toFloat())
                cesstotalspdf = cesstotalspdf.plus(cyz.toFloat())

                igst_tot.setText((String.format("%.2f", igsttotpdf)))
                var l = igst_tot.text.toString()
                var ss = l.toBigDecimal()
                var tt = ss / bpdf.toBigDecimal()
                cgst_tot.setText((String.format("%.2f", tt)))
                sgst_tot.setText((String.format("%.2f", tt)))

                cess_tot.setText((String.format("%.2f", cesstotalspdf)))

                var f = cesstotalspdf
                var g = igsttotpdf

                var op = totalpdf
                var m = f.toFloat()
                var n = g.toFloat()

                var yy = m + n + op

                try {
                    pdfgross.setText((String.format("%.2f", yy)))
                } catch (e: Exception) {
                    pdfgross.setText((String.format("%.2f", yy)))
                }
            }
        }

        val b = Intent(applicationContext, PurchasePdfActivity::class.java)
        b.putExtra("from_pur", "purchase_pdf")
        b.putExtra("pnm", pronameArray)
        b.putExtra("pmanu", manufacturerArray)
        b.putExtra("phsn", hsnArray)
        b.putExtra("barcode", barcodeArray)
        b.putExtra("price", priceArray)
        b.putExtra("quan", quantityArray)
        b.putExtra("tot", totArray)
        b.putExtra("grosstot", grosstotArray)
        b.putExtra("supplieridfr",supplieridfr)
        b.putExtra("suppinv",suppinv)

        b.putExtra("cessup", cessArray)
        b.putExtra("igst", igstArray)
        b.putExtra("cgst", cgstArray)
        b.putExtra("sgst", sgstArray)
        b.putExtra("igsttotal", igsttotArray)
        b.putExtra("cesstotarray", cesstotalArray)
        b.putExtra("tallyarray", tallyArray)
        b.putExtra("receivedarray", receivedArray)
        b.putExtra("received_price", receivedpriceArray)
        b.putExtra("received_total", receivedtotalArray)
        b.putExtra("received_taxtot", receivedtaxtotalArray)
        b.putExtra("received_cesstot", receivedcesstotArray)
        b.putExtra("received_grosstot", receivedgrosstotArray)
        b.putExtra("idsofli", keyArray)
        b.putExtra("smlistids", smlistids)
        b.putExtra("image", imageArray)
        b.putExtra("idpro", idproarray)
        b.putExtra("reprnms", names.text.toString())
        b.putExtra("reqliid", listoids.text.toString())
        b.putExtra("nms", comttname.text.toString())
        b.putExtra("ph", comphone.text.toString())
        b.putExtra("pono", pono.text.toString())
        b.putExtra("orddate", orddate.text.toString())
        b.putExtra("desc", descrip.text.toString())
        b.putExtra("reqdate", reqdate.text.toString())
        b.putExtra("gross", pdfgross.text.toString())
        b.putExtra("grossori", gross_tot.text.toString())
        b.putExtra("igsts", igst_tot.text.toString())
        b.putExtra("cgsts", cgst_tot.text.toString())
        b.putExtra("sgsts", sgst_tot.text.toString())
        b.putExtra("cessts", cess_tot.text.toString())
        b.putExtra("postatus",purc_spinner2.text.toString())
        b.putExtra("brids",branchids)
        b.putExtra("descriplistener",descriplistener)
        b.putExtra("listListener",listListener)
        b.putExtra("viewsuppin", viewsuppin)
        b.putExtra("addsuppin", addsuppin)
        b.putExtra("deletesuppin", deletesuppin)
        b.putExtra("editsuppin", editesuppin)
        b.putExtra("transfersuppin", transfersuppin)
        b.putExtra("exportsuppin", exportsuppin)



        b.putExtra("orddatedup",orddatedup)
        b.putExtra("reqdatedup",reqdatedup)
        b.putExtra("descripdup",descripdup)
        b.putExtra("edclick",edclick)

        b.putExtra("viewpurord", viewpurord)
        b.putExtra("addpurord", addpurord)
        b.putExtra("deletepurord", deletepurord)
        b.putExtra("editpurord", editepurord)
        b.putExtra("transferpurord", transferpurord)
        b.putExtra("exportpurord", exportpurord)
        b.putExtra("sendpurord", sendpurpo)




        b.putExtra("viewpurreq", viewpurreq)
        b.putExtra("addpurreq", addpurreq)
        b.putExtra("deletepurreq", deletepurreq)
        b.putExtra("editpurreq", editepurreq)
        b.putExtra("transferpurreq", transferpurreq)
        b.putExtra("exportpurreq", exportpurreq)



        b.putExtra("ids",ids)




        b.putExtra("postatus", purc_spinner2.text.toString())


        startActivity(b)
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        finish()


    }

    fun sendMail(path: String) {        //Send this purchase order to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("muthumadhavan.vinitas@gmail.com","it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "Purchase PO")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        emailIntent.type = "application/pdf"
        val myUri = Uri.parse("file://" + path)
        emailIntent.putExtra(Intent.EXTRA_STREAM, myUri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        finish()
    }
    fun popup(st:String){       //Access Denied
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    companion object {

 //Listens internet status whether net is on/off.

       private var relativeslayoutdis:RelativeLayout?=null
       private var pur_savedis:Button?=null
       private var userbackdis:ImageButton?=null
       private var mnudis:ImageButton?=null
        private var constraintLayout3dis:ConstraintLayout?=null
        private var editdis:ImageButton?=null
        private val log_str: String? = null
        private var pDialogs: SweetAlertDialog? = null

        private var ponodis:EditText?=null
        private var orddatedis:EditText?=null
        private var reqdatedis:EditText?=null
        private var descripdis:EditText?=null
        private var fabdis:FloatingActionButton?=null
        private var pur_listdis:ListView?=null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){


                 /// if connection is off then all views becomes disable
                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                pur_savedis!!.isEnabled=false
                userbackdis!!.isEnabled=false
                mnudis!!.isEnabled=false
                editdis!!.isEnabled=false

                ponodis!!.isEnabled=false
                orddatedis!!.isEnabled=false
                reqdatedis!!.isEnabled=false
                descripdis!!.isEnabled=false
                fabdis!!.isEnabled=false
                pur_listdis!!.isClickable=false
                pur_listdis!!.isEnabled=false
                pur_listdis!!.isLongClickable=false

                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }
            }
            else
            {

                 /// if connection is off then all views becomes enabled
                relativeslayoutdis!!.visibility=View.GONE
                constraintLayout3dis!!.visibility=View.GONE
                pur_savedis!!.isEnabled=true
                userbackdis!!.isEnabled=true
                mnudis!!.isEnabled=true
                editdis!!.isEnabled=true


                ponodis!!.isEnabled=false

                if(editdis!!.visibility!=View.VISIBLE){
                    orddatedis!!.isEnabled=true
                    reqdatedis!!.isEnabled=true
                    descripdis!!.isEnabled=true
                    pur_listdis!!.isEnabled=true
                    fabdis!!.isEnabled=true
                    pur_listdis!!.isClickable=true
                    pur_listdis!!.isLongClickable=true
                }


            }
        }
    }

    fun setDateord(view: View) {
        showDialog(999)

    }
    fun setDateord1(view: View) {
        showDialog(998)

    }


    //Date dialog

    override fun onCreateDialog(id: Int): Dialog? {
        // TODO Auto-generated method stub
        return if (id == 999) {
            DatePickerDialog(this,
                    myDateListener, year, month, day)
        }
        else if(id==998){
            DatePickerDialog(this,
                    myDateListener1, year, month, day)
        }
        else null
    }

    private fun showDate(year: Int, month: Int, day: Int) {
        dateView!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)




        if(dateView!!.text.isNotEmpty()){
            var f=dateView!!.text.toString()
            reqdate.setText(f)
        }



    }
    private fun showDate1(year: Int, month: Int, day: Int) {
        dateView1!!.text = StringBuilder().append(day).append("/")
                .append(month).append("/").append(year)


        if(dateView1!!.text.isNotEmpty()){
            var f=dateView1!!.text.toString()
            orddate.setText(f)
        }
    }

    fun net_status():Boolean{    ////Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    /*private fun onStarClicked1(pronameArray:Array<String>, manufacturerArray:Array<String>, hsnArray:Array<String>, barcodeArray:Array<String>, quantityArray:Array<String>, priceArray:Array<String>, totArray:Array<String>, cessArray:Array<String>, igstArray:Array<String>,cgstArray:Array<String>, sgstArray:Array<String>, igsttotArray:Array<String>, cesstotalArray:Array<String>, tallyArray: Array<String>,receivedArray: Array<String>, keyArray:Array<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("Purchase_PO")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray.clone(),manufacturerArray.clone(),hsnArray.clone(),barcodeArray.clone(),quantityArray.clone(),priceArray.clone(),totArray.clone(),cessArray.clone(),igstArray.clone(),cgstArray.clone(),sgstArray.clone(),igsttotArray.clone(),cesstotalArray.clone(),tallyArray.clone(),receivedArray.clone(),keyArray.clone())


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }*/

    /*fun prod_insert(id1: String, pronameArray: Array<String>, manufacturerArray: Array<String>, hsnArray: Array<String>, barcodeArray: Array<String>, quantityArray: Array<String>, priceArray: Array<String>, totArray: Array<String>, cessArray: Array<String>,igstArray:Array<String>,cgstArray:Array<String>,sgstArray:Array<String>,igsttotArray:Array<String>,cesstotalArray:Array<String>,tallyArray:Array<String>,receivedArray:Array<String>,keyArray:Array<String>) {

        var pono = id1
        var order_date = (orddate.text).toString()
        var po_Desc = (descrip.text).toString()

        var po_total=(gross_tot.text).toString()
        var poreqby=(reqdate.text).toString()
        var brid=(brnchid.text).toString()
        var postatus="Incomplete"

        val data = s(pono = pono, order_date = order_date, po_Desc = po_Desc,po_total = po_total,stk_brid = brid,po_req_by = poreqby,po_status = postatus)
        var db = FirebaseFirestore.getInstance()
        db.collection("Purchase_Order")
                .add(data)
                .addOnSuccessListener { documentReference ->

                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var refid=documentReference.id

                    *//*db.collection("Receive Stock").document(refid)
                            .set(data)*//*
                    var path="Purchase_Order/$refid/Purchase_products"
                    for(i in 0 until priceArray.size) {

                        var stk_name=pronameArray[i]
                        var stk_mfr=manufacturerArray[i]
                        var stk_hsn=hsnArray[i]
                        var stk_bcode=barcodeArray[i]
                        var stk_quan=quantityArray[i]
                        var stk_pri=  priceArray[i]
                        var stk_tot=totArray[i]
                        var stk_cess=cessArray[i]
                        var stk_igst = igstArray[i]
                        var stk_cgst = cgstArray[i]
                        var stk_sgst = sgstArray[i]

                        var stk_igsttot = igsttotArray[i]
                        var stk_cesstot = cesstotalArray[i]
                        var stk_tally = tallyArray[i]
                        var stk_received = receivedArray[i]
                        var stk_key= keyArray[i]
                        var d=li(stk_name=stk_name,stk_mfr = stk_mfr,stk_hsn=stk_hsn,stk_barcode = stk_bcode,stk_received = stk_quan,stk_price = stk_pri,stk_total = stk_tot,stk_cess = stk_cess,otherstk_igst=stk_igst,otherstk_cgst=stk_cgst,otherstk_sgst=stk_sgst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot,stk_key = stk_key,otherstk_tally = stk_tally,otherstk_received = stk_received)
                        db.collection(path)
                                .add(d)

                                .addOnSuccessListener { documentReference ->
                                    var resid=documentReference.id
                                 *//*   db.collection("Receive Stock/$refid/Received stock items").document(resid)
                                            .set(d)*//*

                                    Toast.makeText(applicationContext,"Data saved successfully",Toast.LENGTH_SHORT).show()
                                    pur_save_prgrs.visibility=View.GONE
                                    onBackPressed()
                                }

                    }



                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    *//* save_progress.visibility = android.view.View.GONE*//*
                }

    }
*/
        }



