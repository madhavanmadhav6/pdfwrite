package com.example.vinitas.inventory_app

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_setbranch.*

class setbranchActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setbranch)
        back6.setOnClickListener {
            finish()
        }
        setbranch.setOnClickListener {
            val b3 = Intent(applicationContext, yourbranchActivity::class.java)
            startActivity(b3)
        }
        select.setOnClickListener {
            val alert = AlertDialog.Builder(this)
            val inflater = this.layoutInflater
            with(alert) {
                setTitle("Select Branch")
            }
            val dialog = alert.create()
            dialog.setView(inflater.inflate(R.layout.select_branch,null))
            dialog.show()
            val kk = dialog.findViewById<TextView>(R.id.kknagar)as TextView
            val ka = dialog.findViewById<TextView>(R.id.kalavasal)as TextView
            val si = dialog.findViewById<TextView>(R.id.sivakasi)as TextView
            val py = dialog.findViewById<TextView>(R.id.periyar)as TextView
            kk.setOnClickListener {
                select.text = kk.text.toString()
                dialog.hide()
            }
            ka.setOnClickListener {
                select.text = ka.text.toString()
                dialog.hide()
            }
            si.setOnClickListener {
                select.text = si.text.toString()
                dialog.hide()
            }
            py.setOnClickListener {
                select.text = py.text.toString()
                dialog.hide()
            }
        }
    }
}
