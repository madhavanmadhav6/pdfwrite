package com.example.vinitas.inventory_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import kotlin.text.Regex;

/**
 * Created by vinitas stock on 28-02-2018.
 */

public class Databasehelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "products.db";//database name
    private static final String TABLE_NAME = "products";//TAble name

    private static final String s="^[a-zA-Z ]+$";

    private static final String re="^[0-9]*$";

    public Databasehelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//Create table
        db.execSQL("create table " + TABLE_NAME +" (id TEXT PRIMARY KEY,p_id TEXT,p_nm TEXT,bc TEXT,descr TEXT,wg_vol TEXT,hsn TEXT,ctgy TEXT,mfr TEXT,ut TEXT,min_stk TEXT,price TEXT,mx_stk TEXT,cn_sold TEXT, emp_com TEXT,taxchk  TEXT,igst TEXT,cgst TEXT,sgst TEXT,cess TEXT,taxtot TEXT,cesstot TEXT,mrp TEXT,curency TEXT,status TEXT, percentage TEXT,percentageval TEXT,product_desc TEXT,stock_hand TEXT,img1n TEXT,img2n TEXT,img3n TEXT,img4n TEXT,img5n TEXT,img1url TEXT,img2url TEXT,img3url TEXT,img4url TEXT,img5url TEXT,img1nhigh TEXT,img2nhigh TEXT,img3nhigh TEXT,img4nhigh TEXT,img5nhigh TEXT,img1urlhigh TEXT,img2urlhigh TEXT,img3urlhigh TEXT,img4urlhigh TEXT,img5urlhigh TEXT,orikys TEXT,retail TEXT,backbar TEXT,protype TEXT,returnable TEXT,retdate TEXT,makeupitem TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }



    //Insert product details
    public boolean insertData(String id,String p_id,String p_nm,String bc,String desc,String wg_vol,String hsn,String
            ctgy,String mfr,String ut,String min_stk,String price,String mx_stk,String cn_sold,String  emp_com,String
            taxchk ,String igst,String cgst,String sgst,String cess,String taxtot,String cesstot,String mrp,String curency,
           String status,String  percentage,String percentageval,String product_desc,String stock_hand,
          String img1n,String img2n,String img3n,String img4n,String img5n,String img1url,String img2url,
          String img3url,String img4url,String img5url,String img1nhigh,String img2nhigh,String img3nhigh,
          String img4nhigh,String img5nhigh,String img1urlhigh,String img2urlhigh,String img3urlhigh,
          String img4urlhigh,String img5urlhigh,String orikys,String  retail,String  backbar,String protype,String returnable,String retdate,String makeupitem) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put("id",id);
        contentValues.put("p_id ",p_id);
        contentValues.put("p_nm",p_nm);
        contentValues.put("bc",bc);
        contentValues.put("descr",desc);
        contentValues.put("wg_vol",wg_vol);
        contentValues.put("hsn",hsn);
        contentValues.put("ctgy",ctgy);
        contentValues.put("mfr",mfr);
        contentValues.put("ut",ut);
        contentValues.put("min_stk",min_stk);
        contentValues.put("price",price);
        contentValues.put("mx_stk",mx_stk);
        contentValues.put("cn_sold",cn_sold);
        contentValues.put("emp_com",emp_com);
        contentValues.put("taxchk",taxchk);
        contentValues.put("igst",igst);
        contentValues.put("cgst",cgst);
        contentValues.put("sgst",sgst);
        contentValues.put("cess",cess);
        contentValues.put("taxtot",taxtot);
        contentValues.put("cesstot",cesstot);
        contentValues.put("mrp",mrp);
        contentValues.put("curency",curency);
        contentValues.put("status",status);
        contentValues.put("percentage",percentage);

        contentValues.put("percentageval",percentageval);
        contentValues.put("product_desc",product_desc);
        contentValues.put("stock_hand",stock_hand);
        contentValues.put("img1n",img1n);
        contentValues.put("img2n",img2n);
        contentValues.put("img3n",img3n);
        contentValues.put("img4n",img4n);
        contentValues.put("img5n",img5n);
        contentValues.put("img1url",img1url);
        contentValues.put("img2url",img2url);
        contentValues.put("img3url",img3url);
        contentValues.put("img4url",img4url);
        contentValues.put("img5url",img5url);
        contentValues.put("img1nhigh",img1nhigh);
        contentValues.put("img2nhigh",img2nhigh);
        contentValues.put("img3nhigh",img3nhigh);
        contentValues.put("img4nhigh",img4nhigh);
        contentValues.put("img5nhigh",img5nhigh);
        contentValues.put("img1urlhigh",img1urlhigh);
        contentValues.put("img2urlhigh",img2urlhigh);
        contentValues.put("img3urlhigh",img3urlhigh);
        contentValues.put("img4urlhigh",img4urlhigh);
        contentValues.put("img5urlhigh",img5urlhigh);
        contentValues.put("orikys",orikys);
        contentValues.put("retail",retail);
        contentValues.put("backbar",backbar);
        contentValues.put("protype",protype);
        contentValues.put("returnable",returnable);
        contentValues.put("retdate",retdate);
        contentValues.put("makeupitem",makeupitem);




        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {

        //Get all datas from table
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor res = db.rawQuery("select * from "+TABLE_NAME+" ORDER BY status ASC " ,null);

        return res;
    }


    //Update prouct details
    public boolean updatedata(String id,String p_id,String p_nm,String bc,String desc,
                              String wg_vol,String hsn,String ctgy,String mfr,String ut,
                              String min_stk,String price,String mx_stk,String cn_sold,
                              String  emp_com,String taxchk ,String igst,String cgst,
                              String sgst,String cess,String taxtot,String cesstot,
                              String mrp,String curency,String status,String  percentage,
                             String percentageval,String product_desc,String stock_hand,String img1n,
                              String img2n,String img3n,String img4n,String img5n,
                              String img1url,String img2url,String img3url,String img4url,
                              String img5url, String img1nhigh,String img2nhigh,String img3nhigh,
                              String img4nhigh,String img5nhigh,String img1urlhigh,String img2urlhigh,
                              String img3urlhigh,String img4urlhigh,String img5urlhigh,String orikys,
                              String  retail,String  backbar,String protype,String returnable,String retdate,String makeupitem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id);//0
        contentValues.put("p_id ",p_id);//1
        contentValues.put("p_nm",p_nm);//2
        contentValues.put("bc",bc);//3
        contentValues.put("descr",desc);//4
        contentValues.put("wg_vol",wg_vol);//5
        contentValues.put("hsn",hsn);//6
        contentValues.put("ctgy",ctgy);//7
        contentValues.put("mfr",mfr);//8
        contentValues.put("ut",ut);//9
        contentValues.put("min_stk",min_stk);//10
        contentValues.put("price",price);//11
        contentValues.put("mx_stk",mx_stk);//12
        contentValues.put("cn_sold",cn_sold);//13
        contentValues.put("emp_com",emp_com);//14
        contentValues.put("taxchk",taxchk);//15
        contentValues.put("igst",igst);//16
        contentValues.put("cgst",cgst);//17
        contentValues.put("sgst",sgst);//18
        contentValues.put("cess",cess);//19
        contentValues.put("taxtot",taxtot);//20
        contentValues.put("cesstot",cesstot);//21
        contentValues.put("mrp",mrp);//22
        contentValues.put("curency",curency);//23
        contentValues.put("status",status);//24
        contentValues.put("percentage",percentage);//25

        contentValues.put("percentageval",percentageval);//26
        contentValues.put("product_desc",product_desc);//27
        contentValues.put("stock_hand",stock_hand);//28
        contentValues.put("img1n",img1n);//29
        contentValues.put("img2n",img2n);//30
        contentValues.put("img3n",img3n);//31
        contentValues.put("img4n",img4n);//32
        contentValues.put("img5n",img5n);//33
        contentValues.put("img1url",img1url);//34
        contentValues.put("img2url",img2url);//35
        contentValues.put("img3url",img3url);//36
        contentValues.put("img4url",img4url);//37
        contentValues.put("img5url",img5url);//38
        contentValues.put("img1nhigh",img1nhigh);//39
        contentValues.put("img2nhigh",img2nhigh);//40
        contentValues.put("img3nhigh",img3nhigh);//41
        contentValues.put("img4nhigh",img4nhigh);//42
        contentValues.put("img5nhigh",img5nhigh);//43
        contentValues.put("img1urlhigh",img1urlhigh);//44
        contentValues.put("img2urlhigh",img2urlhigh);//45
        contentValues.put("img3urlhigh",img3urlhigh);//46
        contentValues.put("img4urlhigh",img4urlhigh);//47
        contentValues.put("img5urlhigh",img5urlhigh);//48
        contentValues.put("orikys",orikys);//49
        contentValues.put("retail",retail);//50

        contentValues.put("backbar",backbar);//51
        contentValues.put("protype",protype);//52
        contentValues.put("returnable",returnable);
        contentValues.put("retdate",retdate);
        contentValues.put("makeupitem",makeupitem);//55




        db.update(TABLE_NAME, contentValues, "id = ?",new String[] { id });
        return true;
    }

    public boolean updatedatasoh(String id,String stock_hand){
        //Update stockon hand of each product
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id);
        contentValues.put("stock_hand",stock_hand);
        db.update(TABLE_NAME, contentValues, "id = ?",new String[] { id });
        return true;
    }


    public void deleteall(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_NAME);
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "id = ?",new String[] {id});
    }
    public Cursor retrieve(String searchTerm)//Retreive details of the products by search terms
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;

        if(searchTerm != null && searchTerm.length()>0){

            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"p_nm"+" LIKE '%"+searchTerm+"%'";



            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE p_nm LIKE '%"+searchTerm+"%' OR bc LIKE '%"+searchTerm+"%' OR mrp LIKE '%"+searchTerm+"%' OR stock_hand LIKE '%"+searchTerm+"%' OR mfr LIKE '%"+searchTerm+"%'",null);



            return c;

            //write code here for success
        }

        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;

       /* else if((searchTerm.matches(re))&&(searchTerm != null)&&(searchTerm.length()>=3))
        {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"bc"+" LIKE '%"+searchTerm+"%'";



            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE bc LIKE '%"+searchTerm+"%'",null);



            return c;
        }

        else if((searchTerm.matches(re))&&(searchTerm != null)&&(searchTerm.length()>=2)){
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"mrp"+" LIKE '%"+searchTerm+"%'";



            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE mrp LIKE '%"+searchTerm+"%'",null);



            return c;

        }

        else if((searchTerm.matches(re))&&(searchTerm != null)&&(searchTerm.length()>=1)){
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"stock_hand"+" LIKE '%"+searchTerm+"%'";



            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE stock_hand LIKE '%"+searchTerm+"%'",null);



            return c;

        }*/









    }
    public boolean checkIfRecordExist(String COL_2)//Check if record already exists
    {
        try
        {
            SQLiteDatabase db=this.getReadableDatabase();
            Cursor cursor=db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id ='"+COL_2+"'",null);
            if (cursor.moveToFirst())
            {
                db.close();
                Log.d("Record  Already Exists", "Table is:"+TABLE_NAME+" ColumnName:"+COL_2);
                return true;//record Exists

            }
            Log.d("New Record  ", "Table is:"+TABLE_NAME+" ColumnName:"+COL_2+" Column Value:"+COL_2);
            db.close();
        }
        catch(Exception errorException)
        {
            Log.d("Exception occured", "Exception occured "+errorException);
            // db.close();
        }
        return false;
    }
    public int getNotesCount() {//Check counts of datas
        String countQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        int count = cursor.getCount();
        cursor.close();


        // return count
        return count;
    }

    public Cursor getOne(String idd){//Get data by id
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;
        String query = "SELECT * FROM "+TABLE_NAME+" WHERE id = ?" +idd;
        if (idd != null && idd.length()>0) {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"snm"+" LIKE '%"+idd+"%'";
            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE id LIKE '%"+idd+"%'",null);
            return c;
            /*c=db.rawQuery("select * from "+TABLE_NAME+" where id = "+idd,null);
            //c = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id = "+idd,null);
            return c;*/
        }
        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;
    }

}