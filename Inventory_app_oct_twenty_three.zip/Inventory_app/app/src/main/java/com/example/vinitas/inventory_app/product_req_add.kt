package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import com.google.firebase.firestore.*

import kotlinx.android.synthetic.main.product_list_activity_pur.*
import android.widget.LinearLayout
import de.hdodenhof.circleimageview.CircleImageView
import android.view.Gravity
import cn.pedant.SweetAlert.SweetAlertDialog
import com.squareup.picasso.Picasso
import java.util.*
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.text.Editable
import android.text.TextWatcher
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot


class product_request_add : AppCompatActivity() {

    var grosschk= String()

    var ids=arrayOf<String>()

    var supplieridfr=String()


    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""



    var befnm=String()
    var request_datedup=String()
    var reqest_datedup=String()
    var supp_namedup=String()
    var supp_gstdup=String()
    var supp_addredup=String()

    var bcd= String()
    var sd = String()
    var x = String()
    var reg = String()
    var esc = String()
    var upstr = String()
    var numberstr = String()
    var regtr = String()
    var nmstr = String()

    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""





    var names = String()
    var prdnms = String()
    var reqid = String()
    var liid = String()
    var reqdt = String()
    var restimt = String()
    var reqnm = String()
    var reqmail = String()
    var reqph = String()
    var imglinkss = String()

    var incompstr= String()
    var supnm = String()
    var supadd1 = String()
    var supadd2 = String()
    var supadd3 = String()
    var supgst = String()
    var supph = String()
    var supcity = String()
    var supstate = String()
    var status = String()
    var keysbr = String()
    var imli = String()


    var namesori = String()
    var namesphones = String()
    var keybrnch=String()
    var namesphonesori = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var idli= arrayOf<String>()

    var edclick= String()



    var pronameArraycpy     = arrayListOf<String>()
    var hsnArraycpy          = arrayListOf<String>()
    var manufacturerArraycpy = arrayListOf<String>()
    var barcodeArraycpy     = arrayListOf<String>()
    var quantityArraycpy     = arrayListOf<String>()
    var priceArraycpy       = arrayListOf<String>()
    var totArraycpy         = arrayListOf<String>()
    var grosstotArraycpy         = arrayListOf<String>()

    var cessArraycpy         = arrayListOf<String>()
    var igstArraycpy= arrayListOf<String>()
    var cgstArraycpy= arrayListOf<String>()
    var sgstArraycpy= arrayListOf<String>()
    var igsttotArraycpy = arrayListOf<String>()
    var cesstotalArraycpy = arrayListOf<String>()
    var tallyArraycpy = arrayListOf<String>()
    var receivedArraycpy = arrayListOf<String>()
    var imageArraycpy        = arrayListOf<String>()
    var idupArraycpy=arrayListOf<String>()
    var idproArraycpy=arrayListOf<String>()





    var  pronameArrayori     = arrayListOf<String>()
    var  hsnArrayori         = arrayListOf<String>()
    var  manufacturerArrayori= arrayListOf<String>()
    var  barcodeArrayori      = arrayListOf<String>()
    var  quantityArrayori     = arrayListOf<String>()
    var  priceArrayori        = arrayListOf<String>()
    var  totArrayori         = arrayListOf<String>()
    var  grosstotArrayori         = arrayListOf<String>()

    var  cessArrayori        = arrayListOf<String>()
    var igstArrayori =arrayListOf<String>()
    var cgstArrayori =arrayListOf<String>()
    var sgstArrayori =arrayListOf<String>()
    var igsttotArrayori =arrayListOf<String>()
    var cesstotalArrayori =arrayListOf<String>()
    var tallyArrayori =arrayListOf<String>()
    var receivedArrayori =arrayListOf<String>()
    var  imageArrayori        = arrayListOf<String>()
    var keyArrayori=arrayListOf<String>()
    var  idproArrayori        = arrayListOf<String>()


    var  pronameArray       = arrayListOf<String>()
    var  hsnArray           = arrayListOf<String>()
    var  manufacturerArray  = arrayListOf<String>()
    var  barcodeArray       = arrayListOf<String>()
    var  quantityArray      = arrayListOf<String>()
    var  priceArray         = arrayListOf<String>()
    var  totArray           = arrayListOf<String>()
    var  grosstotArray           = arrayListOf<String>()

    var  cessArray          = arrayListOf<String>()
    var  imageArray         = arrayListOf<String>()
    var  igstArray         = arrayListOf<String>()
    var  cgstArray         = arrayListOf<String>()
    var  sgstArray         = arrayListOf<String>()
    var  igsttotArray         = arrayListOf<String>()
    var  cesstotalArray         = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var keyArray=arrayListOf<String>()
    var idproArray=arrayListOf<String>()


    var d = arrayListOf<String>()

    var dlt = arrayListOf<String>()

    val db = FirebaseFirestore.getInstance()
    val TAG = "some"


    var deletelistener=String()


    /* var compnameArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
     var itemnmArray = arrayOf<String>("fireboost","loreal","fireboost","professional","pantine")
     var orderArray = arrayOf<String>("BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273","BC - 82934783874273")
     var poArray = arrayOf<String>("60/100 Received","20/100 Received","30/100 Received","40/100 Received","50/100 Received")
     var completeArray = arrayOf<String>("200ml","300ml","400ml","500ml","600ml")
     var priceArray = arrayOf<String>("3000.00","4000.00","4500.00","5000.00","6000.00")
     var imageArray = arrayOf<Int>(R.drawable.promen,R.drawable.loreal_bottl,R.drawable.loreal_bottl,R.drawable.promen,R.drawable.loreal_bottl)
     var d = arrayListOf<String>("fireboost","loreal","fireboost","professional","pantine")*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.product_list_activity_pur)


        net_status()            //Check internet status.



        val bundles = intent.extras
        var req = bundles!!.get("from_req").toString()


        search.setOnClickListener {      //Image button search  action
            cardsearch.visibility = View.VISIBLE
            if(spinner.selectedItemPosition==0){
                searchedit.setHint("Search in $supnm products" )
            }
            else if(spinner.selectedItemPosition==1){
                searchedit.setHint("Search in all products")
            }
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_request_add, R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }


        searback1.setOnClickListener {  //Image button search back action
            searchedit.setText("")
            cardsearch.visibility = View.GONE

            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_request_add, R.anim.slide_to_left))
            nores.visibility = View.GONE
            pur_product_list.visibility = View.VISIBLE
            progressBar3.visibility = View.GONE
            get()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }



                //Get purchase details from (RequestBottProActivity)

        if(req=="req_emptylist"){








            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }

            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch(e:Exception){

            }

            try{
                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            try {
                val a = intent.getStringExtra("reqid")
                reqid = a
                val ac = intent.getStringExtra("relids")
                liid = ac
                val b = intent.getStringExtra("reqname")
                reqnm = b
                val sta=intent.getStringExtra("status")
                status=sta
                val staky=intent.getStringExtra("brky")
                keysbr=staky
                val imgss=intent.getStringExtra("imlinks")
                imglinkss=imgss
            }
            catch (e:Exception){

            }


                val c=intent.getStringExtra("reqdate")
                reqdt=c



                val o=intent.getStringExtra("reqest")
                restimt=o
                val d=intent.getStringExtra("reqmail")
                reqmail=d

                val f=intent.getStringExtra("supnm")
                supnm=f



            val categories1 = ArrayList<String>()
            categories1.add("$supnm products")
            categories1.add("All products")
            val dataAdaptermob = ArrayAdapter(this@product_request_add, R.layout.support_simple_spinner_dropdown_item, categories1)
            dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = dataAdaptermob

                println("SUPPPP NNNNNAAAMMME"+supnm)
                val g=intent.getStringExtra("supadd1")
                supadd1=g
                val h=intent.getStringExtra("supadd2")
                supadd2=h
                val i=intent.getStringExtra("supadd3")
                supadd3=i
                val j=intent.getStringExtra("supcity")
                supcity=j
                val k=intent.getStringExtra("supstate")
                supstate=k
                val l=intent.getStringExtra("supph")
                supph=l
                val m=intent.getStringExtra("supgst")
                supgst=m
        }


        try{
            incompstr=intent.getStringExtra("incompstr")

        }
        catch (e:Exception){

        }


        try {
            val grochk = intent.getStringExtra("groschk")
            grosschk = grochk
        }
        catch (e:Exception){

        }

        try {
            edclick = intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }






        if(req=="req_datalist")
        {

            var a= bundles.get("namess") as ArrayList<String>
            println(a)
            /*     val b=bundle.get("id") as Array<String>*/
            val c=bundles.get("orderarray") as ArrayList<String>
            val ds=bundles.get("hsn") as ArrayList<String>
            /*    val l=bundle.get("item") as Array<String>*/
            val f=bundles.get("poarray")  as ArrayList<String>
            val g=bundles.get("complete") as ArrayList<String>
            val h=bundles.get("price") as ArrayList<String>
            val i=bundles.get("total") as ArrayList<String>
            val igro=bundles.get("grosstotal") as ArrayList<String>

            val j=bundles.get("cess") as ArrayList<String>
            val r=bundles.get("igst") as ArrayList<String>
            val p=bundles.get("cgst") as ArrayList<String>
            val sg=bundles.get("sgst") as ArrayList<String>
            val s=bundles.get("igsttotal") as ArrayList<String>
            val q=bundles.get("cesstotarray") as ArrayList<String>
            val qtall=bundles.get("tallyarray") as ArrayList<String>
            val rec=bundles.get("receivedarray") as ArrayList<String>
            val iddd=bundles.get("idsofli")      as ArrayList<String>
            val idpr= bundles.get("idpro") as ArrayList<String>

             ids=bundles.get("ids") as Array<String>

            try {
                val grochk = intent.getStringExtra("groschk")
                grosschk = grochk
            }
            catch(e:Exception){
                var a=0.0F
                grosschk = a.toString()

            }


            try{
                supplieridfr=intent.getStringExtra("supplieridfr")
            }
            catch (e:Exception){

            }

            try{
                befnm=intent.getStringExtra("befnm")
                request_datedup=intent.getStringExtra("request_datedup")
                reqest_datedup=intent.getStringExtra("reqest_datedup")
                supp_namedup=intent.getStringExtra("supp_namedup")
                supp_gstdup=intent.getStringExtra("supp_gstdup")
                supp_addredup=intent.getStringExtra("supp_addredup")
            }
            catch (e:Exception){

            }




            try{
                deletelistener=intent.getStringExtra("deletelistener")

            }
            catch(e:Exception){

            }


            //Purchase request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            try {
                val a = intent.getStringExtra("reqid")
                reqid = a
                val b = intent.getStringExtra("reqname")
                reqnm = b
                val sta=intent.getStringExtra("status")
                status=sta
                val stakys=intent.getStringExtra("brky")
                keysbr=stakys
                val imgss1=intent.getStringExtra("imlinks")
                imglinkss=imgss1
            }
            catch (e:Exception){

            }

            val lia=intent.getStringExtra("relids")
            liid=lia
            val ca=intent.getStringExtra("reqdate")
            reqdt=ca
            val nm=intent.getStringExtra("reprnms")
            prdnms=nm
            val o=intent.getStringExtra("reqest")
            restimt=o
            val d=intent.getStringExtra("reqmail")
            reqmail=d

            val fa=intent.getStringExtra("supnm")
            supnm=fa


            val categories1 = ArrayList<String>()
            categories1.add("$supnm products")
            categories1.add("All products")
            val dataAdaptermob = ArrayAdapter(this@product_request_add, R.layout.support_simple_spinner_dropdown_item, categories1)
            dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = dataAdaptermob


            println("SUPPPP NNNNNAAAMMME"+supnm)
            val ga=intent.getStringExtra("supadd1")
            supadd1=ga
            val ha=intent.getStringExtra("supadd2")
            supadd2=ha
            val ia=intent.getStringExtra("supadd3")
            supadd3=ia
            val ja=intent.getStringExtra("supcity")
            supcity=ja
            val ka=intent.getStringExtra("supstate")
            supstate=ka
            val l=intent.getStringExtra("supph")
            supph=l
            val m=intent.getStringExtra("supgst")
            supgst=m

            val k=bundles.get("im") as ArrayList<String>


            /*    val i=bundle.get("imageArray") as Array<String>*/
            pronameArrayori      = a
            hsnArrayori          = ds
            manufacturerArrayori =c
            barcodeArrayori      =f
            quantityArrayori     =g
            priceArrayori        =h
            totArrayori          =i
            grosstotArrayori          =igro

            receivedArrayori=rec
            cessArrayori         =j
            igstArrayori =r
            cgstArrayori =p
            sgstArrayori =sg
            igsttotArrayori=s
            cesstotalArrayori=q
            tallyArrayori=qtall
            imageArrayori         =k
            keyArrayori=iddd
            idproArrayori=idpr

            var ids=arrayOf<String>()

            /*     var n=nm.setText(namebr)
                 println(nm.text)
                 names=names.plusElement(n.toString())
                 println(names)


                var ah=loc.setText(locbr)
                 namesphones=namesphones.plusElement(ah.toString())
                 println(namesphones)*/



            /*   d.add(b.toString())*/





        }
/*
       if(frm=="pur_emptylist")
       {
           val namebr=intent.getStringExtra("branch")
           val locbr=intent.getStringExtra("address")
           val brkey=intent.getStringExtra("brnchid")
           purpro_nm.setText(namebr)
           println("BRANCH NAME"+purpro_nm.text)
           purpro_loc.setText(locbr)
           purpro_brnchkey.setText(brkey)
           keybrnch=purpro_brnchkey.text.toString()
           names=purpro_nm.text.toString()
           namesphones=purpro_loc.text.toString()
       }*/


        /*private fun addImageView(layout: LinearLayout) {
             val imageView = ImageView(this)
             imageView.setImageResource(R.drawable.ic_launcher)
             layout.addView(imageView)
         }*/


        try {
            edclick = intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }

        try{
            incompstr=intent.getStringExtra("incompstr")

        }
        catch (e:Exception){

        }




        ///--------------------------Single select on product lis------------------------------//


        pur_product_list.setOnItemClickListener { parent, views, position, id ->


            val az=pronameArray.get(position)
            val bz=hsnArray.get(position)
            val t = manufacturerArray.get(position)
            val cz=quantityArray.get(position)
            val mz=barcodeArray.get(position)
            val fz=priceArray.get(position)
            val oz=totArray.get(position)
            val ozgro=grosstotArray.get(position)

            val qz=cessArray.get(position)
            val qigz=igstArray.get(position)
            val higz=cgstArray.get(position)
            val digz=sgstArray.get(position)
            val qigtotz=igsttotArray.get(position)

            val qcesstotz=cesstotalArray.get(position)
            val qtallyz=tallyArray.get(position)
            val rece=receivedArray.get(position)
            val imz=imageArray.get(position)
            val li=keyArray.get(position)
            val idprz=idproArray.get(position)



            pronameArraycpy.add(az)
            manufacturerArraycpy.add(t)
            hsnArraycpy.add(bz)
            quantityArraycpy.add(cz)
            barcodeArraycpy.add(mz)
            priceArraycpy.add(fz)
            totArraycpy.add(oz)
            grosstotArraycpy.add(ozgro)

            cessArraycpy.add(qz)
            igstArraycpy.add(qigz)
            cgstArraycpy.add(higz)
            sgstArraycpy.add(digz)
            igsttotArraycpy.add(qigtotz)
            cesstotalArraycpy.add(qcesstotz)
            tallyArraycpy.add(qtallyz)
            receivedArraycpy.add(rece)
            imageArraycpy.add(imz.toString())
            idupArraycpy.add(li)
            imageArray.add(imli)
            idproArraycpy.add(idprz)


            var a=pronameArraycpy.toString()
            var atr=a.removeSurrounding("[","]")

            var bs=manufacturerArraycpy.toString()
            var btr=bs.removeSurrounding("[","]")

            var cs=hsnArraycpy.toString()
            var cstr=cs.removeSurrounding("[","]")

            var ds=quantityArraycpy.toString()
            var dstr=ds.removeSurrounding("[","]")

            var es=barcodeArraycpy.toString()
            var estr=es.removeSurrounding("[","]")

            var fs=priceArraycpy.toString()
            var fstr=fs.removeSurrounding("[","]")

            var gs=totArraycpy.toString()
            var gstr=gs.removeSurrounding("[","]")

            var gsgro=grosstotArraycpy.toString()
            var gstrgro=gsgro.removeSurrounding("[","]")

            var hs=cessArraycpy.toString()
            var hstr=hs.removeSurrounding("[","]")


            var ijs=igstArraycpy.toString()
            var ijsstr=ijs.removeSurrounding("[","]")


            var rjs=cgstArraycpy.toString()
            var rjsstr=rjs.removeSurrounding("[","]")


            var sjs=sgstArraycpy.toString()
            var sjsstr=sjs.removeSurrounding("[","]")





            var jjs=igsttotArraycpy.toString()
            var jjsstr=jjs.removeSurrounding("[","]")

            var kjs=cesstotalArraycpy.toString()
            var kjsstr=kjs.removeSurrounding("[","]")

            var ljs=tallyArraycpy.toString()
            var ljsstr=ljs.removeSurrounding("[","]")

            var mjs=receivedArraycpy.toString()
            var mjsstr=mjs.removeSurrounding("[","]")

            var njs=imageArraycpy.toString()
            var njsstr=njs.removeSurrounding("[","]")
            var idprss=idproArraycpy.toString()
            var idprsstr=idprss.removeSurrounding("[","]")


            pronameArrayori.add(atr)
            manufacturerArrayori.add(btr)
            hsnArrayori.add(cstr)
            quantityArrayori.add(dstr)
            barcodeArrayori.add(estr)
            priceArrayori.add(fstr)
            totArrayori.add(gstr)
            grosstotArrayori.add(gstrgro)

            cessArrayori.add(hstr)
            igstArrayori.add(ijsstr)
            cgstArrayori.add(rjsstr)
            sgstArrayori.add(sjsstr)
            igsttotArrayori.add(jjsstr)
            cesstotalArrayori.add(kjsstr)
            tallyArrayori.add(ljsstr)
            receivedArrayori.add(mjsstr)
            imageArrayori.add(njsstr)
            keyArrayori.add("")
            idproArrayori.add(idprsstr)
            namesori=names
            namesphonesori=namesphones


            grosschk="list"


            val b = Intent(applicationContext,RequestBottproActivity::class.java)
                    .putStringArrayListExtra("dlt",dlt)
            println(pronameArrayori)
            println(priceArrayori)

            b.putExtra("from_req","req_list_single")
            b.putExtra("req_pname",pronameArrayori)
            b.putExtra("req_pitem",manufacturerArrayori)
            b.putExtra("req_phsn",hsnArrayori)
            b.putExtra("req_porder",quantityArrayori)

            b.putExtra("req_pprice",priceArrayori)
            b.putExtra("req_ptot",totArrayori)
            b.putExtra("req_pgrosstot",grosstotArrayori)

            b.putExtra("req_poarray",barcodeArrayori)
            b.putExtra("req_cessarray",cessArrayori)
            b.putExtra("req_igstarray",igstArrayori)
            b.putExtra("req_cgstarray",cgstArrayori)
            b.putExtra("req_sgstarray",sgstArrayori)
            b.putExtra("req_igsttotarray",igsttotArrayori)
            b.putExtra("req_cesstotalarray",cesstotalArrayori)
            b.putExtra("req_tallyarray",tallyArrayori)
            b.putExtra("req_receivedarray",receivedArrayori)
            b.putExtra("req_reiddofli",keyArrayori)
            b.putExtra("req_id",reqid)
            b.putExtra("req_liid",liid)
            b.putExtra("req_prnms",prdnms)
            b.putExtra("req_date",reqdt)
            b.putExtra("req_name",reqnm)
            b.putExtra("req_mail",reqmail)
            b.putExtra("req_esti",restimt)
            b.putExtra("request_datedup",request_datedup)
            b.putExtra("reqest_datedup",reqest_datedup)
            b.putExtra("supp_namedup",supp_namedup)
            b.putExtra("supp_gstdup",supp_gstdup)
            b.putExtra("supp_addredup",supp_addredup)
            b.putExtra("befnm",befnm)
            b.putExtra("deletelistener",deletelistener)
            b.putExtra("req_supnm",supnm)
            b.putExtra("req_supadd1",supadd1)
            b.putExtra("req_supadd2",supadd2)
            b.putExtra("req_supadd3",supadd3)
            b.putExtra("req_supgst",supgst)
            b.putExtra("req_supcity",supcity)
            b.putExtra("req_supstate",supstate)
            b.putExtra("req_supph",supph)
            b.putExtra("req_imi",imageArrayori)
            b.putExtra("status",status)
            b.putExtra("groschk",grosschk)
            b.putExtra("brkys",keysbr)
            b.putExtra("imlinks",imglinkss)
            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)
            b.putExtra("edclick",edclick)
            b.putExtra("incompstr",incompstr)
            b.putExtra("idpro",idproArrayori)
            b.putExtra("ids",ids)
            b.putExtra("supplieridfr",supplieridfr)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)







            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()


        }

      /*  fun gets() {





            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            progressBar3.visibility = View.VISIBLE
            db.collection("product")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                        var  pronameArraydup       = arrayListOf<String>()
                        var  hsnArraydup           = arrayListOf<String>()
                        var  manufacturerArraydup  = arrayListOf<String>()

                        var  barcodeArraydup       = arrayListOf<String>()
                        var  quantityArraydup      = arrayListOf<String>()
                        var  priceArraydup         = arrayListOf<String>()
                        var  totArraydup           = arrayListOf<String>()
                        var  grosstotArraydup      = arrayListOf<String>()

                        var  cessArraydup          = arrayListOf<String>()
                        var  imageArraydup         = arrayListOf<String>()
                        var  igstArraydup          = arrayListOf<String>()
                        var  cgstArraydup          = arrayListOf<String>()

                        var  sgstArraydup          = arrayListOf<String>()
                        var  igsttotArraydup         = arrayListOf<String>()
                        var  cesstotalArraydup         = arrayListOf<String>()

                        var receivedArraydup = arrayListOf<String>()
                        var tallyArraydup = arrayListOf<String>()
                        var keyArraydup=arrayListOf<String>()
                        var idproArraydup=arrayListOf<String>()
                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()



                        pronameArray       = pronameArraydup
                        hsnArray           = hsnArraydup
                        manufacturerArray  = manufacturerArraydup
                        barcodeArray       = barcodeArraydup
                        quantityArray      = quantityArraydup
                        priceArray         = priceArraydup
                        totArray           = totArraydup
                        grosstotArray           = grosstotArraydup

                        cessArray          = cessArraydup
                        imageArray         = imageArraydup
                        igstArray         = igstArraydup
                        cgstArray         = cgstArraydup
                        sgstArray         = sgstArraydup
                        igsttotArray         = igsttotArraydup
                        cesstotalArray         = cesstotalArraydup
                        receivedArray = receivedArraydup
                        tallyArray = tallyArraydup
                        keyArray=keyArraydup
                        idproArray=idproArraydup


                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data


                                var kk=document.id

                                if(!idproArrayori.contains(kk)) {




                                    pur_product_list.visibility = View.VISIBLE
                                    progressBar3.visibility = View.GONE
                                    already.visibility = View.GONE
                                    idproArray.add(document.id)



                                    var statuss = dd["status"].toString()

                                    var supky=dd["supp_key"].toString()

                                    if (statuss == "Active") {

                                        if(supky!=supplieridfr) {


                                            var prnm = (dd["p_nm"].toString() + " - " + dd["wg_vol"].toString() + "ml")

                                            if (prnm.isNotEmpty()) {

                                                pronameArray.add(prnm)
                                            } else {
                                                pronameArray.add("No title")
                                            }

                                            val high = dd["img1urlhigh"].toString()
                                            val highnm = dd["img1nhigh"].toString()
                                            icohighnmArray = icohighnmArray.plusElement(highnm)
                                            icohighArray = icohighArray.plusElement(high)


                                            var manu = (dd["mfr"].toString())

                                            if ((manu.isNotEmpty()) && (manu != "Select")) {
                                                manufacturerArray.add(manu)

                                            } else if (manu == "Select") {
                                                manufacturerArray.add("MFR - Not Available")
                                            }

                                            var hsn = (dd["hsn"].toString())

                                            if (hsn.isNotEmpty()) {
                                                hsnArray.add(hsn)

                                            } else {
                                                hsnArray.add("0")
                                            }

                                            quantityArray.add("1")




                                            priceArray.add(dd["price"].toString())

                                            var tot = (dd["price"].toString())

                                            if ((tot.isNotEmpty()) && (tot.contains("."))) {
                                                totArray.add(tot)

                                            } else if ((tot.isNotEmpty()) && (!tot.contains("."))) {
                                                totArray.add(tot + ".00")
                                            } else {
                                                totArray.add("0.0")
                                            }

                                            var totgro = (dd["mrp"].toString())

                                            if ((totgro.isNotEmpty()) && (totgro.contains("."))) {
                                                grosstotArray.add(totgro)

                                            } else if ((totgro.isNotEmpty()) && (!totgro.contains("."))) {
                                                grosstotArray.add(totgro + ".00")
                                            } else {
                                                grosstotArray.add("0.0")
                                            }


                                            var bc = (dd["bc"].toString())

                                            if (bc.isNotEmpty()) {
                                                barcodeArray.add(bc)

                                            } else {
                                                barcodeArray.add("Not Available")
                                            }

                                            var cessarr = (dd["cess"].toString())

                                            if (cessarr.isNotEmpty()) {
                                                cessArray.add(cessarr)

                                            } else {
                                                cessArray.add("0.0")
                                            }

                                            var igst = (dd["igst"].toString())
                                            if (igst.isNotEmpty()) {
                                                igstArray.add(igst)

                                            } else {
                                                igstArray.add("0.0")
                                            }

                                            var cgst = (dd["cgst"].toString())

                                            if (cgst.isNotEmpty()) {
                                                cgstArray.add(cgst)

                                            } else {
                                                cgstArray.add("0.0")
                                            }

                                            var sgst = (dd["sgst"].toString())

                                            if (sgst.isNotEmpty()) {
                                                sgstArray.add(sgst)

                                            } else {
                                                sgstArray.add("0.0")
                                            }

                                            var igsttot = (dd["taxtot"].toString())

                                            if (igsttot.isNotEmpty()) {
                                                igsttotArray.add(igsttot)

                                            } else {
                                                igsttotArray.add("0.0")
                                            }

                                            var cesstotal = (dd["cesstot"].toString())

                                            if (cesstotal.isNotEmpty()) {
                                                cesstotalArray.add(cesstotal)

                                            } else {
                                                cesstotalArray.add("0.0")
                                            }
                                            tallyArray.add("InComplete")

                                            receivedArray.add("")
                                            try {
                                                var im = dd["img1url"].toString()

                                                if (im.isNotEmpty()) {

                                                    imageArray.add(im)
                                                    imli = im
                                                } else {
                                                    imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                    imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                }
                                            } catch (e: Exception) {

                                            }
                                            keyArray.add("")

                                            d.add(document.id.toString())
                                            *//*  swipeContainer.setRefreshing(false);*//*

                                            pDialog.dismiss()
                                        }
                                    } else {
                                        *//*swipeContainer.setRefreshing(false);*//*

                                        pDialog.dismiss()
                                    }

                                    println("Array of idspro if"+idproArray)
                                }
                                else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                {



                                    println("Array of idspro else if"+idproArray)
                                    pDialog.dismiss()
                                    pur_product_list.visibility = View.GONE
                                    progressBar3.visibility = View.GONE
                                    already.visibility = View.VISIBLE

                                }


                                val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                                        priceArray, totArray, cessArray,keyArray,igstArray,cgstArray,sgstArray, igsttotArray, cesstotalArray,
                                        tallyArray, receivedArray, imageArray,icohighnmArray,icohighArray)
                                pur_product_list.adapter = whatever
                                progressBar3.visibility = View.GONE
                            }
                        }
                        else{

                        }
                    })


            println("AZ"+pronameArray)




        }*/



        fun gets() {


            //--------------------------Get and list out the products from db.--------------------------------------//



            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            nores.visibility = View.GONE
            progressBar3.visibility = View.VISIBLE
            db.collection("product")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                        var  pronameArraydup       = arrayListOf<String>()
                        var  hsnArraydup           = arrayListOf<String>()
                        var  manufacturerArraydup  = arrayListOf<String>()

                        var  barcodeArraydup       = arrayListOf<String>()
                        var  quantityArraydup      = arrayListOf<String>()
                        var  priceArraydup         = arrayListOf<String>()
                        var  totArraydup           = arrayListOf<String>()
                        var  grosstotArraydup      = arrayListOf<String>()

                        var  cessArraydup          = arrayListOf<String>()
                        var  imageArraydup         = arrayListOf<String>()
                        var  igstArraydup          = arrayListOf<String>()
                        var  cgstArraydup          = arrayListOf<String>()

                        var  sgstArraydup          = arrayListOf<String>()
                        var  igsttotArraydup         = arrayListOf<String>()
                        var  cesstotalArraydup         = arrayListOf<String>()

                        var receivedArraydup = arrayListOf<String>()
                        var tallyArraydup = arrayListOf<String>()
                        var keyArraydup=arrayListOf<String>()
                        var idproArraydup=arrayListOf<String>()
                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()



                        pronameArray       = pronameArraydup
                        hsnArray           = hsnArraydup
                        manufacturerArray  = manufacturerArraydup
                        barcodeArray       = barcodeArraydup
                        quantityArray      = quantityArraydup
                        priceArray         = priceArraydup
                        totArray           = totArraydup
                        grosstotArray           = grosstotArraydup

                        cessArray          = cessArraydup
                        imageArray         = imageArraydup
                        igstArray         = igstArraydup
                        cgstArray         = cgstArraydup
                        sgstArray         = sgstArraydup
                        igsttotArray         = igsttotArraydup
                        cesstotalArray         = cesstotalArraydup
                        receivedArray = receivedArraydup
                        tallyArray = tallyArraydup
                        keyArray=keyArraydup
                        idproArray=idproArraydup


                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data


                                var kk=document.id

                                if(!idproArrayori.contains(kk)) {



                                    spinner.visibility=View.VISIBLE
                                   nores.visibility=View.INVISIBLE

                                    pur_product_list.visibility = View.VISIBLE
                                    progressBar3.visibility = View.GONE
                                    already.visibility = View.GONE
                                    textView52.visibility=View.GONE
                                    idproArray.add(document.id)



                                    var statuss = dd["status"].toString()

                                    if (statuss == "Active") {



                                        var prnm = (dd["p_nm"].toString())

                                        var wgvols=(dd["wg_vol"].toString())
                                        var uts=(dd["ut"].toString())

                                        if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                            prnm=prnm+" - "+wgvols+" "+uts
                                        }

                                        else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                            prnm=prnm
                                        }
                                        else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                            prnm=prnm
                                        }
                                        else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                            prnm=prnm
                                        }
                                        else{
                                            prnm=prnm
                                        }

                                        if (prnm.isNotEmpty()) {

                                            pronameArray.add(prnm)
                                        } else {
                                            pronameArray.add("No title")
                                        }

                                        val high = dd["img1urlhigh"].toString()
                                        val highnm = dd["img1nhigh"].toString()
                                        icohighnmArray=icohighnmArray.plusElement(highnm)
                                        icohighArray=icohighArray.plusElement(high)


                                        var manu = (dd["mfr"].toString())

                                        if ((manu.isNotEmpty())&&(manu!="Select")) {
                                            manufacturerArray.add(manu)

                                        } else if(manu=="Select") {
                                            manufacturerArray.add("MFR - Not Available")
                                        }

                                        var hsn = (dd["hsn"].toString())

                                        if (hsn.isNotEmpty()) {
                                            hsnArray.add(hsn)

                                        } else {
                                            hsnArray.add("0")
                                        }

                                        quantityArray.add("1")




                                        priceArray.add(dd["price"].toString())

                                        var tot = (dd["price"].toString())

                                        if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                            totArray.add(tot)

                                        }
                                        else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                            totArray.add(tot+".00")
                                        }
                                        else {
                                            totArray.add("0.0")
                                        }

                                        var totgro = (dd["mrp"].toString())

                                        if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                            grosstotArray.add(totgro)

                                        }
                                        else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                            grosstotArray.add(totgro+".00")
                                        }
                                        else {
                                            grosstotArray.add("0.0")
                                        }







                                        var bc = (dd["bc"].toString())

                                        if (bc.isNotEmpty()) {
                                            barcodeArray.add(bc)

                                        } else {
                                            barcodeArray.add("Not Available")
                                        }

                                        var cessarr = (dd["cess"].toString())

                                        if (cessarr.isNotEmpty()) {
                                            cessArray.add(cessarr)

                                        } else {
                                            cessArray.add("0.0")
                                        }

                                        var igst = (dd["igst"].toString())
                                        if (igst.isNotEmpty()) {
                                            igstArray.add(igst)

                                        } else {
                                            igstArray.add("0.0")
                                        }

                                        var cgst = (dd["cgst"].toString())

                                        if (cgst.isNotEmpty()) {
                                            cgstArray.add(cgst)

                                        } else {
                                            cgstArray.add("0.0")
                                        }

                                        var sgst = (dd["sgst"].toString())

                                        if (sgst.isNotEmpty()) {
                                            sgstArray.add(sgst)

                                        } else {
                                            sgstArray.add("0.0")
                                        }

                                        var igsttot = (dd["taxtot"].toString())

                                        if (igsttot.isNotEmpty()) {
                                            igsttotArray.add(igsttot)

                                        } else {
                                            igsttotArray.add("0.0")
                                        }

                                        var cesstotal = (dd["cesstot"].toString())

                                        if (cesstotal.isNotEmpty()) {
                                            cesstotalArray.add(cesstotal)

                                        } else {
                                            cesstotalArray.add("0.0")
                                        }
                                        tallyArray.add("InComplete")

                                        receivedArray.add("")
                                        try {
                                            var im = dd["img1url"].toString()

                                            if (im.isNotEmpty()) {

                                                imageArray.add(im)
                                                imli = im
                                            } else {
                                                imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                            }
                                        } catch (e: Exception) {

                                        }
                                        keyArray.add("")

                                        d.add(document.id.toString())
                                        /*  swipeContainer.setRefreshing(false);*/

                                        pDialog.dismiss()
                                    } else {
                                        /*swipeContainer.setRefreshing(false);*/

                                        pDialog.dismiss()
                                    }

                                    println("Array of idspro if"+idproArray)
                                }
                                else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                {



                                    println("Array of idspro else if"+idproArray)
                                    pDialog.dismiss()
                                    pur_product_list.visibility = View.INVISIBLE
                                    progressBar3.visibility = View.GONE
                                    already.visibility = View.VISIBLE

                                }

                                nores.visibility=View.GONE
                                val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                                        priceArray, totArray, cessArray,keyArray,igstArray,cgstArray,sgstArray, igsttotArray, cesstotalArray,
                                        tallyArray, receivedArray, imageArray,icohighnmArray,icohighArray)
                                pur_product_list.adapter = whatever
                                progressBar3.visibility = View.GONE
                            }
                        }
                        else{
                            pDialog.dismiss()

                        }
                    })


            println("AZ"+pronameArray)




        }





/*
        if(pronameArray.isNotEmpty()){
            gets()
        }*/



        ///------------------------ Multi select the products to (RequestBottproActivity)----------------------------------------///


        pur_product_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        pur_product_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = pur_product_list.getCheckedItemCount()
                val l = d.get(position)
                val az=pronameArray.get(position)
                val bz=hsnArray.get(position)
                val t = manufacturerArray.get(position)
                val cz=quantityArray.get(position)
                val mz=barcodeArray.get(position)
                val fz=priceArray.get(position)
                val oz=totArray.get(position)
                val ozgro=grosstotArray.get(position)
                val qz=cessArray.get(position)
                val qigz=igstArray.get(position)
                val higz=cgstArray.get(position)
                val digz=sgstArray.get(position)
                val qigtotz=igsttotArray.get(position)

                val qcesstotz=cesstotalArray.get(position)
                val qtallyz=tallyArray.get(position)
                val rece=receivedArray.get(position)
                val imz=imageArray.get(position)
                val li=keyArray.get(position)
                val idp=idproArray.get(position)

                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                val tex =CircleImageView(this@product_request_add)
                val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                textLayoutParams.setMargins(20, 0, 0, 0)
                textLayoutParams.height=100
                textLayoutParams.width=100
                tex.setBorderColor(Color.BLACK)
                tex.setBorderWidth(1)
                tex.setPadding(4,4,4,4)
                tex.setLayoutParams(textLayoutParams)
                try {
                    Picasso.with(this@product_request_add)
                            .load(imageArray[position])
                            .into(tex);
                }
                catch (e:Exception){

                }
                /*     tex.setImageResource(imli)*/
                tex.setTag(l)
                linearlayout.setGravity(Gravity.CENTER)
                tex.setOnClickListener {
                    val r = linearlayout.findViewWithTag<View>(l)
                    linearlayout.removeView(r)
                    Log.d("list","    "+pur_product_list.setItemChecked(position,false))
                }
                if (checked) {
                    // list_item.add(id.toString()) // Add to list when checked ==  true

                    dlt.add(l)
                    pronameArraycpy.add(az)
                    manufacturerArraycpy.add(t)
                    hsnArraycpy.add(bz)
                    quantityArraycpy.add(cz)
                    barcodeArraycpy.add(mz)
                    priceArraycpy.add(fz)
                    totArraycpy.add(oz)
                    grosstotArraycpy.add(ozgro)

                    cessArraycpy.add(qz)
                    igstArraycpy.add(qigz)
                    cgstArraycpy.add(higz)
                    sgstArraycpy.add(digz)
                    igsttotArraycpy.add(qigtotz)
                    cesstotalArraycpy.add(qcesstotz)
                    tallyArraycpy.add(qtallyz)
                    receivedArraycpy.add(rece)
                    imageArraycpy.add(imz.toString())
                    idupArraycpy.add(li)

                    idproArraycpy.add(idp)

                    Log.i(TAG,"itm "+dlt.size)
                    Log.d("list","    "+pur_product_list.getCheckedItemPositions())
                    linearlayout.addView(tex)
                    horizontalScrollView.visibility=View.VISIBLE
                } else {
                    val r = linearlayout.findViewWithTag<View>(l)
                    dlt.remove(l)
                    pronameArraycpy.remove(az)
                    manufacturerArraycpy.remove(t)
                    hsnArraycpy.remove(bz)
                    quantityArraycpy.remove(cz)
                    barcodeArraycpy.remove(mz)
                    priceArraycpy.remove(fz)
                    totArraycpy.remove(oz)
                    grosstotArraycpy.remove(ozgro)

                    cessArraycpy.remove(qz)
                    igstArraycpy.remove(qigz)
                    cgstArraycpy.remove(higz)
                    sgstArraycpy.remove(digz)
                    igsttotArraycpy.remove(qigtotz)
                    cesstotalArraycpy.remove(qcesstotz)
                    tallyArraycpy.remove(qtallyz)
                    receivedArraycpy.remove(rece)
                    imageArraycpy.remove(imz.toString())
                    idupArraycpy.remove(li)
                    idproArraycpy.remove(idp)

                    /*       imageArray=imageArray.plusElement(R.drawable.loreal_bottl)*/


                    Log.d("tag","   "+r)
                    linearlayout.removeView(r)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                    Log.d(TAG,"id  "+position)
                }


            }


            override fun onCreateActionMode(mode: ActionMode, menu: Menu):Boolean {
                //Inflate the CAB
                pur_product_list_toolbar.visibility = View.GONE
                search.visibility=View.GONE
                if(cardsearch.visibility==View.VISIBLE) {
                    searchedit.setText("")
                    cardsearch.visibility = View.GONE

                    cardsearch.startAnimation(AnimationUtils.loadAnimation(this@product_request_add, R.anim.slide_to_left))
                }
                product_page_title.visibility=View.GONE
                product_list_back_btn.visibility=View.GONE

                mode.getMenuInflater().inflate(R.menu.product_select, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu):Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem):Boolean {
                val deleteSize =dlt.size
                Log.i("tsdfs","  "+dlt.size)
                /*val cate = null
                val data = s(cat = cate)*/
                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                grosschk="list"
                val itemId = item.getItemId()
                if (itemId == R.id.ok) {
                    println(pronameArraycpy.size)
                    //if (this@product_list_activity.equals("product_list_activity"))
                    for(i in 0 until pronameArraycpy.size)
                    {
                        pronameArrayori.add(pronameArraycpy.get(i))
                        manufacturerArrayori.add(manufacturerArraycpy.get(i))
                        hsnArrayori.add(hsnArraycpy.get(i))
                        quantityArrayori.add(quantityArraycpy.get(i))
                        barcodeArrayori.add(barcodeArraycpy.get(i))
                        priceArrayori.add(priceArraycpy.get(i))
                        totArrayori.add(totArraycpy.get(i))
                        grosstotArrayori.add(grosstotArraycpy.get(i))

                        cessArrayori.add(cessArraycpy.get(i))
                        igstArrayori.add(igstArraycpy.get(i))
                        cgstArrayori.add(cgstArraycpy.get(i))
                        sgstArrayori.add(sgstArraycpy.get(i))
                        igsttotArrayori.add(igsttotArraycpy.get(i))
                        cesstotalArrayori.add(cesstotalArraycpy.get(i))
                        tallyArrayori.add(tallyArraycpy.get(i))
                        receivedArrayori.add(receivedArraycpy.get(i))
                        imageArrayori.add(imageArraycpy.get(i))
                        keyArrayori.add("")
                        idproArrayori.add(idproArraycpy.get(i))

                        namesori=names
                        namesphonesori=namesphones
                        println(pronameArraycpy.lastIndex)
                        if(pronameArraycpy.lastIndex == i)
                        {
                            Log.d("fdgshgtgh","NAMESSSSSSSSSSSSSSSSS             "   + pronameArrayori)
                        }
                    }
                    val b = Intent(applicationContext,RequestBottproActivity::class.java)
                            .putStringArrayListExtra("dlt",dlt)
                    println(pronameArrayori)
                    println(priceArrayori)

                    b.putExtra("from_req","req_list")
                    b.putExtra("req_pname",pronameArrayori)
                    b.putExtra("req_pitem",manufacturerArrayori)
                    b.putExtra("req_phsn",hsnArrayori)
                    b.putExtra("req_porder",quantityArrayori)

                    b.putExtra("req_pprice",priceArrayori)
                    b.putExtra("req_ptot",totArrayori)
                    b.putExtra("req_pgrosstot",grosstotArrayori)

                    b.putExtra("req_poarray",barcodeArrayori)
                    b.putExtra("req_cessarray",cessArrayori)
                    b.putExtra("req_igstarray",igstArrayori)
                    b.putExtra("req_cgstarray",cgstArrayori)
                    b.putExtra("req_sgstarray",sgstArrayori)
                    b.putExtra("req_igsttotarray",igsttotArrayori)
                    b.putExtra("req_cesstotalarray",cesstotalArrayori)
                    b.putExtra("req_tallyarray",tallyArrayori)
                    b.putExtra("req_receivedarray",receivedArrayori)
                    b.putExtra("req_reiddofli",keyArrayori)
                    b.putExtra("idpro",idproArrayori)

                    b.putExtra("req_id",reqid)
                    b.putExtra("req_liid",liid)
                    b.putExtra("req_prnms",prdnms)
                    b.putExtra("req_date",reqdt)
                    b.putExtra("req_name",reqnm)
                    b.putExtra("req_mail",reqmail)
                    b.putExtra("req_esti",restimt)

                    b.putExtra("req_supnm",supnm)
                    b.putExtra("req_supadd1",supadd1)
                    b.putExtra("req_supadd2",supadd2)
                    b.putExtra("req_supadd3",supadd3)
                    b.putExtra("req_supgst",supgst)
                    b.putExtra("req_supcity",supcity)
                    b.putExtra("req_supstate",supstate)
                    b.putExtra("req_supph",supph)
                    b.putExtra("req_imi",imageArrayori)
                    b.putExtra("status",status)
                    b.putExtra("groschk",grosschk)
                    b.putExtra("brkys",keysbr)
                    b.putExtra("imlinks",imglinkss)
                    b.putExtra("deletelistener",deletelistener)
                    b.putExtra("supplieridfr",supplieridfr)

                    b.putExtra("edclick",edclick)
                    b.putExtra("incompstr",incompstr)

                    b.putExtra("viewsuppin", viewsuppin)
                    b.putExtra("addsuppin", addsuppin)
                    b.putExtra("deletesuppin", deletesuppin)
                    b.putExtra("editsuppin", editesuppin)
                    b.putExtra("transfersuppin", transfersuppin)
                    b.putExtra("exportsuppin", exportsuppin)
                    b.putExtra("request_datedup",request_datedup)
                    b.putExtra("reqest_datedup",reqest_datedup)
                    b.putExtra("supp_namedup",supp_namedup)
                    b.putExtra("supp_gstdup",supp_gstdup)
                    b.putExtra("supp_addredup",supp_addredup)
                    b.putExtra("befnm",befnm)

                    b.putExtra("viewpurord", viewpurord)
                    b.putExtra("addpurord", addpurord)
                    b.putExtra("deletepurord", deletepurord)
                    b.putExtra("editpurord", editepurord)
                    b.putExtra("transferpurord", transferpurord)
                    b.putExtra("exportpurord", exportpurord)
                    b.putExtra("sendpurord", sendpurpo)




                    b.putExtra("viewpurreq", viewpurreq)
                    b.putExtra("addpurreq", addpurreq)
                    b.putExtra("deletepurreq", deletepurreq)
                    b.putExtra("editpurreq", editepurreq)
                    b.putExtra("transferpurreq", transferpurreq)
                    b.putExtra("exportpurreq", exportpurreq)





                    b.putExtra("ids",ids)

                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()


                    /*for (i in dlt) {
                        Log.d("dlt","  "+i)
                    }*/
                }
                /* checkedCount = 0*/
                // list_item.clear()


                return true
            }
            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                linearlayout.removeAllViews()
                product_page_title.visibility=View.VISIBLE
                product_list_back_btn.visibility=View.VISIBLE
                pur_product_list_toolbar.visibility =View.VISIBLE
                horizontalScrollView.visibility=View.GONE

            }
        })



      /*  swipeContainer.setOnRefreshListener {

            get()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/



        product_list_back_btn.setOnClickListener {

            //back action

            val b = Intent(applicationContext,RequestBottproActivity::class.java)
                    .putStringArrayListExtra("dlt",dlt)
            println(pronameArrayori)
            println(priceArrayori)

            b.putExtra("from_req","req_list")
            b.putExtra("req_pname",pronameArrayori)
            b.putExtra("req_pitem",manufacturerArrayori)
            b.putExtra("req_phsn",hsnArrayori)
            b.putExtra("req_porder",quantityArrayori)
            b.putExtra("idpro",idproArrayori)
            b.putExtra("edclick",edclick)
            b.putExtra("incompstr",incompstr)

            b.putExtra("req_pprice",priceArrayori)
            b.putExtra("req_ptot",totArrayori)
            b.putExtra("req_pgrosstot",grosstotArrayori)

            b.putExtra("req_poarray",barcodeArrayori)
            b.putExtra("req_cessarray",cessArrayori)
            b.putExtra("req_igstarray",igstArrayori)
            b.putExtra("req_cgstarray",cgstArrayori)
            b.putExtra("req_sgstarray",sgstArrayori)
            b.putExtra("req_igsttotarray",igsttotArrayori)
            b.putExtra("req_cesstotalarray",cesstotalArrayori)
            b.putExtra("req_tallyarray",tallyArrayori)
            b.putExtra("req_receivedarray",receivedArrayori)
            b.putExtra("req_reiddofli",keyArrayori)
            b.putExtra("req_id",reqid)
            b.putExtra("req_liid",liid)
            b.putExtra("req_prnms",prdnms)
            b.putExtra("req_date",reqdt)
            b.putExtra("req_name",reqnm)
            b.putExtra("req_mail",reqmail)
            b.putExtra("req_esti",restimt)
            b.putExtra("deletelistener",deletelistener)

            b.putExtra("request_datedup",request_datedup)
            b.putExtra("reqest_datedup",reqest_datedup)
            b.putExtra("supp_namedup",supp_namedup)
            b.putExtra("supp_gstdup",supp_gstdup)
            b.putExtra("supp_addredup",supp_addredup)
            b.putExtra("befnm",befnm)
            b.putExtra("supplieridfr",supplieridfr)

            b.putExtra("req_supnm",supnm)
            b.putExtra("req_supadd1",supadd1)
            b.putExtra("req_supadd2",supadd2)
            b.putExtra("req_supadd3",supadd3)
            b.putExtra("req_supgst",supgst)
            b.putExtra("req_supcity",supcity)
            b.putExtra("req_supstate",supstate)
            b.putExtra("req_supph",supph)
            b.putExtra("req_imi",imageArrayori)
            b.putExtra("status",status)
            b.putExtra("groschk",grosschk)
            b.putExtra("brkys",keysbr)
            b.putExtra("imlinks",imglinkss)

            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)





            b.putExtra("ids",ids)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }


        get()



        //Select product list option - 'Supplier product' or 'All products'

        spinner.onItemSelectedListener=object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {
                return
            }
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                if(spinner.selectedItemPosition==0){
                    searchedit.setHint("Search in $supnm products")
                    get()
                }
                else if(spinner.selectedItemPosition==1){
                    searchedit.setHint("Search in all products")

                    gets()
                }

            }
        }


        //---------------------------------------SEARCH ----------------------------------------------------------//

        searchedit.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {


                progressBar3.visibility = View.VISIBLE
                pur_product_list.visibility = View.INVISIBLE
              
                nores.visibility = View.GONE

                if(searchedit.length()==0){
                    nores.visibility = View.GONE
                }

                sd = des.toString()
                x = sd
                val ps = "^[a-zA-Z ]+$"
                val regexStr = "^[0-9]*$"
                val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";


                fun priget() {

                    nores.visibility = View.GONE

                    if ((des.length >= 2)&&(spinner.selectedItemPosition==0)) {
                        db.collection("product").orderBy("price").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {


                                                spinner.visibility=View.VISIBLE

                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                idproArraydup.add(document.id)
                                                nores.visibility = View.GONE


                                                var statuss = dd["status"].toString()
                                                var supky=dd["supp_key"].toString()

                                                if ((statuss == "Active")&&(supky==supplieridfr)) {



                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                                nores.visibility=View.INVISIBLE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE

                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
                                        println("PRICE ELSE")
                                        if(searchedit.text.toString().isNotEmpty()){
                                            nores.visibility=View.VISIBLE
                                        }

                                        progressBar3.visibility = View.GONE

                                    }
                                })

                    }
                    else if((des.length >= 2)&&(spinner.selectedItemPosition==1)){
                        nores.visibility = View.GONE

                        db.collection("product").orderBy("price").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {



                                                spinner.visibility=View.VISIBLE
                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                idproArraydup.add(document.id)
                                                nores.visibility = View.GONE


                                                var statuss = dd["status"].toString()

                                                if (statuss == "Active") {


                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                                nores.visibility=View.INVISIBLE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE

                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
                                        println("PRICE ELSE")

                                        if(searchedit.text.toString().isNotEmpty()){
                                            nores.visibility=View.VISIBLE
                                        }
                                        progressBar3.visibility = View.GONE


                                    }
                                })
                    }
                }

                fun bcodeget() {

                    nores.visibility = View.GONE

                    if ((des.length >= 3) && (bcd == "bcode")&&(spinner.selectedItemPosition==0)) {

                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {



                                                spinner.visibility=View.VISIBLE
                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                nores.visibility = View.GONE
                                                idproArraydup.add(document.id)



                                                var statuss = dd["status"].toString()

                                                var supky=dd["supp_key"].toString()

                                                if ((statuss == "Active")&&(supky==supplieridfr)){



                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                                nores.visibility=View.GONE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE

                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
                                        println("BCODE ELSE")

priget()
                                    }
                                })


                        println("AZ"+pronameArray)



                                            }
                    else if(((des.length >= 3) && (bcd == "bcode")&&(spinner.selectedItemPosition==1))) {
                        nores.visibility = View.GONE

                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {



                                                spinner.visibility=View.VISIBLE
                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                idproArraydup.add(document.id)
                                                nores.visibility = View.GONE


                                                var statuss = dd["status"].toString()

                                                if (statuss == "Active") {



                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                               nores.visibility=View.INVISIBLE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE

                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
priget()
                                        println("BCODE ELSE")

                                    }
                                })

                    }
                                        }













                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    bcd = "bcode"
                    bcodeget()
                    //write code here for success
                }
                fun nameget() {
                    nores.visibility = View.GONE

                    if ((des.length >= 3) && (x != reg)&&(spinner.selectedItemPosition==0)) {
                        db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {



                                                spinner.visibility=View.VISIBLE
                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                idproArraydup.add(document.id)
                                                nores.visibility = View.INVISIBLE


                                                var statuss = dd["status"].toString()

                                                var supky=dd["supp_key"].toString()

                                                if ((statuss == "Active")&&(supky==supplieridfr)){



                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                               nores.visibility=View.INVISIBLE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE

                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {

                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                            val dd = document.data


                                                            var kk=document.id

                                                            if(!idproArrayori.contains(kk)) {



                                                                spinner.visibility=View.VISIBLE
                                                                pur_product_list.visibility = View.VISIBLE
                                                                progressBar3.visibility = View.GONE
                                                                textView52.visibility=View.INVISIBLE
                                                                already.visibility = View.GONE
                                                                idproArraydup.add(document.id)
                                                                nores.visibility = View.GONE


                                                                var statuss = dd["status"].toString()
                                                                var supky=dd["supp_key"].toString()

                                                                if ((statuss == "Active")&&(supky==supplieridfr)){



                                                                    var prnm = (dd["p_nm"].toString())

                                                                    var wgvols=(dd["wg_vol"].toString())
                                                                    var uts=(dd["ut"].toString())

                                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                                    }

                                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else{
                                                                        prnm=prnm
                                                                    }

                                                                    if (prnm.isNotEmpty()) {

                                                                        pronameArraydup.add(prnm)
                                                                    } else {
                                                                        pronameArraydup.add("No title")
                                                                    }

                                                                    val high = dd["img1urlhigh"].toString()
                                                                    val highnm = dd["img1nhigh"].toString()
                                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                                    icohighArray=icohighArray.plusElement(high)


                                                                    var manu = (dd["mfr"].toString())

                                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                                        manufacturerArraydup.add(manu)

                                                                    } else if(manu=="Select") {
                                                                        manufacturerArraydup.add("MFR - Not Available")
                                                                    }

                                                                    var hsn = (dd["hsn"].toString())

                                                                    if (hsn.isNotEmpty()) {
                                                                        hsnArraydup.add(hsn)

                                                                    } else {
                                                                        hsnArraydup.add("0")
                                                                    }

                                                                    quantityArraydup.add("1")




                                                                    priceArraydup.add(dd["price"].toString())

                                                                    var tot = (dd["price"].toString())

                                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                                        totArraydup.add(tot)

                                                                    }
                                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                                        totArraydup.add(tot+".00")
                                                                    }
                                                                    else {
                                                                        totArraydup.add("0.0")
                                                                    }

                                                                    var totgro = (dd["mrp"].toString())

                                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                                        grosstotArraydup.add(totgro)

                                                                    }
                                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                                        grosstotArraydup.add(totgro+".00")
                                                                    }
                                                                    else {
                                                                        grosstotArraydup.add("0.0")
                                                                    }







                                                                    var bc = (dd["bc"].toString())

                                                                    if (bc.isNotEmpty()) {
                                                                        barcodeArraydup.add(bc)

                                                                    } else {
                                                                        barcodeArraydup.add("Not Available")
                                                                    }

                                                                    var cessarr = (dd["cess"].toString())

                                                                    if (cessarr.isNotEmpty()) {
                                                                        cessArraydup.add(cessarr)

                                                                    } else {
                                                                        cessArraydup.add("0.0")
                                                                    }

                                                                    var igst = (dd["igst"].toString())
                                                                    if (igst.isNotEmpty()) {
                                                                        igstArraydup.add(igst)

                                                                    } else {
                                                                        igstArraydup.add("0.0")
                                                                    }

                                                                    var cgst = (dd["cgst"].toString())

                                                                    if (cgst.isNotEmpty()) {
                                                                        cgstArraydup.add(cgst)

                                                                    } else {
                                                                        cgstArraydup.add("0.0")
                                                                    }

                                                                    var sgst = (dd["sgst"].toString())

                                                                    if (sgst.isNotEmpty()) {
                                                                        sgstArraydup.add(sgst)

                                                                    } else {
                                                                        sgstArraydup.add("0.0")
                                                                    }

                                                                    var igsttot = (dd["taxtot"].toString())

                                                                    if (igsttot.isNotEmpty()) {
                                                                        igsttotArraydup.add(igsttot)

                                                                    } else {
                                                                        igsttotArraydup.add("0.0")
                                                                    }

                                                                    var cesstotal = (dd["cesstot"].toString())

                                                                    if (cesstotal.isNotEmpty()) {
                                                                        cesstotalArraydup.add(cesstotal)

                                                                    } else {
                                                                        cesstotalArraydup.add("0.0")
                                                                    }
                                                                    tallyArraydup.add("InComplete")

                                                                    receivedArraydup.add("")
                                                                    try {
                                                                        var im = dd["img1url"].toString()

                                                                        if (im.isNotEmpty()) {

                                                                            imageArraydup.add(im)
                                                                            imli = im
                                                                        } else {
                                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                                        }
                                                                    } catch (e: Exception) {

                                                                    }
                                                                    keyArraydup.add("")

                                                                    d.add(document.id.toString())
                                                                    /*  swipeContainer.setRefreshing(false);*/


                                                                } else {
                                                                    /*swipeContainer.setRefreshing(false);*/


                                                                }

                                                                println("Array of idspro if"+idproArray)
                                                                pronameArray       = pronameArraydup
                                                                hsnArray           = hsnArraydup
                                                                manufacturerArray  = manufacturerArraydup
                                                                barcodeArray       = barcodeArraydup
                                                                quantityArray      = quantityArraydup
                                                                priceArray         = priceArraydup
                                                                totArray           = totArraydup
                                                                grosstotArray           = grosstotArraydup

                                                                cessArray          = cessArraydup
                                                                imageArray         = imageArraydup
                                                                igstArray         = igstArraydup
                                                                cgstArray         = cgstArraydup
                                                                sgstArray         = sgstArraydup
                                                                igsttotArray         = igsttotArraydup
                                                                cesstotalArray         = cesstotalArraydup
                                                                receivedArray = receivedArraydup
                                                                tallyArray = tallyArraydup
                                                                keyArray=keyArraydup
                                                                idproArray=idproArraydup
                                                                nores.visibility=View.GONE
                                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                                pur_product_list.adapter = whatever
                                                            }
                                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                                            {


                                                               nores.visibility=View.INVISIBLE
                                                                println("Array of idspro else if"+idproArray)

                                                                pur_product_list.visibility = View.INVISIBLE
                                                                progressBar3.visibility = View.GONE
                                                                already.setText("You have already added all $supnm products")
                                                                already.visibility = View.VISIBLE

                                                            }

                                                            progressBar3.visibility = View.GONE
                                                        }
                                                    }
                                                    else{

                                                        println("PRICE ELSE")

                                                        if(searchedit.text.toString().isNotEmpty()){
                                                            nores.visibility=View.VISIBLE
                                                        }
                                                        progressBar3.visibility = View.GONE

                                                    }
                                                })


                                    }
                                })

                    }
                    else if((des.length >= 3) && (x != reg)&&(spinner.selectedItemPosition==1)){
                        nores.visibility = View.GONE

                        db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                                    var  pronameArraydup       = arrayListOf<String>()
                                    var  hsnArraydup           = arrayListOf<String>()
                                    var  manufacturerArraydup  = arrayListOf<String>()

                                    var  barcodeArraydup       = arrayListOf<String>()
                                    var  quantityArraydup      = arrayListOf<String>()
                                    var  priceArraydup         = arrayListOf<String>()
                                    var  totArraydup           = arrayListOf<String>()
                                    var  grosstotArraydup      = arrayListOf<String>()

                                    var  cessArraydup          = arrayListOf<String>()
                                    var  imageArraydup         = arrayListOf<String>()
                                    var  igstArraydup          = arrayListOf<String>()
                                    var  cgstArraydup          = arrayListOf<String>()

                                    var  sgstArraydup          = arrayListOf<String>()
                                    var  igsttotArraydup         = arrayListOf<String>()
                                    var  cesstotalArraydup         = arrayListOf<String>()

                                    var receivedArraydup = arrayListOf<String>()
                                    var tallyArraydup = arrayListOf<String>()
                                    var keyArraydup=arrayListOf<String>()
                                    var idproArraydup=arrayListOf<String>()
                                    var icohighArray = arrayOf<String>()
                                    var icohighnmArray = arrayOf<String>()






                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                            val dd = document.data


                                            var kk=document.id

                                            if(!idproArrayori.contains(kk)) {



                                                spinner.visibility=View.VISIBLE
                                                pur_product_list.visibility = View.VISIBLE
                                                progressBar3.visibility = View.GONE
                                                textView52.visibility=View.INVISIBLE
                                                already.visibility = View.GONE
                                                idproArraydup.add(document.id)
                                                nores.visibility = View.GONE


                                                var statuss = dd["status"].toString()



                                                if (statuss == "Active"){



                                                    var prnm = (dd["p_nm"].toString())

                                                    var wgvols=(dd["wg_vol"].toString())
                                                    var uts=(dd["ut"].toString())

                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                    }

                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                        prnm=prnm
                                                    }
                                                    else{
                                                        prnm=prnm
                                                    }

                                                    if (prnm.isNotEmpty()) {

                                                        pronameArraydup.add(prnm)
                                                    } else {
                                                        pronameArraydup.add("No title")
                                                    }

                                                    val high = dd["img1urlhigh"].toString()
                                                    val highnm = dd["img1nhigh"].toString()
                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                    icohighArray=icohighArray.plusElement(high)


                                                    var manu = (dd["mfr"].toString())

                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                        manufacturerArraydup.add(manu)

                                                    } else if(manu=="Select") {
                                                        manufacturerArraydup.add("MFR - Not Available")
                                                    }

                                                    var hsn = (dd["hsn"].toString())

                                                    if (hsn.isNotEmpty()) {
                                                        hsnArraydup.add(hsn)

                                                    } else {
                                                        hsnArraydup.add("0")
                                                    }

                                                    quantityArraydup.add("1")




                                                    priceArraydup.add(dd["price"].toString())

                                                    var tot = (dd["price"].toString())

                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                        totArraydup.add(tot)

                                                    }
                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                        totArraydup.add(tot+".00")
                                                    }
                                                    else {
                                                        totArraydup.add("0.0")
                                                    }

                                                    var totgro = (dd["mrp"].toString())

                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                        grosstotArraydup.add(totgro)

                                                    }
                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                        grosstotArraydup.add(totgro+".00")
                                                    }
                                                    else {
                                                        grosstotArraydup.add("0.0")
                                                    }







                                                    var bc = (dd["bc"].toString())

                                                    if (bc.isNotEmpty()) {
                                                        barcodeArraydup.add(bc)

                                                    } else {
                                                        barcodeArraydup.add("Not Available")
                                                    }

                                                    var cessarr = (dd["cess"].toString())

                                                    if (cessarr.isNotEmpty()) {
                                                        cessArraydup.add(cessarr)

                                                    } else {
                                                        cessArraydup.add("0.0")
                                                    }

                                                    var igst = (dd["igst"].toString())
                                                    if (igst.isNotEmpty()) {
                                                        igstArraydup.add(igst)

                                                    } else {
                                                        igstArraydup.add("0.0")
                                                    }

                                                    var cgst = (dd["cgst"].toString())

                                                    if (cgst.isNotEmpty()) {
                                                        cgstArraydup.add(cgst)

                                                    } else {
                                                        cgstArraydup.add("0.0")
                                                    }

                                                    var sgst = (dd["sgst"].toString())

                                                    if (sgst.isNotEmpty()) {
                                                        sgstArraydup.add(sgst)

                                                    } else {
                                                        sgstArraydup.add("0.0")
                                                    }

                                                    var igsttot = (dd["taxtot"].toString())

                                                    if (igsttot.isNotEmpty()) {
                                                        igsttotArraydup.add(igsttot)

                                                    } else {
                                                        igsttotArraydup.add("0.0")
                                                    }

                                                    var cesstotal = (dd["cesstot"].toString())

                                                    if (cesstotal.isNotEmpty()) {
                                                        cesstotalArraydup.add(cesstotal)

                                                    } else {
                                                        cesstotalArraydup.add("0.0")
                                                    }
                                                    tallyArraydup.add("InComplete")

                                                    receivedArraydup.add("")
                                                    try {
                                                        var im = dd["img1url"].toString()

                                                        if (im.isNotEmpty()) {

                                                            imageArraydup.add(im)
                                                            imli = im
                                                        } else {
                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                        }
                                                    } catch (e: Exception) {

                                                    }
                                                    keyArraydup.add("")

                                                    d.add(document.id.toString())
                                                    /*  swipeContainer.setRefreshing(false);*/


                                                } else {
                                                    /*swipeContainer.setRefreshing(false);*/


                                                }

                                                println("Array of idspro if"+idproArray)
                                                pronameArray       = pronameArraydup
                                                hsnArray           = hsnArraydup
                                                manufacturerArray  = manufacturerArraydup
                                                barcodeArray       = barcodeArraydup
                                                quantityArray      = quantityArraydup
                                                priceArray         = priceArraydup
                                                totArray           = totArraydup
                                                grosstotArray           = grosstotArraydup

                                                cessArray          = cessArraydup
                                                imageArray         = imageArraydup
                                                igstArray         = igstArraydup
                                                cgstArray         = cgstArraydup
                                                sgstArray         = sgstArraydup
                                                igsttotArray         = igsttotArraydup
                                                cesstotalArray         = cesstotalArraydup
                                                receivedArray = receivedArraydup
                                                tallyArray = tallyArraydup
                                                keyArray=keyArraydup
                                                idproArray=idproArraydup
                                                nores.visibility=View.GONE
                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                pur_product_list.adapter = whatever
                                            }
                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                            {



                                                println("Array of idspro else if"+idproArray)
                                               nores.visibility=View.INVISIBLE
                                                pur_product_list.visibility = View.INVISIBLE
                                                progressBar3.visibility = View.GONE
                                                already.setText("You have already added all $supnm products")
                                                already.visibility = View.VISIBLE
                                                nores.visibility = View.GONE
                                            }

                                            progressBar3.visibility = View.GONE
                                        }
                                    }
                                    else{
                                        nores.visibility = View.GONE

                                        db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->








                                                    if (e != null) {
                                                    }
                                                    if (value.isEmpty == false) {
                                                        for (document in value) {

                                                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                            val dd = document.data


                                                            var kk=document.id

                                                            if(!idproArrayori.contains(kk)) {



                                                                spinner.visibility=View.VISIBLE
                                                                pur_product_list.visibility = View.VISIBLE
                                                                progressBar3.visibility = View.GONE
                                                                textView52.visibility=View.INVISIBLE
                                                                already.visibility = View.GONE
                                                                idproArraydup.add(document.id)
                                                                nores.visibility = View.GONE


                                                                var statuss = dd["status"].toString()


                                                                if (statuss == "Active"){



                                                                    var prnm = (dd["p_nm"].toString())

                                                                    var wgvols=(dd["wg_vol"].toString())
                                                                    var uts=(dd["ut"].toString())

                                                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                        prnm=prnm+" - "+wgvols+" "+uts
                                                                    }

                                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                                                        prnm=prnm
                                                                    }
                                                                    else{
                                                                        prnm=prnm
                                                                    }

                                                                    if (prnm.isNotEmpty()) {

                                                                        pronameArraydup.add(prnm)
                                                                    } else {
                                                                        pronameArraydup.add("No title")
                                                                    }

                                                                    val high = dd["img1urlhigh"].toString()
                                                                    val highnm = dd["img1nhigh"].toString()
                                                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                                                    icohighArray=icohighArray.plusElement(high)


                                                                    var manu = (dd["mfr"].toString())

                                                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                                                        manufacturerArraydup.add(manu)

                                                                    } else if(manu=="Select") {
                                                                        manufacturerArraydup.add("MFR - Not Available")
                                                                    }

                                                                    var hsn = (dd["hsn"].toString())

                                                                    if (hsn.isNotEmpty()) {
                                                                        hsnArraydup.add(hsn)

                                                                    } else {
                                                                        hsnArraydup.add("0")
                                                                    }

                                                                    quantityArraydup.add("1")




                                                                    priceArraydup.add(dd["price"].toString())

                                                                    var tot = (dd["price"].toString())

                                                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                                                        totArraydup.add(tot)

                                                                    }
                                                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                                                        totArraydup.add(tot+".00")
                                                                    }
                                                                    else {
                                                                        totArraydup.add("0.0")
                                                                    }

                                                                    var totgro = (dd["mrp"].toString())

                                                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                                                        grosstotArraydup.add(totgro)

                                                                    }
                                                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                                                        grosstotArraydup.add(totgro+".00")
                                                                    }
                                                                    else {
                                                                        grosstotArraydup.add("0.0")
                                                                    }







                                                                    var bc = (dd["bc"].toString())

                                                                    if (bc.isNotEmpty()) {
                                                                        barcodeArraydup.add(bc)

                                                                    } else {
                                                                        barcodeArraydup.add("Not Available")
                                                                    }

                                                                    var cessarr = (dd["cess"].toString())

                                                                    if (cessarr.isNotEmpty()) {
                                                                        cessArraydup.add(cessarr)

                                                                    } else {
                                                                        cessArraydup.add("0.0")
                                                                    }

                                                                    var igst = (dd["igst"].toString())
                                                                    if (igst.isNotEmpty()) {
                                                                        igstArraydup.add(igst)

                                                                    } else {
                                                                        igstArraydup.add("0.0")
                                                                    }

                                                                    var cgst = (dd["cgst"].toString())

                                                                    if (cgst.isNotEmpty()) {
                                                                        cgstArraydup.add(cgst)

                                                                    } else {
                                                                        cgstArraydup.add("0.0")
                                                                    }

                                                                    var sgst = (dd["sgst"].toString())

                                                                    if (sgst.isNotEmpty()) {
                                                                        sgstArraydup.add(sgst)

                                                                    } else {
                                                                        sgstArraydup.add("0.0")
                                                                    }

                                                                    var igsttot = (dd["taxtot"].toString())

                                                                    if (igsttot.isNotEmpty()) {
                                                                        igsttotArraydup.add(igsttot)

                                                                    } else {
                                                                        igsttotArraydup.add("0.0")
                                                                    }

                                                                    var cesstotal = (dd["cesstot"].toString())

                                                                    if (cesstotal.isNotEmpty()) {
                                                                        cesstotalArraydup.add(cesstotal)

                                                                    } else {
                                                                        cesstotalArraydup.add("0.0")
                                                                    }
                                                                    tallyArraydup.add("InComplete")

                                                                    receivedArraydup.add("")
                                                                    try {
                                                                        var im = dd["img1url"].toString()

                                                                        if (im.isNotEmpty()) {

                                                                            imageArraydup.add(im)
                                                                            imli = im
                                                                        } else {
                                                                            imageArraydup.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                                                        }
                                                                    } catch (e: Exception) {

                                                                    }
                                                                    keyArraydup.add("")

                                                                    d.add(document.id.toString())
                                                                    /*  swipeContainer.setRefreshing(false);*/


                                                                } else {
                                                                    /*swipeContainer.setRefreshing(false);*/


                                                                }

                                                                println("Array of idspro if"+idproArray)
                                                                pronameArray       = pronameArraydup
                                                                hsnArray           = hsnArraydup
                                                                manufacturerArray  = manufacturerArraydup
                                                                barcodeArray       = barcodeArraydup
                                                                quantityArray      = quantityArraydup
                                                                priceArray         = priceArraydup
                                                                totArray           = totArraydup
                                                                grosstotArray           = grosstotArraydup

                                                                cessArray          = cessArraydup
                                                                imageArray         = imageArraydup
                                                                igstArray         = igstArraydup
                                                                cgstArray         = cgstArraydup
                                                                sgstArray         = sgstArraydup
                                                                igsttotArray         = igsttotArraydup
                                                                cesstotalArray         = cesstotalArraydup
                                                                receivedArray = receivedArraydup
                                                                tallyArray = tallyArraydup
                                                                keyArray=keyArraydup
                                                                idproArray=idproArraydup
                                                                nores.visibility=View.GONE
                                                                val whatever = product_list_adap_pur(this@product_request_add, pronameArraydup, manufacturerArraydup, hsnArraydup, barcodeArraydup, quantityArraydup,
                                                                        priceArraydup, totArraydup, cessArraydup,keyArraydup,igstArraydup,cgstArraydup,sgstArraydup, igsttotArraydup, cesstotalArraydup,
                                                                        tallyArraydup, receivedArraydup, imageArraydup,icohighnmArray,icohighArray)
                                                                pur_product_list.adapter = whatever
                                                            }
                                                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                                                            {



                                                                println("Array of idspro else if"+idproArray)
                                                               nores.visibility=View.INVISIBLE
                                                                pur_product_list.visibility = View.INVISIBLE
                                                                progressBar3.visibility = View.GONE
                                                                already.setText("You have already added all $supnm products")
                                                                already.visibility = View.VISIBLE
                                                                nores.visibility = View.GONE
                                                            }

                                                            progressBar3.visibility = View.GONE
                                                        }
                                                    }
                                                    else{

                                                        if(searchedit.text.toString().isNotEmpty()){
                                                            nores.visibility=View.VISIBLE
                                                        }

                                                        progressBar3.visibility = View.GONE


                                                    }
                                                })

                                    }
                                })

                    }
                }




                if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }
















                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub

                nores.visibility = View.GONE
            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {

                    progressBar3.visibility=View.GONE
                    spinner.visibility=View.VISIBLE

                   nores.visibility=View.INVISIBLE
                    if(spinner.selectedItemPosition==0){
                        get()
                    }
                    else if(spinner.selectedItemPosition==1){
                        gets()
                    }

                }
            }
        })





    }

    fun get() {

        ///-----------------------Get supplier's products from db----------------------------------//




        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        nores.visibility = View.GONE
        progressBar3.visibility = View.VISIBLE
        db.collection("product").whereEqualTo("supp_key",supplieridfr)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                    var  pronameArraydup       = arrayListOf<String>()
                    var  hsnArraydup           = arrayListOf<String>()
                    var  manufacturerArraydup  = arrayListOf<String>()

                    var  barcodeArraydup       = arrayListOf<String>()
                    var  quantityArraydup      = arrayListOf<String>()
                    var  priceArraydup         = arrayListOf<String>()
                    var  totArraydup           = arrayListOf<String>()
                    var  grosstotArraydup      = arrayListOf<String>()

                    var  cessArraydup          = arrayListOf<String>()
                    var  imageArraydup         = arrayListOf<String>()
                    var  igstArraydup          = arrayListOf<String>()
                    var  cgstArraydup          = arrayListOf<String>()

                    var  sgstArraydup          = arrayListOf<String>()
                    var  igsttotArraydup         = arrayListOf<String>()
                    var  cesstotalArraydup         = arrayListOf<String>()

                    var receivedArraydup = arrayListOf<String>()
                    var tallyArraydup = arrayListOf<String>()
                    var keyArraydup=arrayListOf<String>()
                    var idproArraydup=arrayListOf<String>()
                    var icohighArray = arrayOf<String>()
                    var icohighnmArray = arrayOf<String>()



                    pronameArray       = pronameArraydup
                    hsnArray           = hsnArraydup
                    manufacturerArray  = manufacturerArraydup
                    barcodeArray       = barcodeArraydup
                    quantityArray      = quantityArraydup
                    priceArray         = priceArraydup
                    totArray           = totArraydup
                    grosstotArray           = grosstotArraydup

                    cessArray          = cessArraydup
                    imageArray         = imageArraydup
                    igstArray         = igstArraydup
                    cgstArray         = cgstArraydup
                    sgstArray         = sgstArraydup
                    igsttotArray         = igsttotArraydup
                    cesstotalArray         = cesstotalArraydup
                    receivedArray = receivedArraydup
                    tallyArray = tallyArraydup
                    keyArray=keyArraydup
                    idproArray=idproArraydup


                    if (e != null) {
                    }
                    if (value.isEmpty == false) {
                        for (document in value) {

                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                            val dd = document.data


                            var kk=document.id

                            if(!idproArrayori.contains(kk)) {



                                spinner.visibility=View.VISIBLE
                               nores.visibility=View.INVISIBLE

                                pur_product_list.visibility = View.VISIBLE
                                progressBar3.visibility = View.GONE
                                textView52.visibility=View.INVISIBLE
                                already.visibility = View.GONE
                                idproArray.add(document.id)



                                var statuss = dd["status"].toString()

                                if (statuss == "Active") {



                                    var prnm = (dd["p_nm"].toString())

                                    var wgvols=(dd["wg_vol"].toString())
                                    var uts=(dd["ut"].toString())

                                    if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                        prnm=prnm+" - "+wgvols+" "+uts
                                    }

                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts!="Select")){
                                        prnm=prnm
                                    }
                                    else if((wgvols.isNotEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                        prnm=prnm
                                    }
                                    else if((wgvols.isEmpty())&&(uts.isNotEmpty()&&uts=="Select")){
                                        prnm=prnm
                                    }
                                    else{
                                        prnm=prnm
                                    }

                                    if (prnm.isNotEmpty()) {

                                        pronameArray.add(prnm)
                                    } else {
                                        pronameArray.add("No title")
                                    }

                                    val high = dd["img1urlhigh"].toString()
                                    val highnm = dd["img1nhigh"].toString()
                                    icohighnmArray=icohighnmArray.plusElement(highnm)
                                    icohighArray=icohighArray.plusElement(high)


                                    var manu = (dd["mfr"].toString())

                                    if ((manu.isNotEmpty())&&(manu!="Select")) {
                                        manufacturerArray.add(manu)

                                    } else if(manu=="Select") {
                                        manufacturerArray.add("MFR - Not Available")
                                    }

                                    var hsn = (dd["hsn"].toString())

                                    if (hsn.isNotEmpty()) {
                                        hsnArray.add(hsn)

                                    } else {
                                        hsnArray.add("0")
                                    }

                                    quantityArray.add("1")




                                    priceArray.add(dd["price"].toString())

                                    var tot = (dd["price"].toString())

                                    if ((tot.isNotEmpty())&&(tot.contains("."))) {
                                        totArray.add(tot)

                                    }
                                    else if((tot.isNotEmpty())&&(!tot.contains("."))){
                                        totArray.add(tot+".00")
                                    }
                                    else {
                                        totArray.add("0.0")
                                    }

                                    var totgro = (dd["mrp"].toString())

                                    if ((totgro.isNotEmpty())&&(totgro.contains("."))) {
                                        grosstotArray.add(totgro)

                                    }
                                    else if((totgro.isNotEmpty())&&(!totgro.contains("."))){
                                        grosstotArray.add(totgro+".00")
                                    }
                                    else {
                                        grosstotArray.add("0.0")
                                    }







                                    var bc = (dd["bc"].toString())

                                    if (bc.isNotEmpty()) {
                                        barcodeArray.add(bc)

                                    } else {
                                        barcodeArray.add("Not Available")
                                    }

                                    var cessarr = (dd["cess"].toString())

                                    if (cessarr.isNotEmpty()) {
                                        cessArray.add(cessarr)

                                    } else {
                                        cessArray.add("0.0")
                                    }

                                    var igst = (dd["igst"].toString())
                                    if (igst.isNotEmpty()) {
                                        igstArray.add(igst)

                                    } else {
                                        igstArray.add("0.0")
                                    }

                                    var cgst = (dd["cgst"].toString())

                                    if (cgst.isNotEmpty()) {
                                        cgstArray.add(cgst)

                                    } else {
                                        cgstArray.add("0.0")
                                    }

                                    var sgst = (dd["sgst"].toString())

                                    if (sgst.isNotEmpty()) {
                                        sgstArray.add(sgst)

                                    } else {
                                        sgstArray.add("0.0")
                                    }

                                    var igsttot = (dd["taxtot"].toString())

                                    if (igsttot.isNotEmpty()) {
                                        igsttotArray.add(igsttot)

                                    } else {
                                        igsttotArray.add("0.0")
                                    }

                                    var cesstotal = (dd["cesstot"].toString())

                                    if (cesstotal.isNotEmpty()) {
                                        cesstotalArray.add(cesstotal)

                                    } else {
                                        cesstotalArray.add("0.0")
                                    }
                                    tallyArray.add("InComplete")

                                    receivedArray.add("")
                                    try {
                                        var im = dd["img1url"].toString()

                                        if (im.isNotEmpty()) {

                                            imageArray.add(im)
                                            imli = im
                                        } else {
                                            imageArray.add("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                                            imli = "https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063"
                                        }
                                    } catch (e: Exception) {

                                    }
                                    keyArray.add("")

                                    d.add(document.id.toString())
                                    /*  swipeContainer.setRefreshing(false);*/

                                    pDialog.dismiss()
                                } else {
                                    /*swipeContainer.setRefreshing(false);*/

                                    pDialog.dismiss()
                                }

                                println("Array of idspro if"+idproArray)
                            }
                            else if(idproArrayori.contains(kk)&&idproArray.isEmpty())
                            {



                                println("Array of idspro else if"+idproArray)
                                pDialog.dismiss()
                                pur_product_list.visibility = View.INVISIBLE
                                progressBar3.visibility = View.GONE
                                already.setText("You have already added all $supnm products")
                                already.visibility = View.VISIBLE
                               nores.visibility=View.INVISIBLE
                            }

                            nores.visibility=View.GONE
                            val whatever = product_list_adap_pur(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                                    priceArray, totArray, cessArray,keyArray,igstArray,cgstArray,sgstArray, igsttotArray, cesstotalArray,
                                    tallyArray, receivedArray, imageArray,icohighnmArray,icohighArray)
                            pur_product_list.adapter = whatever
                            progressBar3.visibility = View.GONE
                        }
                    }
                    else{
                        pDialog.dismiss()

                        textView52.visibility=View.VISIBLE
                        pur_product_list.visibility=View.INVISIBLE
                        progressBar3.visibility = View.GONE

                    }
                })


        println("AZ"+pronameArray)




    }

    override fun onBackPressed() {


        if (cardsearch.visibility == View.VISIBLE) {

            cardsearch.visibility = View.GONE
            nores.visibility=View.INVISIBLE
            pur_product_list.visibility=View.VISIBLE
            progressBar3.visibility=View.GONE
            searchedit.setText("")
            get()


        }
        else {
            val b = Intent(applicationContext, RequestBottproActivity::class.java)
                    .putStringArrayListExtra("dlt", dlt)
            println(pronameArrayori)
            println(priceArrayori)

            b.putExtra("from_req", "req_list")
            b.putExtra("req_pname", pronameArrayori)
            b.putExtra("req_pitem", manufacturerArrayori)
            b.putExtra("req_phsn", hsnArrayori)
            b.putExtra("req_porder", quantityArrayori)

            b.putExtra("req_pprice", priceArrayori)
            b.putExtra("req_ptot", totArrayori)
            b.putExtra("req_pgrosstot", grosstotArrayori)

            b.putExtra("req_poarray", barcodeArrayori)
            b.putExtra("req_cessarray", cessArrayori)
            b.putExtra("req_igstarray", igstArrayori)
            b.putExtra("req_cgstarray", cgstArrayori)
            b.putExtra("req_sgstarray", sgstArrayori)
            b.putExtra("req_igsttotarray", igsttotArrayori)
            b.putExtra("req_cesstotalarray", cesstotalArrayori)
            b.putExtra("req_tallyarray", tallyArrayori)
            b.putExtra("req_receivedarray", receivedArrayori)
            b.putExtra("req_reiddofli", keyArrayori)
            b.putExtra("req_id", reqid)
            b.putExtra("req_liid", liid)
            b.putExtra("req_prnms", prdnms)
            b.putExtra("req_date", reqdt)
            b.putExtra("req_name", reqnm)
            b.putExtra("req_mail", reqmail)
            b.putExtra("req_esti", restimt)
            b.putExtra("edclick", edclick)
            b.putExtra("incompstr", incompstr)
            b.putExtra("deletelistener", deletelistener)

            b.putExtra("request_datedup", request_datedup)
            b.putExtra("reqest_datedup", reqest_datedup)
            b.putExtra("supp_namedup", supp_namedup)
            b.putExtra("supp_gstdup", supp_gstdup)
            b.putExtra("supp_addredup", supp_addredup)
            b.putExtra("befnm", befnm)
            b.putExtra("supplieridfr", supplieridfr)

            b.putExtra("req_supnm", supnm)
            b.putExtra("req_supadd1", supadd1)
            b.putExtra("req_supadd2", supadd2)
            b.putExtra("req_supadd3", supadd3)
            b.putExtra("req_supgst", supgst)
            b.putExtra("req_supcity", supcity)
            b.putExtra("req_supstate", supstate)
            b.putExtra("req_supph", supph)
            b.putExtra("req_imi", imageArrayori)
            b.putExtra("status", status)
            b.putExtra("groschk", grosschk)
            b.putExtra("brkys", keysbr)
            b.putExtra("imlinks", imglinkss)
            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)
            b.putExtra("idpro", idproArrayori)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)

            b.putExtra("ids", ids)


            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)








            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
            finish()
        }
    }

    fun net_status():Boolean{  ////Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
